#ifndef MAIN_H
#define MAIN_H



#define ENABLE_WATCHDOG
//#define TEST_GAS_1
//#define TEST_GAS_5
/////////////////////////////////////////////////////////////////////
#define AL_O3_ADDRESS              0x62
#define AL_NO2_ADDRESS             0x63
#define AL_CO_ADDRESS              0x64
#define AL_SO2_ADDRESS             0x66
#define DD7_NH3_ADDRESS            0x67
#define AL_H2S_ADDRESS             0x68
#define PIDAY5_VOC_ADDRESS         0x74
#define IRMAT_CH4_ADDRESS          0x78
/*
If there is O3, NO2 must be placed in GAS_1_ADDRESS and O3 in GAS_2_ADDRESS 
for the O3 to obtain the correct concentration value.
*/
#define GAS_1_ADDRESS             AL_O3_ADDRESS
#define GAS_2_ADDRESS             AL_NO2_ADDRESS
#define GAS_3_ADDRESS             AL_CO_ADDRESS
#define GAS_4_ADDRESS             DD7_NH3_ADDRESS
//#define GAS_5_ADDRESS             AL_SO2_ADDRESS
#define GAS_5_ADDRESS             PIDAY5_VOC_ADDRESS
//#define GAS_6_ADDRESS             AL_H2S_ADDRESS
/////////////////////////////////////////////////////////////////////
#define SHT3X
#define OUTDOOR_SHT2X
#define EPA500_GASES
//#define SHT2X
//#define SENSEAIR_S8
//#define AECL_CO_001M
//#define PANASONIC_GCHA1
//#define SENSIRION_SGPC10
//#define SENSIRION_SGP30
//#define SENSIRION_SDP3X
//#define ONEAIR_A4
//#define AECL_MULTIGASES
//#define gas sensor type
//#define SPEC_CO
//#define GS4CO
//#define SPEC_O3
//#define GS4NO2
//#define SPEC_NO2
//#define SPEC_SO2
//#define GS4NH3100
//#define Noise
//#define ALPHA_O3
//#define ALPHA_NO2
//#define ALPHA_SO2
//#define GS7NH3
//#define AL_H2S_B

// 0x51 SPEC CO
// 0x52 GS4CO
// 0x60 GS4NH3100// 0x52 GS4CO 
// 0x53 SPEC O3
// 0x54 GS4NO2
// 0x55 SPEC NO2
// 0x56 SPEC SO2
// 0x62 ALPHA_O3
// 0x63 ALPHA_NO2
// 0x64 ALPHA_CO
// 0x66 ALPHA_SO2
// 0x67 GS7NH3
// 0x68 AL_H2S_B  //Sample and Korea is0x70

//#define PLANTOWER_PM25
//////// end of gases sensor define//////////////////////////////////


/////////////////////////////////////////////////////////////////////
// data logging define
//#define EUSCI_A0_UART_LOGGING
#define MODBUS_SLAVE
//////// end of RF MODULE define//////////////////////////////////

#endif