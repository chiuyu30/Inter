/*******************************************************************************
*
*   EPA500_Gas_SB Main 
*   
*   IAR EW430 V7.2
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/06/23
*
*
*********************************************************************************/
#include "include.h"
#include "string.h"



UINT64 GB_u64gas_3_gas_bsn = 0;
UINT32 GB_u16gas_3_cal_date = 0;
INT32 GB_i32gas_3_cal_b = 0;
INT32 GB_i32gas_3_cal_zero = 0;
float GB_floatgas_3_cal_a = 0;
float GB_floatgas_3_cal_span = 0; 


void main(void)
{
  //Stop WDT
  WDT_A_hold(WDT_A_BASE);
  
  global_Board_status |= SYSTEM_RESTART;   // mark system restart
  
  system_init();
  
  peripheral_init();
  
  sensors_init();
  
  task_timer_init();

  __bis_SR_register(GIE);  // Enable global interrupt
////  AL_O3_ADDRESS 
//  write_and_read_gas_bsn(GAS_1_ADDRESS, 6231335, &GB_u64gas_3_gas_bsn);
//  write_and_read_gas_cal_date(GAS_1_ADDRESS, 241122, &GB_u16gas_3_cal_date);
//  write_and_read_gas_cal_zero(GAS_1_ADDRESS, -15680, &GB_i32gas_3_cal_zero);
//  write_and_read_gas_cal_span(GAS_1_ADDRESS, 1655.5, &GB_floatgas_3_cal_span);
//  write_and_read_gas_cal_a(GAS_1_ADDRESS, 1.0, &GB_floatgas_3_cal_a);
//  write_and_read_gas_cal_b(GAS_1_ADDRESS, 0, &GB_i32gas_3_cal_b);
////  AL_NO2_ADDRESS
//  write_and_read_gas_bsn(GAS_2_ADDRESS, 6350217, &GB_u64gas_3_gas_bsn);
//  write_and_read_gas_cal_date(GAS_2_ADDRESS, 241122, &GB_u16gas_3_cal_date);
//  write_and_read_gas_cal_zero(GAS_2_ADDRESS, 4685, &GB_i32gas_3_cal_zero);
//  write_and_read_gas_cal_span(GAS_2_ADDRESS, 1323.27, &GB_floatgas_3_cal_span);
//  write_and_read_gas_cal_a(GAS_2_ADDRESS, 1.0, &GB_floatgas_3_cal_a);
//  write_and_read_gas_cal_b(GAS_2_ADDRESS, 56, &GB_i32gas_3_cal_b);
//  AL_CO_ADDRESS
//  write_and_read_gas_bsn(GAS_3_ADDRESS, 6451846, &GB_u64gas_3_gas_bsn);
//  write_and_read_gas_cal_date(GAS_3_ADDRESS, 241122, &GB_u16gas_3_cal_date);
//  write_and_read_gas_cal_zero(GAS_3_ADDRESS, -2378, &GB_i32gas_3_cal_zero);
//  write_and_read_gas_cal_span(GAS_3_ADDRESS, -134.6, &GB_floatgas_3_cal_span);
//  write_and_read_gas_cal_a(GAS_3_ADDRESS, 1.0, &GB_floatgas_3_cal_a);
//  write_and_read_gas_cal_b(GAS_3_ADDRESS, 0, &GB_i32gas_3_cal_b);
//  NH3_ADDRESS
//  write_and_read_gas_bsn(GAS_4_ADDRESS, 2408206700452, &GB_u64gas_3_gas_bsn);
//  write_and_read_gas_cal_date(GAS_4_ADDRESS, 240820, &GB_u16gas_3_cal_date);
//  write_and_read_gas_cal_zero(GAS_4_ADDRESS, 12449734, &GB_i32gas_3_cal_zero);
//  write_and_read_gas_cal_span(GAS_4_ADDRESS, -359.86, &GB_floatgas_3_cal_span);
//  write_and_read_gas_cal_a(GAS_4_ADDRESS, 1.0, &GB_floatgas_3_cal_a);
//  write_and_read_gas_cal_b(GAS_4_ADDRESS, 90, &GB_i32gas_3_cal_b);
  
//  write_and_read_gas_bsn(0x67, 2503256712345, &GB_u64gas_3_gas_bsn);
//  write_and_read_gas_cal_date(0x67, 250325, &GB_u16gas_3_cal_date);
//  write_and_read_gas_cal_zero(0x67, 12450000, &GB_i32gas_3_cal_zero);
//  write_and_read_gas_cal_span(0x67, -1000, &GB_floatgas_3_cal_span);
//  write_and_read_gas_cal_a(0x67, 1, &GB_floatgas_3_cal_a);
//  write_and_read_gas_cal_b(0x67, 80, &GB_i32gas_3_cal_b);

//  aeclmg_getSerialId(GAS_4_ADDRESS, &GB_u64gas_3_gas_bsn);


#ifdef ENABLE_WATCHDOG
  // start watchdog timer, 3s expire time with VLOCLK (10KHz)
  WDT_A_initWatchdogTimer(WDT_A_BASE, WDT_A_CLOCKSOURCE_VLOCLK, WDT_A_CLOCKDIVIDER_32K);
  WDT_A_start(WDT_A_BASE);
#endif

  
  while (1)
  {
//    aeclmg_getSerialId(0x67, &GB_u64gas_3_gas_bsn);
    task_run();
  }
}
