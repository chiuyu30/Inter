//******************************************************************************
//  Microcontroller: MSP430F6726
//  32kHz ACLK, 20MHZ SMCLK
//
//  Description: SD24 driver
//
//  Company: Autotronic Enterprise CO., LTD.
//  Department: Production Application Division
//  Author: SY LAU
//  Create Date: 2017/12/2
//  IAR Embedded Workbench Version: 6.30
//*****************************************************************************
#ifndef HAL_SD24_H
#define HAL_SD24_H

void sd24_init();
void sd24_measure();
void sd24_start_conv_single();
void sd24_fill_data_registers();



#endif

