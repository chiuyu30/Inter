/*******************************************************************************
oooooooooooo               .ooooooo.
`888'     `8              d8P'   `YP
 888          'YI.oooo.   d8P          .ooooo.  'YI.oooo.   .oooooo.   .ooooo.
 888oooo8      88'  'd8   Y8P'88bo.   d8'   `8b  88'  'd8  'Y8'   `   d8'   `8b
 888    "      88    88        `Y8b  d888oooo88b 88    88   Y8P'boo. d888oooo88b 
 888       o   88    88  .o     d8P '8'          88    88       '8Y' '8'
o888ooooood8  o88o   88o `Y8oood8P'   "bP88Y8P" o88o   88o `Y8oodP"   "bP88Y8P"
*******************************************************************************/
//******************************************************************************
//  Description: transmit data from UART
//
//  Company: Autotronic Enterprise CO., LTD.
//  Department: Production Application Division
//  Author: SY LAU
//  Create Date: 2016/8/14
//  IAR Embedded Workbench Version: 6.30
//*****************************************************************************
#include "include.h"

#ifdef EUSCI_A0_UART_LOGGING
          
void hal_uart_txrx_init(void) {
  
  //Configure UART pins (UCA0TXD/UCA0SIMO, UCA0RXD/UCA0SOMI)
  GPIO_setAsPeripheralModuleFunctionInputPin(
      GPIO_PORT_P1,
      GPIO_PIN2 + GPIO_PIN3
      );
  
  // Configure UART
  // 57600@20MHz 21,11,34,1
  EUSCI_A_UART_initParam param = {0};
  param.selectClockSource = EUSCI_A_UART_CLOCKSOURCE_SMCLK;
  param.clockPrescalar = 21;
  param.firstModReg = 11;
  param.secondModReg = 34;
  param.parity = EUSCI_A_UART_NO_PARITY;
  param.msborLsbFirst = EUSCI_A_UART_LSB_FIRST;
  param.numberofStopBits = EUSCI_A_UART_ONE_STOP_BIT;
  param.uartMode = EUSCI_A_UART_MODE;
  param.overSampling = EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION;
  
  if(STATUS_FAIL == EUSCI_A_UART_init(EUSCI_A0_BASE, &param))
  {
      return;
  }
  
  //Enable UART module for operation
  EUSCI_A_UART_enable(EUSCI_A0_BASE);
  
//  //Enable Receive Interrupt
//  EUSCI_A_UART_clearInterrupt(EUSCI_A0_BASE,
//                             EUSCI_A_UART_RECEIVE_INTERRUPT);
//  EUSCI_A_UART_enableInterrupt(EUSCI_A0_BASE,
//                              EUSCI_A_UART_RECEIVE_INTERRUPT); 
    
}

void EUSCI_A_UART_transmitBuf(char *pTxBuf, char txLen) {
    for(char i = 0; i < txLen;i++)  
    {     
      if(pTxBuf[i] == 0x00) {
        break;
      }
      EUSCI_A_UART_transmitData(EUSCI_A0_BASE, pTxBuf[i]);
    }
}

#endif