#ifndef ME3487_LCD_H
#define ME3487_LCD_H

#include "system.h"



void lcd_init();   // init LCD register

#define LCD_DISPLAY_P1()      (LCDM7 |= 0x40)
#define LCD_DISPLAY_P2()      (LCDM5 |= 0x40)
#define LCD_DISPLAY_P3()      (LCDM1 |= 0x40)

#define LCD_CLEAR_DISPLAY()\
  do {\
    LCDM1 &= 0x0F;\
    LCDM2 &= 0x00;\
    LCDM3 &= 0x00;\
    LCDM4 &= 0x00;\
    LCDM5 &= 0x00;\
    LCDM6 &= 0x00;\
    LCDM7 &= 0x00;\
    LCDM8 &= 0x00;\
  } while (0)

#define LCD_ALL_ON()\
  do {\
    LCDM1 |= 0x70;\
    LCDM2 |= 0x77;\
    LCDM3 |= 0x77;\
    LCDM4 |= 0x77;\
    LCDM5 |= 0x77;\
    LCDM6 |= 0x77;\
    LCDM7 |= 0x77;\
    LCDM8 |= 0x77;\
  } while (0)

#define LCD_DISPLAY_ERR()\
  do {\
    LCDM6 |= 0x07;\
    LCDM7 |= 0x03;\
    LCDM3 |= 0x02;\
    LCDM4 |= 0x22;\
    LCDM5 |= 0x02;\
  } while (0)

#define LCD_DISPLAY_OVERFLOW()\
  do {\
    LCDM8 |= BIT1;\
    LCDM6 |= BIT1;\
    LCDM3 |= BIT1;\
    LCDM4 |= BIT5;\
  } while (0)

#define LCD_DISPLAY_PPM()\
  do {\
    LCDM3 |= 0x40;\
  } while (0)

#define LCD_DISPLAY_PERCENT()\
  do {\
    LCDM2 |= 0x20;\
  } while (0)

#define LCD_DISPLAY_DEGREE()\
  do {\
    LCDM2 |= 0x10;\
  } while (0)

extern void lcd_display_int(INT16 num);
extern void lcd_display_page(UINT8 pageNum);
extern void Detect_display_noise(void);

#endif
