//******************************************************************************
//  Microcontroller: MSP430F6726
//  32kHz ACLK, 20MHZ SMCLK
//
//  Description: Modbus Slave driver header
//
//  Company: Autotronic Enterprise CO., LTD.
//  Department: Production Application Division
//  Author: SY LAU
//  Create Date: 2017/11/26
//  IAR Embedded Workbench Version: 6.50
//  Revesion History:
//      2017/11/26      Initial rev
//*****************************************************************************

#ifndef MODBUS_RTU_H
#define MODBUS_RTU_H

////////////////////////////////////////////////////////////////////////////////
// variable for modbus slave protocol
////////////////////////////////////////////////////////////////////////////////

#define RS485_DIR_PIN_INIT()\
   do {\
   P8SEL &= ~BIT3;\
   P8DIR |= BIT3;\
   } while(0)     //sensor board V3

    
  
#define RS485_DIR_LOW()         ( P8OUT &= ~BIT3 )  //sensor board V3
#define RS485_DIR_HIGH()        ( P8OUT |= BIT3 )   //sensor board V3
extern UINT8 flag_modbusRequestReceived;


////////////////////////////////////////////////////////////////////////////////
// Define the number of data/info for each sensor
////////////////////////////////////////////////////////////////////////////////
#define MODBUS_SIZE_OF_OUTDOOR_SHT3X_DATA               2
#define MODBUS_SIZE_OF_SHT3X_DATA                       2
#define MODBUS_SIZE_OF_BOARD_STATUS_DATA                1
#define MODBUS_SIZE_OF_GAS_1_DATA                       15
#define MODBUS_SIZE_OF_GAS_2_DATA                       15
#define MODBUS_SIZE_OF_GAS_3_DATA                       15
#define MODBUS_SIZE_OF_GAS_4_DATA                       15
#define MODBUS_SIZE_OF_GAS_5_DATA                       15
#define MODBUS_SIZE_OF_GAS_6_DATA                       15

#define MODBUS_TOTAL_SIZE_OF_DATA_FRAME                 95

#define MODBUS_SIZE_OF_OSHT3X_INFO                      2
#define MODBUS_SIZE_OF_SHT3X_INFO                       2
#define MODBUS_SIZE_OF_BOARD_INFO                       3
#define MODBUS_SIZE_OF_GAS_1_INFO                       10
#define MODBUS_SIZE_OF_GAS_2_INFO                       10
#define MODBUS_SIZE_OF_GAS_3_INFO                       10
#define MODBUS_SIZE_OF_GAS_4_INFO                       10
#define MODBUS_SIZE_OF_GAS_5_INFO                       10
#define MODBUS_SIZE_OF_GAS_6_INFO                       10

#define MODBUS_TOTAL_SIZE_OF_INFO_FRAME                 67

////////////////////////////////////////////////////////////////////////////////
// Define the offseet of data_frame/info_frame for each sensor
////////////////////////////////////////////////////////////////////////////////
#define MODBUS_OFFSET_OUTDOOR_SHT3X_DATA               0
#define MODBUS_OFFSET_SHT3X_DATA                       2
#define MODBUS_OFFSET_BOARD_STATUS_DATA                4
#define MODBUS_OFFSET_GAS_1_DATA                       5
#define MODBUS_OFFSET_GAS_2_DATA                       20
#define MODBUS_OFFSET_GAS_3_DATA                       35
#define MODBUS_OFFSET_GAS_4_DATA                       50
#define MODBUS_OFFSET_GAS_5_DATA                       65
#define MODBUS_OFFSET_GAS_6_DATA                       80

#define MODBUS_OFFSET_OSHT3X_INFO                      0
#define MODBUS_OFFSET_SHT3X_INFO                       2
#define MODBUS_OFFSET_BOARD_INFO                       4
#define MODBUS_OFFSET_GAS_1_INFO                       7
#define MODBUS_OFFSET_GAS_2_INFO                       17
#define MODBUS_OFFSET_GAS_3_INFO                       27
#define MODBUS_OFFSET_GAS_4_INFO                       37
#define MODBUS_OFFSET_GAS_5_INFO                       47
#define MODBUS_OFFSET_GAS_6_INFO                       57
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// Fill in sensor data to modbus register
// INPUT: 
//      data_array: array contain the sensor data
//      offset: offset of the sensor in register map
//      num_of_data: total number of registers of the sensor
// RETURN:
//      0: success
//      -1: data filled larger than total frame length, overflow
////////////////////////////////////////////////////////////////////////////////
INT8 modbus_data_frame_update(INT16 *data_array, UINT8 offset, UINT8 num_of_data);
INT8 modbus_info_frame_update(INT16 *data_array, UINT8 offset, UINT8 num_of_data);


void modbus_reply();
void modbus_init(void);




#endif
