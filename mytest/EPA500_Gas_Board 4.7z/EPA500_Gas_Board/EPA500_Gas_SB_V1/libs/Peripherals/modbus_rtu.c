/*******************************************************************************
oooooooooooo               .ooooooo.
`888'     `8              d8P'   `YP
 888          'YI.oooo.   d8P          .ooooo.  'YI.oooo.   .oooooo.   .ooooo.
 888oooo8      88'  'd8   Y8P'88bo.   d8'   `8b  88'  'd8  'Y8'   `   d8'   `8b
 888    "      88    88        `Y8b  d888oooo88b 88    88   Y8P'boo. d888oooo88b 
 888       o   88    88  .o     d8P '8'          88    88       '8Y' '8'
o888ooooood8  o88o   88o `Y8oood8P'   "bP88Y8P" o88o   88o `Y8oodP"   "bP88Y8P"
*******************************************************************************/
//******************************************************************************
//  Microcontroller: MSP430F6726
//  32kHz ACLK, 20MHZ SMCLK
//
//  Description: Modbus Slave driver
//
//  Company: Autotronic Enterprise CO., LTD.
//  Department: Production Application Division
//  Author: SY LAU
//  Create Date: 2017/11/26
//  IAR Embedded Workbench Version: 6.50
//  Revesion History:
//      2017/11/26      Initial rev
//*****************************************************************************

#include "include.h"

#ifdef MODBUS_SLAVE

UINT8 flag_modbusRequestReceived = 0;

#define SIZE_OF_MODBUS_REQUEST       200
UINT8 modbus_request[SIZE_OF_MODBUS_REQUEST];
UINT8 responseDataCount = 3;    //default error response (3 bytes)
UINT16 modbus_request_length = 8;

UINT16 modbusInterFrameTimeOut = 0;
UINT16 modbusInterCharTimeOut = 0;
UINT8 modbusFrameDelayTimerFired = 0;
static UINT8 remm = 0 ;
UINT8 modbus_RxBuf[16];           //uart receive buffer
UINT8 modbus_rx_bytecount = 0;               //receive byte count
UINT8 dataout[14];

void modbus_init(void);               // initial RS485
void modbus_reply();                    // modbus reply
//void modbus_reply_code03();              // modbus reply function code: 03
void modbus_reply_code04();              // modbus reply function code: 04
//void modbus_reply_code06();              // modbus reply function code: 06

UINT8 crcCheck(UINT8 *puchMsg , UINT16 length);


// Declare modbus data frame and info frame array
static INT16 modbus_data_frame[MODBUS_TOTAL_SIZE_OF_DATA_FRAME];
static INT16 modbus_info_frame[MODBUS_TOTAL_SIZE_OF_INFO_FRAME];

////////////////////////////////////////////////////////////////////////////////
// Fill in sensor data to modbus register
// INPUT: 
//      data_array: array contain the sensor data
//      offset: offset of the sensor in register map
//      num_of_data: total number of registers of the sensor
// RETURN:
//      0: success
//      -1: data filled larger than total frame length, overflow
////////////////////////////////////////////////////////////////////////////////
INT8 modbus_data_frame_update(INT16 *data_array, UINT8 offset, UINT8 num_of_data) {
  if((offset+num_of_data) > MODBUS_TOTAL_SIZE_OF_DATA_FRAME) {  //prevent buffer overflow
    return -1;  // return -1 indicate overflow
  }
  
  // fill in the data
  for(int i=0;i<num_of_data;i++) {
    modbus_data_frame[offset + i] = *(data_array + i);
  }
  return 0;   // return success
}

INT8 modbus_info_frame_update(INT16 *data_array, UINT8 offset, UINT8 num_of_data) {
  if((offset+num_of_data) > MODBUS_TOTAL_SIZE_OF_INFO_FRAME) {  //prevent buffer overflow
    return -1;  // return -1 indicate overflow
  }
  
  // fill in the data
  for(int i=0;i<num_of_data;i++) {
    modbus_info_frame[offset + i] = *(data_array + i);
  }
  return 0;   // return success
}
// init modbus registers
void modbus_init_register() {
  memset(modbus_data_frame,0x00,MODBUS_TOTAL_SIZE_OF_DATA_FRAME);
  memset(modbus_info_frame,0x00,MODBUS_TOTAL_SIZE_OF_INFO_FRAME);
}


//================================RS485 UART===================================
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)   //USCI_A0 RX interrupt service routine
{
  // uint8_t recv;
  switch(__even_in_range(UCA0IV,4))
  {
  case USCI_NONE:break;                       // Vector 0 - no interrupt
  case USCI_UART_UCRXIFG:                     // Vector 2 - RXIFG
    TA2CTL = TASSEL_1 + MC_0 + TACLR;         // ACLK, stop, clear TAR
    modbus_RxBuf[modbus_rx_bytecount] = UCA0RXBUF;
    modbus_rx_bytecount++;
    TA2CCR1 = modbusInterCharTimeOut;    // char delay timer
    TA2CTL = TASSEL_1 + MC_2;         // ACLK, cont
    TA2CCTL1 = CCIE;
    break;
  case USCI_UART_UCTXIFG: break;      // TXIFG
  case USCI_UART_UCSTTIFG: break;     // TTIFG
  case USCI_UART_UCTXCPTIFG: break;   // TXCPTIFG
  default: break;
  }  
}

//==============================================================================
// Timer2 A0 interrupt service routine
#pragma vector=TIMER2_A0_VECTOR
__interrupt void TIMER2_A0_ISR(void)
{
    modbusFrameDelayTimerFired = 1;
    TA2CTL = TASSEL_1 + MC_0 + TACLR;         // ACLK, stop, clear TAR
    TA2CCTL0 &= ~CCIE;                      // enable CCR2 interrupt
}

// Timer2_A1 Interrupt Vector (TAIV) handler
#pragma vector=TIMER2_A1_VECTOR
__interrupt void TIMER2_A1_ISR(void)
{
  switch (__even_in_range(TA2IV, 14))
  {
  case  TA0IV_NONE: break;             // No interrupt
  case  TA0IV_TA0CCR1:                     
    TA2CTL = TASSEL_1 + MC_0 + TACLR;         // ACLK, stop, clear TAR
    TA2CCTL1 &= ~CCIE;                        // disable CCR1 interrupt
    if(modbus_rx_bytecount >= 16) {
      modbus_rx_bytecount = 16;
    }
    for(int i=0;i<modbus_rx_bytecount;i++) modbus_request[i] = modbus_RxBuf[i];
    
    modbus_request_length = modbus_rx_bytecount;
    modbus_rx_bytecount = 0;

    flag_modbusRequestReceived = 1;
    TA2CCR0 = modbusInterFrameTimeOut;    // frame delay timer
    TA2CCTL0 = CCIE;                      // enable CCR2 interrupt
    modbusFrameDelayTimerFired = 0;
    TA2CTL = TASSEL_1 + MC_2;         // ACLK, stop, clear TAR
    modbus_reply(); 
    break;
  case  4: break;                      // Reserved
  case  6: break;                      // Reserved
  case  8: break;                      // Reserved
  case 10: break;                      // Reserved
  case 12: break;                      // Reserved
  case TA0IV_TA0IFG:                   // TA0IFG  
  default: break;
  }
}

void timerA2_init() {    // for S8 timeout
  TA2CTL = TASSEL_1 + MC_0 + TACLR;         // ACLK, stop, clear TAR
}
///////////////////////////////////////////////
// RS485 initialization
//////////////////////////////////////////////
void modbus_init(void)
{  
  // init registers memory, set to zero
  modbus_init_register();
  
  // Setup P2.2 UCA0RXD, P2.3 UCA0TXD
  P1SEL |= BIT2 | BIT3;                   // Set P2.2, P2.3 to non-IO
  P1DIR |= BIT2 | BIT3;                   // Enable UCA0RXD, UCA0TXD
  RS485_DIR_PIN_INIT();
  
  // Setup eUSCI_A0
  UCA0CTLW0 |= UCSWRST;                   // **Put state machine in reset**
  UCA0CTLW0 |= UCSSEL_2;                  // SMCLK
  
  // Baud rate 9600 for 20MHz
  UCA0BRW = 130; 
  UCA0MCTLW = 0x2500 + UCBRF_3 + UCOS16;  // Modln UCBRSx=0xB5, UCBRFx=3, over sampling

  modbusInterCharTimeOut = 75;   // INT((1/9600)*11*32768*2), add 0.5 char interval
  modbusInterFrameTimeOut = 169;   // (1/9600)*11*32768*4.5, add 1 char interval
  
  UCA0CTLW0 &= ~UCSWRST;                  // **Initialize USCI state machine**
  UCA0IE |= UCRXIE;                       // Enable USCI_A0 RX interrupt
  RS485_DIR_LOW();
  
  __delay_cycles(60000);
}

////////////////////////////////////////////////////////////////////////////////
// Modbus reply routine
// INPUT: modbus receive buffer
// Function:
//      -- check address and crc
//      -- call sub-routine based on function code
//      -- send reply on UART
// Caution:
//      this routine runs within ISR
////////////////////////////////////////////////////////////////////////////////
void modbus_reply() {
  UINT8 functionCode = 0;  // invalid function code
  UINT16 responseCRC16;
  
  UINT8 rs485_address = ~(P7IN);
  rs485_address = 12;
  _NOP();
  
  if(modbus_request[0] == rs485_address) //check address
  {
    if(crcCheck(&modbus_request[0],modbus_request_length) == 1)    //check CRC
    {
      functionCode = modbus_request[1]; //read function code
      switch(functionCode) {
        // function code 04, holding registers
      case 4:  
        modbus_reply_code04();
        break;
      default:
        modbus_request[1] += 0x80;   // modbus exception function code (function code + 0x80)
        modbus_request[2] = 0x01;    // unsupported function code
        responseDataCount = 3;       // exception response 3 bytes
        break;
      }
      if(remm == 0 )
      {
        // send response
        responseCRC16 = mCRC16(&modbus_request[0],responseDataCount);
        // fill in crc16
        modbus_request[responseDataCount] = responseCRC16 >> 8;
        modbus_request[responseDataCount+1] = responseCRC16;
        responseDataCount += 2;                     // increment response data count
        RS485_DIR_HIGH();                           // RS485 output direction
        __delay_cycles(100000);                     // wait for pin to get high
        //while(!modbusFrameDelayTimerFired);         // wait for frame delay timeout
        for(UINT8 i=0;i<responseDataCount;i++)
        {
          while (!(UCA0IFG&UCTXIFG));             // USCI_A0 TX buffer ready?
          UCA0TXBUF = modbus_request[i];
        }
        __delay_cycles(100000);
        RS485_DIR_LOW();                            // RS485 input direction 
      } 
      remm = 0;
    }
  }
  for (int i=0;i<SIZE_OF_MODBUS_REQUEST;i++) modbus_request[i] = 0;
}


////////////////////////////////////////////////////////////////////////////////
// Modbus function code:04 reply routine
// Function:
//      -- check starting addr and requested length
//      -- depends on starting addr, copy registers to tx buffer
// Caution:
//      this routine runs within ISR
////////////////////////////////////////////////////////////////////////////////
void modbus_reply_code04() 
{
  UINT16 modbus_04_starting_address = (modbus_request[2] << 8) + modbus_request[3];
  UINT16 modbus_04_qty_registers = (modbus_request[4] << 8) + modbus_request[5];
  // function code 04 request length == 8
  // function code 04, max quantity of registers is 125
  if((modbus_request_length==8) && (modbus_04_qty_registers < 0x7D)) {
    if(modbus_04_starting_address < 256) {   // it is data frame
      if((modbus_04_starting_address + modbus_04_qty_registers) <= MODBUS_TOTAL_SIZE_OF_DATA_FRAME) {  // valid request
        // update status 
#ifdef EPA500_GASES
        modbus_data_frame_update(&global_Board_status, MODBUS_OFFSET_BOARD_STATUS_DATA, MODBUS_SIZE_OF_BOARD_STATUS_DATA);       
        gases_fill_data_registers();
#endif        
        global_Board_status &= ~SYSTEM_RESTART;   // reset system restart
        reset_modbus_req_elapse_counter();
        //=====for test=========================================================
//        for(UINT8 i=0;i<=MODBUS_TOTAL_SIZE_OF_DATA_FRAME;i++){
//          modbus_data_frame[modbus_04_starting_address+i] = 30001+i;
//        }
        //======================================================================
        for(UINT8 i=0;i<modbus_04_qty_registers;i++) {    // fill in data
          modbus_request[3+i*2] = modbus_data_frame[modbus_04_starting_address+i] >> 8;
          modbus_request[4+i*2] = modbus_data_frame[modbus_04_starting_address+i];
        }
        modbus_request[2] = 2 * modbus_04_qty_registers;  // fill in data byte count
        responseDataCount = 3 + modbus_request[2];        // update response data count
      }
      else {  // invalid starting address or number of registers
        modbus_request[1] += 0x80;   // modbus exception function code (function code + 0x80)
        modbus_request[2] = 0x02;    // invalid starting address or number of registers
        responseDataCount = 3;       // exception response 3 bytes
      }
    } // end of data frame fill in
    else {  // starting address > 256, it is info frame
      // shift the starting address
      UINT16 info_start_addr = modbus_04_starting_address-256;
    

      if((info_start_addr + modbus_04_qty_registers) <= MODBUS_TOTAL_SIZE_OF_INFO_FRAME) {  // valid request  
        //=====for test=========================================================
//        for(UINT8 i=0;i<=MODBUS_TOTAL_SIZE_OF_INFO_FRAME;i++){
//          modbus_info_frame[info_start_addr+i] = 30257+i;
//        }
        //======================================================================
//        modbus_info_frame[10]=0x0000;
//        modbus_info_frame[11]=0x0000;
//        modbus_info_frame[12]=0x0000;
//        modbus_info_frame[13]=0x4f33;
//        modbus_info_frame[20]=0x0000;
//        modbus_info_frame[21]=0x0000;
//        modbus_info_frame[22]=0x004e;
//        modbus_info_frame[23]=0x4f32;
//        modbus_info_frame[30]=0x0000;
//        modbus_info_frame[31]=0x0000;
//        modbus_info_frame[32]=0x0000;
//        modbus_info_frame[33]=0x434F;
//        modbus_info_frame[40]=0x0000;
//        modbus_info_frame[41]=0x0000;
//        modbus_info_frame[42]=0x004e;
//        modbus_info_frame[43]=0x4833;
        for(UINT8 i=0;i<modbus_04_qty_registers;i++) {    // fill in data
          modbus_request[3+i*2] = modbus_info_frame[info_start_addr+i] >> 8;
          modbus_request[4+i*2] = modbus_info_frame[info_start_addr+i];
        }
        modbus_request[2] = 2 * modbus_04_qty_registers;  // fill in data byte count
        responseDataCount = 3 + modbus_request[2];        // update response data count
      }
      else {  // invalid starting address or number of registers
        modbus_request[1] += 0x80;
        modbus_request[2] = 0x02;
        responseDataCount = 3;
      }
    }// end of info frame fill in
  }// end of request length check
  else {
    modbus_request[1] += 0x80;
    modbus_request[2] = 0x03;
    responseDataCount = 3;
  }
}
///////////// End of function code 04 reply /////////////////////////////////////


///////////////////////////////////////////////
// CRC check
//////////////////////////////////////////////
UINT8 crcCheck(UINT8 *puchMsg , UINT16 length)	// receive Mast Data input	
{
//  UINT8 *p;
  UINT16 calculateCRC16;
  UINT16 receiveCRC16;

//  p = &modbus_request[0];
  //p = &modbus_s8_requests[0];
  calculateCRC16 = mCRC16(puchMsg, length-2);
  receiveCRC16 = (puchMsg[length-2]<< 8 | puchMsg[length-1]);

  if(calculateCRC16 == receiveCRC16)
      return 1;
  else
      return 0;
}

#endif

