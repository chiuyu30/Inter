#include "include.h"

#ifdef ME3487_DISPLAY

void lcd_init() {
  // Setup LCD_C
  // LCD_FREQ = ACLK/32/4, LCD Mux 4, turn on LCD
  LCDCCTL0 =  LCDDIV_31 | LCDPRE_1 | LCD3MUX | LCDON;
  
  //Charge pump generated internally at 2.96V, external bias (V2-V4) generation
  //Internal reference for charge pump
  LCDCVCTL = LCD2B | LCDCPEN | VLCD_3_44;
  REFCTL0 &= ~REFMSTR;
  
  LCDCPCTL0 = 0xFFFE;                     //Select LCD Segments S1~S15
  LCDCPCTL1 = 0x0000;                     //
}

// LCD Segment Mapping, 3 COM
//            COM3,  COM2,  COM1
// Mapping A:  X,     E,     F
const unsigned char LCD_Num_A[] = 
{ 0x03, 0x00, 0x02, 0x00, 0x01, 0x01, 0x03, 0x00, 0x03, 0x01, };
// Mapping B:  D,     G,     A
const unsigned char LCD_Num_B[] = 
{ 0x05, 0x00, 0x07, 0x07, 0x02, 0x07, 0x07, 0x01, 0x07, 0x07, };
// Mapping C:  X,     C,     B
const unsigned char LCD_Num_C[] = 
{ 0x03, 0x03, 0x01, 0x03, 0x03, 0x02, 0x02, 0x03, 0x03, 0x03, };
  
void lcd_write_num(int digit, int num) {
  switch (digit)  { 
  case 1:
    if (num >= 0) {
      LCDM7 &= ~(0x30);
      LCDM8 &= ~(0x37);
      if (num < 10) {
        LCDM7 |= (LCD_Num_C[num] << 4);
        LCDM8 |= (LCD_Num_A[num] << 4);
        LCDM8 |= (LCD_Num_B[num]);
      }
    }
    // display minus mark
    else { LCDM8 |= BIT1; }
    break;
  case 2:
    if (num >= 0) {
      LCDM6 &= ~(0x07);
      LCDM5 &= ~(0x30);
      LCDM7 &= ~(0x03);
      if (num < 10) {
        LCDM6 |= (LCD_Num_B[num]);
        LCDM5 |= (LCD_Num_C[num] << 4);
        LCDM7 |= (LCD_Num_A[num]);
      }
    }
    // display minus mark
    else { LCDM6 |= BIT1; }
    break;
  case 3:
    if (num >= 0) {
      LCDM1 &= ~(0x30);
      LCDM3 &= ~(0x07);
      LCDM4 &= ~(0x03);
      if (num < 10) {
        LCDM1 |= (LCD_Num_C[num] << 4);
        LCDM3 |= (LCD_Num_B[num]);
        LCDM4 |= (LCD_Num_A[num]);
      }
    }
    // display minus mark
    else { LCDM3 |= BIT1; }
    break;
  case 4:
    if (num >= 0) {
      LCDM3 &= ~(0x30);
      LCDM4 &= ~(0x70);
      LCDM5 &= ~(0x03);
      if (num < 10) {
        LCDM3 |= (LCD_Num_C[num] << 4);
        LCDM4 |= (LCD_Num_B[num] << 4);
        LCDM5 |= (LCD_Num_A[num]);
      }
    }
    // display minus mark
    else { LCDM4 |= BIT5; }
    break;
  default: break;
  }
}
      
void lcd_display_int(INT16  num) {
  UINT8 i;
  LCD_CLEAR_DISPLAY();
  if (num >= 0) {    // display number > 0
    if (num < 9999) {
      i = 4;
      do {
        lcd_write_num(i, num%10);
        num /= 10;
        i--;
      }while(num>0 && i>0);
    }
    else { 
      LCD_DISPLAY_ERR(); //error 
    }
  }
  else {             // display number <0
    if (num > -999) {
      num *= -1;
      i = 4;
      do {
        lcd_write_num(i, num%10);
        num /= 10;
        i--;
      }while(num>0 && i>1);
      lcd_write_num(i, -1);
    }
    else { 
      LCD_DISPLAY_ERR(); //error 
    }
  } 
} 

void lcd_display_page(UINT8 pageNum) {
  switch(pageNum)
  {
  case 0:
    lcd_display_int(display_gas_ppm);            // display co2 ppm
    LCD_DISPLAY_PPM();
  // display PPM
    break;
  case 1:
    if((global_display_temperature < -999) || (global_display_temperature > 9999)) {  // temperature below -9.99 or > 99.99, cannot display
      LCD_DISPLAY_OVERFLOW();
      if(global_display_temperature == -4500) {  // most probably I2C didn't receive anything, display error
        LCD_DISPLAY_ERR();
      }
    }
    else {
      lcd_display_int(global_display_temperature);              // display temp
      LCD_DISPLAY_P2();
      LCD_DISPLAY_DEGREE();
    }
    break;
  case 2:
    if((global_display_relatedHumi < 0) || (global_display_relatedHumi > 10000)) {  // temperature below -9.99 or > 99.99, cannot display
      LCD_DISPLAY_ERR();
    }
    else {
      lcd_display_int(global_display_relatedHumi);              // display humi
      LCD_DISPLAY_P2();
      LCD_DISPLAY_PERCENT();                            // display %
    }    
    break;
  }
}

#endif
  