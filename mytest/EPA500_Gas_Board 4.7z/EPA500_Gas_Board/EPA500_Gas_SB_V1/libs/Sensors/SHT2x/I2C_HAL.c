

//---------- Includes ----------------------------------------------------------
//#include "include.h"
//#include "defs.h"
//#include "driverlib.h"
#include "i2c_hal.h"
extern void Delay_10us (UINT16 nbrOfUs);


//==============================================================================
void I2c_Init(void)
//==============================================================================
{
  SHT_PORT_SEL &= ~(SHT_SCL + SHT_SDA);    // select as GPIO function
    
  SDA_LOW();                // Set port as output for configuration
  SCL_LOW();                // Set port as output for configuration

  SDA_CONF_LOW();           // Set SDA level as low for output mode
  SCL_CONF_LOW();           // Set SCL level as low for output mode

  SDA_HIGH();               // I2C-bus idle mode SDA released (input)
  SCL_HIGH();               // I2C-bus idle mode SCL released (input)
}  

//==============================================================================
void I2c_StartCondition ()
//==============================================================================
{
  SDA_HIGH();
  SCL_HIGH();
  Delay_10us(10);
  SDA_LOW();
  Delay_10us(10);  // hold time start condition (t_HD;STA)
  SCL_LOW();
  Delay_10us(10);
}

//==============================================================================
void I2c_StopCondition ()
//==============================================================================
{
  SDA_LOW();
  SCL_LOW();
  Delay_10us(10);
  SCL_HIGH();
  Delay_10us(10);  // set-up time stop condition (t_SU;STO)
  SDA_HIGH();
  Delay_10us(10);
}

//==============================================================================
UINT8 I2c_WriteByte (UINT8 txByte)
//==============================================================================
{
  UINT8 mask,error=0;
  for (mask=0x80; mask>0; mask>>=1)   //shift bit for masking (8 times)
  { if ((mask & txByte) == 0) SDA_LOW();//masking txByte, write bit to SDA-Line
    else SDA_HIGH();
    Delay_10us(1);             //data set-up time (t_SU;DAT)
    SCL_HIGH();                         //generate clock pulse on SCL
    Delay_10us(5);             //SCL high time (t_HIGH)
    SCL_LOW();
    Delay_10us(1);             //data hold time(t_HD;DAT)
  }
  SDA_HIGH();                           //release SDA-line
  Delay_10us(1);               //data set-up time (t_SU;DAT)
  SCL_HIGH();                           //clk #9 for ack
  Delay_10us(1);               //data set-up time (t_SU;DAT)
  if(SDA_IN==HIGH) error=SHT2X_ACK_ERROR; //check ack from i2c slave
  SCL_LOW();
  Delay_10us(20);              //wait time to see byte package on scope
  return error;                       //return error code
}

//==============================================================================
UINT8 I2c_ReadByte (sht2x_etI2cAck ack)
//==============================================================================
{
  UINT8 mask,rxByte=0;
  SDA_HIGH();                           //release SDA-line
  Delay_10us(1);
  for (mask=0x80; mask>0; mask>>=1)   //shift bit for masking (8 times)
  { SCL_HIGH();                         //start clock on SCL-line
    Delay_10us(1);             //data set-up time (t_SU;DAT)
    Delay_10us(3);             //SCL high time (t_HIGH)
    if (SDA_IN==1) rxByte=(rxByte | mask); //read bit
    SCL_LOW();
    Delay_10us(1);             //data hold time(t_HD;DAT)
  }
  
  //SDA=ack;                            //send acknowledge if necessary
  Delay_10us(1);
  if(ack)
    SDA_HIGH();
  else
    SDA_LOW();
  
  
  Delay_10us(1);               //data set-up time (t_SU;DAT)
  SCL_HIGH();                           //clk #9 for ack
  Delay_10us(5);               //SCL high time (t_HIGH)
  SCL_LOW();
  Delay_10us(1);
  SDA_HIGH();                           //release SDA-line
  Delay_10us(20);              //wait time to see byte package on scope
  return rxByte;                      //return error code
}




