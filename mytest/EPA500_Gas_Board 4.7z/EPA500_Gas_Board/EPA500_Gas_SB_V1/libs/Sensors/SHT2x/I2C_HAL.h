
#include "system.h"
#include "msp430.h"
//#include "include.h"



#ifndef BV
#define BV(n)      (1 << (n))
#endif


#define SHT_SCL  BV(3)
#define SHT_SDA  BV(2)

#define SHT_PORT_IN   P3IN
#define SHT_PORT_OUT  P3OUT
#define SHT_PORT_SEL  P3SEL
#define SHT_PORT_DIR  P3DIR

//SCL
#define SCL_HIGH()    		SHT_PORT_DIR &= ~SHT_SCL 	//do{IO_DIR_PORT_PIN(2, 0, IO_IN);} while(0)    //Input Pull-up mode
#define SCL_LOW()     		do{SHT_PORT_DIR |= SHT_SCL; SHT_PORT_OUT &= ~SHT_SCL;}while(0) 	//do{IO_DIR_PORT_PIN(2, 0, IO_OUT);/* SHT_PORT_OUT &= ~SHT_SCL; */}while(0)
//SDA
#define SDA_HIGH()    		SHT_PORT_DIR &= ~SHT_SDA	//do{IO_DIR_PORT_PIN(2, 1, IO_IN);} while(0)    //Input Pull-up mode
#define SDA_LOW()     		do{SHT_PORT_DIR |= SHT_SDA; SHT_PORT_OUT &= ~SHT_SDA;}while(0)  	//do{IO_DIR_PORT_PIN(2, 1, IO_OUT);/* SHT_PORT_OUT &= ~SHT_SDA; */}while(0)

#define SCL_CONF_LOW()    	SHT_PORT_OUT &= ~SHT_SCL  	//SDA level on output directio
#define SCL_CONF_HIGH()    	SHT_PORT_OUT |= SHT_SCL  	//SDA level on output directio
#define SDA_CONF_LOW()    	SHT_PORT_OUT &= ~SHT_SDA  	//SDA level on output directio
#define SDA_CONF_HIGH()    	SHT_PORT_OUT |= SHT_SDA  	//SDA level on output directio



#define SCL_CONF			((SHT_PORT_OUT&SHT_SCL) >> 3)
#define SDA_CONF			((SHT_PORT_OUT&SHT_SDA) >> 2)

#define SCL_IN				((SHT_PORT_IN&SHT_SCL) >> 3)
#define SDA_IN				((SHT_PORT_IN&SHT_SDA) >> 2)

//---------- Enumerations ------------------------------------------------------
//  I2C level
typedef enum{
  LOW                      = 0,
  HIGH                     = 1,
}etI2cLevel;

// I2C acknowledge
typedef enum{
  SHT2X_ACK                      = 0,
  SHT2X_NO_ACK                   = 1,
}sht2x_etI2cAck;

typedef enum{
  SHT2X_ACK_ERROR                = 0x01,
  SHT2X_TIME_OUT_ERROR           = 0x02,
  SHT2X_CHECKSUM_ERROR           = 0x04,
  SHT2X_UNIT_ERROR               = 0x08
}sht2x_etError;

void I2c_Init(void);
void I2c_StartCondition();
void I2c_StopCondition();
UINT8 I2c_WriteByte(UINT8 txByte);
UINT8 I2c_ReadByte(sht2x_etI2cAck ack);
