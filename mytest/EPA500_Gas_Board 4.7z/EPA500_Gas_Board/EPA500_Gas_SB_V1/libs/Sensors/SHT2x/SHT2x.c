//==============================================================================
//    S E N S I R I O N   AG,  Laubisruetistr. 50, CH-8712 Staefa, Switzerland
//==============================================================================
// Project   :  SHT2x Sample Code (V1.2)
// File      :  SHT2x.c
// Author    :  MST
// Controller:  NEC V850/SG3 (uPD70F3740)
// Compiler  :  IAR compiler for V850 (3.50A)
// Brief     :  Sensor layer. Functions for sensor access
//==============================================================================


//---------- Includes ----------------------------------------------------------

#include "include.h"
//#include "SHT2x.h"
#include "I2C_HAL.h"
//#include "system.h"

UINT8  global_SHT2x_serialNum[8];  //64bit serial number
UINT8  global_SHT2xUserRegister;           //variable for user register

INT16 global_display_outdoor_temperature = 0;     
INT16 global_display_outdoor_relatedHumi = 0;    

const UINT16 POLYNOMIAL = 0x131;  //P(x)=x^8+x^5+x^4+1 = 100110001


void Delay_10us (UINT16 nbrOfUs)
//==============================================================================
{
    nbrOfUs *= 10;
    delay_micro_second(nbrOfUs);
}

//==============================================================================
UINT8 SHT2x_CheckCrc(UINT8 data[], UINT8 nbrOfBytes, UINT8 checksum)
//==============================================================================
{
  UINT8 crc = 0;	
  UINT8 byteCtr;
  //calculates 8-Bit checksum with given polynomial
  for (byteCtr = 0; byteCtr < nbrOfBytes; ++byteCtr)
  { crc ^= (data[byteCtr]);
    for (UINT8 bit = 8; bit > 0; --bit)
    { if (crc & 0x80) crc = (crc << 1) ^ POLYNOMIAL;
      else crc = (crc << 1);
    }
  }
  if (crc != checksum) return CHECKSUM_ERROR;
  else return 0;
}

//===========================================================================
UINT8 SHT2x_ReadUserRegister(UINT8 *pRegisterValue)
//===========================================================================
{
  UINT8 checksum;   //variable for checksum byte
  UINT8 error=0;    //variable for error code

  I2c_StartCondition();
  error |= I2c_WriteByte (I2C_ADR_W);
  error |= I2c_WriteByte (USER_REG_R);
  I2c_StartCondition();
  error |= I2c_WriteByte (I2C_ADR_R);
  *pRegisterValue = I2c_ReadByte(SHT2X_ACK);
  checksum=I2c_ReadByte(SHT2X_NO_ACK);
  error |= SHT2x_CheckCrc (pRegisterValue,1,checksum);
  I2c_StopCondition();
  return error;
}

//===========================================================================
UINT8 SHT2x_WriteUserRegister(UINT8 *pRegisterValue)
//===========================================================================
{
  UINT8 error=0;   //variable for error code

  I2c_StartCondition();
  error |= I2c_WriteByte (I2C_ADR_W);
  error |= I2c_WriteByte (USER_REG_W);
  error |= I2c_WriteByte (*pRegisterValue);
  I2c_StopCondition();
  return error;
}

//===========================================================================
UINT8 SHT2x_MeasureHM(etSHT2xMeasureType eSHT2xMeasureType, nt16 *pMeasurand)
//===========================================================================
{
  UINT8  checksum;   //checksum
  UINT8  data[2];    //data array for checksum verification
  UINT8  error=0;    //error variable
  UINT16 i;          //counting variable

  //-- write I2C sensor address and command --
  I2c_StartCondition();
  error |= I2c_WriteByte (I2C_ADR_W); // I2C Adr
  switch(eSHT2xMeasureType)
  { case HUMIDITY: error |= I2c_WriteByte (TRIG_RH_MEASUREMENT_HM); break;
    case TEMP    : error |= I2c_WriteByte (TRIG_T_MEASUREMENT_HM);  break;
    default: /*assert(0)*/;
  }
  //-- wait until hold master is released --
  I2c_StartCondition();
  error |= I2c_WriteByte (I2C_ADR_R);
  SCL_HIGH();                     // set SCL I/O port as input
  for(i=0; i<1000; i++)         // wait until master hold is released or
  { Delay_10us(1000);    // a timeout (~1s) is reached
    if (SCL_CONF==1) break;
  }
  //-- check for timeout --
  if(SCL_CONF==0) error |= SHT2X_TIME_OUT_ERROR;

  //-- read two data bytes and one checksum byte --
  pMeasurand->s16.u8H = data[0] = I2c_ReadByte(SHT2X_ACK);
  pMeasurand->s16.u8L = data[1] = I2c_ReadByte(SHT2X_ACK);
  checksum=I2c_ReadByte(SHT2X_NO_ACK);

  //-- verify checksum --
  error |= SHT2x_CheckCrc (data,2,checksum);
  I2c_StopCondition();
  return error;
}

//===========================================================================
UINT8 SHT2x_MeasurePoll(etSHT2xMeasureType eSHT2xMeasureType, nt16 *pMeasurand)
//===========================================================================
{
  UINT8  checksum;   //checksum
  UINT8  data[2];    //data array for checksum verification
  UINT8  error=0;    //error variable
  UINT16 i=0;        //counting variable

  //-- write I2C sensor address and command --
  I2c_StartCondition();
  error |= I2c_WriteByte (I2C_ADR_W); // I2C Adr
  switch(eSHT2xMeasureType)
  { case HUMIDITY: error |= I2c_WriteByte (TRIG_RH_MEASUREMENT_POLL); break;
    case TEMP    : error |= I2c_WriteByte (TRIG_T_MEASUREMENT_POLL);  break;
    default: /*assert(0)*/;
  }
  //-- poll every 10ms for measurement ready. Timeout after 20 retries (200ms)--
  do
  { I2c_StartCondition();
    Delay_10us(1000);  //delay 10ms
    if(i++ >= 20) break;
  } while(I2c_WriteByte (I2C_ADR_R) == ACK_ERROR);
  if (i>=20) error |= SHT2X_TIME_OUT_ERROR;

  //-- read two data bytes and one checksum byte --
  pMeasurand->s16.u8H = data[0] = I2c_ReadByte(SHT2X_ACK);
  pMeasurand->s16.u8L = data[1] = I2c_ReadByte(SHT2X_ACK);
  checksum=I2c_ReadByte(SHT2X_NO_ACK);

  //-- verify checksum --
  error |= SHT2x_CheckCrc (data,2,checksum);
  I2c_StopCondition();

  return error;
}

//===========================================================================
UINT8 SHT2x_SoftReset()
//===========================================================================
{
  UINT8  error=0;           //error variable

  I2c_StartCondition();
  error |= I2c_WriteByte(I2C_ADR_W); // I2C Adr
  error |= I2c_WriteByte(SOFT_RESET);                            // Command
  I2c_StopCondition();

  Delay_10us(15000); // wait till sensor has restarted

  return error;
}

//==============================================================================
float SHT2x_CalcRH(UINT16 u16sRH)
//==============================================================================
{
  float humidityRH;              // variable for result

  u16sRH &= ~0x0003;          // clear bits [1..0] (status bits)
  //-- calculate relative humidity [%RH] --

  humidityRH = -6.0 + 125.0/65536 * (float)u16sRH; // RH= -6 + 125 * SRH/2^16
  return humidityRH;
}

//==============================================================================
float SHT2x_CalcTemperatureC(UINT16 u16sT)
//==============================================================================
{
  float temperatureC;            // variable for result

  u16sT &= ~0x0003;           // clear bits [1..0] (status bits)

  //-- calculate temperature [�C] --
  temperatureC= -46.85 + 175.72/65536 *(float)u16sT; //T= -46.85 + 175.72 * ST/2^16
  return temperatureC;
}

//==============================================================================
UINT8 SHT2x_GetSerialNumber(UINT8 u8SerialNumber[])
//==============================================================================
{
  UINT8  error=0;                          //error variable

  //Read from memory location 1
  I2c_StartCondition();
  error |= I2c_WriteByte (I2C_ADR_W);    //I2C address
  error |= I2c_WriteByte (0xFA);         //Command for readout on-chip memory
  error |= I2c_WriteByte (0x0F);         //on-chip memory address
  I2c_StartCondition();
  error |= I2c_WriteByte (I2C_ADR_R);    //I2C address
  u8SerialNumber[5] = I2c_ReadByte(SHT2X_ACK); //Read SNB_3
  I2c_ReadByte(SHT2X_ACK);                     //Read CRC SNB_3 (CRC is not analyzed)
  u8SerialNumber[4] = I2c_ReadByte(SHT2X_ACK); //Read SNB_2
  I2c_ReadByte(SHT2X_ACK);                     //Read CRC SNB_2 (CRC is not analyzed)
  u8SerialNumber[3] = I2c_ReadByte(SHT2X_ACK); //Read SNB_1
  I2c_ReadByte(SHT2X_ACK);                     //Read CRC SNB_1 (CRC is not analyzed)
  u8SerialNumber[2] = I2c_ReadByte(SHT2X_ACK); //Read SNB_0
  I2c_ReadByte(SHT2X_NO_ACK);                  //Read CRC SNB_0 (CRC is not analyzed)
  I2c_StopCondition();

  //Read from memory location 2
  I2c_StartCondition();
  error |= I2c_WriteByte (I2C_ADR_W);    //I2C address
  error |= I2c_WriteByte (0xFC);         //Command for readout on-chip memory
  error |= I2c_WriteByte (0xC9);         //on-chip memory address
  I2c_StartCondition();
  error |= I2c_WriteByte (I2C_ADR_R);    //I2C address
  u8SerialNumber[1] = I2c_ReadByte(SHT2X_ACK); //Read SNC_1
  u8SerialNumber[0] = I2c_ReadByte(SHT2X_ACK); //Read SNC_0
  I2c_ReadByte(SHT2X_ACK);                     //Read CRC SNC0/1 (CRC is not analyzed)
  u8SerialNumber[7] = I2c_ReadByte(SHT2X_ACK); //Read SNA_1
  u8SerialNumber[6] = I2c_ReadByte(SHT2X_ACK); //Read SNA_0
  I2c_ReadByte(SHT2X_NO_ACK);                  //Read CRC SNA0/1 (CRC is not analyzed)
  I2c_StopCondition();

  return error;
}

void SHT2x_Init(void){ 
  UINT8 error = 0;
  
  I2c_Init();    
  I2c_StartCondition();
  I2c_StopCondition();
  
  // --- Reset sensor by command ---
  error |= SHT2x_SoftReset();

  // --- Read the sensors serial number (64bit) ---
  error |= SHT2x_GetSerialNumber(global_SHT2x_serialNum);

  // --- Set Resolution e.g. RH 10bit, Temp 13bit ---
  error |= SHT2x_ReadUserRegister(&global_SHT2xUserRegister);  //get actual user reg
  global_SHT2xUserRegister = (global_SHT2xUserRegister & ~SHT2x_RES_MASK) | SHT2x_RES_10_13BIT;
  error |= SHT2x_WriteUserRegister(&global_SHT2xUserRegister); //write changed user reg
}

nt16 sRH;                    //variable for raw humidity ticks
nt16 sT;                     //variable for raw temperature ticks

INT16 SHT2x_readValue(void){
static UINT8 error;
  
  float   humidityRH;             //variable for relative humidity[%RH] as float
  float   temperatureC;           //variable for temperature[�C] as float

  //pResTH->status = SHTXX_STATUS_NORNAL;

  error = 0;                                       // reset error status
  // --- Reset sensor by command ---
  error |= SHT2x_SoftReset();
 
  error = 0;                                       // reset error status
  // --- measure temperature with "Polling Mode" (no hold master) ---
  error |= SHT2x_MeasurePoll(HUMIDITY, &sRH);
  // --- measure temperature with "Polling Mode" (no hold master) ---
  error |= SHT2x_MeasurePoll(TEMP, &sT);
  
  if(error == 0) {
    //-- calculate humidity and temperature --
    temperatureC = SHT2x_CalcTemperatureC(sT.u16);
    humidityRH   = SHT2x_CalcRH(sRH.u16);
    
    global_display_outdoor_temperature = (INT16) (temperatureC * 100);   // celsius
    global_display_outdoor_relatedHumi = (INT16) (humidityRH * 100);
    
    return 0;
  }
  else {
    global_display_outdoor_temperature = 0;   // celsius
    global_display_outdoor_relatedHumi = 0;
    return error;
  }
  
}

INT16 SHT2x_Get_Humidity(void) {
  return global_display_outdoor_relatedHumi;
}
INT16 SHT2x_Get_Temperature(void) {
  return global_display_outdoor_temperature;
}



