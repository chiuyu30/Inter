/*******************************************************************************
        .o.       oooooooooooo   .oooooo.   ooooo        
       .888.      `888'     `8  d8P'  `Y8b  `888'        
      .8"888.      888         888           888         
     .8' `888.     888oooo8    888           888         
    .88ooo8888.    888    "    888           888         
   .8'     `888.   888       o `88b    ooo   888       o 
  o88o     o8888o o888ooooood8  `Y8bood8P'  o888ooooood8 
*********************************************************************************/
/******************************************************************************
*  32kHz ACLK, 20MHZ SMCLK
*  
*  Description: Sensirion SGPC10 sensor I2C routines
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/8/10
*
*
*********************************************************************************/
#ifndef HAL_SGPC10_H
#define HAL_SGPC10_H

INT16 sgpc10_measureRes(UINT16* data);
INT16 sgpc10_getSerialId(UINT16* data);


#endif