/******************************************************************************
*  32kHz ACLK, 20MHZ SMCLK
*  
*  Description: Sensirion SGPC10 sensor I2C routines
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/8/10
*
*
*********************************************************************************/
#include "include.h"

#define SGPC10_I2C_ADDRESS              0x58 
#define SGPC10_MEASURE_RESISTANCE       0X2024
#define SGPC10_INIT_AIR_QUALITY         0X2003
#define SGPC10_MEASURE_AIR_QUALITY      0X2008
#define SGPC10_MEASURE_TEST             0X20FD
// Generator polynomial for CRC
#define POLYNOMIAL  0x131 // P(x) = x^8 + x^5 + x^4 + 1 = 100110001

//UINT16 sgpc10_resistance[4];
//UINT16 sgpc10_serialId[3];

//-----------------------------------------------------------------------------
static UINT8 sgpc10_calcCrc(UINT8 data[], UINT8 nbrOfBytes)
{
  u8t bit;        // bit mask
  u8t crc = 0xFF; // calculated checksum
  u8t byteCtr;    // byte counter
  
  // calculates 8-Bit checksum with given polynomial
  for(byteCtr = 0; byteCtr < nbrOfBytes; byteCtr++)
  {
    crc ^= (data[byteCtr]);
    for(bit = 8; bit > 0; --bit)
    {
      if(crc & 0x80) crc = (crc << 1) ^ POLYNOMIAL;
      else           crc = (crc << 1);
    }
  }
  
  return crc;
}

INT16 sgpc10_measureRes(UINT16* data) {
  UINT8 sgpc10_buffer[12];
  UINT8 txData[2];
  UINT8 checksum;
  UINT8 crc;
  UINT8 status;
  
  txData[0] = 0x20;
  txData[1] = 0x24;
//  txData[1] = 0x39;

  status = eusci_b_i2c_tx_multi(SGPC10_I2C_ADDRESS, txData, 2);
  
  delay_ms(300);
  
  status = eusci_b_i2c_rx_multi(SGPC10_I2C_ADDRESS, sgpc10_buffer, 12);
//  sgpc10_buffer = eusci_b_i2c_tx_rx_multi(SGPC10_I2C_ADDRESS, 0x20, 4);
  if(status == 0) {  // tx ack success, receive serial number
    for(int i=0;i<12;i+=3) { 
      txData[0] = *(sgpc10_buffer + i);
      txData[1] = *(sgpc10_buffer + (i+1));
      checksum = *(sgpc10_buffer + (i+2));
      crc = sgpc10_calcCrc(txData, 2);
      if(crc == checksum) {
        *(data+(i/3)) = (txData[0] << 8) + txData[1];
//        sgpc10_resistance[i/3] = (txData[0] << 8) + txData[1];
      }
      else {
        //crc error
        return ERROR_CHECKSUM;
//        sgpc10_resistance[i/3] = 0xffff; // max value indicate crc error
      }
    }
  }

  return ERROR_NONE;

}

// ��Init_air_quality�� command starts the air quality measurement. 
// After the ��Init_air_quality�� command, 
// a ��Measure_air_quality�� command has to be sent in regular intervals of 1s.
void sgpc10_initAirQuality() {
  UINT8 txData[2];
  UINT8 status;
  
  txData[0] = 0x20;
  txData[1] = 0x03;

//  eusci_b_i2c_tx_single(SGPC10_I2C_ADDRESS, 0x20);
  status = eusci_b_i2c_tx_multi(SGPC10_I2C_ADDRESS, txData, 2);
  
}

UINT16 sgpc10_measureAirQuality() {
  UINT8 sgpc10_buffer[2];
  UINT8 txData[2];
  UINT8 checksum;
  UINT8 crc;
  UINT16 airQualityData = 0;
  UINT8 status;
  
  txData[0] = 0x20;
  txData[1] = 0x08;

//  eusci_b_i2c_tx_single(SGPC10_I2C_ADDRESS, 0x20);
  status = eusci_b_i2c_tx_multi(SGPC10_I2C_ADDRESS, txData, 2);
  
  delay_ms(1);
  
  status = eusci_b_i2c_rx_multi(SGPC10_I2C_ADDRESS, sgpc10_buffer, 2);
  txData[0] = *(sgpc10_buffer);
  txData[1] = *(sgpc10_buffer + 1);
  checksum = *(sgpc10_buffer + 2);
  crc = sgpc10_calcCrc(txData, 2);
  if(crc == checksum) {
    airQualityData = (txData[0] << 8) + txData[1];
  }
  else {
    //crc error
    airQualityData = 0xffff; // max value indicate crc error
  }

  return airQualityData;
  
}


INT16 sgpc10_getSerialId(UINT16* data) {
  UINT8 sgpc10_buffer[9];
  UINT8 txData[2];
  UINT8 checksum;
  UINT8 crc;
  UINT8 status;
  
  txData[0] = 0x36;
  txData[1] = 0x82;

//  eusci_b_i2c_tx_single(SGPC10_I2C_ADDRESS, 0x20);
  status = eusci_b_i2c_tx_multi(SGPC10_I2C_ADDRESS, txData, 2);
  
  if(status == 0) {  // tx ack success, receive serial number
    delay_ms(10);
    
    status = eusci_b_i2c_rx_multi(SGPC10_I2C_ADDRESS, sgpc10_buffer, 9);
  //  sgpc10_buffer = eusci_b_i2c_tx_rx_multi(SGPC10_I2C_ADDRESS, 0x20, 4);
    
    for(int i=0;i<9;i+=3) {
      txData[0] = *(sgpc10_buffer + i);
      txData[1] = *(sgpc10_buffer + (i+1));
      checksum = *(sgpc10_buffer + (i+2));
      crc = sgpc10_calcCrc(txData, 2);
      if(crc == checksum) {
        *(data+(i/3)) = (txData[0] << 8) + txData[1];
//        sgpc10_serialId[i/3] = (txData[0] << 8) + txData[1];
      }
      else {
        //crc error
        return ERROR_CHECKSUM;
      }
    }
  }

  return ERROR_NONE;
  
}

