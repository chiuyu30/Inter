/******************************************************************************
*  Microcontroller: MSP430F6736
*  32kHz ACLK, 20MHZ SMCLK
*  
*  Description: Panasonic GCHA1 PM2.5 sensor I2C routines
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/8/10
*
*
*********************************************************************************/
#include "include.h"

#define GCHA1_I2C_ADDRESS       0x33  

INT32 hal_read_gcha1(void) {
  INT32 gcha1_pm25 = 0;
  UINT8 *gcha1_buffer;

//  eusci_b_i2c_tx_single(GCHA1_I2C_ADDRESS, 0x20);
//  eusci_b_i2c_tx_multi(GCHA1_I2C_ADDRESS, txData, 2);
  
//  gcha1_buffer = eusci_b_i2c_rx_multi(GCHA1_I2C_ADDRESS, 4);
  gcha1_buffer = eusci_b_i2c_tx_rx_multi(GCHA1_I2C_ADDRESS, 0x20, 4);
  
  gcha1_pm25 = *(gcha1_buffer) + (*(gcha1_buffer+1) << 8) +
               (*(gcha1_buffer+2) << 16) + (*(gcha1_buffer+3) << 24);
////  global_display_temperature = (global_CO[3] << 8) + (global_CO[4]);
//  for(unsigned int i=0;i<500;i++) {
//    _NOP();
//  }
  return gcha1_pm25;

}
