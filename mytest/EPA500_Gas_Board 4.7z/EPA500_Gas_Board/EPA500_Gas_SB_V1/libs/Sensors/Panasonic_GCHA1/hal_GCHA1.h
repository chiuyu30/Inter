/*******************************************************************************
        .o.       oooooooooooo   .oooooo.   ooooo        
       .888.      `888'     `8  d8P'  `Y8b  `888'        
      .8"888.      888         888           888         
     .8' `888.     888oooo8    888           888         
    .88ooo8888.    888    "    888           888         
   .8'     `888.   888       o `88b    ooo   888       o 
  o88o     o8888o o888ooooood8  `Y8bood8P'  o888ooooood8 
*********************************************************************************/
//******************************************************************************
//  Hardware: SmartMesh IP Sensor Board for Advantech RevA
//  Microcontroller: MSP430F6736
//  32kHz ACLK, 20MHZ SMCLK
//
//  Description: AECL CO module driver
//
//  Company: Autotronic Enterprise CO., LTD.
//  Department: Production Application Division
//  Author: SY LAU
//  Create Date: 2015/3/27
//  IAR Embedded Workbench Version: 5.40
//*****************************************************************************
#ifndef HAL_GCHA1_H
#define HAL_GCHA1_H

INT32 hal_read_gcha1(void);


#endif