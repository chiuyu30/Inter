/******************************************************************************
*  Hardware: SmartMesh IP Sensor Board for Advantech RevA
*  Microcontroller: MSP430F6736
*  32kHz ACLK, 20MHZ SMCLK
*  
*  Description: AECL CO module I2C routines
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2014/10/16
*
*
*********************************************************************************/
#include "include.h"

#define POLYNOMIAL  0x131    // P(x) = x^8 + x^5 + x^4 + 1 = 100110001

#define CO_001M_I2C_ADDRESS       0x48

UINT8 txData[2];


void aecl_co001m_init(void) {
//#ifdef GLOBALSAT_LM130
//  //Set P2.2, P2.3 to I2C function, for CO module
//  // use Port Mapping Controller to map UCB0SCL/UCB0SDA to P2.2/P2.3
//  PMAPPWD = PMAPKEY;       // Get write-access to port mapping regs
//  P2MAP3 = PM_UCB0SCL;       // Map UCB0SCL input to P2.3
//  P2MAP2 = PM_UCB0SDA;       // Map UCB0SDA output to P2.2
//  PMAPPWD = 0;             // Lock port mapping registers
//  P2SEL |= BIT2 + BIT3;
//#endif
//  
//#ifdef GEMTEK_GL6509
//  // 20160628 CO module on GL6509 RevB mount on S8 pin
//  // S8_bCAL(P2.4) configured as Power pin (set high), 
//  // LP8_EN(P8.6) configured as GND pin (set low)
//  // S8/UCA1RX(P1.4) configured as SDA (port mapping)
//  // S8/UCA1TX(P1.5) configured as SCL (port mapping)
//  GPIO_setAsOutputPin(GPIO_PORT_P2,GPIO_PIN4);
//  GPIO_setOutputHighOnPin(GPIO_PORT_P2,GPIO_PIN4);
//  GPIO_setAsOutputPin(GPIO_PORT_P8,GPIO_PIN6);
//  GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN6);
//  
//  PMAPPWD = PMAPKEY;       // Get write-access to port mapping regs
//  P1MAP5 = PM_UCB0SCL;       // Map UCB0SCL input to P2.3
//  P1MAP4 = PM_UCB0SDA;       // Map UCB0SDA output to P2.2
//  PMAPPWD = 0;             // Lock port mapping registers
//  P1SEL |= BIT4 + BIT5;
//  
//#endif
//  
//  UCB0CTLW0 |= UCSWRST;                      // Enable SW reset
//  UCB0CTLW0 |= UCMST + UCMODE_3 + UCSSEL_2;     // I2C Master, synchronous mode, SMCLK
////  UCB0CTL1 = UCSSEL_2 + UCSWRST;            // Use SMCLK, keep SW reset
//  UCB0BRW_L = 0xC8;                             // fSCL = SMCLK/400 = ~50kHz
//  UCB0BRW_H = 0x00;
//  UCB0I2CSA = 0x48;                         // Slave Address is 048h
//  UCB0CTLW0 &= ~UCSWRST;                     // Clear SW reset, resume operation
//  UCB0IE |= UCTXIE0 + UCRXIE0;
}
  

//INT16 hal_read_CO(void) {
//  INT16 co_ppm = 0;
////  Setup_TX();
////  RPT_Flag = 1;
//  Transmit();
//  while(UCB0CTLW0 & UCTXSTP);             // Ensure stop condition got sent
//  for(unsigned int i=0;i<5000;i++) {
//    _NOP();
//  }
//  
//  //Receive process
////  Setup_RX();
//  Receive();
//  while(UCB0CTLW0 & UCTXSTP); 
//  for(int i=0;i<6;i++) {
//    global_CO[i] = RxBuffer[i];
//  }
//  co_ppm = (global_CO[0] << 8) + (global_CO[1]);
////  global_display_temperature = (global_CO[3] << 8) + (global_CO[4]);
//  for(unsigned int i=0;i<500;i++) {
//    _NOP();
//  }
//  return co_ppm;
//
//}

INT16 hal_read_CO(void) {
  INT16 co_ppm = 0;
  UINT8 *co_buffer;

  txData[0] = 0x30;
  txData[1] = 0x31;
  eusci_b_i2c_tx_single(CO_001M_I2C_ADDRESS, 0xA0);
//  eusci_b_i2c_tx_multi(CO_001M_I2C_ADDRESS, txData, 2);
  
  co_buffer = eusci_b_i2c_rx_multi(CO_001M_I2C_ADDRESS, 6);
  
  co_ppm = (*(co_buffer) << 8) + *(co_buffer + 1);
////  global_display_temperature = (global_CO[3] << 8) + (global_CO[4]);
//  for(unsigned int i=0;i<500;i++) {
//    _NOP();
//  }
  return co_ppm;

}


//==============================================================================
unsigned char CalCrc(unsigned char data[], unsigned char nbrOfBytes){
//==============================================================================
  unsigned char bit;     // bit mask
  unsigned char crc = 0; // calculated checksum
  unsigned char byteCtr; // byte counter
  
  // calculates 8-Bit checksum with given polynomial
  for(byteCtr = 0; byteCtr < nbrOfBytes; byteCtr++)
  {
    crc ^= (data[byteCtr]);
    for(bit = 8; bit > 0; --bit)
    {
      if(crc & 0x80) crc = (crc << 1) ^ POLYNOMIAL;
      else           crc = (crc << 1);
    }
  }
  
  // return checksum
  return crc;
}