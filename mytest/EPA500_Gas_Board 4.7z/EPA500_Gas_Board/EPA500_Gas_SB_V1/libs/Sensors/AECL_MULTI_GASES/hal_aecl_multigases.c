/******************************************************************************
*  32kHz ACLK, 20MHZ SMCLK
*  
*  Description: AECL multiple gases sensor I2C routines
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/8/10
*
*
*********************************************************************************/
#include "include.h"

//#define AECLMG_I2C_ADDRESS              0x51 
#define AECLMG_MEASURE_RESISTANCE       0X2024
#define AECLMG_INIT_AIR_QUALITY         0X2003
#define AECLMG_MEASURE_AIR_QUALITY      0X2008
#define AECLMG_MEASURE_TEST             0X20FD
// Generator polynomial for CRC
#define POLYNOMIAL  0x131 // P(x) = x^8 + x^5 + x^4 + 1 = 100110001

UINT32 aeclmg_adc;
UINT32 aeclmg_ppb;
UINT16 aeclmg_serialId[3];

//-----------------------------------------------------------------------------
static UINT8 aeclmg_calcCrc(UINT8 data[], UINT8 nbrOfBytes)
{
  u8t bit;        // bit mask
  u8t crc = 0xFF; // calculated checksum
  u8t byteCtr;    // byte counter
  
  // calculates 8-Bit checksum with given polynomial
  for(byteCtr = 0; byteCtr < nbrOfBytes; byteCtr++)
  {
    crc ^= (data[byteCtr]);
    for(bit = 8; bit > 0; --bit)
    {
      if(crc & 0x80) crc = (crc << 1) ^ POLYNOMIAL;
      else           crc = (crc << 1);
    }
  }
  
  return crc;
}

INT32 aeclmg_getAdc(UINT8 address) {
  UINT8 *aeclmg_buffer;
  UINT8 txData[3];
  UINT8 checksum;
  UINT8 crc;
  UINT16 tempData[2];
  UINT8 status;
  
  txData[0] = 0x20;
  txData[1] = 0x24;
  txData[2] = 0x00;
  
  aeclmg_adc = 0;

  status = eusci_b_i2c_tx_multi(address, txData, 3);
  
  if(status == 0) {  // tx ack success, receive data
    delay_ms(10);
    
    aeclmg_buffer = eusci_b_i2c_rx_multi(address, 6);
  //  aeclmg_buffer = eusci_b_i2c_tx_rx_multi(address, 0x20, 4);
    
    for(int i=0;i<6;i+=3) { 
      txData[0] = *(aeclmg_buffer + i);
      txData[1] = *(aeclmg_buffer + (i+1));
      checksum = *(aeclmg_buffer + (i+2));
      crc = aeclmg_calcCrc(txData, 2);
      if(crc == checksum) {
        tempData[i/3] = (txData[0] << 8) + txData[1];
      }
      else {
        //crc error
        tempData[i/3] = 0xffff; // max value indicate crc error
      }
    }

    aeclmg_adc = (((INT32) tempData[0]) << 16) + (INT32) tempData[1];
  }

  return aeclmg_adc;

}

INT32 aeclmg_getPpb(UINT8 address) {
  UINT8 *aeclmg_buffer;
  UINT8 txData[3];
  UINT8 checksum;
  UINT8 crc;
  UINT16 tempData[2];
  UINT8 status;
  
  txData[0] = 0x20;
  txData[1] = 0x08;
  txData[2] = 0x00;
  
  aeclmg_ppb = 0;

  status = eusci_b_i2c_tx_multi(address, txData, 3);
  
  if(status == 0) {  // tx ack success, receive data
    delay_ms(10);
    
    aeclmg_buffer = eusci_b_i2c_rx_multi(address, 6);
  //  aeclmg_buffer = eusci_b_i2c_tx_rx_multi(address, 0x20, 4);
   
    for(int i=0;i<6;i+=3) { 
      txData[0] = *(aeclmg_buffer + i);
      txData[1] = *(aeclmg_buffer + (i+1));
      checksum = *(aeclmg_buffer + (i+2));
      crc = aeclmg_calcCrc(txData, 2);
      if(crc == checksum) {
        tempData[i/3] = (txData[0] << 8) + txData[1];
      }
      else {
        //crc error
        tempData[i/3] = 0xffff; // max value indicate crc error
      }
    }

    aeclmg_ppb = (((INT32) tempData[0]) << 16) + (INT32) tempData[1];
  }

  return aeclmg_ppb;

}


UINT16 * aeclmg_getSerialId(UINT8 address) {
  UINT8 *aeclmg_buffer;
  UINT8 txData[3];
  UINT8 checksum;
  UINT8 crc;
  UINT8 status;

  
  txData[0] = 0x36;
  txData[1] = 0x82;
  txData[2] = 0x00;
  
  aeclmg_serialId[0] = 0;
  aeclmg_serialId[1] = 0;
  aeclmg_serialId[2] = 0;

//  eusci_b_i2c_tx_single(address, 0x20);
  // tx command, return 1 if tx non-ack
  status = eusci_b_i2c_tx_multi(address, txData, 3);
  
  if(status == 0) {  // tx ack success, receive serial number
    delay_ms(5);
    
    aeclmg_buffer = eusci_b_i2c_rx_multi(address, 9);
    
    for(int i=0;i<9;i+=3) {
      txData[0] = *(aeclmg_buffer + i);
      txData[1] = *(aeclmg_buffer + (i+1));
      checksum = *(aeclmg_buffer + (i+2));
      crc = aeclmg_calcCrc(txData, 2);
      if(crc == checksum) {
        aeclmg_serialId[i/3] = (txData[0] << 8) + txData[1];
      }
      else {
        //crc error
        aeclmg_serialId[i/3] = 0xffff; // max value indicate crc error
      }
    }
  }

  return aeclmg_serialId;
  
}

