/*******************************************************************************
        .o.       oooooooooooo   .oooooo.   ooooo        
       .888.      `888'     `8  d8P'  `Y8b  `888'        
      .8"888.      888         888           888         
     .8' `888.     888oooo8    888           888         
    .88ooo8888.    888    "    888           888         
   .8'     `888.   888       o `88b    ooo   888       o 
  o88o     o8888o o888ooooood8  `Y8bood8P'  o888ooooood8 
*********************************************************************************/
/*******************************************************************************
*
*   This is the PlantTower PMS3003 hal source file
*   
*   1. read data from PMS3003
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/01/22
*
*
*********************************************************************************/
#ifndef HAL_ONEAIR_A4_H
#define HAL_ONEAIR_A4_H


void a4_init(void);

extern UINT16 a4_atmosphere_pm1;
extern UINT16 a4_atmosphere_pm25;
extern UINT16 a4_atmosphere_pm10;
extern UINT16 a4_0u3_count;
extern UINT16 a4_0u5_count;
extern UINT16 a4_1u0_count;
extern UINT16 a4_2u5_count;
extern UINT16 a4_5u0_count;
extern UINT16 a4_10u_count;

#endif

