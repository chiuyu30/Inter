/*******************************************************************************
        .o.       oooooooooooo   .oooooo.   ooooo        
       .888.      `888'     `8  d8P'  `Y8b  `888'        
      .8"888.      888         888           888         
     .8' `888.     888oooo8    888           888         
    .88ooo8888.    888    "    888           888         
   .8'     `888.   888       o `88b    ooo   888       o 
  o88o     o8888o o888ooooood8  `Y8bood8P'  o888ooooood8 
*********************************************************************************/
/*******************************************************************************
*
*   This is the PlantTower PMS3003 hal source file
*   
*   1. read data from PMS3003
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/01/22
*
*
*********************************************************************************/
#ifdef ONEAIR_A4

#include "include.h"

#define FRAME_LENGTH     32

UINT8 a4_frame_start = 0;
UINT8 a4_RxBuf[FRAME_LENGTH];
UINT8 a4_rx_bytecount = 0;

UINT16 a4_atmosphere_pm1 = 0;
UINT16 a4_atmosphere_pm25 = 0;
UINT16 a4_atmosphere_pm10 = 0;
UINT16 a4_0u3_count = 0;
UINT16 a4_0u5_count = 0;
UINT16 a4_1u0_count = 0;
UINT16 a4_2u5_count = 0;
UINT16 a4_5u0_count = 0;
UINT16 a4_10u_count = 0;

void a4_init(void)
{ 
    // Setup P1.2 S8_RXD, P1.3 S8_TXD
  P1SEL |= BIT4 | BIT5;                   // Set P1.4, P1.5 to non-IO
  P1DIR |= BIT4 | BIT5;                   // Enable UCA1RXD, UCA1TXD
  
//  P1SEL &= ~(BIT2 | BIT3);                   // Set P1.2, P1.3 to non-IO
//  P1DIR &= ~(BIT2 | BIT3);                   // Enable UCA2RXD, UCA2TXD
  
 // Setup eUSCI_A2 
  UCA1CTLW0 |= UCSWRST;                   // **Put state machine in reset**
  UCA1CTLW0 |= UCSSEL_2;                  // SMCLK     
//  20MHz
  UCA1BRW = 130; 
  UCA1MCTLW = 0x0000 + UCBRF_3 + UCOS16;   // Modln UCBRSx=0xB5, UCBRFx=3, over sampling
  
  UCA1CTLW0 &= ~UCSWRST;                     // **Initialize USCI state machine**
  UCA1IE |= UCRXIE;                          // Enable USCI_A2 RX interrupt
//  modbusInterCharTimeOut = 75;   // INT((1/9600)*11*32768*2), add 0.5 char interval
//  modbusInterFrameTimeOut = 169;   //((1/9600)*11*32768*4.5), add 1 char interval
  
//   GPIO_setAsOutputPin( GPIO_PORT_P3,GPIO_PIN2);
//   GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN2 );
//  PMS3003_GPIO_INIT();
  

   
    __delay_cycles(60000);    
    
}

UINT16 a4_crc = 0;
INT16 a4_extract_data(void)
{ 

  a4_crc = 0;
  for(int i = 0; i < 30; i++) {
    a4_crc += a4_RxBuf[i];
  }
  UINT8 high_byte = a4_crc >> 8;
  UINT8 low_byte = a4_crc & 0x00FF;
  _NOP();
  if((a4_RxBuf[30] != (high_byte)) || (a4_RxBuf[31] != (low_byte))) {
    // crc error
    return -1;
  }
//  a4_crc = 0;
  
  a4_atmosphere_pm1 = (a4_RxBuf[4] << 8) + a4_RxBuf[5];   // pm1.0 TSI value CF=1
  a4_atmosphere_pm25 = (a4_RxBuf[6] << 8) + a4_RxBuf[7];  // pm2.5 TSI value CF=1
  a4_atmosphere_pm10 = (a4_RxBuf[8] << 8) + a4_RxBuf[9]; // pm10 TSI value CF=1
  a4_0u3_count = (a4_RxBuf[10] << 8) + a4_RxBuf[11]; // pm1 atmosphere value 
  a4_0u5_count = (a4_RxBuf[12] << 8) + a4_RxBuf[13]; // pm1 atmosphere value 
  a4_1u0_count = (a4_RxBuf[14] << 8) + a4_RxBuf[15]; // pm1 atmosphere value 
  a4_2u5_count = (a4_RxBuf[16] << 8) + a4_RxBuf[17]; // pm1 atmosphere value 
  a4_5u0_count = (a4_RxBuf[18] << 8) + a4_RxBuf[19]; // pm1 atmosphere value 
  a4_10u_count = (a4_RxBuf[20] << 8) + a4_RxBuf[21]; // pm1 atmosphere value 
  
  return 0;
}

//=================================S8 UART======================================
#pragma vector=USCI_A1_VECTOR
__interrupt void USCI_A1_ISR(void)   //USCI_A2 RX interrupt service routine
{ 
//  UINT8 temp = 0x00;;
  switch(__even_in_range(UCA1IV,4))
  {
  case USCI_NONE:break;                             // Vector 0 - no interrupt
  case USCI_UART_UCRXIFG:                           // Vector 2 - RXIFG
//    temp  = UCA2RXBUF;
    if(a4_frame_start == 0) {   // no start condition, receive first 2 bytes
      a4_RxBuf[a4_rx_bytecount] = UCA1RXBUF;
      a4_rx_bytecount++;
      if((a4_RxBuf[0] != 0x32)) {
        a4_frame_start = 0;  // address incorrect, reset counter
        a4_rx_bytecount = 0;
      }
      else {
        if(a4_rx_bytecount == 2) {
          if (a4_RxBuf[1] == 0x3D) {
            a4_frame_start = 1;  // address  correct, frame start
          }
          else {
            a4_frame_start = 0;  // address incorrect, reset counter
            a4_rx_bytecount = 0;
          }
        }
      }
    }
    else {   // start condition met
      a4_RxBuf[a4_rx_bytecount] = UCA1RXBUF;
      a4_rx_bytecount++;
      if(a4_rx_bytecount >= FRAME_LENGTH) {  // frame received
        a4_extract_data();
        a4_rx_bytecount = 0;
        a4_frame_start = 0;
        for(int i = 0; i < FRAME_LENGTH; i++) {
          a4_RxBuf[i] = 0x00;
        }
      }
    }
    break;
  case USCI_UART_UCTXIFG: break;      // TXIFG
  case USCI_UART_UCSTTIFG: break;     // TTIFG
  case USCI_UART_UCTXCPTIFG: break;   // TXCPTIFG
  default: break;
  }  
}

#endif
