/*******************************************************************************
        .o.       oooooooooooo   .oooooo.   ooooo        
       .888.      `888'     `8  d8P'  `Y8b  `888'        
      .8"888.      888         888           888         
     .8' `888.     888oooo8    888           888         
    .88ooo8888.    888    "    888           888         
   .8'     `888.   888       o `88b    ooo   888       o 
  o88o     o8888o o888ooooood8  `Y8bood8P'  o888ooooood8 
*********************************************************************************/
/*******************************************************************************
*
*   This is the PlantTower PMS3003 hal source file
*   
*   1. read data from PMS3003
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/01/22
*   Revision History: 2017/11/28 add average until read
*
*
*********************************************************************************/

#include "include.h"


#ifdef PLANTOWER_PM25

UINT8 plantower_frame_start = 0;
UINT8 plantower_RxBuf[FRAME_LENGTH];
UINT8 plantower_rx_bytecount = 0;

UINT16 plantower_pm_array[PLANTOWER_DATA_SIZE];
UINT16 plantower_ver_n_error;
static UINT16 plantower_pm_avg_array[PLANTOWER_DATA_SIZE];
UINT8 flag_plantower_avg_init = 1;  // initial to 1

void plantower_init(void)
{ 
  // PMS3003 SET, RESET pin init
  PLANTOWER_PM25_CTRL_GPIO_INIT();
  PLANTOWER_PM25_SET_HIGH();
  PLANTOWER_PM25_RESET_HIGH();
  
  // Setup P1.2 S8_RXD, P1.3 S8_TXD
  P1SEL |= BIT4 | BIT5;                   // Set P1.4, P1.5 to non-IO
  P1DIR |= BIT4 | BIT5;                   // Enable UCA1RXD, UCA1TXD
    
 // Setup eUSCI_A2 
  UCA1CTLW0 |= UCSWRST;                   // **Put state machine in reset**
  UCA1CTLW0 |= UCSSEL_2;                  // SMCLK     
//  20MHz
  UCA1BRW = 130; 
  UCA1MCTLW = 0x0000 + UCBRF_3 + UCOS16;   // Modln UCBRSx=0xB5, UCBRFx=3, over sampling
  
  UCA1CTLW0 &= ~UCSWRST;                     // **Initialize USCI state machine**
  UCA1IE |= UCRXIE;                          // Enable USCI_A2 RX interrupt
//  modbusInterCharTimeOut = 75;   // INT((1/9600)*11*32768*2), add 0.5 char interval
//  modbusInterFrameTimeOut = 169;   //((1/9600)*11*32768*4.5), add 1 char interval
  
//   GPIO_setAsOutputPin( GPIO_PORT_P3,GPIO_PIN2);
//   GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN2 );
//  PMS3003_GPIO_INIT();
  

   
    __delay_cycles(60000);    
    
}

////////////////////////////////////////////////////////////////////////////////
// Extract plantower pm sensor data, do average until read
// Note: this routine is excuted inside ISR loop, care must be taken to keep it short
// G5 data format:      | PM1 CF1 | PM2.5 CF1 | PM10 CF1 |
//                      | PM1 AIR | PM2.5 AIR | PM10 AIR |
//                      | 0.3um count | 0.5um count | 1.0um count |
//                      | 2.5um count | 5.0um count | 10um count  |
//                      | Version + Error code |
// RETURN:
//      0: success
//      -1: crc error
////////////////////////////////////////////////////////////////////////////////
UINT16 plantower_crc = 0;
INT16 plantower_extract_data(void)
{ 

  plantower_crc = 0;
  for(int i = 0; i < (FRAME_LENGTH-2); i++) {
    plantower_crc += plantower_RxBuf[i];
  }
  UINT8 high_byte = plantower_crc >> 8;
  UINT8 low_byte = plantower_crc & 0x00FF;
  _NOP();
  if((plantower_RxBuf[FRAME_LENGTH-2] != (high_byte)) || (plantower_RxBuf[FRAME_LENGTH-1] != (low_byte))) {
    // crc error
    g_pm_board_status |= PM_CRC_ERROR;   // mark pm crc error in status word
    return -1;
  }
  global_Board_status1 &= ~PM_NOT_RENEW;   // crc check pass, reset no_renew error bit
//  plantower_crc = 0;
  UINT16 temp;
  UINT16 bound = PLANTOWER_DATA_SIZE - 1;
  if(flag_plantower_avg_init == 1) {  // data just read, do not average
    flag_plantower_avg_init = 0;
    for(int i=0;i<bound;i++) {
      // extract the data, do not average
      plantower_pm_avg_array[i] = (plantower_RxBuf[((i * 2) + 4)] << 8) + plantower_RxBuf[((i * 2) + 5)];  
    }
  }
  else {  // do average
    for(int i=0;i<bound;i++) {
      // extract the data and average
      temp = (plantower_RxBuf[((i * 2) + 4)] << 8) + plantower_RxBuf[((i * 2) + 5)];
      plantower_pm_avg_array[i] = (plantower_pm_avg_array[i]/2) + (temp/2);  
    }
  }
  // record version and error code, last two bytes
  plantower_pm_avg_array[bound] = (plantower_RxBuf[((bound * 2) + 4)] << 8) + plantower_RxBuf[((bound * 2) + 5)];
  return 0;
}

////////////////////////////////////////////////////////////////////////////////
// Fill Modbus data registers and reset average data/flag
// This routine is called inside modbus_reply_04(),
// PM value average until this routine is called
// After modbus data registers filled, reset buffer and re-init error code
// 
// Error handling: 
//      If it is not called after 1 min (Modbus master didn't request data)
//      plantower_reset_avg_data() must be called in task timer ISR, 
//      to reset buffer and error code to avoid long averaging
//
// Note: 
//      plantower_fill_data_registers() called in modbus_reply_04() (inside ISR)
//
////////////////////////////////////////////////////////////////////////////////
void plantower_reset_avg_data() {
  memset(plantower_pm_avg_array, 0x00, PLANTOWER_DATA_SIZE);
  flag_plantower_avg_init = 1;
  global_Board_status1 |= PM_NO_DATA + PM_NOT_RENEW;   // data read, re-init error with no_data and no_renew error
  global_Board_status1 &= ~PM_CRC_ERROR;   // data read, reset crc error bit
}

void plantower_fill_data_registers() {
  modbus_data_frame_update(plantower_pm_avg_array, MODBUS_OFFSET_G5_DATA, MODBUS_SIZE_OF_G5_DATA);
  
  plantower_reset_avg_data();
}

void plantower_fill_info_registers() {
  UINT16 plantower_id[MODBUS_SIZE_OF_G5_INFO];
  plantower_id[0] = info_pm25_id_up;
  plantower_id[1] = info_pm25_id_low;
  modbus_info_frame_update(plantower_id, MODBUS_OFFSET_G5_INFO, MODBUS_SIZE_OF_G5_INFO);
}
////////////////////////////////////////////////////////////////////////////////

//=================================S8 UART======================================
#pragma vector=USCI_A1_VECTOR
__interrupt void USCI_A1_ISR(void)   //USCI_A2 RX interrupt service routine
{ 
//  UINT8 temp = 0x00;;
  switch(__even_in_range(UCA1IV,4))
  {
  case USCI_NONE:break;                             // Vector 0 - no interrupt
  case USCI_UART_UCRXIFG:                           // Vector 2 - RXIFG
//    temp  = UCA2RXBUF;
    if(plantower_frame_start == 0) {   // no start condition, receive first 2 bytes
      plantower_RxBuf[plantower_rx_bytecount] = UCA1RXBUF;
      plantower_rx_bytecount++;
      if((plantower_RxBuf[0] != 0x42)) {
        plantower_frame_start = 0;  // address incorrect, reset counter
        plantower_rx_bytecount = 0;
      }
      else {
        if(plantower_rx_bytecount == 2) {
          if (plantower_RxBuf[1] == 0x4D) {
            plantower_frame_start = 1;  // address correct, frame start
          }
          else {
            plantower_frame_start = 0;  // address incorrect, reset counter
            plantower_rx_bytecount = 0;
          }
        }
      }
    }
    else {   // start condition met
      plantower_RxBuf[plantower_rx_bytecount] = UCA1RXBUF;
      plantower_rx_bytecount++;
      if(plantower_rx_bytecount >= FRAME_LENGTH) {  // frame received
        global_Board_status1 &= ~PM_NO_DATA;   // data frame received, reset no_data error bit
        plantower_extract_data();
        plantower_rx_bytecount = 0;
        plantower_frame_start = 0;
        for(int i = 0; i < FRAME_LENGTH; i++) {
          plantower_RxBuf[i] = 0x00;
        }
      }
    }
    break;
  case USCI_UART_UCTXIFG: break;      // TXIFG
  case USCI_UART_UCSTTIFG: break;     // TTIFG
  case USCI_UART_UCTXCPTIFG: break;   // TXCPTIFG
  default: break;
  }  
}

#endif
