/*******************************************************************************
        .o.       oooooooooooo   .oooooo.   ooooo        
       .888.      `888'     `8  d8P'  `Y8b  `888'        
      .8"888.      888         888           888         
     .8' `888.     888oooo8    888           888         
    .88ooo8888.    888    "    888           888         
   .8'     `888.   888       o `88b    ooo   888       o 
  o88o     o8888o o888ooooood8  `Y8bood8P'  o888ooooood8 
*********************************************************************************/
/*******************************************************************************
*
*   This is the PlantTower PMS3003 hal source file
*   
*   1. read data from PMS3003
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/01/22
*
*
*********************************************************************************/
#ifndef HAL_PLANTOWER_PM25_H
#define HAL_PLANTOWER_PM25_H

//#define PLANTOWER_PMS3003
#define PLANTOWER_PMS5003

#ifdef PLANTOWER_PMS3003
#define FRAME_LENGTH     24
#endif

#ifdef PLANTOWER_PMS5003
#define FRAME_LENGTH     32
#define PLANTOWER_DATA_SIZE     13
#endif

//#define PLANTOWER_PM25_CTRL_GPIO_PORT   GPIO_PORT_P9   //sensor board V2
//#define PLANTOWER_PM25_SET_PIN          GPIO_PIN2      //sensor board V2
//#define PLANTOWER_PM25_RESET_PIN        GPIO_PIN1      //sensor board V2

#define PLANTOWER_PM25_CTRL_GPIO_PORT   GPIO_PORT_P8     //sensor board V3
#define PLANTOWER_PM25_SET_PIN          GPIO_PIN5        //sensor board V3
#define PLANTOWER_PM25_RESET_PIN        GPIO_PIN4        //sensor board V3

#define PLANTOWER_PM25_SET_LOW()                GPIO_setOutputLowOnPin(PLANTOWER_PM25_CTRL_GPIO_PORT,PLANTOWER_PM25_SET_PIN);
#define PLANTOWER_PM25_SET_HIGH()               GPIO_setOutputHighOnPin(PLANTOWER_PM25_CTRL_GPIO_PORT,PLANTOWER_PM25_SET_PIN);
#define PLANTOWER_PM25_RESET_LOW()              GPIO_setOutputHighOnPin(PLANTOWER_PM25_CTRL_GPIO_PORT,PLANTOWER_PM25_RESET_PIN);
#define PLANTOWER_PM25_RESET_HIGH()             GPIO_setOutputHighOnPin(PLANTOWER_PM25_CTRL_GPIO_PORT,PLANTOWER_PM25_RESET_PIN);
#define PLANTOWER_PM25_CTRL_GPIO_INIT()\
  do {\
    (GPIO_setAsOutputPin(PLANTOWER_PM25_CTRL_GPIO_PORT,\
      PLANTOWER_PM25_SET_PIN+PLANTOWER_PM25_RESET_PIN));\
  } while(0)

void plantower_init(void);

UINT16 * pms3003_get_result();
extern UINT16 plantower_pm_array[PLANTOWER_DATA_SIZE];

////////////////////////////////////////////////////////////////////////////////
// Fill Modbus data registers and reset average data/flag
// This routine is called inside modbus_reply_04(),
// PM value average until this routine is called
// After modbus data registers filled, reset buffer and re-init error code
// 
// Error handling: 
//      If it is not called after 1 min (Modbus master didn't request data)
//      plantower_reset_avg_data() must be called in task timer ISR, 
//      to reset buffer and error code to avoid long averaging
//
// Note: 
//      plantower_fill_data_registers() called in modbus_reply_04() (inside ISR)
//
////////////////////////////////////////////////////////////////////////////////
void plantower_reset_avg_data();
void plantower_fill_data_registers();
void plantower_fill_info_registers();


#endif

