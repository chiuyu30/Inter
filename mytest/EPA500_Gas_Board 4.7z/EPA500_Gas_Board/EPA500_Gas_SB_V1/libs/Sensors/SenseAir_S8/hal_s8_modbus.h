#ifndef HAL_S8_MODBUS_H
#define HAL_S8_MODBUS_H

#include "include.h"

void S8_initial(void);
void modbus_s8_request(void);            //S8 request

extern INT16 global_display_co2ppm;

#endif