/*******************************************************************************
*
*   This is the SenseAir S8 modbus RTU source file
*   
*   1. send modbus request to S8
*   2. receive reply and process CO2 value
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2014/04/13
*
*
*********************************************************************************/
#include "include.h"

UINT8 modbus_s8_Status_requests[8] ={0xFE,0x04,0x00,0x00,0x00,0x01};    //  Sensor status read sequence:
//<FE> <04> <02> <00> <00> <AD> <24>   00 00 
UINT8 modbus_s8_CO2_requests[8] ={0xFE,0x04,0x00,0x03,0x00,0x01};       //  CO 2  read sequence: 
//<FE> <04> <02> <01> <90> <AC> <D8>   400 ppm = 0x190
UINT8 modbus_s8_StatusCO2[8] ={0xFE,0x04,0x00,0x00,0x00,0x04};          //  Sensor status and CO2 
//<FE> <04> <08> <00> <00> <00> <00> <00> <00> <01> <90> <16> <E6>   
UINT8 modbus_s8_BCAL1[8] ={0xFE,0x06,0x00,0x00,0x00,0x00};          //  Sensor Background calibration1 
//<FE> <06> <00> <00> <00> <00> <9D> <C5>  
UINT8 modbus_s8_BCAL2[8] ={0xFE,0x06,0x00,0x01,0x7C,0x06};          //  Sensor Background calibration2 
//<FE> <06> <00> <01> <7C> <06> <6C> <C7> 
UINT8 modbus_s8_RxBuf[16];
UINT8 modbus_s8_rx_bytecount = 0;


//S8 status flg
INT16 O2_Status = 0;
UINT8 S8_status = 0;
UINT8 Analytics;

//CO2 value  =  display_co2ppm +  O2_measurement
INT16 display_co2ppm = 0;
INT16 global_display_co2ppm = 0;

UINT8 s8crcCheck(UINT8 *puchMsg , UINT16 length)	// receive Mast Data input	
{
//  UINT8 *p;
  UINT16 calculateCRC16;
  UINT16 receiveCRC16;

//  p = &modbus_request[0];
  //p = &modbus_s8_requests[0];
  calculateCRC16 = mCRC16(puchMsg, length-2);
  receiveCRC16 = (puchMsg[length-2]<< 8 | puchMsg[length-1]);

  if(calculateCRC16 == receiveCRC16)
      return 1;
  else
      return 0;
}
///////////////////////////////////////////////
// S8 initialization
//////////////////////////////////////////////
void S8_initial(void)
{ 
   // Setup S8 calibration pin, initial high
   GPIO_setAsOutputPin( GPIO_PORT_P2,GPIO_PIN4);
   GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN4 );
   
  
  // Setup P1.4 S8_RXD, P1.5 S8_TXD
  GPIO_setAsPeripheralModuleFunctionInputPin(
    GPIO_PORT_P1,
    GPIO_PIN4 + GPIO_PIN5
    );
  
  //Initialize USCI UART
  //Baudrate = 9600, clock freq = 20MHz
  //UCBRx = 130, UCBRFx = 3, UCBRSx = 0, UCOS16 = 1
  EUSCI_A_UART_initParam param = {0};
  param.selectClockSource = EUSCI_A_UART_CLOCKSOURCE_SMCLK;
  param.clockPrescalar = 130;
  param.firstModReg = 3;
  param.secondModReg = 0;
  param.parity = EUSCI_A_UART_NO_PARITY;
  param.msborLsbFirst = EUSCI_A_UART_LSB_FIRST;
  param.numberofStopBits = EUSCI_A_UART_ONE_STOP_BIT;
  param.uartMode = EUSCI_A_UART_MODE;
  param.overSampling = EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION;
  if(STATUS_FAIL == EUSCI_A_UART_init(EUSCI_A1_BASE, &param))
  {
      return;
  }
  
  //Enable UART module for operation
  EUSCI_A_UART_enable(EUSCI_A1_BASE);
  
  //Enable Receive Interrupt
  EUSCI_A_UART_clearInterrupt(EUSCI_A1_BASE,
                             EUSCI_A_UART_RECEIVE_INTERRUPT);
  EUSCI_A_UART_enableInterrupt(EUSCI_A1_BASE,
                              EUSCI_A_UART_RECEIVE_INTERRUPT);
  
//  modbusInterCharTimeOut = 75;   // INT((1/9600)*11*32768*2), add 0.5 char interval
//  modbusInterFrameTimeOut = 169;   //((1/9600)*11*32768*4.5), add 1 char interval
}

///////////////s8 request///////////////////////////
void modbus_s8_request(void)
{        
  //S8_initial();
  ///////set request CRC/////////////
   UINT16 requestCRC16;
   switch(S8_status)
   {
   case 0 :   
     requestCRC16 = mCRC16(&modbus_s8_CO2_requests[0],6);       
     modbus_s8_CO2_requests[6] = requestCRC16 >> 8;
     modbus_s8_CO2_requests[7] = requestCRC16;
     
   case 1 :        
     requestCRC16 = mCRC16(&modbus_s8_BCAL1[0],6);       
     modbus_s8_BCAL1[6] = requestCRC16 >> 8;
     modbus_s8_BCAL1[7] = requestCRC16;
     
   case 2 :          
     requestCRC16 = mCRC16(&modbus_s8_BCAL2[0],6);       
     modbus_s8_BCAL2[6] = requestCRC16 >> 8;
     modbus_s8_BCAL2[7] = requestCRC16;
     
   }
   
 ///////////set address/////////////  
//   __delay_cycles(40000);
   //while(!modbusFrameDelayTimerFired);   // wait for frame delay timeout
   for(UINT8 i = 0; i < 8;i++)
   {
     if(S8_status == 0)
     {
       EUSCI_A_UART_transmitData(EUSCI_A1_BASE, modbus_s8_CO2_requests[i]);
     }
     else if(S8_status == 1)
     {
       modbus_s8_rx_bytecount = 0;
       EUSCI_A_UART_transmitData(EUSCI_A1_BASE, modbus_s8_BCAL1[i]);
     }
     else if(S8_status == 2)
     {
       modbus_s8_rx_bytecount = 0;
       EUSCI_A_UART_transmitData(EUSCI_A1_BASE, modbus_s8_BCAL2[i]);
     }
   }
   _NOP();
//   __delay_cycles(100000);
}


INT16 modbus_s8_Analytics(void)
{       
  if (Analytics)
  {    
    if(modbus_s8_rx_bytecount >= 7) {
       if(s8crcCheck(&modbus_s8_RxBuf[0], modbus_s8_rx_bytecount) == 1) {
            if (modbus_s8_RxBuf[3] == 0xFF) 
            {
              display_co2ppm = (0x00 << 8)+modbus_s8_RxBuf[4];
            }else{
              display_co2ppm = (modbus_s8_RxBuf[3] << 8)+modbus_s8_RxBuf[4];
            }
            global_display_co2ppm = display_co2ppm;
         //   O2_Status = (modbus_s8_RxBuf[3] << 8)+modbus_s8_RxBuf[4];
        //    if (O2_Status>0x01)  //Reset SPI port ,but need pull hi S8 DVCC to Reset Devices
          //   S8_initial();
       }else{            
       }
       modbus_s8_rx_bytecount = 0;       
    }
    Analytics = 0;
  }
  return display_co2ppm;
}
 UINT8 start = 0x00;

//******************************************************************************
//
//This is the USCI_A1 interrupt vector service routine.
//
//******************************************************************************
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=USCI_A1_VECTOR
__interrupt
#elif defined(__GNUC__)
__attribute__((interrupt(USCI_A1_VECTOR)))
#endif
void EUSCI_A1_ISR(void)
{
  UINT8 temp = 0x00;
  switch(__even_in_range(UCA1IV,4))
  {
  case USCI_NONE:break;                             // Vector 0 - no interrupt
  case USCI_UART_UCRXIFG:                           // Vector 2 - RXIFG
    temp  = EUSCI_A_UART_receiveData(EUSCI_A1_BASE);
    if (temp == 0xFE)
    {
      start = 1;
    }
     if (start && Analytics != 1)
     {
       modbus_s8_RxBuf[modbus_s8_rx_bytecount] = temp;
       modbus_s8_rx_bytecount++;
        if(modbus_s8_rx_bytecount >= 7) {
          if(S8_status == 0)
          {         
            Analytics = 1;
            modbus_s8_Analytics();
          }
          if(S8_status == 2)
          {
            S8_status = 0;
            for(int i = 0; i < 16; i++)
            {
              modbus_s8_RxBuf[i] = 0x00;
            }
            _NOP();
          }
        }       
      }
    break;
  case USCI_UART_UCTXIFG: break;      // TXIFG
  case USCI_UART_UCSTTIFG: break;     // TTIFG
  case USCI_UART_UCTXCPTIFG: break;   // TXCPTIFG
  default: break;
  }  
}
