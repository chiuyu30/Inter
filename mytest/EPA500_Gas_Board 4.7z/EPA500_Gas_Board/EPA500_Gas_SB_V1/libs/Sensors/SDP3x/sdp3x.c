//=============================================================================
//    S E N S I R I O N   AG,  Laubisruetistr. 50, CH-8712 Staefa, Switzerland
//=============================================================================
/// \file    sdp3x.c (V1.0)
/// \author  RFU
/// \date    17-Aug-2016
/// \brief   Sensor Layer: Implementation of functions for sensor access.
//=============================================================================
#ifdef SENSIRION_SDP3X

#include "stdint.h"
#include "stdbool.h"
#include "include.h"

// Sensor Commands
typedef enum {
  /// Undefined dummy command.
  COMMAND_UNDEFINED                       = 0x0000,
  /// Start continous measurement                     \n
  /// Temperature compensation: Mass flow             \n
  /// Averaging: Average till read
  COMMAND_START_MEASURMENT_MF_AVERAGE     = 0x3603,
  /// Start continous measurement                     \n
  /// Temperature compensation: Mass flow             \n
  /// Averaging: None - Update rate 1ms
  COMMAND_START_MEASURMENT_MF_NONE        = 0x3608,
  /// Start continous measurement                     \n
  /// Temperature compensation: Differential pressure \n
  /// Averaging: Average till read
  COMMAND_START_MEASURMENT_DP_AVERAGE     = 0x3615,
  /// Start continous measurement                     \n
  /// Temperature compensation: Differential pressure \n
  /// Averaging: None - Update rate 1ms
  COMMAND_START_MEASURMENT_DP_NONE        = 0x361E,
  // Stop continuous measurement.
  COMMAND_STOP_CONTINOUS_MEASUREMENT      = 0x3FF9
} Command;

static Error ExecuteCommand(Command cmd);
static Error ReadMeasurementRawResults(int16_t* diffPressureTicks,
                                       int16_t* temperatureTicks,
                                       uint16_t* scaleFactor);
static Error CheckCrc(const uint8_t data[], uint8_t size, uint8_t checksum);

static const float scaleFactorTemperature = 200;

static uint8_t sdp_i2cAddress;

//-----------------------------------------------------------------------------
void Sdp3x_Init(uint8_t i2cAddress){
  sdp_i2cAddress = i2cAddress;
}

//-----------------------------------------------------------------------------
Error Sdp3x_StartContinousMeasurement(Sdp3xTempComp  tempComp,
                                      Sdp3xAveraging averaging)
{
  Error   error;
  Command command = COMMAND_UNDEFINED;
  
  // determine command code
  switch(tempComp) {
    case SDP3X_TEMPCOMP_MASS_FLOW:
      switch(averaging) {
        case SDP3X_AVERAGING_TILL_READ:
          command = COMMAND_START_MEASURMENT_MF_AVERAGE;
          break;
        case SDP3X_AVERAGING_NONE:
          command = COMMAND_START_MEASURMENT_MF_NONE;
          break;
      }
      break;
    case SDP3X_TEMPCOMP_DIFFERNTIAL_PRESSURE:
      switch(averaging) {
        case SDP3X_AVERAGING_TILL_READ:
          command = COMMAND_START_MEASURMENT_DP_AVERAGE;
          break;
        case SDP3X_AVERAGING_NONE:
          command = COMMAND_START_MEASURMENT_DP_NONE;
          break;
      }
      break;
  }
  
  if(COMMAND_UNDEFINED != command) {
    error = ExecuteCommand(command);
    // wait 10 ms for startup
    delay_micro_second(10000);
  } else {
    error = ERROR_IVALID_PARAMETER;
  }
  
  return error;
}

//-----------------------------------------------------------------------------
Error Sdp3x_StopContinousMeasurement(void)
{
  return ExecuteCommand(COMMAND_STOP_CONTINOUS_MEASUREMENT);
}

//-----------------------------------------------------------------------------
Error Sdp3x_ReadMeasurementResults(float* diffPressure, float* temperature)
{
  Error  error;
  int16_t  diffPressureTicks;
  int16_t  temperatureTicks;
  uint16_t scaleFactorDiffPressure;
  
  error = ReadMeasurementRawResults(&diffPressureTicks, &temperatureTicks,
                                    &scaleFactorDiffPressure);
  
  if(ERROR_NONE == error) {
    *diffPressure = (float)diffPressureTicks / (float)scaleFactorDiffPressure;
    *temperature  = (float)temperatureTicks / scaleFactorTemperature;
  }
  
  return error;
}

//-----------------------------------------------------------------------------
//Error Sdp3x_SoftReset(void)
//{
////  Error error;
////  
////  // write a start condition
////  I2c_StartCondition();
////
////  // write the upper 8 bits of reset
////  error = I2c_WriteByte(0x00);
////  
////  // write the lower 8 bits of reset
////  if(ERROR_NONE == error) {
////    error = I2c_WriteByte(0x06);
////  }
////  
////  I2c_StopCondition();
////
////  // wait 20 ms
////  DelayMicroSeconds(20000); 
////
////  return error;
//}

//-----------------------------------------------------------------------------
static Error ReadMeasurementRawResults(int16_t*  diffPressureTicks,
                                       int16_t*  temperatureTicks,
                                       uint16_t* scaleFactor)
{
  Error error;
  UINT8 sdpData[9];
  UINT8 txData[2];
  UINT8 status;
  UINT8 checksum;
  
  status = eusci_b_i2c_rx_multi(sdp_i2cAddress, sdpData, 9);
  if(status != 0) {
    return ERROR_ACK;
  }
  else {
      
    txData[0] = sdpData[0];
    txData[1] = sdpData[1];
    checksum = sdpData[2];
    // verify checksum
    error = CheckCrc(txData, 2, checksum);
    if(error == ERROR_NONE) {
      *diffPressureTicks = (txData[0] << 8) + txData[1];
    }
    else {   //crc error
      error = ERROR_CHECKSUM;
      // update pm board status register
    }
    
    txData[0] = sdpData[3];
    txData[1] = sdpData[4];
    checksum = sdpData[5];
    error = CheckCrc(txData, 2, checksum);
    if(error == ERROR_NONE) {
      *temperatureTicks = (txData[0] << 8) + txData[1];
    }
    else {   //crc error
      error = ERROR_CHECKSUM;
      // update pm board status register
    }
    
    txData[0] = sdpData[6];
    txData[1] = sdpData[7];
    checksum = sdpData[8];
    error = CheckCrc(txData, 2, checksum);
    if(error == ERROR_NONE) {
      *scaleFactor = (txData[0] << 8) + txData[1];
    }
    else {   //crc error
      error = ERROR_CHECKSUM;
      // update pm board status register
    }
  }
  
  return error;
}

//-----------------------------------------------------------------------------
Error ExecuteCommand(Command cmd)
{
  UINT8 status;
  UINT8 txData[2];
  
  txData[0] = cmd>>8;
  txData[1] = cmd&0xff;
  
  status = eusci_b_i2c_tx_multi(sdp_i2cAddress, txData, 2);
  if(status != 0) {
    return ERROR_ACK;
  }
  else {
    return ERROR_NONE;
  }
}

//-----------------------------------------------------------------------------
//static Error ReadWordWithCrcCheck(uint16_t *value, bool ack)
//{
//  Error error;
//  uint8_t bytes[2];
//  uint8_t checksum;
// 
//  // read two data bytes and one checksum byte
//  bytes[0] = I2c_ReadByte(ACK);
//  bytes[1] = I2c_ReadByte(ACK);
//  checksum = I2c_ReadByte(ack ? ACK : NACK);
//  
//  // verify checksum
//  error = CheckCrc(bytes, 2, checksum);
//  
//  // combine the two bytes to a 16-bit value
//  *value = (bytes[0] << 8) | bytes[1];
//  
//  return error;
//}

//-----------------------------------------------------------------------------
static Error CheckCrc(const uint8_t data[], uint8_t size, uint8_t checksum)
{
  uint8_t crc = 0xFF;
  
  // calculates 8-Bit checksum with given polynomial 0x31 (x^8 + x^5 + x^4 + 1)
  for(int i = 0; i < size; i++) {
    crc ^= (data[i]);
    for(uint8_t bit = 8; bit > 0; --bit) {
      if(crc & 0x80) crc = (crc << 1) ^ 0x31;
      else           crc = (crc << 1);
    }
  }
  
  // verify checksum
  return (crc == checksum) ? ERROR_NONE : ERROR_CHECKSUM;
}

#endif