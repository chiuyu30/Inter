#ifndef PERIPHERAL_ABSTRACTION
#define PERIPHERAL_ABSTRACTION

void peripheral_init(void);
void display_lcd(void);
void update_lcd(void);


#endif
