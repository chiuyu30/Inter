#ifndef RF_ABSTRACTION
#define RF_ABSTRACTION

void rf_module_init(void);
void rf_module_send_data(void);
void rf_module_setup(void);

#endif