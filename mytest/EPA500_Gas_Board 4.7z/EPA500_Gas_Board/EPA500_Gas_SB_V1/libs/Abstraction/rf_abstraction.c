#include "include.h"

void rf_module_init(void) {
#ifdef GLOBALSAT_LM130
  lm130_init();
#endif
  
#ifdef GEMTEK_GL6509
  gl6509_init();
#endif
}

void rf_module_setup(void) {
#ifdef GLOBALSAT_LM130
  lm130_setup();
#endif

}

void rf_module_send_data(void) {
#ifdef GLOBALSAT_LM130
  lm130_send_data(DEVICE_TYPE);
#endif
  
#ifdef GEMTEK_GL6509
  gl6509_sent_lass();
#endif
}

