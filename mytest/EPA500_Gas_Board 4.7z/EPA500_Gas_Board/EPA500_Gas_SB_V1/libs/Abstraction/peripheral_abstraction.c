#include "include.h"

void internal_ref_init() {
  //If ref generator busy, WAIT
  while(Ref_isRefGenBusy(REF_BASE))
  {
      ;
  }
  //Select internal ref = 2.5V
  Ref_setReferenceVoltage(REF_BASE, REF_VREF1_5V);
  //Internal Reference ON
  Ref_enableReferenceVoltage(REF_BASE);

  //Delay (~75us) for Ref to settle
  delay_micro_second(75);
}

void peripheral_init(void) {
  LED_init();
  eusci_b_i2c_port_init();
//  internal_ref_init();
#ifdef EUSCI_A0_UART_LOGGING
  hal_uart_txrx_init();
#endif 
  
#ifdef MODBUS_SLAVE
  modbus_init();
#endif
}



  
  