#include "include.h"
#include <stdio.h>

#define GAS_FW_VER_INFO         0
#define GAS_GASNAME_INFO        3
#define GAS_BSN_INFO            7

UINT8 flag_Gas_1_raw_data_1_avg_init = 1;  // initial to 1
UINT8 flag_Gas_1_raw_data_2_avg_init = 1;  // initial to 1
//UINT8 flag_Gas_1_raw_data_3_avg_init = 1;  // initial to 1
UINT8 flag_Gas_2_raw_data_1_avg_init = 1;  // initial to 1
UINT8 flag_Gas_2_raw_data_2_avg_init = 1;  // initial to 1
//UINT8 flag_Gas_2_raw_data_3_avg_init = 1;  // initial to 1
UINT8 flag_Gas_3_raw_data_1_avg_init = 1;  // initial to 1
UINT8 flag_Gas_3_raw_data_2_avg_init = 1;  // initial to 1
//UINT8 flag_Gas_3_raw_data_3_avg_init = 1;  // initial to 1
UINT8 flag_Gas_4_raw_data_1_avg_init = 1;  // initial to 1
UINT8 flag_Gas_4_raw_data_2_avg_init = 1;  // initial to 1
//UINT8 flag_Gas_4_raw_data_3_avg_init = 1;  // initial to 1
UINT8 flag_Gas_5_raw_data_1_avg_init = 1;  // initial to 1
UINT8 flag_Gas_5_raw_data_2_avg_init = 1;  // initial to 1
//UINT8 flag_Gas_5_raw_data_3_avg_init = 1;  // initial to 1
UINT8 flag_Gas_6_raw_data_1_avg_init = 1;  // initial to 1
UINT8 flag_Gas_6_raw_data_2_avg_init = 1;  // initial to 1
//UINT8 flag_Gas_6_raw_data_3_avg_init = 1;  // initial to 1


UINT8 flag_Gas_1_concentrations_avg_init = 1;  // initial to 1
UINT8 flag_Gas_2_concentrations_avg_init = 1;  // initial to 1
UINT8 flag_Gas_3_concentrations_avg_init = 1;  // initial to 1
UINT8 flag_Gas_4_concentrations_avg_init = 1;  // initial to 1
UINT8 flag_Gas_5_concentrations_avg_init = 1;  // initial to 1
UINT8 flag_Gas_6_concentrations_avg_init = 1;  // initial to 1

INT16 gas_1_data[MODBUS_SIZE_OF_GAS_1_DATA];
INT16 gas_2_data[MODBUS_SIZE_OF_GAS_2_DATA];
INT16 gas_3_data[MODBUS_SIZE_OF_GAS_3_DATA];
INT16 gas_4_data[MODBUS_SIZE_OF_GAS_4_DATA];
INT16 gas_5_data[MODBUS_SIZE_OF_GAS_5_DATA];
INT16 gas_6_data[MODBUS_SIZE_OF_GAS_6_DATA];
UINT16 gas_1_info[MODBUS_SIZE_OF_GAS_1_INFO];
UINT16 gas_2_info[MODBUS_SIZE_OF_GAS_2_INFO];
UINT16 gas_3_info[MODBUS_SIZE_OF_GAS_3_INFO];
UINT16 gas_4_info[MODBUS_SIZE_OF_GAS_4_INFO];
UINT16 gas_5_info[MODBUS_SIZE_OF_GAS_5_INFO];
UINT16 gas_6_info[MODBUS_SIZE_OF_GAS_6_INFO];

UINT32 GBu32_gas_1_raw_data_1_avg = 0;
UINT32 GBu32_gas_1_raw_data_2_avg = 0;
//UINT32 GBu32_gas_1_raw_data_3_avg = 0;
UINT32 GBu32_gas_2_raw_data_1_avg = 0;
UINT32 GBu32_gas_2_raw_data_2_avg = 0;
//UINT32 GBu32_gas_2_raw_data_3_avg = 0;
UINT32 GBu32_gas_3_raw_data_1_avg = 0;
UINT32 GBu32_gas_3_raw_data_2_avg = 0;
//UINT32 GBu32_gas_3_raw_data_3_avg = 0;
UINT32 GBu32_gas_4_raw_data_1_avg = 0;
UINT32 GBu32_gas_4_raw_data_2_avg = 0;
//UINT32 GBu32_gas_4_raw_data_3_avg = 0;
UINT32 GBu32_gas_5_raw_data_1_avg = 0;
UINT32 GBu32_gas_5_raw_data_2_avg = 0;
//UINT32 GBu32_gas_5_raw_data_3_avg = 0;
UINT32 GBu32_gas_6_raw_data_1_avg = 0;
UINT32 GBu32_gas_6_raw_data_2_avg = 0;
//UINT32 GBu32_gas_6_raw_data_3_avg = 0;

UINT16 GBu16_gas_1_concentrations_avg = 0;
UINT16 GBu16_gas_2_concentrations_avg = 0;
UINT16 GBu16_gas_3_concentrations_avg = 0;
UINT16 GBu16_gas_4_concentrations_avg = 0;
UINT16 GBu16_gas_5_concentrations_avg = 0;
UINT16 GBu16_gas_6_concentrations_avg = 0;

UINT64 GBgas_1_gas_bsn = 0;
UINT64 GBgas_2_gas_bsn = 0;
UINT64 GBgas_3_gas_bsn = 0;
UINT64 GBgas_4_gas_bsn = 0;
UINT64 GBgas_5_gas_bsn = 0;
UINT64 GBgas_6_gas_bsn = 0;

UINT64 GBgas_1_gas_name = 0;
UINT64 GBgas_2_gas_name = 0;
UINT64 GBgas_3_gas_name = 0;
UINT64 GBgas_4_gas_name = 0;
UINT64 GBgas_5_gas_name = 0;
UINT64 GBgas_6_gas_name = 0;

INT16 GBgas_1_tepmerature = 0;
INT16 GBgas_2_tepmerature = 0;
INT16 GBgas_3_tepmerature = 0;
INT16 GBgas_4_tepmerature = 0;
INT16 GBgas_5_tepmerature = 0;
INT16 GBgas_6_tepmerature = 0;


UINT32 sht_serial;
UINT16 global_Board_status = 0;

INT16 global_display_temperature = 0;
INT16 global_display_relatedHumi = 0;

#ifdef EUSCI_A0_UART_LOGGING
char UART_buf[200];
#endif

void sensors_init(void) {
#ifdef SHT3X  
  SHT3X_Init(0x44); // Address: 0x44 = Sensor on EvalBoard connector
#endif

#ifdef OUTDOOR_SHT2X  
  SHT2x_Init();
#endif

#ifdef EPA500_GASES
  // EPA500 gas board gas sensor reset control
  GPIO_setAsOutputPin(GPIO_PORT_P8, GPIO_PIN6 + GPIO_PIN7);
  GPIO_setAsOutputPin(GPIO_PORT_P1, GPIO_PIN1);
  // pull low to reset gas sensors
  GPIO_setOutputLowOnPin(GPIO_PORT_P8, GPIO_PIN6 + GPIO_PIN7);
  GPIO_setOutputLowOnPin(GPIO_PORT_P1, GPIO_PIN1);
  delay_micro_second(5000);  // delay 1ms
  // set as input to release the line
  GPIO_setAsInputPin(GPIO_PORT_P8, GPIO_PIN6 + GPIO_PIN7);
  GPIO_setAsInputPin(GPIO_PORT_P1, GPIO_PIN1);
  delay_micro_second(200000);  // delay 200ms for sensor to restart
#endif
}

////////////////////////////////////////////////////////////////////////////////
// update modbus info memory
////////////////////////////////////////////////////////////////////////////////
void update_modbus_info_registers(void) {
  UINT16 data[3];
  sht_fill_info_registers();
#ifdef EPA500_GASES
  gases_fill_info_registers();
#endif
  data[0] = info_fw_version;
  data[1] = info_sb_id_up;
  data[2] = info_sb_id_low;
  modbus_info_frame_update(data, MODBUS_OFFSET_BOARD_INFO, MODBUS_SIZE_OF_BOARD_INFO); 
}

////////////////////////////////////////////////////////////////////////////////
// Abstraction layer for rht sensor measurement
////////////////////////////////////////////////////////////////////////////////
void sht_fill_info_registers(void) {
  INT16 sht_serial_data[2];
  etError   error;       // error code
  
  memset(sht_serial_data,0x00,2);
  // read serial number and fill modbus info registers
  error = SHT3x_ReadSerialNumber(&sht_serial);
  sht_serial_data[0] = sht_serial >> 16;
  sht_serial_data[1] = sht_serial;
  if(error == NO_ERROR){
    modbus_info_frame_update(sht_serial_data, MODBUS_OFFSET_SHT3X_INFO, MODBUS_SIZE_OF_SHT3X_INFO);
  }
}

void measure_rht(void) {
  INT16 rht_data[2];
  etError   error;                      // error code

  // reset buffer
  memset(rht_data,0x00,2);
  // read RHT and fill modbus data registers
  error = SHT3X_GetTempAndHumi(&temperature, &humidity, REPEATAB_HIGH, MODE_POLLING, 50);   
  if(error != NO_ERROR){
    global_Board_status |= SHT_ERROR;   // mark SHT error
  }
  else {  // no error, record RH&T value
    global_Board_status &= ~SHT_ERROR;   // reset SHT error
    global_display_temperature = (INT16) (temperature * 100);
    global_display_relatedHumi = (INT16) (humidity * 100);
    rht_data[0] = global_display_relatedHumi;
    rht_data[1] = global_display_temperature;
#ifdef MODBUS_SLAVE
    modbus_data_frame_update(rht_data, MODBUS_OFFSET_SHT3X_DATA, MODBUS_SIZE_OF_SHT3X_DATA);
#endif
  }
}
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// update outdoor sht modbus data memory
////////////////////////////////////////////////////////////////////////////////
#ifdef OUTDOOR_SHT2X
void measure_outdoor_rht(void) {
  INT16 outdoor_rht_data[2];
  INT16 error;       // error code
  
  // reset buffer
  memset(outdoor_rht_data,0x00,2);
  // read RHT and fill modbus data registers
  error = SHT2x_readValue(); 
  if(error != NO_ERROR){
    global_Board_status |= OUTDOOR_SHT_ERROR;   // mark SHT error
  }
  else {  // no error, record RH&T value
    global_Board_status &= ~OUTDOOR_SHT_ERROR;   // reset SHT error    
    outdoor_rht_data[0] = SHT2x_Get_Humidity();
    outdoor_rht_data[1] = SHT2x_Get_Temperature();
    modbus_data_frame_update(outdoor_rht_data, MODBUS_OFFSET_OUTDOOR_SHT3X_DATA, MODBUS_SIZE_OF_OUTDOOR_SHT3X_DATA);
  }
}
#endif
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// Gases module routines
// -- Get raw ADC
// -- Fill Modbus data registers and reset average data/flag
// This routine is called inside modbus_reply_04(),
// PM value average until this routine is called
// After modbus data registers filled, reset buffer and re-init error code
// 
// Error handling: 
//      If it is not called after 1 min (Modbus master didn't request data)
//      plantower_reset_avg_data() must be called in task timer ISR, 
//      to reset buffer and error code to avoid long averaging
//
// Note: 
//      plantower_fill_data_registers() called in modbus_reply_04() (inside ISR)
//
////////////////////////////////////////////////////////////////////////////////
#ifdef EPA500_GASES
void measure_gases(void) {
  
  UINT32 LCgas_1_raw_data_1;
  UINT32 LCgas_1_raw_data_2;
  UINT16 LCgas_1_concentrations;
  UINT64 LCgas_1_gas_name;
  UINT64 LCgas_1_gas_bsn;
  
  UINT32 LCgas_2_raw_data_1;
  UINT32 LCgas_2_raw_data_2;
  UINT16 LCgas_2_concentrations;
  UINT64 LCgas_2_gas_name;
  UINT64 LCgas_2_gas_bsn;
  
  UINT32 LCgas_3_raw_data_1;
  UINT32 LCgas_3_raw_data_2;
  UINT16 LCgas_3_concentrations;
  UINT64 LCgas_3_gas_name;
  UINT64 LCgas_3_gas_bsn;
  
  UINT32 LCgas_4_raw_data_1;
  UINT32 LCgas_4_raw_data_2;
  UINT16 LCgas_4_concentrations;
  UINT64 LCgas_4_gas_name;
  UINT64 LCgas_4_gas_bsn;
  
  UINT32 LCgas_5_raw_data_1;
  UINT32 LCgas_5_raw_data_2;
  UINT16 LCgas_5_concentrations;
  UINT64 LCgas_5_gas_name;
  UINT64 LCgas_5_gas_bsn;

  UINT32 LCgas_6_raw_data_1;
  UINT32 LCgas_6_raw_data_2;
  UINT16 LCgas_6_concentrations;
  UINT64 LCgas_6_gas_name;
  UINT64 LCgas_6_gas_bsn;  

  INT16 err;
#ifdef GAS_1_ADDRESS  
//  //////////// get GAS_1 Gas Name ////////////////////////////
  err = aeclmg_get_gas_name(GAS_1_ADDRESS, &LCgas_1_gas_name);
  if(err == ERROR_NONE) {
    GBgas_1_gas_name = LCgas_1_gas_name;
    global_Board_status &= ~GAS_1_ERROR;
  }
  else {
    global_Board_status |= GAS_1_ERROR;
  }
  //////////// get GAS_1 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_1_ADDRESS, &LCgas_1_gas_bsn);
  if(err == ERROR_NONE) {
    GBgas_1_gas_bsn = LCgas_1_gas_bsn;
    global_Board_status &= ~GAS_1_ERROR;
  }
  else {
    global_Board_status |= GAS_1_ERROR;
  }
  //////////// get GAS_1 ADC 1 ///////////////////////////////
  err = aeclmg_getAdc_1(GAS_1_ADDRESS, &LCgas_1_raw_data_1);
  if(err == ERROR_NONE) {
    if(flag_Gas_1_raw_data_1_avg_init == 1) {  // data just read, do not average
      flag_Gas_1_raw_data_1_avg_init = 0;
      GBu32_gas_1_raw_data_1_avg = LCgas_1_raw_data_1;
    }
    else { //do average
      GBu32_gas_1_raw_data_1_avg = GBu32_gas_1_raw_data_1_avg/2 + LCgas_1_raw_data_1/2;
    }
    global_Board_status &= ~GAS_1_ERROR;
  }
  else {
    global_Board_status |= GAS_1_ERROR;
  }
  //////////// get GAS_1 ADC 2 ///////////////////////////////
  err = aeclmg_getAdc_2(GAS_1_ADDRESS, &LCgas_1_raw_data_2);
  if(err == ERROR_NONE) {
    if(flag_Gas_1_raw_data_2_avg_init == 1) {
      flag_Gas_1_raw_data_2_avg_init = 0;
      GBu32_gas_1_raw_data_2_avg = LCgas_1_raw_data_2;
    }
    else {
      GBu32_gas_1_raw_data_2_avg = GBu32_gas_1_raw_data_2_avg/2 + LCgas_1_raw_data_2/2;
    }
    global_Board_status &= ~GAS_1_ERROR;
  }
  else {
    global_Board_status |= GAS_1_ERROR;
  }
  //////////// get GAS_1 concentrations ///////////////////////////////
  err = aeclmg_get_gas_concentrations(GAS_1_ADDRESS, &LCgas_1_concentrations);
  if(err == ERROR_NONE) {
    if(flag_Gas_1_concentrations_avg_init == 1) {
      flag_Gas_1_concentrations_avg_init = 0;
      GBu16_gas_1_concentrations_avg = LCgas_1_concentrations;
    }
    else {
      GBu16_gas_1_concentrations_avg = GBu16_gas_1_concentrations_avg/2 + LCgas_1_concentrations/2;
    }
    global_Board_status &= ~GAS_1_ERROR;
  }
  else {
    global_Board_status |= GAS_1_ERROR;
  }
#endif  
#ifdef GAS_2_ADDRESS
//  //////////// get GAS_2 Gas Name ////////////////////////////
#ifdef ENABLE_WATCHDOG    
    WDT_A_resetTimer(WDT_A_BASE);
#endif
  err = aeclmg_get_gas_name(GAS_2_ADDRESS, &LCgas_2_gas_name);
  if(err == ERROR_NONE) {
    GBgas_2_gas_name = LCgas_2_gas_name;
    global_Board_status &= ~GAS_2_ERROR;
  }
  else {
    global_Board_status |= GAS_2_ERROR;
  }
  //////////// get GAS_2 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_2_ADDRESS, &LCgas_2_gas_bsn);
  if(err == ERROR_NONE) {
    GBgas_2_gas_bsn = LCgas_2_gas_bsn;
    global_Board_status &= ~GAS_2_ERROR;
  }
  else {
    global_Board_status |= GAS_2_ERROR;
  }
  //////////// get GAS_2 ADC 1 ///////////////////////////////
  err = aeclmg_getAdc_1(GAS_2_ADDRESS, &LCgas_2_raw_data_1);
  if(err == ERROR_NONE) {
    if(flag_Gas_2_raw_data_1_avg_init == 1) {  // data just read, do not average
      flag_Gas_2_raw_data_1_avg_init = 0;
      GBu32_gas_2_raw_data_1_avg = LCgas_2_raw_data_1;
    }
    else { //do average
      GBu32_gas_2_raw_data_1_avg = GBu32_gas_2_raw_data_1_avg/2 + LCgas_2_raw_data_1/2;
    }
    global_Board_status &= ~GAS_2_ERROR;
  }
  else {
    global_Board_status |= GAS_2_ERROR;
  }
  //////////// get GAS_2 ADC 2 ///////////////////////////////
  err = aeclmg_getAdc_2(GAS_2_ADDRESS, &LCgas_2_raw_data_2);
  if(err == ERROR_NONE) {
    if(flag_Gas_2_raw_data_2_avg_init == 1) {
      flag_Gas_2_raw_data_2_avg_init = 0;
      GBu32_gas_2_raw_data_2_avg = LCgas_2_raw_data_2;
    }
    else {
      GBu32_gas_2_raw_data_2_avg = GBu32_gas_2_raw_data_2_avg/2 + LCgas_2_raw_data_2/2;
    }
    global_Board_status &= ~GAS_2_ERROR;
  }
  else {
    global_Board_status |= GAS_2_ERROR;
  }
  //////////// get GAS_2 concentrations ///////////////////////////////
  err = aeclmg_get_gas_concentrations(GAS_2_ADDRESS, &LCgas_2_concentrations);
 
  if(err == ERROR_NONE) {
    if(flag_Gas_2_concentrations_avg_init == 1) {
      flag_Gas_2_concentrations_avg_init = 0;
      GBu16_gas_2_concentrations_avg = LCgas_2_concentrations;
    }
    else {
      GBu16_gas_2_concentrations_avg = GBu16_gas_2_concentrations_avg/2 + LCgas_2_concentrations/2;
    }
    global_Board_status &= ~GAS_2_ERROR;
  }
  else {
    global_Board_status |= GAS_2_ERROR;
  }
#endif  
#ifdef GAS_3_ADDRESS
//  //////////// get GAS_3 Gas Name ////////////////////////////
#ifdef ENABLE_WATCHDOG    
    WDT_A_resetTimer(WDT_A_BASE);
#endif
  err = aeclmg_get_gas_name(GAS_3_ADDRESS, &LCgas_3_gas_name);
  if(err == ERROR_NONE) {
    GBgas_3_gas_name = LCgas_3_gas_name;
    global_Board_status &= ~GAS_3_ERROR;
  }
  else {
    global_Board_status |= GAS_3_ERROR;
  }
  //////////// get GAS_3 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_3_ADDRESS, &LCgas_3_gas_bsn);
  if(err == ERROR_NONE) {
    GBgas_3_gas_bsn = LCgas_3_gas_bsn;
    global_Board_status &= ~GAS_3_ERROR;
  }
  else {
    global_Board_status |= GAS_3_ERROR;
  }
  //////////// get GAS_3 ADC 1 ///////////////////////////////
  err = aeclmg_getAdc_1(GAS_3_ADDRESS, &LCgas_3_raw_data_1);
  if(err == ERROR_NONE) {
    if(flag_Gas_3_raw_data_1_avg_init == 1) {  // data just read, do not average
      flag_Gas_3_raw_data_1_avg_init = 0;
      GBu32_gas_3_raw_data_1_avg = LCgas_3_raw_data_1;
    }
    else { //do average
      GBu32_gas_3_raw_data_1_avg = GBu32_gas_3_raw_data_1_avg/2 + LCgas_3_raw_data_1/2;
    }
    global_Board_status &= ~GAS_3_ERROR;
  }
  else {
    global_Board_status |= GAS_3_ERROR;
  }
  //////////// get GAS_3 ADC 2 ///////////////////////////////
  err = aeclmg_getAdc_2(GAS_3_ADDRESS, &LCgas_3_raw_data_2);
  if(err == ERROR_NONE) {
    if(flag_Gas_3_raw_data_2_avg_init == 1) {
      flag_Gas_3_raw_data_2_avg_init = 0;
      GBu32_gas_3_raw_data_2_avg = LCgas_3_raw_data_2;
    }
    else {
      GBu32_gas_3_raw_data_2_avg = GBu32_gas_3_raw_data_2_avg/2 + LCgas_3_raw_data_2/2;
    }
    global_Board_status &= ~GAS_3_ERROR;
  }
  else {
    global_Board_status |= GAS_3_ERROR;
  }
  //////////// get GAS_3 concentrations ///////////////////////////////
  err = aeclmg_get_gas_concentrations(GAS_3_ADDRESS, &LCgas_3_concentrations);
  if(err == ERROR_NONE) {
    if(flag_Gas_3_concentrations_avg_init == 1) {
      flag_Gas_3_concentrations_avg_init = 0;
      GBu16_gas_3_concentrations_avg = LCgas_3_concentrations;
    }
    else {
      GBu16_gas_3_concentrations_avg = GBu16_gas_3_concentrations_avg/2 + LCgas_3_concentrations/2;
    }
    global_Board_status &= ~GAS_3_ERROR;
  }
  else {
    global_Board_status |= GAS_3_ERROR;
  }
#endif  
#ifdef GAS_4_ADDRESS
//  //////////// get GAS_4 Gas Name ////////////////////////////
#ifdef ENABLE_WATCHDOG    
    WDT_A_resetTimer(WDT_A_BASE);
#endif
  err = aeclmg_get_gas_name(GAS_4_ADDRESS, &LCgas_4_gas_name);
  if(err == ERROR_NONE) {
    GBgas_4_gas_name = LCgas_4_gas_name;
    global_Board_status &= ~GAS_4_ERROR;
  }
  else {
    global_Board_status |= GAS_4_ERROR;
  }
  //////////// get GAS_4 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_4_ADDRESS, &LCgas_4_gas_bsn);
  if(err == ERROR_NONE) {
    GBgas_4_gas_bsn = LCgas_4_gas_bsn;
    global_Board_status &= ~GAS_4_ERROR;
  }
  else {
    global_Board_status |= GAS_4_ERROR;
  }
  //////////// get GAS_4 ADC 1 ///////////////////////////////
  err = aeclmg_getAdc_1(GAS_4_ADDRESS, &LCgas_4_raw_data_1);
  if(err == ERROR_NONE) {
    if(flag_Gas_4_raw_data_1_avg_init == 1) {  // data just read, do not average
      flag_Gas_4_raw_data_1_avg_init = 0;
      GBu32_gas_4_raw_data_1_avg = LCgas_4_raw_data_1;
    }
    else { //do average
      GBu32_gas_4_raw_data_1_avg = GBu32_gas_4_raw_data_1_avg/2 + LCgas_4_raw_data_1/2;
    }
    global_Board_status &= ~GAS_4_ERROR;
  }
  else {
    global_Board_status |= GAS_4_ERROR;
  }
  //////////// get GAS_4 ADC 2 ///////////////////////////////
  err = aeclmg_getAdc_2(GAS_4_ADDRESS, &LCgas_4_raw_data_2);
  if(err == ERROR_NONE) {
    if(flag_Gas_4_raw_data_2_avg_init == 1) {
      flag_Gas_4_raw_data_2_avg_init = 0;
      GBu32_gas_4_raw_data_2_avg = LCgas_4_raw_data_2;
    }
    else {
      GBu32_gas_4_raw_data_2_avg = GBu32_gas_4_raw_data_2_avg/2 + LCgas_4_raw_data_2/2;
    }
    global_Board_status &= ~GAS_4_ERROR;
  }
  else {
    global_Board_status |= GAS_4_ERROR;
  }
  //////////// get GAS_4 concentrations ///////////////////////////////
  err = aeclmg_get_gas_concentrations(GAS_4_ADDRESS, &LCgas_4_concentrations);
  if(err == ERROR_NONE) {
    if(flag_Gas_4_concentrations_avg_init == 1) {
      flag_Gas_4_concentrations_avg_init = 0;
      GBu16_gas_4_concentrations_avg = LCgas_4_concentrations;
    }
    else {
      GBu16_gas_4_concentrations_avg = GBu16_gas_4_concentrations_avg/2 + LCgas_4_concentrations/2;
    }
    global_Board_status &= ~GAS_4_ERROR;
  }
  else {
    global_Board_status |= GAS_4_ERROR;
  }
#endif  
#ifdef GAS_5_ADDRESS
//  //////////// get GAS_5 Gas Name ////////////////////////////
#ifdef ENABLE_WATCHDOG    
    WDT_A_resetTimer(WDT_A_BASE);
#endif
  err = aeclmg_get_gas_name(GAS_5_ADDRESS, &LCgas_5_gas_name);
  if(err == ERROR_NONE) {
    GBgas_5_gas_name = LCgas_5_gas_name;
    global_Board_status &= ~GAS_5_ERROR;
  }
  else {
    global_Board_status |= GAS_5_ERROR;
  }
  //////////// get GAS_5 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_5_ADDRESS, &LCgas_5_gas_bsn);
  if(err == ERROR_NONE) {
    GBgas_5_gas_bsn = LCgas_5_gas_bsn;
    global_Board_status &= ~GAS_5_ERROR;
  }
  else {
    global_Board_status |= GAS_5_ERROR;
  }
  //////////// get GAS_5 ADC 1 ///////////////////////////////
  err = aeclmg_getAdc_1(GAS_5_ADDRESS, &LCgas_5_raw_data_1);
  if(err == ERROR_NONE) {
    if(flag_Gas_5_raw_data_1_avg_init == 1) {  // data just read, do not average
      flag_Gas_5_raw_data_1_avg_init = 0;
      GBu32_gas_5_raw_data_1_avg = LCgas_5_raw_data_1;
    }
    else { //do average
      GBu32_gas_5_raw_data_1_avg = GBu32_gas_5_raw_data_1_avg/2 + LCgas_5_raw_data_1/2;
    }
    global_Board_status &= ~GAS_5_ERROR;
  }
  else {
    global_Board_status |= GAS_4_ERROR;
  }
  //////////// get GAS_5 ADC 2 ///////////////////////////////
  err = aeclmg_getAdc_2(GAS_5_ADDRESS, &LCgas_5_raw_data_2);
  if(err == ERROR_NONE) {
    if(flag_Gas_5_raw_data_2_avg_init == 1) {
      flag_Gas_5_raw_data_2_avg_init = 0;
      GBu32_gas_5_raw_data_2_avg = LCgas_5_raw_data_2;
    }
    else {
      GBu32_gas_5_raw_data_2_avg = GBu32_gas_5_raw_data_2_avg/2 + LCgas_5_raw_data_2/2;
    }
    global_Board_status &= ~GAS_5_ERROR;
  }
  else {
    global_Board_status |= GAS_5_ERROR;
  }
  //////////// get GAS_5 concentrations ///////////////////////////////
  err = aeclmg_get_gas_concentrations(GAS_5_ADDRESS, &LCgas_5_concentrations);
  if(err == ERROR_NONE) {
    if(flag_Gas_5_concentrations_avg_init == 1) {
      flag_Gas_5_concentrations_avg_init = 0;
      GBu16_gas_5_concentrations_avg = LCgas_5_concentrations;
    }
    else {
      GBu16_gas_5_concentrations_avg = GBu16_gas_5_concentrations_avg/2 + LCgas_5_concentrations/2;
    }
    global_Board_status &= ~GAS_5_ERROR;
  }
  else {
    global_Board_status |= GAS_5_ERROR;
  }
#endif  
#ifdef GAS_6_ADDRESS
//  //////////// get GAS_6 Gas Name ////////////////////////////
#ifdef ENABLE_WATCHDOG    
    WDT_A_resetTimer(WDT_A_BASE);
#endif
  err = aeclmg_get_gas_name(GAS_6_ADDRESS, &LCgas_6_gas_name);
  if(err == ERROR_NONE) {
    GBgas_6_gas_name = LCgas_6_gas_name;
    global_Board_status &= ~GAS_6_ERROR;
  }
  else {
    global_Board_status |= GAS_6_ERROR;
  }
  //////////// get GAS_6 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_6_ADDRESS, &LCgas_6_gas_bsn);
  if(err == ERROR_NONE) {
    GBgas_6_gas_bsn = LCgas_6_gas_bsn;
    global_Board_status &= ~GAS_6_ERROR;
  }
  else {
    global_Board_status |= GAS_6_ERROR;
  }
  //////////// get GAS_6 ADC 1 ///////////////////////////////
  err = aeclmg_getAdc_1(GAS_6_ADDRESS, &LCgas_6_raw_data_1);
  if(err == ERROR_NONE) {
    if(flag_Gas_6_raw_data_1_avg_init == 1) {  // data just read, do not average
      flag_Gas_6_raw_data_1_avg_init = 0;
      GBu32_gas_6_raw_data_1_avg = LCgas_6_raw_data_1;
    }
    else { //do average
      GBu32_gas_6_raw_data_1_avg = GBu32_gas_6_raw_data_1_avg/2 + LCgas_6_raw_data_1/2;
    }
    global_Board_status &= ~GAS_6_ERROR;
  }
  else {
    global_Board_status |= GAS_6_ERROR;
  }
  //////////// get GAS_6 ADC 2 ///////////////////////////////
  err = aeclmg_getAdc_2(GAS_6_ADDRESS, &LCgas_6_raw_data_2);
  if(err == ERROR_NONE) {
    if(flag_Gas_6_raw_data_2_avg_init == 1) {
      flag_Gas_6_raw_data_2_avg_init = 0;
      GBu32_gas_6_raw_data_2_avg = LCgas_6_raw_data_2;
    }
    else {
      GBu32_gas_6_raw_data_2_avg = GBu32_gas_6_raw_data_2_avg/2 + LCgas_6_raw_data_2/2;
    }
    global_Board_status &= ~GAS_6_ERROR;
  }
  else {
    global_Board_status |= GAS_6_ERROR;
  }
  //////////// get GAS_6 concentrations ///////////////////////////////
  err = aeclmg_get_gas_concentrations(GAS_6_ADDRESS, &LCgas_6_concentrations);
  if(err == ERROR_NONE) {
    if(flag_Gas_6_concentrations_avg_init == 1) {
      flag_Gas_6_concentrations_avg_init = 0;
      GBu16_gas_6_concentrations_avg = LCgas_6_concentrations;
    }
    else {
      GBu16_gas_6_concentrations_avg = GBu16_gas_6_concentrations_avg/2 + LCgas_6_concentrations/2;
    }
    global_Board_status &= ~GAS_6_ERROR;
  }
  else {
    global_Board_status |= GAS_6_ERROR;
  }  
#endif  
}

void gases_reset_avg_data() {
  memset(gas_1_data, 0x00, MODBUS_SIZE_OF_GAS_1_DATA);
  memset(gas_2_data, 0x00, MODBUS_SIZE_OF_GAS_2_DATA);
  memset(gas_3_data, 0x00, MODBUS_SIZE_OF_GAS_3_DATA);
  memset(gas_4_data, 0x00, MODBUS_SIZE_OF_GAS_4_DATA);
  memset(gas_5_data, 0x00, MODBUS_SIZE_OF_GAS_5_DATA);
  memset(gas_6_data, 0x00, MODBUS_SIZE_OF_GAS_6_DATA);
   
  GBu32_gas_1_raw_data_1_avg = 0;
  GBu32_gas_1_raw_data_2_avg = 0;
//  Gas_1_raw_data_3_avg = 0;
  GBu32_gas_2_raw_data_1_avg = 0;
  GBu32_gas_2_raw_data_2_avg = 0;
//  Gas_2_raw_data_3_avg = 0;
  GBu32_gas_3_raw_data_1_avg = 0;
  GBu32_gas_3_raw_data_2_avg = 0;
//  Gas_3_raw_data_3_avg = 0;
  GBu32_gas_4_raw_data_1_avg = 0;
  GBu32_gas_4_raw_data_2_avg = 0;
//  Gas_4_raw_data_3_avg = 0;
  GBu32_gas_5_raw_data_1_avg = 0;
  GBu32_gas_5_raw_data_2_avg = 0;
//  Gas_5_raw_data_3_avg = 0;
  GBu32_gas_6_raw_data_1_avg = 0;
  GBu32_gas_6_raw_data_2_avg = 0;
//  Gas_6_raw_data_3_avg = 0;  
  
  GBu16_gas_1_concentrations_avg = 0;
  GBu16_gas_2_concentrations_avg = 0;
  GBu16_gas_3_concentrations_avg = 0;
  GBu16_gas_4_concentrations_avg = 0;
  GBu16_gas_5_concentrations_avg = 0;
  GBu16_gas_6_concentrations_avg = 0;  
  
  flag_Gas_1_raw_data_1_avg_init = 1;
  flag_Gas_1_raw_data_2_avg_init = 1;
//  flag_Gas_1_raw_data_3_avg_init = 1;
  flag_Gas_2_raw_data_1_avg_init = 1;
  flag_Gas_2_raw_data_2_avg_init = 1;
//  flag_Gas_2_raw_data_3_avg_init = 1;
  flag_Gas_3_raw_data_1_avg_init = 1;
  flag_Gas_3_raw_data_2_avg_init = 1;
//  flag_Gas_3_raw_data_3_avg_init = 1;
  flag_Gas_4_raw_data_1_avg_init = 1;
  flag_Gas_4_raw_data_2_avg_init = 1;
//  flag_Gas_4_raw_data_3_avg_init = 1;
  flag_Gas_5_raw_data_1_avg_init = 1;
  flag_Gas_5_raw_data_2_avg_init = 1;
//  flag_Gas_5_raw_data_3_avg_init = 1;
  flag_Gas_6_raw_data_1_avg_init = 1;
  flag_Gas_6_raw_data_2_avg_init = 1;
//  flag_Gas_6_raw_data_3_avg_init = 1;
  
  flag_Gas_1_concentrations_avg_init = 1;
  flag_Gas_2_concentrations_avg_init = 1;
  flag_Gas_3_concentrations_avg_init = 1;
  flag_Gas_4_concentrations_avg_init = 1;
  flag_Gas_5_concentrations_avg_init = 1;
  flag_Gas_6_concentrations_avg_init = 1;  

  global_Board_status &= ~GAS_6_ERROR;       //reset crc error bit
  global_Board_status &= ~GAS_5_ERROR;       //reset crc error bit
  global_Board_status &= ~GAS_4_ERROR;       //reset crc error bit
  global_Board_status &= ~GAS_3_ERROR;       //reset crc error bit  
  global_Board_status &= ~GAS_2_ERROR;       //reset crc error bit
  global_Board_status &= ~GAS_1_ERROR;       //reset crc error bit
  global_Board_status &= ~Gases_I2C_ERROR;   //reset I2C Error bit      
}


void gases_fill_data_registers() {
#ifdef GAS_1_ADDRESS    
  gas_1_data[0] = (GBgas_1_gas_name >> 48);
  gas_1_data[1] = (GBgas_1_gas_name >> 32);
  gas_1_data[2] = (GBgas_1_gas_name >> 16);
  gas_1_data[3] = GBgas_1_gas_name;
  gas_1_data[4] = (GBgas_1_gas_bsn >> 48);
  gas_1_data[5] = (GBgas_1_gas_bsn >> 32);
  gas_1_data[6] = (GBgas_1_gas_bsn >> 16);
  gas_1_data[7] = (GBu32_gas_1_raw_data_1_avg >> 16);
  gas_1_data[8] = GBu32_gas_1_raw_data_1_avg;
  gas_1_data[9] = (GBu32_gas_1_raw_data_2_avg >> 16);
  gas_1_data[10] = GBu32_gas_1_raw_data_2_avg;
  gas_1_data[11] = 0; //adc 3
  gas_1_data[12] = 0; //adc 3
#if (GAS_1_ADDRESS == AL_O3_ADDRESS)
  if(GBu16_gas_1_concentrations_avg >= GBu16_gas_2_concentrations_avg){
    gas_1_data[13] = GBu16_gas_1_concentrations_avg - GBu16_gas_2_concentrations_avg;
  }
  else{
    gas_1_data[13] = 0;
  }
#else
  gas_1_data[13] = GBu16_gas_2_concentrations_avg;
#endif
  gas_1_data[14] = 0;//GBgas_1_tepmerature; 
  modbus_data_frame_update(gas_1_data, MODBUS_OFFSET_GAS_1_DATA, MODBUS_SIZE_OF_GAS_1_DATA);
#endif  
#ifdef GAS_2_ADDRESS
  gas_2_data[0] = (GBgas_2_gas_name >> 48);
  gas_2_data[1] = (GBgas_2_gas_name >> 32);
  gas_2_data[2] = (GBgas_2_gas_name >> 16);
  gas_2_data[3] = GBgas_2_gas_name;
  gas_2_data[4] = (GBgas_2_gas_bsn >> 48);
  gas_2_data[5] = (GBgas_2_gas_bsn >> 32);
  gas_2_data[6] = (GBgas_2_gas_bsn >> 16);
  gas_2_data[7] = (GBu32_gas_2_raw_data_1_avg >> 16);
  gas_2_data[8] = GBu32_gas_2_raw_data_1_avg;
  gas_2_data[9] = (GBu32_gas_2_raw_data_2_avg >> 16);
  gas_2_data[10] = GBu32_gas_2_raw_data_2_avg;
  gas_2_data[11] = 0; //adc 3
  gas_2_data[12] = 0; //adc 3
#if (GAS_2_ADDRESS == AL_O3_ADDRESS)
  if(GBu16_gas_2_concentrations_avg >= GBu16_gas_1_concentrations_avg){
    gas_2_data[13] = GBu16_gas_2_concentrations_avg - GBu16_gas_1_concentrations_avg;
  }
  else{
    gas_2_data[13] = 0;
  }
#else
  gas_2_data[13] = GBu16_gas_2_concentrations_avg;
#endif
  gas_2_data[14] = 0;//GBgas_2_tepmerature; 
  modbus_data_frame_update(gas_2_data, MODBUS_OFFSET_GAS_2_DATA, MODBUS_SIZE_OF_GAS_2_DATA);
#endif  
#ifdef GAS_3_ADDRESS
  gas_3_data[0] = (GBgas_3_gas_name >> 48);
  gas_3_data[1] = (GBgas_3_gas_name >> 32);
  gas_3_data[2] = (GBgas_3_gas_name >> 16);
  gas_3_data[3] = GBgas_3_gas_name;
  gas_3_data[4] = (GBgas_3_gas_bsn >> 48);
  gas_3_data[5] = (GBgas_3_gas_bsn >> 32);
  gas_3_data[6] = (GBgas_3_gas_bsn >> 16);
  gas_3_data[7] = (GBu32_gas_3_raw_data_1_avg >> 16);
  gas_3_data[8] = GBu32_gas_3_raw_data_1_avg;
  gas_3_data[9] = (GBu32_gas_3_raw_data_2_avg >> 16);
  gas_3_data[10] = GBu32_gas_3_raw_data_2_avg;
  gas_3_data[11] = 0; //adc 3
  gas_3_data[12] = 0; //adc 3
  gas_3_data[13] = GBu16_gas_3_concentrations_avg;
  gas_3_data[14] = 0;//GBgas_3_tepmerature; 
  modbus_data_frame_update(gas_3_data, MODBUS_OFFSET_GAS_3_DATA, MODBUS_SIZE_OF_GAS_3_DATA);
#endif  
#ifdef GAS_4_ADDRESS
  gas_4_data[0] = (GBgas_4_gas_name >> 48);
  gas_4_data[1] = (GBgas_4_gas_name >> 32);
  gas_4_data[2] = (GBgas_4_gas_name >> 16);
  gas_4_data[3] = GBgas_4_gas_name;
  gas_4_data[4] = (GBgas_4_gas_bsn >> 48);
  gas_4_data[5] = (GBgas_4_gas_bsn >> 32);
  gas_4_data[6] = (GBgas_4_gas_bsn >> 16);
  gas_4_data[7] = (GBu32_gas_4_raw_data_1_avg >> 16);
  gas_4_data[8] = GBu32_gas_4_raw_data_1_avg;
  gas_4_data[9] = (GBu32_gas_4_raw_data_2_avg >> 16);
  gas_4_data[10] = GBu32_gas_4_raw_data_2_avg;
  gas_4_data[11] = 0; //adc 3
  gas_4_data[12] = 0; //adc 3
  gas_4_data[13] = GBu16_gas_4_concentrations_avg;
  gas_4_data[14] = 0;//GBgas_4_tepmerature; 
  modbus_data_frame_update(gas_4_data, MODBUS_OFFSET_GAS_4_DATA, MODBUS_SIZE_OF_GAS_4_DATA);
#endif  
#ifdef GAS_5_ADDRESS
  gas_5_data[0] = (GBgas_5_gas_name >> 48);
  gas_5_data[1] = (GBgas_5_gas_name >> 32);
  gas_5_data[2] = (GBgas_5_gas_name >> 16);
  gas_5_data[3] = GBgas_5_gas_name;
  gas_5_data[4] = (GBgas_5_gas_bsn >> 48);
  gas_5_data[5] = (GBgas_5_gas_bsn >> 32);
  gas_5_data[6] = (GBgas_5_gas_bsn >> 16);
  gas_5_data[7] = (GBu32_gas_5_raw_data_1_avg >> 16);
  gas_5_data[8] = GBu32_gas_5_raw_data_1_avg;
  gas_5_data[9] = (GBu32_gas_5_raw_data_2_avg >> 16);
  gas_5_data[10] = GBu32_gas_5_raw_data_2_avg;
  gas_5_data[11] = 0; //adc 3
  gas_5_data[12] = 0; //adc 3
  gas_5_data[13] = GBu16_gas_5_concentrations_avg;
  gas_5_data[14] = 0;//GBgas_5_tepmerature; 
  modbus_data_frame_update(gas_5_data, MODBUS_OFFSET_GAS_5_DATA, MODBUS_SIZE_OF_GAS_5_DATA);
#endif  
#ifdef GAS_6_ADDRESS
  gas_6_data[0] = (GBgas_6_gas_name >> 48);
  gas_6_data[1] = (GBgas_6_gas_name >> 32);
  gas_6_data[2] = (GBgas_6_gas_name >> 16);
  gas_6_data[3] = GBgas_6_gas_name;
  gas_6_data[4] = (GBgas_6_gas_bsn >> 48);
  gas_6_data[5] = (GBgas_6_gas_bsn >> 32);
  gas_6_data[6] = (GBgas_6_gas_bsn >> 16);
  gas_6_data[7] = (GBu32_gas_6_raw_data_1_avg >> 16);
  gas_6_data[8] = GBu32_gas_6_raw_data_1_avg;
  gas_6_data[9] = (GBu32_gas_6_raw_data_2_avg >> 16);
  gas_6_data[10] = GBu32_gas_6_raw_data_2_avg;
  gas_6_data[11] = 0; //adc 3
  gas_6_data[12] = 0; //adc 3
  gas_6_data[13] = GBu16_gas_6_concentrations_avg;
  gas_6_data[14] = 0;//GBgas_6_tepmerature; 
  modbus_data_frame_update(gas_6_data, MODBUS_OFFSET_GAS_6_DATA, MODBUS_SIZE_OF_GAS_6_DATA);  
#endif  
  gases_reset_avg_data();//check
}

void gases_fill_info_registers(void) {

  UINT64 LCgas_1_gas_name;
  UINT64 LCgas_1_gas_bsn;
  UINT64 LCgas_2_gas_name;
  UINT64 LCgas_2_gas_bsn;
  UINT64 LCgas_3_gas_name;
  UINT64 LCgas_3_gas_bsn;
  UINT64 LCgas_4_gas_name;
  UINT64 LCgas_4_gas_bsn;
  UINT64 LCgas_5_gas_name;
  UINT64 LCgas_5_gas_bsn;
  UINT64 LCgas_6_gas_name;
  UINT64 LCgas_6_gas_bsn;  
  INT16 err;
  UINT16 fw_version =0;
  
#ifdef GAS_1_ADDRESS    
  ///////////// get gas_1 module info ////////////////////////////////////
  err = aeclmg_get_fw_version(GAS_1_ADDRESS,&fw_version);
  if(err == ERROR_NONE) {
    gas_1_info[GAS_FW_VER_INFO] = fw_version;
  }
  err = aeclmg_get_cal_date(GAS_1_ADDRESS, gas_1_info);
  if(err == ERROR_NONE) {
    modbus_info_frame_update(gas_1_info, MODBUS_OFFSET_GAS_1_INFO, MODBUS_SIZE_OF_GAS_1_INFO);
  }
  ////////////// get GAS_1 Gas Name ////////////////////////////
  err = aeclmg_get_gas_name(GAS_1_ADDRESS, &LCgas_1_gas_name);
  if(err == ERROR_NONE) {
    gas_1_info[GAS_GASNAME_INFO] = (LCgas_1_gas_name >> 48);
    gas_1_info[GAS_GASNAME_INFO+1] = (LCgas_1_gas_name >> 32);
    gas_1_info[GAS_GASNAME_INFO+2] = (LCgas_1_gas_name >> 16);
    gas_1_info[GAS_GASNAME_INFO+3] = LCgas_1_gas_name;
    modbus_info_frame_update(gas_1_info, MODBUS_OFFSET_GAS_1_INFO, MODBUS_SIZE_OF_GAS_1_INFO);
    global_Board_status &= ~GAS_1_ERROR;
  }
  else {
    global_Board_status |= GAS_1_ERROR;
  }
  //////////// get GAS_1 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_1_ADDRESS, &LCgas_1_gas_bsn);
  if(err == ERROR_NONE) {
    gas_1_info[GAS_BSN_INFO] = (LCgas_1_gas_bsn >> 48);
    gas_1_info[GAS_BSN_INFO+1] = (LCgas_1_gas_bsn >> 32);
    gas_1_info[GAS_BSN_INFO+2] = (LCgas_1_gas_bsn >> 16);
    modbus_info_frame_update(gas_1_info, MODBUS_OFFSET_GAS_1_INFO, MODBUS_SIZE_OF_GAS_1_INFO);
    global_Board_status &= ~GAS_1_ERROR;
  }
  else {
    global_Board_status |= GAS_1_ERROR;
  }
#endif  
#ifdef GAS_2_ADDRESS   
  fw_version = 0;
  ///////////// get gas_2 module info ////////////////////////////////////
  err = aeclmg_get_fw_version(GAS_2_ADDRESS,&fw_version);
  if(err == ERROR_NONE) {
    gas_2_info[GAS_FW_VER_INFO] = fw_version;
  }
  err = aeclmg_get_cal_date(GAS_2_ADDRESS, gas_2_info);
  if(err == ERROR_NONE) {
    modbus_info_frame_update(gas_2_info, MODBUS_OFFSET_GAS_2_INFO, MODBUS_SIZE_OF_GAS_2_INFO);
  }
  ////////////// get GAS_2 Gas Name ////////////////////////////
  err = aeclmg_get_gas_name(GAS_2_ADDRESS, &LCgas_2_gas_name);
  if(err == ERROR_NONE) {
    gas_2_info[GAS_GASNAME_INFO] = (LCgas_2_gas_name >> 48);
    gas_2_info[GAS_GASNAME_INFO+1] = (LCgas_2_gas_name >> 32);
    gas_2_info[GAS_GASNAME_INFO+2] = (LCgas_2_gas_name >> 16);
    gas_2_info[GAS_GASNAME_INFO+3] = LCgas_2_gas_name;
    modbus_info_frame_update(gas_2_info, MODBUS_OFFSET_GAS_2_INFO, MODBUS_SIZE_OF_GAS_2_INFO);
    global_Board_status &= ~GAS_2_ERROR;
  }
  else {
    global_Board_status |= GAS_2_ERROR;
  }
  //////////// get GAS_2 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_2_ADDRESS, &LCgas_2_gas_bsn);
  if(err == ERROR_NONE) {
    gas_2_info[GAS_BSN_INFO] = (LCgas_2_gas_bsn >> 48);
    gas_2_info[GAS_BSN_INFO+1] = (LCgas_2_gas_bsn >> 32);
    gas_2_info[GAS_BSN_INFO+2] = (LCgas_2_gas_bsn >> 16);
    modbus_info_frame_update(gas_2_info, MODBUS_OFFSET_GAS_2_INFO, MODBUS_SIZE_OF_GAS_2_INFO);
    global_Board_status &= ~GAS_2_ERROR;
  }
  else {
    global_Board_status |= GAS_2_ERROR;
  }
#endif  
#ifdef GAS_3_ADDRESS   
  fw_version = 0;
  ///////////// get gas_3 module info ////////////////////////////////////
  err = aeclmg_get_fw_version(GAS_3_ADDRESS,&fw_version);
  if(err == ERROR_NONE) {
    gas_3_info[GAS_FW_VER_INFO] = fw_version;
  }
  err = aeclmg_get_cal_date(GAS_3_ADDRESS, gas_3_info);
  if(err == ERROR_NONE) {
    modbus_info_frame_update(gas_3_info, MODBUS_OFFSET_GAS_3_INFO, MODBUS_SIZE_OF_GAS_3_INFO);
  }
  ////////////// get GAS_3 Gas Name ////////////////////////////
  err = aeclmg_get_gas_name(GAS_3_ADDRESS, &LCgas_3_gas_name);
  if(err == ERROR_NONE) {
    gas_3_info[GAS_GASNAME_INFO] = (LCgas_3_gas_name >> 48);
    gas_3_info[GAS_GASNAME_INFO+1] = (LCgas_3_gas_name >> 32);
    gas_3_info[GAS_GASNAME_INFO+2] = (LCgas_3_gas_name >> 16);
    gas_3_info[GAS_GASNAME_INFO+3] = LCgas_3_gas_name;
    modbus_info_frame_update(gas_3_info, MODBUS_OFFSET_GAS_3_INFO, MODBUS_SIZE_OF_GAS_3_INFO);
    global_Board_status &= ~GAS_3_ERROR;
  }
  else {
    global_Board_status |= GAS_3_ERROR;
  }
  //////////// get GAS_3 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_3_ADDRESS, &LCgas_3_gas_bsn);
  if(err == ERROR_NONE) {
    gas_3_info[GAS_BSN_INFO] = (LCgas_3_gas_bsn >> 48);
    gas_3_info[GAS_BSN_INFO+1] = (LCgas_3_gas_bsn >> 32);
    gas_3_info[GAS_BSN_INFO+2] = (LCgas_3_gas_bsn >> 16);
    modbus_info_frame_update(gas_3_info, MODBUS_OFFSET_GAS_3_INFO, MODBUS_SIZE_OF_GAS_3_INFO);
    global_Board_status &= ~GAS_3_ERROR;
  }
  else {
    global_Board_status |= GAS_3_ERROR;
  }
#endif  
#ifdef GAS_4_ADDRESS
  fw_version = 0;
  ///////////// get gas_4 module info ////////////////////////////////////
  err = aeclmg_get_fw_version(GAS_4_ADDRESS,&fw_version);
  if(err == ERROR_NONE) {
    gas_4_info[GAS_FW_VER_INFO] = fw_version;
  }
  err = aeclmg_get_cal_date(GAS_4_ADDRESS, gas_4_info);
  if(err == ERROR_NONE) {
    modbus_info_frame_update(gas_4_info, MODBUS_OFFSET_GAS_4_INFO, MODBUS_SIZE_OF_GAS_4_INFO);
  }
  ////////////// get GAS_4 Gas Name ////////////////////////////
  err = aeclmg_get_gas_name(GAS_4_ADDRESS, &LCgas_4_gas_name);
  if(err == ERROR_NONE) {
    gas_4_info[GAS_GASNAME_INFO] = (LCgas_4_gas_name >> 48);
    gas_4_info[GAS_GASNAME_INFO+1] = (LCgas_4_gas_name >> 32);
    gas_4_info[GAS_GASNAME_INFO+2] = (LCgas_4_gas_name >> 16);
    gas_4_info[GAS_GASNAME_INFO+3] = LCgas_4_gas_name;
    modbus_info_frame_update(gas_4_info, MODBUS_OFFSET_GAS_4_INFO, MODBUS_SIZE_OF_GAS_4_INFO);
    global_Board_status &= ~GAS_4_ERROR;
  }
  else {
    global_Board_status |= GAS_4_ERROR;
  }
  //////////// get GAS_4 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_4_ADDRESS, &LCgas_4_gas_bsn);
  if(err == ERROR_NONE) {
    gas_4_info[GAS_BSN_INFO] = (LCgas_4_gas_bsn >> 48);
    gas_4_info[GAS_BSN_INFO+1] = (LCgas_4_gas_bsn >> 32);
    gas_4_info[GAS_BSN_INFO+2] = (LCgas_4_gas_bsn >> 16);
    modbus_info_frame_update(gas_4_info, MODBUS_OFFSET_GAS_4_INFO, MODBUS_SIZE_OF_GAS_4_INFO);
    global_Board_status &= ~GAS_4_ERROR;
  }
  else {
    global_Board_status |= GAS_4_ERROR;
  }
#endif  
#ifdef GAS_5_ADDRESS
  fw_version = 0;
#if (GAS_5_ADDRESS == PIDAY5_VOC_ADDRESS)
  delay_ms(700);
#endif
  ///////////// get gas_5 module info ////////////////////////////////////
  err = aeclmg_get_fw_version(GAS_5_ADDRESS,&fw_version);
  if(err == ERROR_NONE) {
    gas_5_info[GAS_FW_VER_INFO] = fw_version;
  }
  err = aeclmg_get_cal_date(GAS_5_ADDRESS, gas_5_info);
  if(err == ERROR_NONE) {
    modbus_info_frame_update(gas_5_info, MODBUS_OFFSET_GAS_5_INFO, MODBUS_SIZE_OF_GAS_5_INFO);
  }
  ////////////// get GAS_5 Gas Name ////////////////////////////
  err = aeclmg_get_gas_name(GAS_5_ADDRESS, &LCgas_5_gas_name);
  if(err == ERROR_NONE) {
    gas_5_info[GAS_GASNAME_INFO] = (LCgas_5_gas_name >> 48);
    gas_5_info[GAS_GASNAME_INFO+1] = (LCgas_5_gas_name >> 32);
    gas_5_info[GAS_GASNAME_INFO+2] = (LCgas_5_gas_name >> 16);
    gas_5_info[GAS_GASNAME_INFO+3] = LCgas_5_gas_name;
    modbus_info_frame_update(gas_5_info, MODBUS_OFFSET_GAS_5_INFO, MODBUS_SIZE_OF_GAS_5_INFO);
    global_Board_status &= ~GAS_5_ERROR;
  }
  else {
    global_Board_status |= GAS_5_ERROR;
  }
  //////////// get GAS_5 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_5_ADDRESS, &LCgas_5_gas_bsn);
  if(err == ERROR_NONE) {
    gas_5_info[GAS_BSN_INFO] = (LCgas_5_gas_bsn >> 48);
    gas_5_info[GAS_BSN_INFO+1] = (LCgas_5_gas_bsn >> 32);
    gas_5_info[GAS_BSN_INFO+2] = (LCgas_5_gas_bsn >> 16);
    modbus_info_frame_update(gas_5_info, MODBUS_OFFSET_GAS_5_INFO, MODBUS_SIZE_OF_GAS_5_INFO);
    global_Board_status &= ~GAS_5_ERROR;
  }
  else {
    global_Board_status |= GAS_5_ERROR;
  }
#endif
#ifdef GAS_6_ADDRESS
  fw_version = 0;
  ///////////// get gas_6 module info ////////////////////////////////////
  err = aeclmg_get_fw_version(GAS_6_ADDRESS,&fw_version);
  if(err == ERROR_NONE) {
    gas_6_info[GAS_FW_VER_INFO] = fw_version;
  }
  err = aeclmg_get_cal_date(GAS_6_ADDRESS, gas_6_info);
  if(err == ERROR_NONE) {
    modbus_info_frame_update(gas_6_info, MODBUS_OFFSET_GAS_6_INFO, MODBUS_SIZE_OF_GAS_6_INFO);
  }
  ////////////// get GAS_6 Gas Name ////////////////////////////
  err = aeclmg_get_gas_name(GAS_6_ADDRESS, &LCgas_6_gas_name);
  if(err == ERROR_NONE) {
    gas_6_info[GAS_GASNAME_INFO] = (LCgas_6_gas_name >> 48);
    gas_6_info[GAS_GASNAME_INFO+1] = (LCgas_6_gas_name >> 32);
    gas_6_info[GAS_GASNAME_INFO+2] = (LCgas_6_gas_name >> 16);
    gas_6_info[GAS_GASNAME_INFO+3] = LCgas_6_gas_name;
    modbus_info_frame_update(gas_6_info, MODBUS_OFFSET_GAS_6_INFO, MODBUS_SIZE_OF_GAS_6_INFO);
    global_Board_status &= ~GAS_6_ERROR;
  }
  else {
    global_Board_status |= GAS_6_ERROR;
  }
  //////////// get GAS_6 BSN /////////////////////////////////
  err = aeclmg_getSerialId(GAS_6_ADDRESS, &LCgas_6_gas_bsn);
  if(err == ERROR_NONE) {
    gas_6_info[GAS_BSN_INFO] = (LCgas_6_gas_bsn >> 48);
    gas_6_info[GAS_BSN_INFO+1] = (LCgas_6_gas_bsn >> 32);
    gas_6_info[GAS_BSN_INFO+2] = (LCgas_6_gas_bsn >> 16);
    modbus_info_frame_update(gas_6_info, MODBUS_OFFSET_GAS_6_INFO, MODBUS_SIZE_OF_GAS_6_INFO);
    global_Board_status &= ~GAS_6_ERROR;
  }
  else {
    global_Board_status |= GAS_6_ERROR;
  }  
#endif
}
#endif

