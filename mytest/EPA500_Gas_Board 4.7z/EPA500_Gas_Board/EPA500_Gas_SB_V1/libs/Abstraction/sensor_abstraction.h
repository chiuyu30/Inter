#ifndef SENSOR_ABSTRACTION
#define SENSOR_ABSTRACTION

// define error code
//#define CO_NO_DATA              0x8000
//#define CO_ERROR                0x4000
//#define O3_WE_NO_DATA           0x2000
//#define O3_AE_NO_DATA           0x1000
//#define O3_WE_ERROR             0x0800
//#define O3_AE_ERROR             0x0400
//#define NO2_WE_NO_DATA          0x0200
//#define NO2_AE_NO_DATA          0x0100
//#define NO2_WE_ERROR            0x0080
//#define NO2_AE_ERROR            0x0040
#define ALL_I2C_ERROR           0xFFD0

#define GAS_6_ERROR             0x0800
#define GAS_5_ERROR             0x0400
#define GAS_4_ERROR             0x0200
#define GAS_3_ERROR             0x0100
#define GAS_2_ERROR             0x0080
#define GAS_1_ERROR             0x0040
#define SYSTEM_RESTART          0x0020
#define SHT_ERROR               0x0010
#define OUTDOOR_SHT_ERROR       0x0008
#define Gases_I2C_ERROR         0x0004




extern UINT16 global_Board_status;
extern INT16 global_display_temperature;
extern INT16 global_display_relatedHumi;
void sensors_init(void);
void sht_get_serial(void);
void measure_rht(void);
void update_modbus_info_registers(void);
void sht_fill_info_registers(void);
void gases_fill_info_registers(void);


#ifdef EPA500_GASES
void measure_gases(void);
void gases_fill_data_registers();
void gases_reset_avg_data();
#endif

#ifdef OUTDOOR_SHT2X
void measure_outdoor_rht(void);
#endif


#endif