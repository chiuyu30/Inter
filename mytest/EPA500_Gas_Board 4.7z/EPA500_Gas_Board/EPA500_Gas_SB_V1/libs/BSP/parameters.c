/*******************************************************************************
oooooooooooo               .ooooooo.
`888'     `8              d8P'   `YP
 888          'YI.oooo.   d8P          .ooooo.  'YI.oooo.   .oooooo.   .ooooo.
 888oooo8      88'  'd8   Y8P'88bo.   d8'   `8b  88'  'd8  'Y8'   `   d8'   `8b
 888    "      88    88        `Y8b  d888oooo88b 88    88   Y8P'boo. d888oooo88b 
 888       o   88    88  .o     d8P '8'          88    88       '8Y' '8'
o888ooooood8  o88o   88o `Y8oood8P'   "bP88Y8P" o88o   88o `Y8oodP"   "bP88Y8P"
*******************************************************************************/
/*******************************************************************************
*
*   Parameters Setting for LoRa Main Board source file
*   
*   1. store parameters in info_memory
*   2. retrive parameters
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/10/05
*
*
*********************************************************************************/

#include "include.h"


void flash_read_parameters(void) { 
  //Get info data from internal Flash
  /*
  para_tx_rate = info_tx_rate;         //
  para_lorawan_app_port = info_lorawan_app_port;
  para_lorawan_ack_req = info_lorawan_ack_req;
  para_lorawan_join_abp = info_lorawan_join_abp;
  */
}

void flash_update_parameters(void) {
  uint16_t status;
 //Erase INFOD
  do
  {
      FlashCtl_eraseSegment((uint8_t *)INFO_MEMORY_D_START);
      status = FlashCtl_performEraseCheck((uint8_t *)INFO_MEMORY_D_START,128);
  }
  while(status == STATUS_FAIL);

  //Write calibration data to INFO_D
  /*
  uint16_t array[4];
  array[0] = para_tx_rate;
  array[1] = para_lorawan_app_port;
  array[2] = para_lorawan_ack_req;
  array[3] = para_lorawan_join_abp;

  FlashCtl_write16(array,(uint16_t*)INFO_MEMORY_D_START,4);  
  */
}

/*
UINT8 flash_get_ua1_set(void)
{
    UINT8 value = info_ua1_set;
    return value;
}
*/
