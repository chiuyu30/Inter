/*******************************************************************************
*
*   Tasks and timer 
*   
*   1. timer init
*   2. tasks loop
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/9/3
*
*
*********************************************************************************/
#include "include.h"
//******************************************************************************
//
// define tasks interval
//
//******************************************************************************
#define COMPARE_VALUE           2047    // 16HZ
#define ONE_SECOND_TICK         16
#define FOUR_SECOND_TICK        64
#define UPDATE_MODBUS_INFO_TIME 3600
UINT16 tick_count = 0;
UINT16 tick_count_2 = 0;

//******************************************************************************
//
// Tasks flags, setting flags in ISR
//
//******************************************************************************
static UINT8 flag_measureSensors = 0;
static UINT16 flag_modbus_req_elapse_counter = 0; // count last modbus request elapse time
static UINT16 flag_update_modbus_info = UPDATE_MODBUS_INFO_TIME;  // perform info update at the begining
static UINT8 flag_measure_outdoor_rht = 1;


//******************************************************************************
//
// Init tasks timer, define interval by COMPARE_VALUE
//
//******************************************************************************
void task_timer_init() {
  //Start timer in continuous mode sourced by ACLK
  Timer_A_initContinuousModeParam initContParam = {0};
  initContParam.clockSource = TIMER_A_CLOCKSOURCE_ACLK;
  initContParam.clockSourceDivider = TIMER_A_CLOCKSOURCE_DIVIDER_1;
  initContParam.timerInterruptEnable_TAIE = TIMER_A_TAIE_INTERRUPT_DISABLE;
  initContParam.timerClear = TIMER_A_DO_CLEAR;
  initContParam.startTimer = false;
  Timer_A_initContinuousMode(TIMER_A1_BASE, &initContParam);

  //Initiaze compare mode
  Timer_A_clearCaptureCompareInterrupt(TIMER_A1_BASE,
                                       TIMER_A_CAPTURECOMPARE_REGISTER_0
                                       );

  Timer_A_initCompareModeParam initCompParam = {0};
  initCompParam.compareRegister = TIMER_A_CAPTURECOMPARE_REGISTER_0;
  initCompParam.compareInterruptEnable =
      TIMER_A_CAPTURECOMPARE_INTERRUPT_ENABLE;
  initCompParam.compareOutputMode = TIMER_A_OUTPUTMODE_OUTBITVALUE;
  initCompParam.compareValue = COMPARE_VALUE;
  Timer_A_initCompareMode(TIMER_A1_BASE, &initCompParam);

  Timer_A_startCounter(TIMER_A1_BASE,
                       TIMER_A_CONTINUOUS_MODE
                       );
  
}

//******************************************************************************
//
// Tasks loop
//
//******************************************************************************
void task_run() {
  
  if(flag_clock_low_timeout_fired == 1) {
    flag_clock_low_timeout_fired = 0;
    eusci_b_i2c_port_init();
    global_Board_status |= Gases_I2C_ERROR;
  }
  
  if(flag_update_modbus_info >= UPDATE_MODBUS_INFO_TIME) {
#ifdef ENABLE_WATCHDOG
    WDT_A_resetTimer(WDT_A_BASE);
#endif
    flag_update_modbus_info = 0;
    update_modbus_info_registers();
  }
  
#ifdef MODBUS_SLAVE   
  // clear average buffer if modbus request didn't received for a period of time
  if(flag_modbus_req_elapse_counter >= info_modbus_req_limit) {
    flag_modbus_req_elapse_counter = 0;   
#ifdef EPA500_GASES    
#ifdef ENABLE_WATCHDOG
    WDT_A_resetTimer(WDT_A_BASE);
#endif
//    gases_reset_avg_data();
#endif
  }
#endif
  
  // 1 second interval tasks
  if(flag_measureSensors == 1) {
    flag_measureSensors = 0;
#ifdef ENABLE_WATCHDOG    
    WDT_A_resetTimer(WDT_A_BASE);
#endif
    measure_rht(); 
#ifdef EPA500_GASES    
#ifdef ENABLE_WATCHDOG    
    WDT_A_resetTimer(WDT_A_BASE);
#endif
    measure_gases();
#endif
  }
  
  if(flag_measure_outdoor_rht == 1) {
#ifdef ENABLE_WATCHDOG
    WDT_A_resetTimer(WDT_A_BASE);
#endif    
    flag_measure_outdoor_rht = 0;
#ifdef OUTDOOR_SHT2X
    measure_outdoor_rht();
#endif
  }
}

void reset_modbus_req_elapse_counter() {
  flag_modbus_req_elapse_counter = 0;
}

//******************************************************************************
//
//This is the TIMER1_A0 interrupt vector service routine.
//
//******************************************************************************
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=TIMER1_A0_VECTOR
__interrupt
#elif defined(__GNUC__)
__attribute__((interrupt(TIMER1_A0_VECTOR)))
#endif
void TIMER1_A0_ISR(void)
{
  uint16_t compVal = Timer_A_getCaptureCompareCount(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_0)
    + COMPARE_VALUE;
  
  //Add Offset to CCR0
  Timer_A_setCompareValue(TIMER_A1_BASE,
                          TIMER_A_CAPTURECOMPARE_REGISTER_0,
                          compVal
                            );
  tick_count++;
  tick_count_2++;
  if(tick_count >= ONE_SECOND_TICK) {   // one second
    tick_count = 0;
    TOGGLE_GLED();
    flag_measureSensors = 1;
    flag_modbus_req_elapse_counter++;
    flag_update_modbus_info++;
    
    // check if all I2C sensor dead
    if((global_Board_status & ALL_I2C_ERROR) == ALL_I2C_ERROR) {
      // trigger a software BOR.   
      PMMCTL0 = PMMPW | PMMSWBOR;          // Apply PMM password and trigger SW BOR
    }
  }
  if(tick_count_2 >= FOUR_SECOND_TICK) {   // one second
    tick_count_2 = 0;
    flag_measure_outdoor_rht = 1;
  }
}