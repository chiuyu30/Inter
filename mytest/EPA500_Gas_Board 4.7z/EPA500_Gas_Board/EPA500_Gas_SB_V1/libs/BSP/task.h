/*******************************************************************************
*
*   Tasks and timer 
*   
*   1. timer init
*   2. tasks loop
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/9/3
*
*
*********************************************************************************/
#ifndef TASK_H
#define TASK_H

void task_timer_init();
void task_run();

void reset_modbus_req_elapse_counter();

#endif