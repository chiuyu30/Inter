/*******************************************************************************
*
*   Board Specific header
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/08/9
*
*
*********************************************************************************/

#ifndef BOARD_H
#define BOARD_H

// RF Module Pin define
#define MOD_UART_PORT                   GPIO_PORT_P1   
#define MOD_UART_RX_PIN                 GPIO_PIN2
#define MOD_UART_TX_PIN                 GPIO_PIN3

#define MOD_9P2_UART_CTS_PORT           GPIO_PORT_P9
#define MOD_9P2_UART_CTS_PIN            GPIO_PIN2

#define MOD_9P3_UART_RTS_PORT           GPIO_PORT_P9
#define MOD_9P3_UART_RTS_PIN            GPIO_PIN3

#define MOD_RF_EN_PORT                  GPIO_PORT_P2
#define MOD_RF_EN_PIN                   GPIO_PIN7

#define MOD_RESET_PORT                  GPIO_PORT_P9
#define MOD_RESET_PIN                   GPIO_PIN3

#define MOD_1P0_SPI_SI_PORT             GPIO_PORT_P1
#define MOD_1P0_SPI_SI_PIN              GPIO_PIN0

#define MOD_1P1_SPI_SO_PORT             GPIO_PORT_P1
#define MOD_1P1_SPI_SO_PIN              GPIO_PIN1

#define MOD_2P4_SPI_CLK_PORT            GPIO_PORT_P2
#define MOD_2P4_SPI_CLK_PIN             GPIO_PIN2

#define MOD_1P6_GPIO3_PORT              GPIO_PORT_P1
#define MOD_1P6_GPIO3_PIN               GPIO_PIN6

#define MOD_1P7_GPIO4_PORT              GPIO_PORT_P1
#define MOD_1P7_GPIO4_PIN               GPIO_PIN7

#define MOD_3P0_I2C_SCL_PORT            GPIO_PORT_P3
#define MOD_3P0_I2C_SCL_PIN             GPIO_PIN0

#define MOD_3P1_I2C_SDA_PORT            GPIO_PORT_P3
#define MOD_3P1_I2C_SDA_PIN             GPIO_PIN1



#endif