/*******************************************************************************
*
*   This file contain the system initialization routines
*   
*   1. low level init: stop watchdog timer
*   2. Unified clock system init
*   3. LEDs, switches I/O init
*   4. System timer init
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2010/2/16
*
*
*********************************************************************************/
#include "include.h"

//*****************************************************************************
//
//Target frequency for MCLK in kHz
//
//*****************************************************************************
#define UCS_MCLK_DESIRED_FREQUENCY_IN_KHZ   20000

//*****************************************************************************
//
//MCLK/FLLRef Ratio
//
//*****************************************************************************
#define UCS_MCLK_FLLREF_RATIO   611

//*****************************************************************************
//
//Variable to store status of Oscillator fault flags
//
//*****************************************************************************
uint16_t status;

void system_init(void) {
  //Set VCore = 3 for 20MHz clock
  PMM_setVCore(PMM_CORE_LEVEL_3);
  
  //Set DCO FLL reference = REFO
  UCS_initClockSignal(
      UCS_FLLREF,
      UCS_REFOCLK_SELECT,
      UCS_CLOCK_DIVIDER_1
      );
  
  //Set ACLK = REFO
  UCS_initClockSignal(
      UCS_ACLK,
      UCS_REFOCLK_SELECT,
      UCS_CLOCK_DIVIDER_1
      );
    
  //Set Ratio and Desired MCLK Frequency  and initialize DCO
  UCS_initFLLSettle(
      UCS_MCLK_DESIRED_FREQUENCY_IN_KHZ,
      UCS_MCLK_FLLREF_RATIO
      );
  
  // Enable global oscillator fault flag
  SFR_clearInterrupt(SFR_OSCILLATOR_FAULT_INTERRUPT);
  SFR_enableInterrupt(SFR_OSCILLATOR_FAULT_INTERRUPT);
  
}

//void system_init(void) {
//  //Set VCore = 3 for 20MHz clock
//  PMM_setVCore(PMM_CORE_LEVEL_3);
//  
//  //Initializes the XT1 crystal oscillator with no timeout
//  //In case of failure, code hangs here.
//  //For time-out instead of code hang use UCS_turnOnLFXT1WithTimeout()
//  UCS_turnOnLFXT1(
//      UCS_XT1_DRIVE_0,
//      UCS_XCAP_3
//      );
//  
//  //Set DCO FLL reference = XT1
//  UCS_initClockSignal(
//      UCS_FLLREF,
//      UCS_XT1CLK_SELECT ,
//      UCS_CLOCK_DIVIDER_1
//      );
//  
//  //Set ACLK = XT1
//  UCS_initClockSignal(
//      UCS_ACLK,
//      UCS_XT1CLK_SELECT,
//      UCS_CLOCK_DIVIDER_1
//      );
//    
//  //Set Ratio and Desired MCLK Frequency  and initialize DCO
//  UCS_initFLLSettle(
//      UCS_MCLK_DESIRED_FREQUENCY_IN_KHZ,
//      UCS_MCLK_FLLREF_RATIO
//      );
//  
//  // Enable global oscillator fault flag
//  SFR_clearInterrupt(SFR_OSCILLATOR_FAULT_INTERRUPT);
//  SFR_enableInterrupt(SFR_OSCILLATOR_FAULT_INTERRUPT);
//  
//}

  
void LED_init(void) {
  // LED1 P4.0, LED2 P4.1, LED3 P4.2
  // Set P4.0, P4.1, P4.2 as output
  GPIO_setAsOutputPin(GLED_PORT,GLED_PIN);
  GPIO_setAsOutputPin(RLED_PORT,RLED_PIN);
  GPIO_setAsOutputPin(YLED_PORT,YLED_PIN);
  // init to high, close all LEDs
  GPIO_setOutputHighOnPin(GLED_PORT,GLED_PIN);
  GPIO_setOutputHighOnPin(RLED_PORT,RLED_PIN);
  GPIO_setOutputHighOnPin(YLED_PORT,YLED_PIN);
}

// delay time is ms
void delay_ms(UINT16 timeout) {
  // (121 + 1) * 32768 = 19.660800MHz
  do {
    __delay_cycles(20000);   // approximate 1ms
  } while (--timeout);
}

void sys_get_info_sb_id(char* InfoBuf, unsigned char size)
{
//  char* pInfo_Data = (char*)&info_sb_id;
//  
//  for (int i = 0; i < size; i++)
//  {
//    InfoBuf[i] = *pInfo_Data++;
//  }
}


/******************************************************************************
 * @brief        delay micro second (depends on the system clock setting above
 * @param[in]    None
 * @return       None
 * @Note         default system clock 20MHz, 20 cycles/us
 * @update       2014-05-12  
 *****************************************************************************/
void delay_micro_second(UINT32 us) {
  UINT32 i;
  for(i=0;i<us;i++) {
    __delay_cycles(20);
  }
}

//*****************************************************************************
//
// ISR for Oscillator fault trap
//
//*****************************************************************************
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=UNMI_VECTOR
__interrupt
#elif defined(__GNUC__)
__attribute__((interrupt(UNMI_VECTOR)))
#endif
void NMI_ISR(void)
{
    do
    {
        // If it still can't clear the oscillator fault flags after the timeout,
        // trap and wait here.
        status = UCS_clearAllOscFlagsWithTimeout(1000);
        TOGGLE_RLED();   // inidicate OSC fault
    }
    while(status != 0);
}

