/****************************************************************************************
*
*   This file should should included in all source files, no other inclusions are required.
*
***********************************************************************************************/
#ifndef INCLUDE_H
#define INCLUDE_H


// Include files for MSP430
#include "driverlib.h"
#include "system.h"
#include "main.h"
#include "task.h"
#include "string.h"
#include "crc2.h"
#include "sensor_abstraction.h"
#include "peripheral_abstraction.h"
#include "rf_abstraction.h"
#include "hal_eusci_b_i2c.h"
#include "hal_uart_txrx.h"
#include "parameters.h"

#ifdef MODBUS_SLAVE
#include "modbus_rtu.h"
#endif

#ifdef SHT3X
#include "sht3x_typedefs.h"
#include "sht3x_i2c_hal.h"
#include "sht3x.h"
#endif

#ifdef SENSEAIR_S8
#include "hal_s8_modbus.h"
#endif

#ifdef AECL_CO_001M
#include "hal_CO001M.h"
#endif

#ifdef PANASONIC_GCHA1
#include "hal_GCHA1.h"
#endif

#ifdef SENSIRION_SGP30
#include "sgp30.h"
#include "hal_sgpc10.h"
#endif

#ifdef ONEAIR_A4
#include "hal_oneair_a4.h"
#endif

#ifdef AECL_MULTIGASES
#include "hal_aecl_multigases.h"
#endif

#ifdef PLANTOWER_PM25  
#include "hal_plantower_pm25.h"
#endif

#ifdef SENSIRION_SDP3X  
#include "sdp3x.h"
#endif

#ifdef EPA500_GASES
#include "hal_aecl_4e_ec_gases.h"
#endif

#ifdef OUTDOOR_SHT2X
//#include "I2C_HAL.h"
#include "SHT2x.h"
#endif






#endif
