#ifndef SYSTEM_H
#define SYSTEM_H

// Common data types
typedef unsigned char		BOOL;

typedef unsigned char		BYTE;
typedef unsigned short		WORD;
typedef unsigned long		DWORD;
typedef unsigned long long	QWORD;

typedef unsigned char		UINT8;
typedef unsigned short		UINT16;
typedef unsigned long		UINT32;
typedef unsigned long long	UINT64;

typedef signed char             INT8;
typedef signed short		INT16;
typedef signed long             INT32;
typedef signed long long	INT64;

/// \brief Error codes
typedef enum {
  ERROR_NONE              = 0x00, // no error
  ERROR_ACK               = 0x01, // no acknowledgment error
  ERROR_CHECKSUM          = 0x02, // checksum mismatch error
  ERROR_IVALID_PARAMETER  = 0xFF, // invalid parameter
} Error;

// Common values
#ifndef FALSE
	#define FALSE 0
#endif
#ifndef TRUE
	#define TRUE 1
#endif
#ifndef NULL
	#define NULL 0
#endif

#define SENSOR_BOARD_ID_EN      1

// Useful stuff
#define BV(n) (1 << (n))
#define BF(x,b,s) (((x) & (b)) >> (s))
#define MIN(n,m) (((n) < (m)) ? (n) : (m))
#define MAX(n,m) (((n) < (m)) ? (m) : (n))
#define ABS(n) ((n < 0) ? -(n) : (n))

// LED pin define

//#define GLED_PORT                 GPIO_PORT_P3   //sensor board V2// Green LED output port

#define GLED_PORT                 GPIO_PORT_P4    //sensor board V3// Green LED output port

#define RLED_PORT                 GPIO_PORT_P4   // Red LED output port
#define YLED_PORT                 GPIO_PORT_P4   // Yellow LED output port

//#define GLED_PIN                  GPIO_PIN7      //sensor board V2// P3.7 - Output: Green LED
//#define RLED_PIN                  GPIO_PIN0      //sensor board V2// P4.0 - Output: Red LED
//#define YLED_PIN                  GPIO_PIN1      //sensor board V2// P4.1 - Output: Yellow pin

#define GLED_PIN                  GPIO_PIN2      //sensor board V3// P4.2 - Output: Green LED
#define RLED_PIN                  GPIO_PIN1      //sensor board V3// P4.1 - Output: Red LED
#define YLED_PIN                  GPIO_PIN0      //sensor board V3// P4.0 - Output: Yellow pin
// LED setting
#define SET_GLED()      ( GPIO_setOutputLowOnPin(GLED_PORT,GLED_PIN) )
#define CLR_GLED()      ( GPIO_setOutputHighOnPin(GLED_PORT,GLED_PIN) )
#define TOGGLE_GLED()   ( GPIO_toggleOutputOnPin(GLED_PORT,GLED_PIN) )
#define SET_RLED()      ( GPIO_setOutputLowOnPin(RLED_PORT,RLED_PIN) )
#define CLR_RLED()      ( GPIO_setOutputHighOnPin(RLED_PORT,RLED_PIN) )
#define TOGGLE_RLED()   ( GPIO_toggleOutputOnPin(RLED_PORT,RLED_PIN) )
#define SET_YLED()      ( GPIO_setOutputLowOnPin(GLED_PORT,YLED_PIN) )
#define CLR_YLED()      ( GPIO_setOutputHighOnPin(GLED_PORT,YLED_PIN) )
#define TOGGLE_YLED()   ( GPIO_toggleOutputOnPin(GLED_PORT,YLED_PIN) )

void delay_ms(UINT16 timeout);
void delay_micro_second(UINT32 us);
void LED_init(void);
void system_init(void);
void sys_get_info_sb_id(char* InfoBuf, unsigned char size);



#endif
