#ifndef FLASH_H
#define FLASH_H

#define INFO_MEMORY_D_START      (0x1800)

// initial system parameters
const UINT16 info_sb_id_up @ 0x1880 = 0x0404;
const UINT16 info_sb_id_low @ 0x1882 = 0x0404;
const UINT16 info_pm25_id_up @ 0x1884 = 0x0303;
const UINT16 info_pm25_id_low @ 0x1886 = 0x0303;
// clear average buffer if modbus request didn't received for 60 seconds
const UINT16 info_modbus_req_limit @ 0x1888 = 60;   
const UINT16 info_fw_version @ 0x188a = 0x300;   
//const float info_latitude @ 0x1890 = 25.016898;
//const float info_longitude @ 0x1894 = 121.516305;
//const UINT8 info_ua1_set @ 0x1898;


//////////////////////////////////////////////////
// read the parameters from information memory
//////////////////////////////////////////////////
void flash_read_parameters(void);

//////////////////////////////////////////////////
// write the parameters to information memory
//////////////////////////////////////////////////
void flash_update_parameters(void);

//UINT8 flash_get_ua1_set(void);

#endif