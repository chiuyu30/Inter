/*******************************************************************************
*
*   LM130 driver 
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/05/15
*
*
*********************************************************************************/
#include "include.h"
//#include "stdio.h"

#ifdef GEMTEK_GL6509

// Global Variables
UINT8 flag_GL6509_reply_received = 0;
UINT8 modbus_RxBuf[64];           //uart receive buffer
UINT8 modbus_rx_bytecount = 0;               //receive byte count
#pragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)   //USCI_A0 RX interrupt service routine
{
  switch(__even_in_range(UCA0IV,4))
  {
  case USCI_NONE:break;                             // Vector 0 - no interrupt
  case USCI_UART_UCRXIFG:                                   // Vector 2 - RXIFG

    modbus_RxBuf[modbus_rx_bytecount] = UCA0RXBUF;
    
//    if((modbus_RxBuf[modbus_rx_bytecount] == 0x0A) && (modbus_RxBuf[modbus_rx_bytecount-1] == 0x0D)) {
//      modbus_rx_bytecount = 0;
//      flag_GL6509_reply_received = 1;
//    }
//    modbus_rx_bytecount++;
//    if(modbus_rx_bytecount >= 64) {
//      modbus_rx_bytecount = 0;
//    }
    break;
  case USCI_UART_UCTXIFG: break;      // TXIFG
  case USCI_UART_UCSTTIFG: break;     // TTIFG
  case USCI_UART_UCTXCPTIFG: break;   // TXCPTIFG
  default: break;
  }  
}


void gl6509_init(void)
{
//  P9SEL &= ~(BIT3);
//  P9DIR &= ~(BIT3);
////  P9OUT |= (BIT3);

  // Setup P1.2 UCA0RXD, P1.3 UCA0TXD
  P1SEL |= BIT2 | BIT3;                   // Set P1.2, P1.3 to non-IO
  P1DIR |= BIT2 | BIT3;                   // Enable UCA0RXD, UCA0TXD
  
  // Setup eUSCI_A0
  UCA0CTLW0 |= UCSWRST;                   // **Put state machine in reset**
  UCA0CTLW0 |= UCSSEL_2;                  // SMCLK
  
  // Baudrate 9600, 20MHz
  UCA0BRW = 130; 
  UCA0MCTLW = 0x2500 + UCBRF_3 + UCOS16;   // Modln UCBRSx=0xB5, UCBRFx=3, over sampling

  UCA0CTLW0 &= ~UCSWRST;                     // **Initialize USCI state machine**
  UCA0IE |= UCRXIE;                         // Enable USCI_A0 RX interrupt
    
}
  
/*  
*	GPS example for IIS NRL, Academia Sinica in Taipei, Taiwan.
* 	Using DMS format: 
*	D-25 M-02 S-28 for latitude
*	D-121 M-36 S-52 for latitude
* 	Replace this position to your location whatever you are :)
*/
float gps_lat_f = 25.0228;  // device's gps latitude,  
float gps_lon_f = 121.3652; // device's gps longitude, IIS NRL, Academia Sinica
int fix_num = 15;			// 15 for fake GPS, who don't have GPS module
int idx = 0;
int pm10 = 0;
int pm25 = 0;
int pm100 = 0;
UINT8 app_id = 0;
UINT8 lora_trans[11];
static UINT8 buff[64];


void gl6509_sent_lass(){

  UINT8 i = 0;
  UINT16 temperatureLora = (int)((temperature+20)*10);
  UINT16 humiditylora = (int)(humidity*10);
  UINT16 pm25lora = pm25;
  UINT8 pm100Offset = pm100 - pm25;
//  float gps_lat_f = (float)atof(gps_lat);
//  float gps_lon_f = (float)atof(gps_lon);
  gps_lat_f += 90;
  gps_lon_f += 180;
  int gps_lat_i = (int) (gps_lat_f*10000);
  int gps_lon_i = (int) (gps_lon_f*10000);	
  UINT8 lat_D = (int) gps_lat_f;
  float temp_lat_M = (gps_lat_f - lat_D)*100;
  UINT8 lat_M = (int) temp_lat_M;
  UINT8 lat_S = (int) gps_lat_i%100;
  UINT16 lon_D = (int) gps_lon_f;
  float temp_lon_M = (gps_lon_f - lon_D)*100;
  UINT8 lon_M = (int) temp_lon_M;
  UINT8 lon_S = (int) gps_lon_i%100;
  UINT8 gps_fix = fix_num;
//  char buff[150];
  
  lora_trans[0] = (app_id << 4) | (temperatureLora >> 6);	
  lora_trans[1] = (temperatureLora << 2) | (humiditylora >> 8);
  lora_trans[2] = humiditylora;
          // END FOR THE APP_ID, TEMPERATURE AND HUMIDITY
  lora_trans[3] =  pm25lora >> 3;
  lora_trans[4] = (pm25lora << 5)|(pm100Offset >> 3);
          // END FOR PM2.5	
  lora_trans[5] = (pm100Offset <<5) | (lat_D >> 3);
  lora_trans[6] = (lat_D << 5) | (lat_M >> 1);
  lora_trans[7] = (lat_M << 7) | (lat_S << 1) | (lon_D >> 8);
  lora_trans[8] = (UINT8)lon_D;
  lora_trans[9] = (lon_M << 2) | (lon_S >> 4);
  lora_trans[10] = (lon_S << 4) | gps_fix;
          // END FOR PM10 AND GPS

  buff[0] = 0x41;
  buff[1] = 0x54;
  buff[2] = 0x2B;
  buff[3] = 0x44;
  buff[4] = 0x54;
  buff[5] = 0x58;
  buff[6] = 0x3D;
  buff[7] = 0x32;
  buff[8] = 0x32;
  buff[9] = 0x2C;
//  sprintf(buff, "AT+DTX=22,%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X\r\n", \
//  lora_trans[0], lora_trans[1], lora_trans[2], lora_trans[3], lora_trans[4], \
//  lora_trans[5], lora_trans[6], lora_trans[7], lora_trans[8], lora_trans[9], lora_trans[10]);
  for(i=0;i<11;i++) {
    UINT8 a = lora_trans[i] >> 4;
    if(a < 10) {
      buff[i*2+10] = a + 0x30;
    }
    else {
      buff[i*2+10] = (a - 9) + 0x40;
    }
    UINT8 b = lora_trans[i] & 0x0F;
    if(b < 10) {
      buff[i*2+11] = b + 0x30;
    }
    else {
      buff[i*2+11] = (b - 9) + 0x40;
    }
  }
  buff[32] = 0x0D;
  buff[33] = 0x0A;
  
  for(i=0;i<34;i++) {
    while (!(UCA0IFG&UCTXIFG));             // USCI_A0 TX buffer ready?
    UCA0TXBUF = buff[i];
  }
//  lora.print(buff);
//  while(buff[i])  {
//    if(i>=150) { break;}
//      while (!(UCA0IFG&UCTXIFG));             // USCI_A0 TX buffer ready?
////      UCA0TXBUF = atc0[i];
//      UCA0TXBUF = buff[i++];
//  }
//  while (!(UCA0IFG&UCTXIFG));             // USCI_A0 TX buffer ready?
//  UCA0TXBUF = 0x0D;
//  while (!(UCA0IFG&UCTXIFG));             // USCI_A0 TX buffer ready?
//  UCA0TXBUF = 0x0A;
//  while(!flag_GL6509_reply_received) {
//    delay_ms(10000);
//    flag_GL6509_reply_received = 1;
//  }
  flag_GL6509_reply_received = 0;
  _NOP();
}

#endif
