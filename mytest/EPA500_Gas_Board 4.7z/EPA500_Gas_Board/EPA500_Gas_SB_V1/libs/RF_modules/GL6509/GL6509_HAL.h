#ifndef GL6509_HAL
#define GL6509_HAL

void gl6509_init(void);
void gl6509_sent_lass();

#endif