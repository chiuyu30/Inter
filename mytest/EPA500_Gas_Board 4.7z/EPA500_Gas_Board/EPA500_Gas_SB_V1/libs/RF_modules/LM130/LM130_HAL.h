#ifndef LM130_HAL
#define LM130_HAL

//// LM130 pin define
#define LM130_UART_PORT                 GPIO_PORT_P1   
#define LM130_UART_RX_PIN               GPIO_PIN2
#define LM130_UART_TX_PIN               GPIO_PIN3

#define LM130_LORA_EN_PORT              GPIO_PORT_P2
#define LM130_LORA_EN_PIN               GPIO_PIN7

#define LM130_RESET_PORT                GPIO_PORT_P9
#define LM130_RESET_PIN                 GPIO_PIN3


void lm130_init(void);
void lm130_send_data(UINT8 messageType);
void lm130_setup(void);


#endif