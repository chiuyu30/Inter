#ifndef T77I718_HAL
#define T77I718_HAL

//// T77I718 pin define
#define T77I718_UART_PORT                 GPIO_PORT_P1   
#define T77I718_UART_RX_PIN               GPIO_PIN2
#define T77I718_UART_TX_PIN               GPIO_PIN3

#define T77I718_LORA_EN_PORT              GPIO_PORT_P2
#define T77I718_LORA_EN_PIN               GPIO_PIN7

#define T77I718_RESET_PORT                GPIO_PORT_P9
#define T77I718_RESET_PIN                 GPIO_PIN3


void t77i718_init(void);
void t77i718_send_data(UINT8 messageType);
void t77i718_setup(void);

#endif