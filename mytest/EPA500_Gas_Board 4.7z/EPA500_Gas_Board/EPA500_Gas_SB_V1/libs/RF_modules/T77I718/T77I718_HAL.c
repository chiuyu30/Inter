/*******************************************************************************
*
*   FHNNET T77I718 driver 
*
*   Company: Autotronic Enterprise CO., LTD.
*   Author: SY LAU
*   Create Date: 2016/08/9
*
*
*********************************************************************************/
#include "include.h"
#include "stdio.h"

#ifdef FHNET_T77I718

UINT8 modbus_RxBuf[64];           //uart receive buffer
UINT8 modbus_rx_bytecount = 0;               //receive byte count
UINT8 flag_t77i718_reply_received = 0;

//******************************************************************************
//
//This is the USCI_A0 interrupt vector service routine.
//
//******************************************************************************
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=USCI_A0_VECTOR
__interrupt
#elif defined(__GNUC__)
__attribute__((interrupt(USCI_A0_VECTOR)))
#endif
void EUSCI_A0_ISR(void)
{
  switch(__even_in_range(UCA0IV,USCI_UART_UCTXCPTIFG))
  {
  case USCI_NONE:break;                             // Vector 0 - no interrupt
  case USCI_UART_UCRXIFG:                                   // Vector 2 - RXIFG

    modbus_RxBuf[modbus_rx_bytecount] = EUSCI_A_UART_receiveData(EUSCI_A0_BASE);;
    
    if((modbus_RxBuf[modbus_rx_bytecount] == 0x0A) && (modbus_RxBuf[modbus_rx_bytecount-1] == 0x0D)) {
      modbus_rx_bytecount = 0;
      flag_t77i718_reply_received = 1;
    }
    modbus_rx_bytecount++;
    if(modbus_rx_bytecount >= 64) {
      modbus_rx_bytecount = 0;
    }
    break;
  case USCI_UART_UCTXIFG: break;      // TXIFG
  case USCI_UART_UCSTTIFG: break;     // TTIFG
  case USCI_UART_UCTXCPTIFG: break;   // TXCPTIFG
  default: break;
  }  
}

void t77i718_init(void) {
  // enable module (do not control)
  GPIO_setAsInputPin(T77I718_LORA_EN_PORT,T77I718_LORA_EN_PIN);

  // do not control reset pin (internal pull up)
  GPIO_setAsInputPin(T77I718_RESET_PORT,T77I718_RESET_PIN);
  
  //Configure UART pins (UCA0TXD/UCA0SIMO, UCA0RXD/UCA0SOMI)
  GPIO_setAsPeripheralModuleFunctionInputPin(
      T77I718_UART_PORT,
      T77I718_UART_RX_PIN + T77I718_UART_TX_PIN
      );
  
  // Configure UART
  // 57600@20MHz 21,11,34,1
  EUSCI_A_UART_initParam param = {0};
  param.selectClockSource = EUSCI_A_UART_CLOCKSOURCE_SMCLK;
  param.clockPrescalar = 21;
  param.firstModReg = 11;
  param.secondModReg = 34;
  param.parity = EUSCI_A_UART_NO_PARITY;
  param.msborLsbFirst = EUSCI_A_UART_LSB_FIRST;
  param.numberofStopBits = EUSCI_A_UART_ONE_STOP_BIT;
  param.uartMode = EUSCI_A_UART_MODE;
  param.overSampling = EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION;
  
  if(STATUS_FAIL == EUSCI_A_UART_init(EUSCI_A0_BASE, &param))
  {
      return;
  }
  
  //Enable UART module for operation
  EUSCI_A_UART_enable(EUSCI_A0_BASE);
  
  //Enable Receive Interrupt
  EUSCI_A_UART_clearInterrupt(EUSCI_A0_BASE,
                             EUSCI_A_UART_RECEIVE_INTERRUPT);
  EUSCI_A_UART_enableInterrupt(EUSCI_A0_BASE,
                              EUSCI_A_UART_RECEIVE_INTERRUPT); 
    
}

void EUSCI_A0_UART_transmitBuf(char *pTxBuf, char txLen) {
    for(char i = 0; i < txLen;i++)  
    {     
      if(pTxBuf[i] == 0x00) {
        break;
      }
      EUSCI_A_UART_transmitData(EUSCI_A0_BASE, pTxBuf[i]);
    }
}

const char atc0[] = "AAT1 FwVersion";
const char atc1[] = "AAT2 DevAddr=?";
const char atc2[] = "AAT2 Tx=2,cnf,2378";
const char atc3[] = "AAT2 Tx=2,cnf";
const char atc4[] = "AAT2 DevEui=?";

void t77i718_send_data(UINT8 messageType) {
  char buff[64];
  buff[0] = 0;
//  if(messageType < 10) {
//  sprintf(buff, "%s,a11a2345a6789a1234\r\n", atc3);
//  sprintf(buff, "%s,a%da%da%da%d\r\n", atc3,messageType,global_display_temperature,global_display_relatedHumi,display_gas_ppm);
  sprintf(buff, "%s,%02x%04x%04x%04x\r\n", atc3,messageType,global_display_temperature,global_display_relatedHumi,display_gas_ppm);
//  }
//  else {
//    sprintf(buff, "%s,%x%x%x%x\r\n", atc3,messageType,global_display_temperature,global_display_relatedHumi,display_gas_ppm);
//  }
  EUSCI_A0_UART_transmitBuf(buff, 64);
  while(!flag_t77i718_reply_received) {
    delay_ms(100);
  }
  flag_t77i718_reply_received = 0;
  _NOP();
}

void t77i718_send_cmd(char *cmd) {
  char buff[64];
  memset(buff, 0x00, 64);
  sprintf(buff, "%s\r\n", cmd);
  EUSCI_A0_UART_transmitBuf(buff, 64);
  while(!flag_t77i718_reply_received);
  flag_t77i718_reply_received = 0;
}

const char at_init1[] = "AAT2 DevAddr=33333333";
const char at_init2[] = "AAT1 Save";
const char at_init3[] = "AAT1 Reset";
const char at_init4[] = "AAT1 DebugMsg=1";
const char at_init5[] = "AAT1 FwVersion";

void t77i718_setup(void) {
  t77i718_send_cmd((char*)at_init1);
  
  t77i718_send_cmd((char*)at_init2);

  t77i718_send_cmd((char*)at_init3);
  
  _NOP();
}
  

#endif


