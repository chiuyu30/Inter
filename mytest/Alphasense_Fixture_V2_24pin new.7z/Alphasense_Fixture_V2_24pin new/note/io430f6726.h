/********************************************************************
 *
 * Standard register and bit definitions for the Texas Instruments
 * MSP430 microcontroller.
 *
 * This file supports assembler and C/EC++ development for
 * msp430f6726 devices.
 *
 * Copyright 1996-2016 IAR Systems AB.
 *
 *
 *
 ********************************************************************/

#ifndef __IO430F6726
#define __IO430F6726

#ifdef  __IAR_SYSTEMS_ICC__

#include "intrinsics.h"
#ifndef _SYSTEM_BUILD
#pragma system_include
#endif
#endif

#if (((__TID__ >> 8) & 0x7F) != 0x2b)     /* 0x2b = 43 dec */
#error io430f6726.h file for use with ICC430/A430 only
#endif

#if __REGISTER_MODEL__ == __REGISTER_MODEL_REG20__
#define __ACCESS_20BIT_REG__  void __data20 * volatile
#else
#define __ACCESS_20BIT_REG__  volatile unsigned short  /* only short access from C is allowed in small memory model */
#endif


#define __MSP430_HAS_MSP430XV2_CPU__  /* Definition to show that it has MSP430XV2 CPU */


#ifdef __IAR_SYSTEMS_ICC__
#pragma language=save
#pragma language=extended


#ifdef __cplusplus
#define __READ    /* not supported */
#else
#define __READ    const
#endif


/*-------------------------------------------------------------------------
 *   Standard Bits
 *-------------------------------------------------------------------------*/

#define BIT0                (0x0001)
#define BIT1                (0x0002)
#define BIT2                (0x0004)
#define BIT3                (0x0008)
#define BIT4                (0x0010)
#define BIT5                (0x0020)
#define BIT6                (0x0040)
#define BIT7                (0x0080)
#define BIT8                (0x0100)
#define BIT9                (0x0200)
#define BITA                (0x0400)
#define BITB                (0x0800)
#define BITC                (0x1000)
#define BITD                (0x2000)
#define BITE                (0x4000)
#define BITF                (0x8000)

/*-------------------------------------------------------------------------
 *   Status register bits
 *-------------------------------------------------------------------------*/

#define C                   (0x0001)
#define Z                   (0x0002)
#define N                   (0x0004)
#define V                   (0x0100)
#define GIE                 (0x0008)
#define CPUOFF              (0x0010)
#define OSCOFF              (0x0020)
#define SCG0                (0x0040)
#define SCG1                (0x0080)

/* Low Power Modes coded with Bits 4-7 in SR */

#define LPM0_bits           (CPUOFF)
#define LPM1_bits           (SCG0+CPUOFF)
#define LPM2_bits           (SCG1+CPUOFF)
#define LPM3_bits           (SCG1+SCG0+CPUOFF)
#define LPM4_bits           (SCG1+SCG0+OSCOFF+CPUOFF)


#define LPM0      __bis_SR_register(LPM0_bits)     /* Enter Low Power Mode 0 */
#define LPM0_EXIT __bic_SR_register_on_exit(LPM0_bits) /* Exit Low Power Mode 0 */
#define LPM1      __bis_SR_register(LPM1_bits)     /* Enter Low Power Mode 1 */
#define LPM1_EXIT __bic_SR_register_on_exit(LPM1_bits) /* Exit Low Power Mode 1 */
#define LPM2      __bis_SR_register(LPM2_bits)     /* Enter Low Power Mode 2 */
#define LPM2_EXIT __bic_SR_register_on_exit(LPM2_bits) /* Exit Low Power Mode 2 */
#define LPM3      __bis_SR_register(LPM3_bits)     /* Enter Low Power Mode 3 */
#define LPM3_EXIT __bic_SR_register_on_exit(LPM3_bits) /* Exit Low Power Mode 3 */
#define LPM4      __bis_SR_register(LPM4_bits)     /* Enter Low Power Mode 4 */
#define LPM4_EXIT __bic_SR_register_on_exit(LPM4_bits) /* Exit Low Power Mode 4 */



/*-------------------------------------------------------------------------
 *   ADC10_A
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short ADC10CTL0;   /* ADC10 Control 0  */

  struct
  {
    unsigned short ADC10SC         : 1; /* ADC10 Start Conversion  */
    unsigned short ADC10ENC        : 1; /* ADC10 Enable Conversion  */
    unsigned short                : 2;
    unsigned short ADC10ON         : 1; /* ADC10 On/enable  */
    unsigned short                : 2;
    unsigned short ADC10MSC        : 1; /* ADC10 Multiple SampleConversion  */
    unsigned short ADC10SHT0       : 1; /* ADC10 Sample Hold Select Bit: 0  */
    unsigned short ADC10SHT1       : 1; /* ADC10 Sample Hold Select Bit: 1  */
    unsigned short ADC10SHT2       : 1; /* ADC10 Sample Hold Select Bit: 2  */
    unsigned short ADC10SHT3       : 1; /* ADC10 Sample Hold Select Bit: 3  */
  } ADC10CTL0_bit;

  struct
  {
    unsigned char ADC10CTL0_L;
    unsigned char ADC10CTL0_H;
  };
} @ 0x0740;

enum {
  ADC10SC         = 0x0001,
  ADC10ENC        = 0x0002,
  ADC10ON         = 0x0010,
  ADC10MSC        = 0x0080,
  ADC10SHT0       = 0x0100,
  ADC10SHT1       = 0x0200,
  ADC10SHT2       = 0x0400,
  ADC10SHT3       = 0x0800
};

__no_init volatile union
{
  unsigned short ADC10CTL1;   /* ADC10 Control 1  */

  struct
  {
    unsigned short ADC10BUSY       : 1; /* ADC10 Busy  */
    unsigned short ADC10CONSEQ0    : 1; /* ADC10 Conversion Sequence Select 0  */
    unsigned short ADC10CONSEQ1    : 1; /* ADC10 Conversion Sequence Select 1  */
    unsigned short ADC10SSEL0      : 1; /* ADC10 Clock Source Select 0  */
    unsigned short ADC10SSEL1      : 1; /* ADC10 Clock Source Select 1  */
    unsigned short ADC10DIV0       : 1; /* ADC10 Clock Divider Select 0  */
    unsigned short ADC10DIV1       : 1; /* ADC10 Clock Divider Select 1  */
    unsigned short ADC10DIV2       : 1; /* ADC10 Clock Divider Select 2  */
    unsigned short ADC10ISSH       : 1; /* ADC10 Invert Sample Hold Signal  */
    unsigned short ADC10SHP        : 1; /* ADC10 Sample/Hold Pulse Mode  */
    unsigned short ADC10SHS0       : 1; /* ADC10 Sample/Hold Source 0  */
    unsigned short ADC10SHS1       : 1; /* ADC10 Sample/Hold Source 1  */
  } ADC10CTL1_bit;

  struct
  {
    unsigned char ADC10CTL1_L;
    unsigned char ADC10CTL1_H;
  };
} @ 0x0742;

enum {
  ADC10BUSY       = 0x0001,
  ADC10CONSEQ0    = 0x0002,
  ADC10CONSEQ1    = 0x0004,
  ADC10SSEL0      = 0x0008,
  ADC10SSEL1      = 0x0010,
  ADC10DIV0       = 0x0020,
  ADC10DIV1       = 0x0040,
  ADC10DIV2       = 0x0080,
  ADC10ISSH       = 0x0100,
  ADC10SHP        = 0x0200,
  ADC10SHS0       = 0x0400,
  ADC10SHS1       = 0x0800
};

__no_init volatile union
{
  unsigned short ADC10CTL2;   /* ADC10 Control 2  */

  struct
  {
    unsigned short ADC10REFBURST   : 1; /* ADC10 Reference Burst  */
    unsigned short                : 1;
    unsigned short ADC10SR         : 1; /* ADC10 Sampling Rate  */
    unsigned short ADC10DF         : 1; /* ADC10 Data Format  */
    unsigned short ADC10RES        : 1; /* ADC10 Resolution Bit  */
    unsigned short                : 3;
    unsigned short ADC10PDIV0      : 1; /* ADC10 predivider Bit: 0  */
    unsigned short ADC10PDIV1      : 1; /* ADC10 predivider Bit: 1  */
  } ADC10CTL2_bit;

  struct
  {
    unsigned char ADC10CTL2_L;
    unsigned char ADC10CTL2_H;
  };
} @ 0x0744;

enum {
  ADC10REFBURST   = 0x0001,
  ADC10SR         = 0x0004,
  ADC10DF         = 0x0008,
  ADC10RES        = 0x0010,
  ADC10PDIV0      = 0x0100,
  ADC10PDIV1      = 0x0200
};

__no_init volatile union
{
  unsigned short ADC10LO;   /* ADC10 Window Comparator High Threshold  */
  struct
  {
    unsigned char ADC10LO_L;
    unsigned char ADC10LO_H;
  };
} @ 0x0746;

__no_init volatile union
{
  unsigned short ADC10HI;   /* ADC10 Window Comparator High Threshold  */
  struct
  {
    unsigned char ADC10HI_L;
    unsigned char ADC10HI_H;
  };
} @ 0x0748;

__no_init volatile union
{
  unsigned short ADC10MCTL0;   /* ADC10 Memory Control 0  */

  struct
  {
    unsigned short ADC10INCH0      : 1; /* ADC10 Input Channel Select Bit 0  */
    unsigned short ADC10INCH1      : 1; /* ADC10 Input Channel Select Bit 1  */
    unsigned short ADC10INCH2      : 1; /* ADC10 Input Channel Select Bit 2  */
    unsigned short ADC10INCH3      : 1; /* ADC10 Input Channel Select Bit 3  */
    unsigned short ADC10SREF0      : 1; /* ADC10 Select Reference Bit 0  */
    unsigned short ADC10SREF1      : 1; /* ADC10 Select Reference Bit 1  */
    unsigned short ADC10SREF2      : 1; /* ADC10 Select Reference Bit 2  */
  } ADC10MCTL0_bit;

  struct
  {
    unsigned char ADC10MCTL0_L;
    unsigned char ADC10MCTL0_H;
  };
} @ 0x074A;

enum {
  ADC10INCH0      = 0x0001,
  ADC10INCH1      = 0x0002,
  ADC10INCH2      = 0x0004,
  ADC10INCH3      = 0x0008,
  ADC10SREF0      = 0x0010,
  ADC10SREF1      = 0x0020,
  ADC10SREF2      = 0x0040
};

__no_init volatile union
{
  unsigned short ADC10MEM0;   /* ADC10 Conversion Memory 0  */
  struct
  {
    unsigned char ADC10MEM0_L;
    unsigned char ADC10MEM0_H;
  };
} @ 0x0752;

__no_init volatile union
{
  unsigned short ADC10IE;   /* ADC10 Interrupt Enable  */

  struct
  {
    unsigned short ADC10IE0        : 1; /* ADC10_A Interrupt enable  */
    unsigned short ADC10INIE       : 1; /* ADC10_A Interrupt enable for the inside of window of the Window comparator  */
    unsigned short ADC10LOIE       : 1; /* ADC10_A Interrupt enable for lower threshold of the Window comparator  */
    unsigned short ADC10HIIE       : 1; /* ADC10_A Interrupt enable for upper threshold of the Window comparator  */
    unsigned short ADC10OVIE       : 1; /* ADC10_A ADC10MEM overflow Interrupt enable  */
    unsigned short ADC10TOVIE      : 1; /* ADC10_A conversion-time-overflow Interrupt enable  */
  } ADC10IE_bit;

  struct
  {
    unsigned char ADC10IE_L;
    unsigned char ADC10IE_H;
  };
} @ 0x075A;

enum {
  ADC10IE0        = 0x0001,
  ADC10INIE       = 0x0002,
  ADC10LOIE       = 0x0004,
  ADC10HIIE       = 0x0008,
  ADC10OVIE       = 0x0010,
  ADC10TOVIE      = 0x0020
};

__no_init volatile union
{
  unsigned short ADC10IFG;   /* ADC10 Interrupt Flag  */

  struct
  {
    unsigned short ADC10IFG0       : 1; /* ADC10_A Interrupt Flag  */
    unsigned short ADC10INIFG      : 1; /* ADC10_A Interrupt Flag for the inside of window of the Window comparator  */
    unsigned short ADC10LOIFG      : 1; /* ADC10_A Interrupt Flag for lower threshold of the Window comparator  */
    unsigned short ADC10HIIFG      : 1; /* ADC10_A Interrupt Flag for upper threshold of the Window comparator  */
    unsigned short ADC10OVIFG      : 1; /* ADC10_A ADC10MEM overflow Interrupt Flag  */
    unsigned short ADC10TOVIFG     : 1; /* ADC10_A conversion-time-overflow Interrupt Flag  */
  } ADC10IFG_bit;

  struct
  {
    unsigned char ADC10IFG_L;
    unsigned char ADC10IFG_H;
  };
} @ 0x075C;

enum {
  ADC10IFG0       = 0x0001,
  ADC10INIFG      = 0x0002,
  ADC10LOIFG      = 0x0004,
  ADC10HIIFG      = 0x0008,
  ADC10OVIFG      = 0x0010,
  ADC10TOVIFG     = 0x0020
};

__no_init volatile union
{
  unsigned short ADC10IV;   /* ADC10 Interrupt Vector Word  */
  struct
  {
    unsigned char ADC10IV_L;
    unsigned char ADC10IV_H;
  };
} @ 0x075E;

#define __MSP430_HAS_ADC10_A__        /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_ADC10_A__ 0x0740
#define ADC10_A_BASE __MSP430_BASEADDRESS_ADC10_A__
/* ADC10CTL0 Control Bits */
#define ADC10SC_L           (0x0001u)  /* ADC10 Start Conversion */
#define ADC10ENC_L          (0x0002u)  /* ADC10 Enable Conversion */
#define ADC10ON_L           (0x0010u)  /* ADC10 On/enable */
#define ADC10MSC_L          (0x0080u)  /* ADC10 Multiple SampleConversion */
/* ADC10CTL0 Control Bits */
#define ADC10SHT0_H         (0x0001u)  /* ADC10 Sample Hold Select Bit: 0 */
#define ADC10SHT1_H         (0x0002u)  /* ADC10 Sample Hold Select Bit: 1 */
#define ADC10SHT2_H         (0x0004u)  /* ADC10 Sample Hold Select Bit: 2 */
#define ADC10SHT3_H         (0x0008u)  /* ADC10 Sample Hold Select Bit: 3 */

#define ADC10SHT_0          (0*0x100u) /* ADC10 Sample Hold Select 0 */
#define ADC10SHT_1          (1*0x100u) /* ADC10 Sample Hold Select 1 */
#define ADC10SHT_2          (2*0x100u) /* ADC10 Sample Hold Select 2 */
#define ADC10SHT_3          (3*0x100u) /* ADC10 Sample Hold Select 3 */
#define ADC10SHT_4          (4*0x100u) /* ADC10 Sample Hold Select 4 */
#define ADC10SHT_5          (5*0x100u) /* ADC10 Sample Hold Select 5 */
#define ADC10SHT_6          (6*0x100u) /* ADC10 Sample Hold Select 6 */
#define ADC10SHT_7          (7*0x100u) /* ADC10 Sample Hold Select 7 */
#define ADC10SHT_8          (8*0x100u) /* ADC10 Sample Hold Select 8 */
#define ADC10SHT_9          (9*0x100u) /* ADC10 Sample Hold Select 9 */
#define ADC10SHT_10         (10*0x100u) /* ADC10 Sample Hold Select 10 */
#define ADC10SHT_11         (11*0x100u) /* ADC10 Sample Hold Select 11 */
#define ADC10SHT_12         (12*0x100u) /* ADC10 Sample Hold Select 12 */
#define ADC10SHT_13         (13*0x100u) /* ADC10 Sample Hold Select 13 */
#define ADC10SHT_14         (14*0x100u) /* ADC10 Sample Hold Select 14 */
#define ADC10SHT_15         (15*0x100u) /* ADC10 Sample Hold Select 15 */
/* ADC10CTL1 Control Bits */
#define ADC10BUSY_L         (0x0001u)    /* ADC10 Busy */
#define ADC10CONSEQ0_L      (0x0002u)    /* ADC10 Conversion Sequence Select 0 */
#define ADC10CONSEQ1_L      (0x0004u)    /* ADC10 Conversion Sequence Select 1 */
#define ADC10SSEL0_L        (0x0008u)    /* ADC10 Clock Source Select 0 */
#define ADC10SSEL1_L        (0x0010u)    /* ADC10 Clock Source Select 1 */
#define ADC10DIV0_L         (0x0020u)    /* ADC10 Clock Divider Select 0 */
#define ADC10DIV1_L         (0x0040u)    /* ADC10 Clock Divider Select 1 */
#define ADC10DIV2_L         (0x0080u)    /* ADC10 Clock Divider Select 2 */
/* ADC10CTL1 Control Bits */
#define ADC10ISSH_H         (0x0001u)    /* ADC10 Invert Sample Hold Signal */
#define ADC10SHP_H          (0x0002u)    /* ADC10 Sample/Hold Pulse Mode */
#define ADC10SHS0_H         (0x0004u)    /* ADC10 Sample/Hold Source 0 */
#define ADC10SHS1_H         (0x0008u)    /* ADC10 Sample/Hold Source 1 */

#define ADC10CONSEQ_0        (0*2u)      /* ADC10 Conversion Sequence Select: 0 */
#define ADC10CONSEQ_1        (1*2u)      /* ADC10 Conversion Sequence Select: 1 */
#define ADC10CONSEQ_2        (2*2u)      /* ADC10 Conversion Sequence Select: 2 */
#define ADC10CONSEQ_3        (3*2u)      /* ADC10 Conversion Sequence Select: 3 */

#define ADC10SSEL_0          (0*8u)      /* ADC10 Clock Source Select: 0 */
#define ADC10SSEL_1          (1*8u)      /* ADC10 Clock Source Select: 1 */
#define ADC10SSEL_2          (2*8u)      /* ADC10 Clock Source Select: 2 */
#define ADC10SSEL_3          (3*8u)      /* ADC10 Clock Source Select: 3 */

#define ADC10DIV_0           (0*0x20u)   /* ADC10 Clock Divider Select: 0 */
#define ADC10DIV_1           (1*0x20u)   /* ADC10 Clock Divider Select: 1 */
#define ADC10DIV_2           (2*0x20u)   /* ADC10 Clock Divider Select: 2 */
#define ADC10DIV_3           (3*0x20u)   /* ADC10 Clock Divider Select: 3 */
#define ADC10DIV_4           (4*0x20u)   /* ADC10 Clock Divider Select: 4 */
#define ADC10DIV_5           (5*0x20u)   /* ADC10 Clock Divider Select: 5 */
#define ADC10DIV_6           (6*0x20u)   /* ADC10 Clock Divider Select: 6 */
#define ADC10DIV_7           (7*0x20u)   /* ADC10 Clock Divider Select: 7 */

#define ADC10SHS_0           (0*0x400u)  /* ADC10 Sample/Hold Source: 0 */
#define ADC10SHS_1           (1*0x400u)  /* ADC10 Sample/Hold Source: 1 */
#define ADC10SHS_2           (2*0x400u)  /* ADC10 Sample/Hold Source: 2 */
#define ADC10SHS_3           (3*0x400u)  /* ADC10 Sample/Hold Source: 3 */
/* ADC10CTL2 Control Bits */
#define ADC10REFBURST_L     (0x0001u)    /* ADC10 Reference Burst */
#define ADC10SR_L           (0x0004u)    /* ADC10 Sampling Rate */
#define ADC10DF_L           (0x0008u)    /* ADC10 Data Format */
#define ADC10RES_L          (0x0010u)    /* ADC10 Resolution Bit */
/* ADC10CTL2 Control Bits */
#define ADC10PDIV0_H        (0x0001u)    /* ADC10 predivider Bit: 0 */
#define ADC10PDIV1_H        (0x0002u)    /* ADC10 predivider Bit: 1 */

#define ADC10PDIV_0         (0x0000u)    /* ADC10 predivider /1 */
#define ADC10PDIV_1         (0x0100u)    /* ADC10 predivider /2 */
#define ADC10PDIV_2         (0x0200u)    /* ADC10 predivider /64 */
#define ADC10PDIV_3         (0x0300u)    /* ADC10 predivider reserved */

#define ADC10PDIV__1        (0x0000u)    /* ADC10 predivider /1 */
#define ADC10PDIV__4        (0x0100u)    /* ADC10 predivider /2 */
#define ADC10PDIV__64       (0x0200u)    /* ADC10 predivider /64 */
/* ADC10MCTL0 Control Bits */
#define ADC10INCH0_L        (0x0001u)    /* ADC10 Input Channel Select Bit 0 */
#define ADC10INCH1_L        (0x0002u)    /* ADC10 Input Channel Select Bit 1 */
#define ADC10INCH2_L        (0x0004u)    /* ADC10 Input Channel Select Bit 2 */
#define ADC10INCH3_L        (0x0008u)    /* ADC10 Input Channel Select Bit 3 */
#define ADC10SREF0_L        (0x0010u)    /* ADC10 Select Reference Bit 0 */
#define ADC10SREF1_L        (0x0020u)    /* ADC10 Select Reference Bit 1 */
#define ADC10SREF2_L        (0x0040u)    /* ADC10 Select Reference Bit 2 */

#define ADC10INCH_0         (0)         /* ADC10 Input Channel 0 */
#define ADC10INCH_1         (1)         /* ADC10 Input Channel 1 */
#define ADC10INCH_2         (2)         /* ADC10 Input Channel 2 */
#define ADC10INCH_3         (3)         /* ADC10 Input Channel 3 */
#define ADC10INCH_4         (4)         /* ADC10 Input Channel 4 */
#define ADC10INCH_5         (5)         /* ADC10 Input Channel 5 */
#define ADC10INCH_6         (6)         /* ADC10 Input Channel 6 */
#define ADC10INCH_7         (7)         /* ADC10 Input Channel 7 */
#define ADC10INCH_8         (8)         /* ADC10 Input Channel 8 */
#define ADC10INCH_9         (9)         /* ADC10 Input Channel 9 */
#define ADC10INCH_10        (10)        /* ADC10 Input Channel 10 */
#define ADC10INCH_11        (11)        /* ADC10 Input Channel 11 */
#define ADC10INCH_12        (12)        /* ADC10 Input Channel 12 */
#define ADC10INCH_13        (13)        /* ADC10 Input Channel 13 */
#define ADC10INCH_14        (14)        /* ADC10 Input Channel 14 */
#define ADC10INCH_15        (15)        /* ADC10 Input Channel 15 */

#define ADC10SREF_0         (0*0x10u)    /* ADC10 Select Reference 0 */
#define ADC10SREF_1         (1*0x10u)    /* ADC10 Select Reference 1 */
#define ADC10SREF_2         (2*0x10u)    /* ADC10 Select Reference 2 */
#define ADC10SREF_3         (3*0x10u)    /* ADC10 Select Reference 3 */
#define ADC10SREF_4         (4*0x10u)    /* ADC10 Select Reference 4 */
#define ADC10SREF_5         (5*0x10u)    /* ADC10 Select Reference 5 */
#define ADC10SREF_6         (6*0x10u)    /* ADC10 Select Reference 6 */
#define ADC10SREF_7         (7*0x10u)    /* ADC10 Select Reference 7 */
/* ADC10IE Interrupt Enable Bits */
#define ADC10IE0_L          (0x0001u)    /* ADC10_A Interrupt enable */
#define ADC10INIE_L         (0x0002u)    /* ADC10_A Interrupt enable for the inside of window of the Window comparator */
#define ADC10LOIE_L         (0x0004u)    /* ADC10_A Interrupt enable for lower threshold of the Window comparator */
#define ADC10HIIE_L         (0x0008u)    /* ADC10_A Interrupt enable for upper threshold of the Window comparator */
#define ADC10OVIE_L         (0x0010u)    /* ADC10_A ADC10MEM overflow Interrupt enable */
#define ADC10TOVIE_L        (0x0020u)    /* ADC10_A conversion-time-overflow Interrupt enable */
/* ADC10IFG Interrupt Flag Bits */
#define ADC10IFG0_L         (0x0001u)    /* ADC10_A Interrupt Flag */
#define ADC10INIFG_L        (0x0002u)    /* ADC10_A Interrupt Flag for the inside of window of the Window comparator */
#define ADC10LOIFG_L        (0x0004u)    /* ADC10_A Interrupt Flag for lower threshold of the Window comparator */
#define ADC10HIIFG_L        (0x0008u)    /* ADC10_A Interrupt Flag for upper threshold of the Window comparator */
#define ADC10OVIFG_L        (0x0010u)    /* ADC10_A ADC10MEM overflow Interrupt Flag */
#define ADC10TOVIFG_L       (0x0020u)    /* ADC10_A conversion-time-overflow Interrupt Flag */
/* ADC10IV Definitions */
#define ADC10IV_NONE        (0x0000u)    /* No Interrupt pending */
#define ADC10IV_ADC10OVIFG  (0x0002u)    /* ADC10OVIFG */
#define ADC10IV_ADC10TOVIFG (0x0004u)    /* ADC10TOVIFG */
#define ADC10IV_ADC10HIIFG  (0x0006u)    /* ADC10HIIFG */
#define ADC10IV_ADC10LOIFG  (0x0008u)    /* ADC10LOIFG */
#define ADC10IV_ADC10INIFG  (0x000Au)    /* ADC10INIFG */
#define ADC10IV_ADC10IFG    (0x000Cu)    /* ADC10IFG */

/*-------------------------------------------------------------------------
 *   Auxilary Supply
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short AUXCTL0;   /* Auxiliary Supply Control register 0  */

  struct
  {
    unsigned short LOCKAUX         : 1; /* Lock auxiliary supply system.  */
    unsigned short AUX0SW          : 1; /* DVCC switch state.  */
    unsigned short AUX1SW          : 1; /* AUX1 switch state.  */
    unsigned short AUX2SW          : 1; /* AUX2 switch state.  */
  } AUXCTL0_bit;

  struct
  {
    unsigned char AUXCTL0_L;
    unsigned char AUXCTL0_H;
  };
} @ 0x09E0;

enum {
  LOCKAUX         = 0x0001,
  AUX0SW          = 0x0002,
  AUX1SW          = 0x0004,
  AUX2SW          = 0x0008
};

__no_init volatile union
{
  unsigned short AUXCTL1;   /* Auxiliary Supply Control register 1  */

  struct
  {
    unsigned short AUX0OK          : 1; /* DVCC okay flag.  */
    unsigned short AUX1OK          : 1; /* AUX 1 supply okay flag.  */
    unsigned short AUX2OK          : 1; /* AUX 2 supply okay flag.  */
    unsigned short AUX2PRIO        : 1; /* Auxiliary supply AUX2 priority.  */
    unsigned short                : 4;
    unsigned short AUX0MD          : 1; /* DVCC supply mode.  */
    unsigned short AUX1MD          : 1; /* AUX1 supply mode.  */
    unsigned short AUX2MD          : 1; /* AUX2 supply mode.  */
  } AUXCTL1_bit;

  struct
  {
    unsigned char AUXCTL1_L;
    unsigned char AUXCTL1_H;
  };
} @ 0x09E2;

enum {
  AUX0OK          = 0x0001,
  AUX1OK          = 0x0002,
  AUX2OK          = 0x0004,
  AUX2PRIO        = 0x0008,
  AUX0MD          = 0x0100,
  AUX1MD          = 0x0200,
  AUX2MD          = 0x0400
};

__no_init volatile union
{
  unsigned short AUXCTL2;   /* Auxiliary Supply Control register 2  */

  struct
  {
    unsigned short AUX0LVL0        : 1; /* DVCC supply threshold level Bit: 0  */
    unsigned short AUX0LVL1        : 1; /* DVCC supply threshold level Bit: 1  */
    unsigned short AUX0LVL2        : 1; /* DVCC supply threshold level Bit: 2  */
    unsigned short                : 1;
    unsigned short AUX1LVL0        : 1; /* AUX1 supply threshold level Bit: 0  */
    unsigned short AUX1LVL1        : 1; /* AUX1 supply threshold level Bit: 1  */
    unsigned short AUX1LVL2        : 1; /* AUX1 supply threshold level Bit: 2  */
    unsigned short                : 1;
    unsigned short AUX2LVL0        : 1; /* AUX2 supply threshold level Bit: 0  */
    unsigned short AUX2LVL1        : 1; /* AUX2 supply threshold level Bit: 1  */
    unsigned short AUX2LVL2        : 1; /* AUX2 supply threshold level Bit: 2  */
    unsigned short                : 1;
    unsigned short AUXMR0          : 1; /* Auxiliary supply monitoring rate Bit: 0  */
    unsigned short AUXMR1          : 1; /* Auxiliary supply monitoring rate Bit: 1  */
  } AUXCTL2_bit;

  struct
  {
    unsigned char AUXCTL2_L;
    unsigned char AUXCTL2_H;
  };
} @ 0x09E4;

enum {
  AUX0LVL0        = 0x0001,
  AUX0LVL1        = 0x0002,
  AUX0LVL2        = 0x0004,
  AUX1LVL0        = 0x0010,
  AUX1LVL1        = 0x0020,
  AUX1LVL2        = 0x0040,
  AUX2LVL0        = 0x0100,
  AUX2LVL1        = 0x0200,
  AUX2LVL2        = 0x0400,
  AUXMR0          = 0x1000,
  AUXMR1          = 0x2000
};

__no_init volatile union
{
  unsigned short AUX2CHCTL;   /* AUX2 Charger Control register  */

  struct
  {
    unsigned short AUXCHEN         : 1; /* Lock auxiliary supply system.  */
    unsigned short AUXCHC0         : 1; /* Charger charge current Bit: 0  */
    unsigned short AUXCHC1         : 1; /* Charger charge current Bit: 1  */
    unsigned short                : 1;
    unsigned short AUXCHV0         : 1; /* Charger end voltage Bit: 0  */
    unsigned short AUXCHV1         : 1; /* Charger end voltage Bit: 1  */
  } AUX2CHCTL_bit;

  struct
  {
    unsigned char AUX2CHCTL_L;
    unsigned char AUX2CHCTL_H;
  };
} @ 0x09F2;

enum {
  AUXCHEN         = 0x0001,
  AUXCHC0         = 0x0002,
  AUXCHC1         = 0x0004,
  AUXCHV0         = 0x0010,
  AUXCHV1         = 0x0020
};

__no_init volatile union
{
  unsigned short AUX3CHCTL;   /* AUX3 Charger Control register  */

  struct
  {
    unsigned short AUXCHEN         : 1; /* Lock auxiliary supply system.  */
    unsigned short AUXCHC0         : 1; /* Charger charge current Bit: 0  */
    unsigned short AUXCHC1         : 1; /* Charger charge current Bit: 1  */
    unsigned short                : 1;
    unsigned short AUXCHV0         : 1; /* Charger end voltage Bit: 0  */
    unsigned short AUXCHV1         : 1; /* Charger end voltage Bit: 1  */
  } AUX3CHCTL_bit;

  struct
  {
    unsigned char AUX3CHCTL_L;
    unsigned char AUX3CHCTL_H;
  };
} @ 0x09F4;

/*
enum {
  AUXCHEN         = 0x0001,
  AUXCHC0         = 0x0002,
  AUXCHC1         = 0x0004,
  AUXCHV0         = 0x0010,
  AUXCHV1         = 0x0020,
};

*/
__no_init volatile union
{
  unsigned short AUXADCCTL;   /* AUX ADC Control  */

  struct
  {
    unsigned short AUXADC          : 1; /* Auxiliary supplies to ADC  */
    unsigned short AUXADCSEL0      : 1; /* Select supply to be measured with ADC Bit: 0  */
    unsigned short AUXADCSEL1      : 1; /* Select supply to be measured with ADC Bit: 1  */
    unsigned short                : 1;
    unsigned short AUXADCR0        : 1; /* Load resistance Bit: 0  */
    unsigned short AUXADCR1        : 1; /* Load resistance Bit: 1  */
  } AUXADCCTL_bit;

  struct
  {
    unsigned char AUXADCCTL_L;
    unsigned char AUXADCCTL_H;
  };
} @ 0x09F6;

enum {
  AUXADC          = 0x0001,
  AUXADCSEL0      = 0x0002,
  AUXADCSEL1      = 0x0004,
  AUXADCR0        = 0x0010,
  AUXADCR1        = 0x0020
};

__no_init volatile union
{
  unsigned short AUXIFG;   /* AUX Interrupt Flag  */

  struct
  {
    unsigned short AUX0SWIFG       : 1; /* Switched to DVCC interrupt flag  */
    unsigned short AUX1SWIFG       : 1; /* Switched to AUX1 interrupt flag  */
    unsigned short AUX2SWIFG       : 1; /* Switched to AUX2 interrupt flag  */
    unsigned short                : 1;
    unsigned short AUX0DRPIFG      : 1; /* DVCC dropped below its threshold interrupt flag  */
    unsigned short AUX1DRPIFG      : 1; /* AUX1 dropped below its threshold interrupt flag  */
    unsigned short AUX2DRPIFG      : 1; /* AUX2 dropped below its threshold interrupt flag  */
    unsigned short AUXMONIFG       : 1; /* Supply monitor interrupt flag  */
    unsigned short AUXSWNMIFG      : 1; /* Supplies switched (non-)maskable interrupt flag  */
  } AUXIFG_bit;

  struct
  {
    unsigned char AUXIFG_L;
    unsigned char AUXIFG_H;
  };
} @ 0x09FA;

enum {
  AUX0SWIFG       = 0x0001,
  AUX1SWIFG       = 0x0002,
  AUX2SWIFG       = 0x0004,
  AUX0DRPIFG      = 0x0010,
  AUX1DRPIFG      = 0x0020,
  AUX2DRPIFG      = 0x0040,
  AUXMONIFG       = 0x0080,
  AUXSWNMIFG      = 0x0100
};

__no_init volatile union
{
  unsigned short AUXIE;   /* AUX Interrupt Enable  */

  struct
  {
    unsigned short AUX0SWIE        : 1; /* Switched to DVCC interrupt enable  */
    unsigned short AUX1SWIE        : 1; /* Switched to AUX1 interrupt enable  */
    unsigned short AUX2SWIE        : 1; /* Switched to AUX2 interrupt enable  */
    unsigned short AUXSWGIE        : 1; /* Global supply switched interrupt enable.  */
    unsigned short AUX0DRPIE       : 1; /* DVCC dropped below its threshold interrupt enable  */
    unsigned short AUX1DRPIE       : 1; /* AUX1 dropped below its threshold interrupt enable  */
    unsigned short AUX2DRPIE       : 1; /* AUX2 dropped below its threshold interrupt enable  */
    unsigned short AUXMONIE        : 1; /* Supply monitor interrupt enable  */
    unsigned short AUXSWNMIE       : 1; /* Supplies switched (non-)maskable interrupt enable  */
  } AUXIE_bit;

  struct
  {
    unsigned char AUXIE_L;
    unsigned char AUXIE_H;
  };
} @ 0x09FC;

enum {
  AUX0SWIE        = 0x0001,
  AUX1SWIE        = 0x0002,
  AUX2SWIE        = 0x0004,
  AUXSWGIE        = 0x0008,
  AUX0DRPIE       = 0x0010,
  AUX1DRPIE       = 0x0020,
  AUX2DRPIE       = 0x0040,
  AUXMONIE        = 0x0080,
  AUXSWNMIE       = 0x0100
};

__no_init volatile union
{
  unsigned short AUXIV;   /* AUX Interrupt Vector Word  */
  struct
  {
    unsigned char AUXIV_L;
    unsigned char AUXIV_H;
  };
} @ 0x09FE;

#define __MSP430_HAS_AUX_SUPPLY__      /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_AUX_SUPPLY__ 0x09E0
#define AUX_SUPPLY_BASE __MSP430_BASEADDRESS_AUX_SUPPLY__
/* AUXCTL0 Control Bits */
#define LOCKAUX_L           (0x0001u)  /* Lock auxiliary supply system. */
#define AUX0SW_L            (0x0002u)  /* DVCC switch state. */
#define AUX1SW_L            (0x0004u)  /* AUX1 switch state. */
#define AUX2SW_L            (0x0008u)  /* AUX2 switch state. */

#define AUXKEY              (0xA500u)  /* AUX Key */
#define AUXKEY_H            (0xA5)    /* AUX Key (high word access) */
/* AUXCTL1 Control Bits */
#define AUX0OK_L            (0x0001u)  /* DVCC okay flag. */
#define AUX1OK_L            (0x0002u)  /* AUX 1 supply okay flag. */
#define AUX2OK_L            (0x0004u)  /* AUX 2 supply okay flag. */
#define AUX2PRIO_L          (0x0008u)  /* Auxiliary supply AUX2 priority. */
/* AUXCTL1 Control Bits */
#define AUX0MD_H            (0x0001u)  /* DVCC supply mode. */
#define AUX1MD_H            (0x0002u)  /* AUX1 supply mode. */
#define AUX2MD_H            (0x0004u)  /* AUX2 supply mode. */
/* AUXCTL2 Control Bits */
#define AUX0LVL0_L          (0x0001u)  /* DVCC supply threshold level Bit: 0 */
#define AUX0LVL1_L          (0x0002u)  /* DVCC supply threshold level Bit: 1 */
#define AUX0LVL2_L          (0x0004u)  /* DVCC supply threshold level Bit: 2 */
#define AUX1LVL0_L          (0x0010u)  /* AUX1 supply threshold level Bit: 0 */
#define AUX1LVL1_L          (0x0020u)  /* AUX1 supply threshold level Bit: 1 */
#define AUX1LVL2_L          (0x0040u)  /* AUX1 supply threshold level Bit: 2 */
/* AUXCTL2 Control Bits */
#define AUX2LVL0_H          (0x0001u)  /* AUX2 supply threshold level Bit: 0 */
#define AUX2LVL1_H          (0x0002u)  /* AUX2 supply threshold level Bit: 1 */
#define AUX2LVL2_H          (0x0004u)  /* AUX2 supply threshold level Bit: 2 */
#define AUXMR0_H            (0x0010u)  /* Auxiliary supply monitoring rate Bit: 0 */
#define AUXMR1_H            (0x0020u)  /* Auxiliary supply monitoring rate Bit: 1 */

#define AUX0LVL_0           (0x0000u)  /* DVCC supply threshold level: 0 */
#define AUX0LVL_1           (0x0001u)  /* DVCC supply threshold level: 1 */
#define AUX0LVL_2           (0x0002u)  /* DVCC supply threshold level: 2 */
#define AUX0LVL_3           (0x0003u)  /* DVCC supply threshold level: 3 */
#define AUX0LVL_4           (0x0004u)  /* DVCC supply threshold level: 4 */
#define AUX0LVL_5           (0x0005u)  /* DVCC supply threshold level: 5 */
#define AUX0LVL_6           (0x0006u)  /* DVCC supply threshold level: 6 */
#define AUX0LVL_7           (0x0007u)  /* DVCC supply threshold level: 7 */

#define AUX1LVL_0           (0x0000u)  /* AUX1 supply threshold level: 0 */
#define AUX1LVL_1           (0x0010u)  /* AUX1 supply threshold level: 1 */
#define AUX1LVL_2           (0x0020u)  /* AUX1 supply threshold level: 2 */
#define AUX1LVL_3           (0x0030u)  /* AUX1 supply threshold level: 3 */
#define AUX1LVL_4           (0x0040u)  /* AUX1 supply threshold level: 4 */
#define AUX1LVL_5           (0x0050u)  /* AUX1 supply threshold level: 5 */
#define AUX1LVL_6           (0x0060u)  /* AUX1 supply threshold level: 6 */
#define AUX1LVL_7           (0x0070u)  /* AUX1 supply threshold level: 7 */

#define AUX2LVL_0           (0x0000u)  /* AUX2 supply threshold level: 0 */
#define AUX2LVL_1           (0x0100u)  /* AUX2 supply threshold level: 1 */
#define AUX2LVL_2           (0x0200u)  /* AUX2 supply threshold level: 2 */
#define AUX2LVL_3           (0x0300u)  /* AUX2 supply threshold level: 3 */
#define AUX2LVL_4           (0x0400u)  /* AUX2 supply threshold level: 4 */
#define AUX2LVL_5           (0x0500u)  /* AUX2 supply threshold level: 5 */
#define AUX2LVL_6           (0x0600u)  /* AUX2 supply threshold level: 6 */
#define AUX2LVL_7           (0x0700u)  /* AUX2 supply threshold level: 7 */

#define AUXMR_0             (0x0000u)  /* Auxiliary supply monitoring rate: 0 */
#define AUXMR_1             (0x1000u)  /* Auxiliary supply monitoring rate: 1 */
#define AUXMR_2             (0x2000u)  /* Auxiliary supply monitoring rate: 2 */
#define AUXMR_3             (0x3000u)  /* Auxiliary supply monitoring rate: 3 */
/* AUXADCCTL Control Bits */
#define AUXADC_L            (0x0001u)  /* Auxiliary supplies to ADC */
#define AUXADCSEL0_L        (0x0002u)  /* Select supply to be measured with ADC Bit: 0 */
#define AUXADCSEL1_L        (0x0004u)  /* Select supply to be measured with ADC Bit: 1 */
#define AUXADCR0_L          (0x0010u)  /* Load resistance Bit: 0 */
#define AUXADCR1_L          (0x0020u)  /* Load resistance Bit: 1 */

#define AUXADCSEL_0         (0x0000u)  /* Select supply to be measured with ADC: DVCC */
#define AUXADCSEL_1         (0x0002u)  /* Select supply to be measured with ADC: AUXVCC1 */
#define AUXADCSEL_2         (0x0004u)  /* Select supply to be measured with ADC: AUXVCC2 */
#define AUXADCSEL_3         (0x0006u)  /* Select supply to be measured with ADC: AUXVCC3 */
#define AUXADCSEL__DVCC     (0x0000u)  /* Select supply to be measured with ADC: DVCC */
#define AUXADCSEL__AUXVCC1  (0x0002u)  /* Select supply to be measured with ADC: AUXVCC1 */
#define AUXADCSEL__AUXVCC2  (0x0004u)  /* Select supply to be measured with ADC: AUXVCC2 */
#define AUXADCSEL__AUXVCC3  (0x0006u)  /* Select supply to be measured with ADC: AUXVCC3 */

#define AUXADCR_0           (0x0000u)  /* Load resistance: 0 */
#define AUXADCR_1           (0x0010u)  /* Load resistance: 1 */
#define AUXADCR_2           (0x0020u)  /* Load resistance: 2 */
#define AUXADCR_3           (0x0030u)  /* Load resistance: 3 */
/* AUXxCHCTL Control Bits */
#define AUXCHEN_L           (0x0001u)  /* Lock auxiliary supply system. */
#define AUXCHC0_L           (0x0002u)  /* Charger charge current Bit: 0 */
#define AUXCHC1_L           (0x0004u)  /* Charger charge current Bit: 1 */
#define AUXCHV0_L           (0x0010u)  /* Charger end voltage Bit: 0 */
#define AUXCHV1_L           (0x0020u)  /* Charger end voltage Bit: 1 */

#define AUXCHKEY            (0x6900u)  /* Charger Access Key */

#define AUXCHC_0            (0x0000u)  /* Charger charge current: 0 */
#define AUXCHC_1            (0x0002u)  /* Charger charge current: 1 */
#define AUXCHC_2            (0x0004u)  /* Charger charge current: 2 */
#define AUXCHC_3            (0x0006u)  /* Charger charge current: 3 */

#define AUXCHV_0            (0x0000u)  /* Charger end voltage: 0 */
#define AUXCHV_1            (0x0010u)  /* Charger end voltage: 1 */
#define AUXCHV_2            (0x0020u)  /* Charger end voltage: 2 */
#define AUXCHV_3            (0x0030u)  /* Charger end voltage: 3 */
/* AUXIFG Control Bits */
#define AUX0SWIFG_L         (0x0001u)  /* Switched to DVCC interrupt flag */
#define AUX1SWIFG_L         (0x0002u)  /* Switched to AUX1 interrupt flag */
#define AUX2SWIFG_L         (0x0004u)  /* Switched to AUX2 interrupt flag */
#define AUX0DRPIFG_L        (0x0010u)  /* DVCC dropped below its threshold interrupt flag */
#define AUX1DRPIFG_L        (0x0020u)  /* AUX1 dropped below its threshold interrupt flag */
#define AUX2DRPIFG_L        (0x0040u)  /* AUX2 dropped below its threshold interrupt flag */
#define AUXMONIFG_L         (0x0080u)  /* Supply monitor interrupt flag */
/* AUXIFG Control Bits */
#define AUXSWNMIFG_H        (0x0001u)  /* Supplies switched (non-)maskable interrupt flag */
/* AUXIE Control Bits */
#define AUX0SWIE_L          (0x0001u)  /* Switched to DVCC interrupt enable */
#define AUX1SWIE_L          (0x0002u)  /* Switched to AUX1 interrupt enable */
#define AUX2SWIE_L          (0x0004u)  /* Switched to AUX2 interrupt enable */
#define AUXSWGIE_L          (0x0008u)  /* Global supply switched interrupt enable. */
#define AUX0DRPIE_L         (0x0010u)  /* DVCC dropped below its threshold interrupt enable */
#define AUX1DRPIE_L         (0x0020u)  /* AUX1 dropped below its threshold interrupt enable */
#define AUX2DRPIE_L         (0x0040u)  /* AUX2 dropped below its threshold interrupt enable */
#define AUXMONIE_L          (0x0080u)  /* Supply monitor interrupt enable */
/* AUXIE Control Bits */
#define AUXSWNMIE_H         (0x0001u)  /* Supplies switched (non-)maskable interrupt enable */
/* AUXIV Definitions */
#define AUXIV_NONE        (0x0000u)    /* No Interrupt pending */
#define AUXIV_AUXSWNMIFG  (0x0002u)    /* AUXSWNMIFG */
#define AUXIV_AUX0SWIFG   (0x0004u)    /* AUX0SWIFG */
#define AUXIV_AUX1SWIFG   (0x0006u)    /* AUX1SWIFG */
#define AUXIV_AUX2SWIFG   (0x0008u)    /* AUX2SWIFG */
#define AUXIV_AUX0DRPIFG  (0x000Au)    /* AUX0DRPIFG */
#define AUXIV_AUX1DRPIFG  (0x000Cu)    /* AUX1DRPIFG */
#define AUXIV_AUX2DRPIFG  (0x000Eu)    /* AUX2DRPIFG */
#define AUXIV_AUXMONIFG   (0x0010u)    /* AUXMONIFG */

/*-------------------------------------------------------------------------
 *   Backup RAM
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short BAKMEM0;   /* Battery Backup Memory 0  */
  struct
  {
    unsigned char BAKMEM0_L;
    unsigned char BAKMEM0_H;
  };
} @ 0x0480;

__no_init volatile union
{
  unsigned short BAKMEM1;   /* Battery Backup Memory 1  */
  struct
  {
    unsigned char BAKMEM1_L;
    unsigned char BAKMEM1_H;
  };
} @ 0x0482;

__no_init volatile union
{
  unsigned short BAKMEM2;   /* Battery Backup Memory 2  */
  struct
  {
    unsigned char BAKMEM2_L;
    unsigned char BAKMEM2_H;
  };
} @ 0x0484;

__no_init volatile union
{
  unsigned short BAKMEM3;   /* Battery Backup Memory 3  */
  struct
  {
    unsigned char BAKMEM3_L;
    unsigned char BAKMEM3_H;
  };
} @ 0x0486;

#define __MSP430_HAS_BACKUP_RAM__      /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_BACKUP_RAM__ 0x0480
#define BAK_RAM_BASE __MSP430_BASEADDRESS_BACKUP_RAM__

/*-------------------------------------------------------------------------
 *   CRC16
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short CRCDI;   /* CRC Data In Register  */
  struct
  {
    unsigned char CRCDI_L;
    unsigned char CRCDI_H;
  };
} @ 0x0150;

__no_init volatile union
{
  unsigned short CRCDIRB;   /* CRC data in reverse byte Register  */
  struct
  {
    unsigned char CRCDIRB_L;
    unsigned char CRCDIRB_H;
  };
} @ 0x0152;

__no_init volatile union
{
  unsigned short CRCINIRES;   /* CRC Initialisation Register and Result Register  */
  struct
  {
    unsigned char CRCINIRES_L;
    unsigned char CRCINIRES_H;
  };
} @ 0x0154;

__no_init volatile union
{
  unsigned short CRCRESR;   /* CRC reverse result Register  */
  struct
  {
    unsigned char CRCRESR_L;
    unsigned char CRCRESR_H;
  };
} @ 0x0156;

#define __MSP430_HAS_CRC__            /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_CRC__ 0x0150
#define CRC_BASE __MSP430_BASEADDRESS_CRC__

/*-------------------------------------------------------------------------
 *   DMA
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short DMACTL0;   /* DMA Module Control 0  */

  struct
  {
    unsigned short DMA0TSEL0       : 1; /* DMA channel 0 transfer select bit 0  */
    unsigned short DMA0TSEL1       : 1; /* DMA channel 0 transfer select bit 1  */
    unsigned short DMA0TSEL2       : 1; /* DMA channel 0 transfer select bit 2  */
    unsigned short DMA0TSEL3       : 1; /* DMA channel 0 transfer select bit 3  */
    unsigned short DMA0TSEL4       : 1; /* DMA channel 0 transfer select bit 4  */
    unsigned short                : 3;
    unsigned short DMA1TSEL0       : 1; /* DMA channel 1 transfer select bit 0  */
    unsigned short DMA1TSEL1       : 1; /* DMA channel 1 transfer select bit 1  */
    unsigned short DMA1TSEL2       : 1; /* DMA channel 1 transfer select bit 2  */
    unsigned short DMA1TSEL3       : 1; /* DMA channel 1 transfer select bit 3  */
    unsigned short DMA1TSEL4       : 1; /* DMA channel 1 transfer select bit 4  */
  } DMACTL0_bit;

  struct
  {
    unsigned char DMACTL0_L;
    unsigned char DMACTL0_H;
  };
} @ 0x0500;

enum {
  DMA0TSEL0       = 0x0001,
  DMA0TSEL1       = 0x0002,
  DMA0TSEL2       = 0x0004,
  DMA0TSEL3       = 0x0008,
  DMA0TSEL4       = 0x0010,
  DMA1TSEL0       = 0x0100,
  DMA1TSEL1       = 0x0200,
  DMA1TSEL2       = 0x0400,
  DMA1TSEL3       = 0x0800,
  DMA1TSEL4       = 0x1000
};

__no_init volatile union
{
  unsigned short DMACTL1;   /* DMA Module Control 1  */

  struct
  {
    unsigned short DMA2TSEL0       : 1; /* DMA channel 2 transfer select bit 0  */
    unsigned short DMA2TSEL1       : 1; /* DMA channel 2 transfer select bit 1  */
    unsigned short DMA2TSEL2       : 1; /* DMA channel 2 transfer select bit 2  */
    unsigned short DMA2TSEL3       : 1; /* DMA channel 2 transfer select bit 3  */
    unsigned short DMA2TSEL4       : 1; /* DMA channel 2 transfer select bit 4  */
  } DMACTL1_bit;

  struct
  {
    unsigned char DMACTL1_L;
    unsigned char DMACTL1_H;
  };
} @ 0x0502;

enum {
  DMA2TSEL0       = 0x0001,
  DMA2TSEL1       = 0x0002,
  DMA2TSEL2       = 0x0004,
  DMA2TSEL3       = 0x0008,
  DMA2TSEL4       = 0x0010
};

__no_init volatile union
{
  unsigned short DMACTL2;   /* DMA Module Control 2  */
  struct
  {
    unsigned char DMACTL2_L;
    unsigned char DMACTL2_H;
  };
} @ 0x0504;

__no_init volatile union
{
  unsigned short DMACTL3;   /* DMA Module Control 3  */
  struct
  {
    unsigned char DMACTL3_L;
    unsigned char DMACTL3_H;
  };
} @ 0x0506;

__no_init volatile union
{
  unsigned short DMACTL4;   /* DMA Module Control 4  */

  struct
  {
    unsigned short ENNMI           : 1; /* Enable NMI interruption of DMA  */
    unsigned short ROUNDROBIN      : 1; /* Round-Robin DMA channel priorities  */
    unsigned short DMARMWDIS       : 1; /* Inhibited DMA transfers during read-modify-write CPU operations  */
  } DMACTL4_bit;

  struct
  {
    unsigned char DMACTL4_L;
    unsigned char DMACTL4_H;
  };
} @ 0x0508;

enum {
  ENNMI           = 0x0001,
  ROUNDROBIN      = 0x0002,
  DMARMWDIS       = 0x0004
};

__no_init volatile union
{
  unsigned short DMAIV;   /* DMA Interrupt Vector Word  */
  struct
  {
    unsigned char DMAIV_L;
    unsigned char DMAIV_H;
  };
} @ 0x050E;

__no_init volatile union
{
  unsigned short DMA0CTL;   /* DMA Channel 0 Control  */

  struct
  {
    unsigned short DMAREQ          : 1; /* Initiate DMA transfer with DMATSEL  */
    unsigned short DMAABORT        : 1; /* DMA transfer aborted by NMI  */
    unsigned short DMAIE           : 1; /* DMA interrupt enable  */
    unsigned short DMAIFG          : 1; /* DMA interrupt flag  */
    unsigned short DMAEN           : 1; /* DMA enable  */
    unsigned short DMALEVEL        : 1; /* DMA level sensitive trigger select  */
    unsigned short DMASRCBYTE      : 1; /* DMA source byte  */
    unsigned short DMADSTBYTE      : 1; /* DMA destination byte  */
    unsigned short DMASRCINCR0     : 1; /* DMA source increment bit 0  */
    unsigned short DMASRCINCR1     : 1; /* DMA source increment bit 1  */
    unsigned short DMADSTINCR0     : 1; /* DMA destination increment bit 0  */
    unsigned short DMADSTINCR1     : 1; /* DMA destination increment bit 1  */
    unsigned short DMADT0          : 1; /* DMA transfer mode bit 0  */
    unsigned short DMADT1          : 1; /* DMA transfer mode bit 1  */
    unsigned short DMADT2          : 1; /* DMA transfer mode bit 2  */
  } DMA0CTL_bit;

  struct
  {
    unsigned char DMA0CTL_L;
    unsigned char DMA0CTL_H;
  };
} @ 0x0510;

enum {
  DMAREQ          = 0x0001,
  DMAABORT        = 0x0002,
  DMAIE           = 0x0004,
  DMAIFG          = 0x0008,
  DMAEN           = 0x0010,
  DMALEVEL        = 0x0020,
  DMASRCBYTE      = 0x0040,
  DMADSTBYTE      = 0x0080,
  DMASRCINCR0     = 0x0100,
  DMASRCINCR1     = 0x0200,
  DMADSTINCR0     = 0x0400,
  DMADSTINCR1     = 0x0800,
  DMADT0          = 0x1000,
  DMADT1          = 0x2000,
  DMADT2          = 0x4000
};

__no_init volatile union
{
  __ACCESS_20BIT_REG__ DMA0SA;   /* DMA Channel 0 Source Address  */
  struct
  {
    unsigned char DMA0SA_L;
    unsigned char DMA0SA_H;
  };
  struct
  {
    unsigned short DMA0SAL;
    unsigned short DMA0SAH;
  };
} @ 0x0512;

__no_init volatile union
{
  __ACCESS_20BIT_REG__ DMA0DA;   /* DMA Channel 0 Destination Address  */
  struct
  {
    unsigned char DMA0DA_L;
    unsigned char DMA0DA_H;
  };
  struct
  {
    unsigned short DMA0DAL;
    unsigned short DMA0DAH;
  };
} @ 0x0516;


  /* DMA Channel 0 Transfer Size  */
__no_init volatile unsigned short DMA0SZ @ 0x051A;


__no_init volatile union
{
  unsigned short DMA1CTL;   /* DMA Channel 1 Control  */

  struct
  {
    unsigned short DMAREQ          : 1; /* Initiate DMA transfer with DMATSEL  */
    unsigned short DMAABORT        : 1; /* DMA transfer aborted by NMI  */
    unsigned short DMAIE           : 1; /* DMA interrupt enable  */
    unsigned short DMAIFG          : 1; /* DMA interrupt flag  */
    unsigned short DMAEN           : 1; /* DMA enable  */
    unsigned short DMALEVEL        : 1; /* DMA level sensitive trigger select  */
    unsigned short DMASRCBYTE      : 1; /* DMA source byte  */
    unsigned short DMADSTBYTE      : 1; /* DMA destination byte  */
    unsigned short DMASRCINCR0     : 1; /* DMA source increment bit 0  */
    unsigned short DMASRCINCR1     : 1; /* DMA source increment bit 1  */
    unsigned short DMADSTINCR0     : 1; /* DMA destination increment bit 0  */
    unsigned short DMADSTINCR1     : 1; /* DMA destination increment bit 1  */
    unsigned short DMADT0          : 1; /* DMA transfer mode bit 0  */
    unsigned short DMADT1          : 1; /* DMA transfer mode bit 1  */
    unsigned short DMADT2          : 1; /* DMA transfer mode bit 2  */
  } DMA1CTL_bit;

  struct
  {
    unsigned char DMA1CTL_L;
    unsigned char DMA1CTL_H;
  };
} @ 0x0520;

/*
enum {
  DMAREQ          = 0x0001,
  DMAABORT        = 0x0002,
  DMAIE           = 0x0004,
  DMAIFG          = 0x0008,
  DMAEN           = 0x0010,
  DMALEVEL        = 0x0020,
  DMASRCBYTE      = 0x0040,
  DMADSTBYTE      = 0x0080,
  DMASRCINCR0     = 0x0100,
  DMASRCINCR1     = 0x0200,
  DMADSTINCR0     = 0x0400,
  DMADSTINCR1     = 0x0800,
  DMADT0          = 0x1000,
  DMADT1          = 0x2000,
  DMADT2          = 0x4000,
};

*/
__no_init volatile union
{
  __ACCESS_20BIT_REG__ DMA1SA;   /* DMA Channel 1 Source Address  */
  struct
  {
    unsigned char DMA1SA_L;
    unsigned char DMA1SA_H;
  };
  struct
  {
    unsigned short DMA1SAL;
    unsigned short DMA1SAH;
  };
} @ 0x0522;

__no_init volatile union
{
  __ACCESS_20BIT_REG__ DMA1DA;   /* DMA Channel 1 Destination Address  */
  struct
  {
    unsigned char DMA1DA_L;
    unsigned char DMA1DA_H;
  };
  struct
  {
    unsigned short DMA1DAL;
    unsigned short DMA1DAH;
  };
} @ 0x0526;


  /* DMA Channel 1 Transfer Size  */
__no_init volatile unsigned short DMA1SZ @ 0x052A;


__no_init volatile union
{
  unsigned short DMA2CTL;   /* DMA Channel 2 Control  */

  struct
  {
    unsigned short DMAREQ          : 1; /* Initiate DMA transfer with DMATSEL  */
    unsigned short DMAABORT        : 1; /* DMA transfer aborted by NMI  */
    unsigned short DMAIE           : 1; /* DMA interrupt enable  */
    unsigned short DMAIFG          : 1; /* DMA interrupt flag  */
    unsigned short DMAEN           : 1; /* DMA enable  */
    unsigned short DMALEVEL        : 1; /* DMA level sensitive trigger select  */
    unsigned short DMASRCBYTE      : 1; /* DMA source byte  */
    unsigned short DMADSTBYTE      : 1; /* DMA destination byte  */
    unsigned short DMASRCINCR0     : 1; /* DMA source increment bit 0  */
    unsigned short DMASRCINCR1     : 1; /* DMA source increment bit 1  */
    unsigned short DMADSTINCR0     : 1; /* DMA destination increment bit 0  */
    unsigned short DMADSTINCR1     : 1; /* DMA destination increment bit 1  */
    unsigned short DMADT0          : 1; /* DMA transfer mode bit 0  */
    unsigned short DMADT1          : 1; /* DMA transfer mode bit 1  */
    unsigned short DMADT2          : 1; /* DMA transfer mode bit 2  */
  } DMA2CTL_bit;

  struct
  {
    unsigned char DMA2CTL_L;
    unsigned char DMA2CTL_H;
  };
} @ 0x0530;

/*
enum {
  DMAREQ          = 0x0001,
  DMAABORT        = 0x0002,
  DMAIE           = 0x0004,
  DMAIFG          = 0x0008,
  DMAEN           = 0x0010,
  DMALEVEL        = 0x0020,
  DMASRCBYTE      = 0x0040,
  DMADSTBYTE      = 0x0080,
  DMASRCINCR0     = 0x0100,
  DMASRCINCR1     = 0x0200,
  DMADSTINCR0     = 0x0400,
  DMADSTINCR1     = 0x0800,
  DMADT0          = 0x1000,
  DMADT1          = 0x2000,
  DMADT2          = 0x4000,
};

*/
__no_init volatile union
{
  __ACCESS_20BIT_REG__ DMA2SA;   /* DMA Channel 2 Source Address  */
  struct
  {
    unsigned char DMA2SA_L;
    unsigned char DMA2SA_H;
  };
  struct
  {
    unsigned short DMA2SAL;
    unsigned short DMA2SAH;
  };
} @ 0x0532;

__no_init volatile union
{
  __ACCESS_20BIT_REG__ DMA2DA;   /* DMA Channel 2 Destination Address  */
  struct
  {
    unsigned char DMA2DA_L;
    unsigned char DMA2DA_H;
  };
  struct
  {
    unsigned short DMA2DAL;
    unsigned short DMA2DAH;
  };
} @ 0x0536;


  /* DMA Channel 2 Transfer Size  */
__no_init volatile unsigned short DMA2SZ @ 0x053A;


#define __MSP430_HAS_DMAX_3__           /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_DMAX_3__ 0x0500
#define DMA_BASE __MSP430_BASEADDRESS_DMAX_3__
/* DMACTL0 Control Bits */
#define DMA0TSEL0_L         (0x0001u)    /* DMA channel 0 transfer select bit 0 */
#define DMA0TSEL1_L         (0x0002u)    /* DMA channel 0 transfer select bit 1 */
#define DMA0TSEL2_L         (0x0004u)    /* DMA channel 0 transfer select bit 2 */
#define DMA0TSEL3_L         (0x0008u)    /* DMA channel 0 transfer select bit 3 */
#define DMA0TSEL4_L         (0x0010u)    /* DMA channel 0 transfer select bit 4 */
/* DMACTL0 Control Bits */
#define DMA1TSEL0_H         (0x0001u)    /* DMA channel 1 transfer select bit 0 */
#define DMA1TSEL1_H         (0x0002u)    /* DMA channel 1 transfer select bit 1 */
#define DMA1TSEL2_H         (0x0004u)    /* DMA channel 1 transfer select bit 2 */
#define DMA1TSEL3_H         (0x0008u)    /* DMA channel 1 transfer select bit 3 */
#define DMA1TSEL4_H         (0x0010u)    /* DMA channel 1 transfer select bit 4 */
/* DMACTL01 Control Bits */
#define DMA2TSEL0_L         (0x0001u)    /* DMA channel 2 transfer select bit 0 */
#define DMA2TSEL1_L         (0x0002u)    /* DMA channel 2 transfer select bit 1 */
#define DMA2TSEL2_L         (0x0004u)    /* DMA channel 2 transfer select bit 2 */
#define DMA2TSEL3_L         (0x0008u)    /* DMA channel 2 transfer select bit 3 */
#define DMA2TSEL4_L         (0x0010u)    /* DMA channel 2 transfer select bit 4 */
/* DMACTL4 Control Bits */
#define ENNMI_L             (0x0001u)    /* Enable NMI interruption of DMA */
#define ROUNDROBIN_L        (0x0002u)    /* Round-Robin DMA channel priorities */
#define DMARMWDIS_L         (0x0004u)    /* Inhibited DMA transfers during read-modify-write CPU operations */
/* DMAxCTL Control Bits */
#define DMAREQ_L            (0x0001u)    /* Initiate DMA transfer with DMATSEL */
#define DMAABORT_L          (0x0002u)    /* DMA transfer aborted by NMI */
#define DMAIE_L             (0x0004u)    /* DMA interrupt enable */
#define DMAIFG_L            (0x0008u)    /* DMA interrupt flag */
#define DMAEN_L             (0x0010u)    /* DMA enable */
#define DMALEVEL_L          (0x0020u)    /* DMA level sensitive trigger select */
#define DMASRCBYTE_L        (0x0040u)    /* DMA source byte */
#define DMADSTBYTE_L        (0x0080u)    /* DMA destination byte */
/* DMAxCTL Control Bits */
#define DMASRCINCR0_H       (0x0001u)    /* DMA source increment bit 0 */
#define DMASRCINCR1_H       (0x0002u)    /* DMA source increment bit 1 */
#define DMADSTINCR0_H       (0x0004u)    /* DMA destination increment bit 0 */
#define DMADSTINCR1_H       (0x0008u)    /* DMA destination increment bit 1 */
#define DMADT0_H            (0x0010u)    /* DMA transfer mode bit 0 */
#define DMADT1_H            (0x0020u)    /* DMA transfer mode bit 1 */
#define DMADT2_H            (0x0040u)    /* DMA transfer mode bit 2 */

#define DMASWDW             (0*0x0040u)  /* DMA transfer: source word to destination word */
#define DMASBDW             (1*0x0040u)  /* DMA transfer: source byte to destination word */
#define DMASWDB             (2*0x0040u)  /* DMA transfer: source word to destination byte */
#define DMASBDB             (3*0x0040u)  /* DMA transfer: source byte to destination byte */

#define DMASRCINCR_0        (0*0x0100u)  /* DMA source increment 0: source address unchanged */
#define DMASRCINCR_1        (1*0x0100u)  /* DMA source increment 1: source address unchanged */
#define DMASRCINCR_2        (2*0x0100u)  /* DMA source increment 2: source address decremented */
#define DMASRCINCR_3        (3*0x0100u)  /* DMA source increment 3: source address incremented */

#define DMADSTINCR_0        (0*0x0400u)  /* DMA destination increment 0: destination address unchanged */
#define DMADSTINCR_1        (1*0x0400u)  /* DMA destination increment 1: destination address unchanged */
#define DMADSTINCR_2        (2*0x0400u)  /* DMA destination increment 2: destination address decremented */
#define DMADSTINCR_3        (3*0x0400u)  /* DMA destination increment 3: destination address incremented */

#define DMADT_0             (0*0x1000u)  /* DMA transfer mode 0: Single transfer */
#define DMADT_1             (1*0x1000u)  /* DMA transfer mode 1: Block transfer */
#define DMADT_2             (2*0x1000u)  /* DMA transfer mode 2: Burst-Block transfer */
#define DMADT_3             (3*0x1000u)  /* DMA transfer mode 3: Burst-Block transfer */
#define DMADT_4             (4*0x1000u)  /* DMA transfer mode 4: Repeated Single transfer */
#define DMADT_5             (5*0x1000u)  /* DMA transfer mode 5: Repeated Block transfer */
#define DMADT_6             (6*0x1000u)  /* DMA transfer mode 6: Repeated Burst-Block transfer */
#define DMADT_7             (7*0x1000u)  /* DMA transfer mode 7: Repeated Burst-Block transfer */
/* DMAIV Definitions */
#define DMAIV_NONE           (0x0000u)    /* No Interrupt pending */
#define DMAIV_DMA0IFG        (0x0002u)    /* DMA0IFG*/
#define DMAIV_DMA1IFG        (0x0004u)    /* DMA1IFG*/
#define DMAIV_DMA2IFG        (0x0006u)    /* DMA2IFG*/

#define DMA0TSEL_0          (0*0x0001u)  /* DMA channel 0 transfer select 0 */
#define DMA0TSEL_1          (1*0x0001u)  /* DMA channel 0 transfer select 1 */
#define DMA0TSEL_2          (2*0x0001u)  /* DMA channel 0 transfer select 2 */
#define DMA0TSEL_3          (3*0x0001u)  /* DMA channel 0 transfer select 3 */
#define DMA0TSEL_4          (4*0x0001u)  /* DMA channel 0 transfer select 4 */
#define DMA0TSEL_5          (5*0x0001u)  /* DMA channel 0 transfer select 5 */
#define DMA0TSEL_6          (6*0x0001u)  /* DMA channel 0 transfer select 6 */
#define DMA0TSEL_7          (7*0x0001u)  /* DMA channel 0 transfer select 7 */
#define DMA0TSEL_8          (8*0x0001u)  /* DMA channel 0 transfer select 8 */
#define DMA0TSEL_9          (9*0x0001u)  /* DMA channel 0 transfer select 9 */
#define DMA0TSEL_10         (10*0x0001u) /* DMA channel 0 transfer select 10 */
#define DMA0TSEL_11         (11*0x0001u) /* DMA channel 0 transfer select 11 */
#define DMA0TSEL_12         (12*0x0001u) /* DMA channel 0 transfer select 12 */
#define DMA0TSEL_13         (13*0x0001u) /* DMA channel 0 transfer select 13 */
#define DMA0TSEL_14         (14*0x0001u) /* DMA channel 0 transfer select 14 */
#define DMA0TSEL_15         (15*0x0001u) /* DMA channel 0 transfer select 15 */
#define DMA0TSEL_16         (16*0x0001u) /* DMA channel 0 transfer select 16 */
#define DMA0TSEL_17         (17*0x0001u) /* DMA channel 0 transfer select 17 */
#define DMA0TSEL_18         (18*0x0001u) /* DMA channel 0 transfer select 18 */
#define DMA0TSEL_19         (19*0x0001u) /* DMA channel 0 transfer select 19 */
#define DMA0TSEL_20         (20*0x0001u) /* DMA channel 0 transfer select 20 */
#define DMA0TSEL_21         (21*0x0001u) /* DMA channel 0 transfer select 21 */
#define DMA0TSEL_22         (22*0x0001u) /* DMA channel 0 transfer select 22 */
#define DMA0TSEL_23         (23*0x0001u) /* DMA channel 0 transfer select 23 */
#define DMA0TSEL_24         (24*0x0001u) /* DMA channel 0 transfer select 24 */
#define DMA0TSEL_25         (25*0x0001u) /* DMA channel 0 transfer select 25 */
#define DMA0TSEL_26         (26*0x0001u) /* DMA channel 0 transfer select 26 */
#define DMA0TSEL_27         (27*0x0001u) /* DMA channel 0 transfer select 27 */
#define DMA0TSEL_28         (28*0x0001u) /* DMA channel 0 transfer select 28 */
#define DMA0TSEL_29         (29*0x0001u) /* DMA channel 0 transfer select 29 */
#define DMA0TSEL_30         (30*0x0001u) /* DMA channel 0 transfer select 30 */
#define DMA0TSEL_31         (31*0x0001u) /* DMA channel 0 transfer select 31 */

#define DMA1TSEL_0          (0*0x0100u)  /* DMA channel 1 transfer select 0 */
#define DMA1TSEL_1          (1*0x0100u)  /* DMA channel 1 transfer select 1 */
#define DMA1TSEL_2          (2*0x0100u)  /* DMA channel 1 transfer select 2 */
#define DMA1TSEL_3          (3*0x0100u)  /* DMA channel 1 transfer select 3 */
#define DMA1TSEL_4          (4*0x0100u)  /* DMA channel 1 transfer select 4 */
#define DMA1TSEL_5          (5*0x0100u)  /* DMA channel 1 transfer select 5 */
#define DMA1TSEL_6          (6*0x0100u)  /* DMA channel 1 transfer select 6 */
#define DMA1TSEL_7          (7*0x0001u)  /* DMA channel 1 transfer select 7 */
#define DMA1TSEL_8          (8*0x0001u)  /* DMA channel 1 transfer select 8 */
#define DMA1TSEL_9          (9*0x0100u)  /* DMA channel 1 transfer select 9 */
#define DMA1TSEL_10         (10*0x0100u) /* DMA channel 1 transfer select 10 */
#define DMA1TSEL_11         (11*0x0100u) /* DMA channel 1 transfer select 11 */
#define DMA1TSEL_12         (12*0x0100u) /* DMA channel 1 transfer select 12 */
#define DMA1TSEL_13         (13*0x0100u) /* DMA channel 1 transfer select 13 */
#define DMA1TSEL_14         (14*0x0100u) /* DMA channel 1 transfer select 14 */
#define DMA1TSEL_15         (15*0x0100u) /* DMA channel 1 transfer select 15 */
#define DMA1TSEL_16         (16*0x0100u) /* DMA channel 1 transfer select 16 */
#define DMA1TSEL_17         (17*0x0100u) /* DMA channel 1 transfer select 17 */
#define DMA1TSEL_18         (18*0x0100u) /* DMA channel 1 transfer select 18 */
#define DMA1TSEL_19         (19*0x0100u) /* DMA channel 1 transfer select 19 */
#define DMA1TSEL_20         (20*0x0100u) /* DMA channel 1 transfer select 20 */
#define DMA1TSEL_21         (21*0x0100u) /* DMA channel 1 transfer select 21 */
#define DMA1TSEL_22         (22*0x0100u) /* DMA channel 1 transfer select 22 */
#define DMA1TSEL_23         (23*0x0100u) /* DMA channel 1 transfer select 23 */
#define DMA1TSEL_24         (24*0x0100u) /* DMA channel 1 transfer select 24 */
#define DMA1TSEL_25         (25*0x0100u) /* DMA channel 1 transfer select 25 */
#define DMA1TSEL_26         (26*0x0100u) /* DMA channel 1 transfer select 26 */
#define DMA1TSEL_27         (27*0x0100u) /* DMA channel 1 transfer select 27 */
#define DMA1TSEL_28         (28*0x0100u) /* DMA channel 1 transfer select 28 */
#define DMA1TSEL_29         (29*0x0100u) /* DMA channel 1 transfer select 29 */
#define DMA1TSEL_30         (30*0x0100u) /* DMA channel 1 transfer select 30 */
#define DMA1TSEL_31         (31*0x0100u) /* DMA channel 1 transfer select 31 */

#define DMA2TSEL_0          (0*0x0001u)  /* DMA channel 2 transfer select 0 */
#define DMA2TSEL_1          (1*0x0001u)  /* DMA channel 2 transfer select 1 */
#define DMA2TSEL_2          (2*0x0001u)  /* DMA channel 2 transfer select 2 */
#define DMA2TSEL_3          (3*0x0001u)  /* DMA channel 2 transfer select 3 */
#define DMA2TSEL_4          (4*0x0001u)  /* DMA channel 2 transfer select 4 */
#define DMA2TSEL_5          (5*0x0001u)  /* DMA channel 2 transfer select 5 */
#define DMA2TSEL_6          (6*0x0001u)  /* DMA channel 2 transfer select 6 */
#define DMA2TSEL_7          (7*0x0001u)  /* DMA channel 2 transfer select 7 */
#define DMA2TSEL_8          (8*0x0001u)  /* DMA channel 2 transfer select 8 */
#define DMA2TSEL_9          (9*0x0001u)  /* DMA channel 2 transfer select 9 */
#define DMA2TSEL_10         (10*0x0001u) /* DMA channel 2 transfer select 10 */
#define DMA2TSEL_11         (11*0x0001u) /* DMA channel 2 transfer select 11 */
#define DMA2TSEL_12         (12*0x0001u) /* DMA channel 2 transfer select 12 */
#define DMA2TSEL_13         (13*0x0001u) /* DMA channel 2 transfer select 13 */
#define DMA2TSEL_14         (14*0x0001u) /* DMA channel 2 transfer select 14 */
#define DMA2TSEL_15         (15*0x0001u) /* DMA channel 2 transfer select 15 */
#define DMA2TSEL_16         (16*0x0001u) /* DMA channel 2 transfer select 16 */
#define DMA2TSEL_17         (17*0x0001u) /* DMA channel 2 transfer select 17 */
#define DMA2TSEL_18         (18*0x0001u) /* DMA channel 2 transfer select 18 */
#define DMA2TSEL_19         (19*0x0001u) /* DMA channel 2 transfer select 19 */
#define DMA2TSEL_20         (20*0x0001u) /* DMA channel 2 transfer select 20 */
#define DMA2TSEL_21         (21*0x0001u) /* DMA channel 2 transfer select 21 */
#define DMA2TSEL_22         (22*0x0001u) /* DMA channel 2 transfer select 22 */
#define DMA2TSEL_23         (23*0x0001u) /* DMA channel 2 transfer select 23 */
#define DMA2TSEL_24         (24*0x0001u) /* DMA channel 2 transfer select 24 */
#define DMA2TSEL_25         (25*0x0001u) /* DMA channel 2 transfer select 25 */
#define DMA2TSEL_26         (26*0x0001u) /* DMA channel 2 transfer select 26 */
#define DMA2TSEL_27         (27*0x0001u) /* DMA channel 2 transfer select 27 */
#define DMA2TSEL_28         (28*0x0001u) /* DMA channel 2 transfer select 28 */
#define DMA2TSEL_29         (29*0x0001u) /* DMA channel 2 transfer select 29 */
#define DMA2TSEL_30         (30*0x0001u) /* DMA channel 2 transfer select 30 */
#define DMA2TSEL_31         (31*0x0001u) /* DMA channel 2 transfer select 31 */

#define DMA0TSEL__DMA_REQ   (0*0x0001u)  /* DMA channel 0 transfer select 0:  DMA_REQ (sw) */
#define DMA0TSEL__TA0CCR0   (1*0x0001u)  /* DMA channel 0 transfer select 1:  Timer0_A (TA0CCR0.IFG) */
#define DMA0TSEL__TA0CCR1   (2*0x0001u)  /* DMA channel 0 transfer select 2:  Timer0_A (TA0CCR1.IFG) */
#define DMA0TSEL__TA1CCR0   (3*0x0001u)  /* DMA channel 0 transfer select 3:  Timer1_A (TA1CCR0.IFG) */
#define DMA0TSEL__RES4      (4*0x0001u)  /* DMA channel 0 transfer select 4:  Reserved */
#define DMA0TSEL__TA2CCR0   (5*0x0001u)  /* DMA channel 0 transfer select 5:  Timer2_A (TA2CCR0.IFG) */
#define DMA0TSEL__RES6      (6*0x0001u)  /* DMA channel 0 transfer select 6:  Reserved */
#define DMA0TSEL__TA3CCR0   (7*0x0001u)  /* DMA channel 0 transfer select 7:  Timer3_A (TA3CCR0.IFG) */
#define DMA0TSEL__RES8      (8*0x0001u)  /* DMA channel 0 transfer select 8:  Reserved */
#define DMA0TSEL__RES9      (9*0x0001u)  /* DMA channel 0 transfer select 9:  Reserved */
#define DMA0TSEL__RES10     (10*0x0001u) /* DMA channel 0 transfer select 10: Reserved */
#define DMA0TSEL__RES11     (11*0x0001u) /* DMA channel 0 transfer select 11: Reserved */
#define DMA0TSEL__RES12     (12*0x0001u) /* DMA channel 0 transfer select 12: Reserved */
#define DMA0TSEL__SD24IFG   (13*0x0001u) /* DMA channel 0 transfer select 13: SD24IFG */
#define DMA0TSEL__RES14     (14*0x0001u) /* DMA channel 0 transfer select 14: Reserved */
#define DMA0TSEL__RES15     (15*0x0001u) /* DMA channel 0 transfer select 15: Reserved */
#define DMA0TSEL__USCIA0RX  (16*0x0001u) /* DMA channel 0 transfer select 16: USCIA0 receive */
#define DMA0TSEL__USCIA0TX  (17*0x0001u) /* DMA channel 0 transfer select 17: USCIA0 transmit */
#define DMA0TSEL__USCIA1RX  (18*0x0001u) /* DMA channel 0 transfer select 18: USCIA1 receive */
#define DMA0TSEL__USCIA1TX  (19*0x0001u) /* DMA channel 0 transfer select 19: USCIA1 transmit */
#define DMA0TSEL__USCIA2RX  (20*0x0001u) /* DMA channel 0 transfer select 20: USCIA2 receive */
#define DMA0TSEL__USCIA2TX  (21*0x0001u) /* DMA channel 0 transfer select 21: USCIA2 transmit */
#define DMA0TSEL__USCIB0RX  (22*0x0001u) /* DMA channel 0 transfer select 22: USCIB0 receive */
#define DMA0TSEL__USCIB0TX  (23*0x0001u) /* DMA channel 0 transfer select 23: USCIB0 transmit */
#define DMA0TSEL__ADC10IFG0 (24*0x0001u) /* DMA channel 0 transfer select 24: ADC10IFG0 */
#define DMA0TSEL__RES25     (25*0x0001u) /* DMA channel 0 transfer select 25: Reserved */
#define DMA0TSEL__RES26     (26*0x0001u) /* DMA channel 0 transfer select 26: Reserved */
#define DMA0TSEL__RES27     (27*0x0001u) /* DMA channel 0 transfer select 27: Reserved */
#define DMA0TSEL__RES28     (28*0x0001u) /* DMA channel 0 transfer select 28: Reserved */
#define DMA0TSEL__MPY       (29*0x0001u) /* DMA channel 0 transfer select 29: Multiplier ready */
#define DMA0TSEL__DMA2IFG   (30*0x0001u) /* DMA channel 0 transfer select 30: previous DMA channel DMA2IFG */
#define DMA0TSEL__DMAE0     (31*0x0001u) /* DMA channel 0 transfer select 31: ext. Trigger (DMAE0) */

#define DMA1TSEL__DMA_REQ   (0*0x0100u)  /* DMA channel 1 transfer select 0:  DMA_REQ (sw) */
#define DMA1TSEL__TA0CCR0   (1*0x0100u)  /* DMA channel 1 transfer select 1:  Timer0_A (TA0CCR0.IFG) */
#define DMA1TSEL__TA0CCR1   (2*0x0100u)  /* DMA channel 1 transfer select 2:  Timer0_A (TA0CCR1.IFG) */
#define DMA1TSEL__TA1CCR0   (3*0x0100u)  /* DMA channel 1 transfer select 3:  Timer1_A (TA1CCR0.IFG) */
#define DMA1TSEL__RES4      (4*0x0100u)  /* DMA channel 1 transfer select 4:  Reserved */
#define DMA1TSEL__TA2CCR0   (5*0x0100u)  /* DMA channel 1 transfer select 5:  Timer2_A (TA2CCR0.IFG) */
#define DMA1TSEL__RES6      (6*0x0100u)  /* DMA channel 1 transfer select 6:  Reserved */
#define DMA1TSEL__TA3CCR0   (7*0x0001u)  /* DMA channel 1 transfer select 7:  Timer3_A (TA3CCR0.IFG) */
#define DMA1TSEL__RES8      (8*0x0001u)  /* DMA channel 1 transfer select 8:  Reserved */
#define DMA1TSEL__RES9      (9*0x0100u)  /* DMA channel 1 transfer select 9:  Reserved */
#define DMA1TSEL__RES10     (10*0x0100u) /* DMA channel 1 transfer select 10: Reserved */
#define DMA1TSEL__RES11     (11*0x0100u) /* DMA channel 1 transfer select 11: Reserved */
#define DMA1TSEL__RES12     (12*0x0100u) /* DMA channel 1 transfer select 12: Reserved */
#define DMA1TSEL__SD24IFG   (13*0x0100u) /* DMA channel 1 transfer select 13: SD24IFG */
#define DMA1TSEL__RES14     (14*0x0100u) /* DMA channel 1 transfer select 14: Reserved */
#define DMA1TSEL__RES15     (15*0x0100u) /* DMA channel 1 transfer select 15: Reserved */
#define DMA1TSEL__USCIA0RX  (16*0x0100u) /* DMA channel 1 transfer select 16: USCIA0 receive */
#define DMA1TSEL__USCIA0TX  (17*0x0100u) /* DMA channel 1 transfer select 17: USCIA0 transmit */
#define DMA1TSEL__USCIA1RX  (18*0x0100u) /* DMA channel 1 transfer select 18: USCIA1 receive */
#define DMA1TSEL__USCIA1TX  (19*0x0100u) /* DMA channel 1 transfer select 19: USCIA1 transmit */
#define DMA1TSEL__USCIA2RX  (20*0x0100u) /* DMA channel 1 transfer select 20: USCIA2 receive */
#define DMA1TSEL__USCIA2TX  (21*0x0100u) /* DMA channel 1 transfer select 21: USCIA2 transmit */
#define DMA1TSEL__USCIB0RX  (22*0x0100u) /* DMA channel 1 transfer select 22: USCIB0 receive */
#define DMA1TSEL__USCIB0TX  (23*0x0100u) /* DMA channel 1 transfer select 23: USCIB0 transmit */
#define DMA1TSEL__ADC10IFG0 (24*0x0100u) /* DMA channel 1 transfer select 24: ADC10IFG0 */
#define DMA1TSEL__RES25     (25*0x0100u) /* DMA channel 1 transfer select 25: Reserved */
#define DMA1TSEL__RES26     (26*0x0100u) /* DMA channel 1 transfer select 26: Reserved */
#define DMA1TSEL__RES27     (27*0x0100u) /* DMA channel 1 transfer select 27: Reserved */
#define DMA1TSEL__RES28     (28*0x0100u) /* DMA channel 1 transfer select 28: Reserved */
#define DMA1TSEL__MPY       (29*0x0100u) /* DMA channel 1 transfer select 29: Multiplier ready */
#define DMA1TSEL__DMA0IFG   (30*0x0100u) /* DMA channel 1 transfer select 30: previous DMA channel DMA0IFG */
#define DMA1TSEL__DMAE0     (31*0x0100u) /* DMA channel 1 transfer select 31: ext. Trigger (DMAE0) */

#define DMA2TSEL__DMA_REQ   (0*0x0001u)  /* DMA channel 2 transfer select 0:  DMA_REQ (sw) */
#define DMA2TSEL__TA0CCR0   (1*0x0001u)  /* DMA channel 2 transfer select 1:  Timer0_A (TA0CCR0.IFG) */
#define DMA2TSEL__TA0CCR1   (2*0x0001u)  /* DMA channel 2 transfer select 2:  Timer0_A (TA0CCR1.IFG) */
#define DMA2TSEL__TA1CCR0   (3*0x0001u)  /* DMA channel 2 transfer select 3:  Timer1_A (TA1CCR0.IFG) */
#define DMA2TSEL__RES4      (4*0x0001u)  /* DMA channel 2 transfer select 4:  Reserved */
#define DMA2TSEL__TA2CCR0   (5*0x0001u)  /* DMA channel 2 transfer select 5:  Timer2_A (TA2CCR0.IFG) */
#define DMA2TSEL__RES6      (6*0x0001u)  /* DMA channel 2 transfer select 6:  Reserved */
#define DMA2TSEL__TA3CCR0   (7*0x0001u)  /* DMA channel 2 transfer select 7:  Timer3_A (TA3CCR0.IFG) */
#define DMA2TSEL__RES8      (8*0x0001u)  /* DMA channel 2 transfer select 8:  Reserved */
#define DMA2TSEL__RES9      (9*0x0001u)  /* DMA channel 2 transfer select 9:  Reserved */
#define DMA2TSEL__RES10     (10*0x0001u) /* DMA channel 2 transfer select 10: Reserved */
#define DMA2TSEL__RES11     (11*0x0001u) /* DMA channel 2 transfer select 11: Reserved */
#define DMA2TSEL__RES12     (12*0x0001u) /* DMA channel 2 transfer select 12: Reserved */
#define DMA2TSEL__SD24IFG   (13*0x0001u) /* DMA channel 2 transfer select 13: SD24IFG */
#define DMA2TSEL__RES14     (14*0x0001u) /* DMA channel 2 transfer select 14: Reserved */
#define DMA2TSEL__RES15     (15*0x0001u) /* DMA channel 2 transfer select 15: Reserved */
#define DMA2TSEL__USCIA0RX  (16*0x0001u) /* DMA channel 2 transfer select 16: USCIA0 receive */
#define DMA2TSEL__USCIA0TX  (17*0x0001u) /* DMA channel 2 transfer select 17: USCIA0 transmit */
#define DMA2TSEL__USCIA1RX  (18*0x0001u) /* DMA channel 2 transfer select 18: USCIA1 receive */
#define DMA2TSEL__USCIA1TX  (19*0x0001u) /* DMA channel 2 transfer select 19: USCIA1 transmit */
#define DMA2TSEL__USCIA2RX  (20*0x0001u) /* DMA channel 2 transfer select 20: USCIA2 receive */
#define DMA2TSEL__USCIA2TX  (21*0x0001u) /* DMA channel 2 transfer select 21: USCIA2 transmit */
#define DMA2TSEL__USCIB0RX  (22*0x0001u) /* DMA channel 2 transfer select 22: USCIB0 receive */
#define DMA2TSEL__USCIB0TX  (23*0x0001u) /* DMA channel 2 transfer select 23: USCIB0 transmit */
#define DMA2TSEL__ADC10IFG0 (24*0x0001u) /* DMA channel 2 transfer select 24: ADC10IFG0 */
#define DMA2TSEL__RES25     (25*0x0001u) /* DMA channel 2 transfer select 25: Reserved */
#define DMA2TSEL__RES26     (26*0x0001u) /* DMA channel 2 transfer select 26: Reserved */
#define DMA2TSEL__RES27     (27*0x0001u) /* DMA channel 2 transfer select 27: Reserved */
#define DMA2TSEL__RES28     (28*0x0001u) /* DMA channel 2 transfer select 28: Reserved */
#define DMA2TSEL__MPY       (29*0x0001u) /* DMA channel 2 transfer select 29: Multiplier ready */
#define DMA2TSEL__DMA1IFG   (30*0x0001u) /* DMA channel 2 transfer select 30: previous DMA channel DMA1IFG */
#define DMA2TSEL__DMAE0     (31*0x0001u) /* DMA channel 2 transfer select 31: ext. Trigger (DMAE0) */

/*-------------------------------------------------------------------------
 *   Flash
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short FCTL1;   /* FLASH Control 1  */

  struct
  {
    unsigned short                : 1;
    unsigned short ERASE           : 1; /* Enable bit for Flash segment erase  */
    unsigned short MERAS           : 1; /* Enable bit for Flash mass erase  */
    unsigned short                : 2;
    unsigned short SWRT            : 1; /* Smart Write enable  */
    unsigned short WRT             : 1; /* Enable bit for Flash write  */
    unsigned short BLKWRT          : 1; /* Enable bit for Flash segment write  */
  } FCTL1_bit;

  struct
  {
    unsigned char FCTL1_L;
    unsigned char FCTL1_H;
  };
} @ 0x0140;

enum {
  ERASE           = 0x0002,
  MERAS           = 0x0004,
  SWRT            = 0x0020,
  WRT             = 0x0040,
  BLKWRT          = 0x0080
};

__no_init volatile union
{
  unsigned short FCTL3;   /* FLASH Control 3  */

  struct
  {
    unsigned short BUSY            : 1; /* Flash busy: 1  */
    unsigned short KEYV            : 1; /* Flash Key violation flag  */
    unsigned short ACCVIFG         : 1; /* Flash Access violation flag  */
    unsigned short WAIT            : 1; /* Wait flag for segment write  */
    unsigned short LOCK            : 1; /* Lock bit: 1 - Flash is locked (read only)  */
    unsigned short EMEX            : 1; /* Flash Emergency Exit  */
    unsigned short LOCKA           : 1; /* Segment A Lock bit: read = 1 - Segment is locked (read only)  */
  } FCTL3_bit;

  struct
  {
    unsigned char FCTL3_L;
    unsigned char FCTL3_H;
  };
} @ 0x0144;

enum {
  BUSY            = 0x0001,
  KEYV            = 0x0002,
  ACCVIFG         = 0x0004,
  WAIT            = 0x0008,
  LOCK            = 0x0010,
  EMEX            = 0x0020,
  LOCKA           = 0x0040
};

__no_init volatile union
{
  unsigned short FCTL4;   /* FLASH Control 4  */

  struct
  {
    unsigned short VPE             : 1; /* Voltage Changed during Program Error Flag  */
    unsigned short                : 3;
    unsigned short MGR0            : 1; /* Marginal read 0 mode.  */
    unsigned short MGR1            : 1; /* Marginal read 1 mode.  */
    unsigned short                : 1;
    unsigned short LOCKINFO        : 1; /* Lock INFO Memory bit: read = 1 - Segment is locked (read only)  */
  } FCTL4_bit;

  struct
  {
    unsigned char FCTL4_L;
    unsigned char FCTL4_H;
  };
} @ 0x0146;

enum {
  VPE             = 0x0001,
  MGR0            = 0x0010,
  MGR1            = 0x0020,
  LOCKINFO        = 0x0080
};



#define __MSP430_HAS_FLASH__         /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_FLASH__ 0x0140
#define FLASH_BASE __MSP430_BASEADDRESS_FLASH__

#define FRPW                (0x9600u)  /* Flash password returned by read */
#define FWPW                (0xA500u)  /* Flash password for write */
#define FXPW                (0x3300u)  /* for use with XOR instruction */
#define FRKEY               (0x9600u)  /* (legacy definition) Flash key returned by read */
#define FWKEY               (0xA500u)  /* (legacy definition) Flash key for write */
#define FXKEY               (0x3300u)  /* (legacy definition) for use with XOR instruction */
#define ERASE_L             (0x0002u)  /* Enable bit for Flash segment erase */
#define MERAS_L             (0x0004u)  /* Enable bit for Flash mass erase */
#define SWRT_L              (0x0020u)  /* Smart Write enable */
#define WRT_L               (0x0040u)  /* Enable bit for Flash write */
#define BLKWRT_L            (0x0080u)  /* Enable bit for Flash segment write */
/* FCTL3 Control Bits */
#define BUSY_L              (0x0001u)  /* Flash busy: 1 */
#define KEYV_L              (0x0002u)  /* Flash Key violation flag */
#define ACCVIFG_L           (0x0004u)  /* Flash Access violation flag */
#define WAIT_L              (0x0008u)  /* Wait flag for segment write */
#define LOCK_L              (0x0010u)  /* Lock bit: 1 - Flash is locked (read only) */
#define EMEX_L              (0x0020u)  /* Flash Emergency Exit */
#define LOCKA_L             (0x0040u)  /* Segment A Lock bit: read = 1 - Segment is locked (read only) */
/* FCTL4 Control Bits */
#define VPE_L               (0x0001u)  /* Voltage Changed during Program Error Flag */
#define MGR0_L              (0x0010u)  /* Marginal read 0 mode. */
#define MGR1_L              (0x0020u)  /* Marginal read 1 mode. */
#define LOCKINFO_L          (0x0080u)  /* Lock INFO Memory bit: read = 1 - Segment is locked (read only) */

/*-------------------------------------------------------------------------
 *   LCD_C
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short LCDCCTL0;   /* LCD_C Control Register 0  */

  struct
  {
    unsigned short LCDON           : 1; /* LCD_C LCD On  */
    unsigned short LCDLP           : 1; /* LCD_C Low Power Waveform  */
    unsigned short LCDSON          : 1; /* LCD_C LCD Segments On  */
    unsigned short LCDMX0          : 1; /* LCD_C Mux Rate Bit: 0  */
    unsigned short LCDMX1          : 1; /* LCD_C Mux Rate Bit: 1  */
    unsigned short LCDMX2          : 1; /* LCD_C Mux Rate Bit: 2  */
    unsigned short                : 1;
    unsigned short LCDSSEL         : 1; /* LCD_C Clock Select  */
    unsigned short LCDPRE0         : 1; /* LCD_C LCD frequency pre-scaler Bit: 0  */
    unsigned short LCDPRE1         : 1; /* LCD_C LCD frequency pre-scaler Bit: 1  */
    unsigned short LCDPRE2         : 1; /* LCD_C LCD frequency pre-scaler Bit: 2  */
    unsigned short LCDDIV0         : 1; /* LCD_C LCD frequency divider Bit: 0  */
    unsigned short LCDDIV1         : 1; /* LCD_C LCD frequency divider Bit: 1  */
    unsigned short LCDDIV2         : 1; /* LCD_C LCD frequency divider Bit: 2  */
    unsigned short LCDDIV3         : 1; /* LCD_C LCD frequency divider Bit: 3  */
    unsigned short LCDDIV4         : 1; /* LCD_C LCD frequency divider Bit: 4  */
  } LCDCCTL0_bit;

  struct
  {
    unsigned char LCDCCTL0_L;
    unsigned char LCDCCTL0_H;
  };
} @ 0x0A00;

enum {
  LCDON           = 0x0001,
  LCDLP           = 0x0002,
  LCDSON          = 0x0004,
  LCDMX0          = 0x0008,
  LCDMX1          = 0x0010,
  LCDMX2          = 0x0020,
  LCDSSEL         = 0x0080,
  LCDPRE0         = 0x0100,
  LCDPRE1         = 0x0200,
  LCDPRE2         = 0x0400,
  LCDDIV0         = 0x0800,
  LCDDIV1         = 0x1000,
  LCDDIV2         = 0x2000,
  LCDDIV3         = 0x4000,
  LCDDIV4         = 0x8000
};

__no_init volatile union
{
  unsigned short LCDCCTL1;   /* LCD_C Control Register 1  */

  struct
  {
    unsigned short LCDFRMIFG       : 1; /* LCD_C LCD frame interrupt flag  */
    unsigned short LCDBLKOFFIFG    : 1; /* LCD_C LCD blinking off interrupt flag,  */
    unsigned short LCDBLKONIFG     : 1; /* LCD_C LCD blinking on interrupt flag,  */
    unsigned short LCDNOCAPIFG     : 1; /* LCD_C No cpacitance connected interrupt flag  */
    unsigned short                : 4;
    unsigned short LCDFRMIE        : 1; /* LCD_C LCD frame interrupt enable  */
    unsigned short LCDBLKOFFIE     : 1; /* LCD_C LCD blinking off interrupt flag,  */
    unsigned short LCDBLKONIE      : 1; /* LCD_C LCD blinking on interrupt flag,  */
    unsigned short LCDNOCAPIE      : 1; /* LCD_C No cpacitance connected interrupt enable  */
  } LCDCCTL1_bit;

  struct
  {
    unsigned char LCDCCTL1_L;
    unsigned char LCDCCTL1_H;
  };
} @ 0x0A02;

enum {
  LCDFRMIFG       = 0x0001,
  LCDBLKOFFIFG    = 0x0002,
  LCDBLKONIFG     = 0x0004,
  LCDNOCAPIFG     = 0x0008,
  LCDFRMIE        = 0x0100,
  LCDBLKOFFIE     = 0x0200,
  LCDBLKONIE      = 0x0400,
  LCDNOCAPIE      = 0x0800
};

__no_init volatile union
{
  unsigned short LCDCBLKCTL;   /* LCD_C blinking control register  */

  struct
  {
    unsigned short LCDBLKMOD0      : 1; /* LCD_C Blinking mode Bit: 0  */
    unsigned short LCDBLKMOD1      : 1; /* LCD_C Blinking mode Bit: 1  */
    unsigned short LCDBLKPRE0      : 1; /* LCD_C Clock pre-scaler for blinking frequency Bit: 0  */
    unsigned short LCDBLKPRE1      : 1; /* LCD_C Clock pre-scaler for blinking frequency Bit: 1  */
    unsigned short LCDBLKPRE2      : 1; /* LCD_C Clock pre-scaler for blinking frequency Bit: 2  */
    unsigned short LCDBLKDIV0      : 1; /* LCD_C Clock divider for blinking frequency Bit: 0  */
    unsigned short LCDBLKDIV1      : 1; /* LCD_C Clock divider for blinking frequency Bit: 1  */
    unsigned short LCDBLKDIV2      : 1; /* LCD_C Clock divider for blinking frequency Bit: 2  */
  } LCDCBLKCTL_bit;

  struct
  {
    unsigned char LCDCBLKCTL_L;
    unsigned char LCDCBLKCTL_H;
  };
} @ 0x0A04;

enum {
  LCDBLKMOD0      = 0x0001,
  LCDBLKMOD1      = 0x0002,
  LCDBLKPRE0      = 0x0004,
  LCDBLKPRE1      = 0x0008,
  LCDBLKPRE2      = 0x0010,
  LCDBLKDIV0      = 0x0020,
  LCDBLKDIV1      = 0x0040,
  LCDBLKDIV2      = 0x0080
};

__no_init volatile union
{
  unsigned short LCDCMEMCTL;   /* LCD_C memory control register  */

  struct
  {
    unsigned short LCDDISP         : 1; /* LCD_C LCD memory registers for display  */
    unsigned short LCDCLRM         : 1; /* LCD_C Clear LCD memory  */
    unsigned short LCDCLRBM        : 1; /* LCD_C Clear LCD blinking memory  */
  } LCDCMEMCTL_bit;

  struct
  {
    unsigned char LCDCMEMCTL_L;
    unsigned char LCDCMEMCTL_H;
  };
} @ 0x0A06;

enum {
  LCDDISP         = 0x0001,
  LCDCLRM         = 0x0002,
  LCDCLRBM        = 0x0004
};

__no_init volatile union
{
  unsigned short LCDCVCTL;   /* LCD_C Voltage Control Register  */

  struct
  {
    unsigned short LCD2B           : 1; /* Selects 1/2 bias.  */
    unsigned short VLCDREF0        : 1; /* Selects reference voltage for regulated charge pump: 0  */
    unsigned short VLCDREF1        : 1; /* Selects reference voltage for regulated charge pump: 1  */
    unsigned short LCDCPEN         : 1; /* LCD Voltage Charge Pump Enable.  */
    unsigned short VLCDEXT         : 1; /* Select external source for VLCD.  */
    unsigned short LCDEXTBIAS      : 1; /* V2 - V4 voltage select.  */
    unsigned short R03EXT          : 1; /* Selects external connections for LCD mid voltages.  */
    unsigned short LCDREXT         : 1; /* Selects external connection for lowest LCD voltage.  */
    unsigned short                : 1;
    unsigned short VLCD0           : 1; /* VLCD select: 0  */
    unsigned short VLCD1           : 1; /* VLCD select: 1  */
    unsigned short VLCD2           : 1; /* VLCD select: 2  */
    unsigned short VLCD3           : 1; /* VLCD select: 3  */
    unsigned short VLCD4           : 1; /* VLCD select: 4  */
    unsigned short VLCD5           : 1; /* VLCD select: 5  */
  } LCDCVCTL_bit;

  struct
  {
    unsigned char LCDCVCTL_L;
    unsigned char LCDCVCTL_H;
  };
} @ 0x0A08;

enum {
  LCD2B           = 0x0001,
  VLCDREF0        = 0x0002,
  VLCDREF1        = 0x0004,
  LCDCPEN         = 0x0008,
  VLCDEXT         = 0x0010,
  LCDEXTBIAS      = 0x0020,
  R03EXT          = 0x0040,
  LCDREXT         = 0x0080,
  VLCD0           = 0x0200,
  VLCD1           = 0x0400,
  VLCD2           = 0x0800,
  VLCD3           = 0x1000,
  VLCD4           = 0x2000,
  VLCD5           = 0x4000
};

__no_init volatile union
{
  unsigned short LCDCPCTL0;   /* LCD_C Port Control Register 0  */

  struct
  {
    unsigned short LCDS0           : 1; /* LCD Segment  0 enable.  */
    unsigned short LCDS1           : 1; /* LCD Segment  1 enable.  */
    unsigned short LCDS2           : 1; /* LCD Segment  2 enable.  */
    unsigned short LCDS3           : 1; /* LCD Segment  3 enable.  */
    unsigned short LCDS4           : 1; /* LCD Segment  4 enable.  */
    unsigned short LCDS5           : 1; /* LCD Segment  5 enable.  */
    unsigned short LCDS6           : 1; /* LCD Segment  6 enable.  */
    unsigned short LCDS7           : 1; /* LCD Segment  7 enable.  */
    unsigned short LCDS8           : 1; /* LCD Segment  8 enable.  */
    unsigned short LCDS9           : 1; /* LCD Segment  9 enable.  */
    unsigned short LCDS10          : 1; /* LCD Segment 10 enable.  */
    unsigned short LCDS11          : 1; /* LCD Segment 11 enable.  */
    unsigned short LCDS12          : 1; /* LCD Segment 12 enable.  */
    unsigned short LCDS13          : 1; /* LCD Segment 13 enable.  */
    unsigned short LCDS14          : 1; /* LCD Segment 14 enable.  */
    unsigned short LCDS15          : 1; /* LCD Segment 15 enable.  */
  } LCDCPCTL0_bit;

  struct
  {
    unsigned char LCDCPCTL0_L;
    unsigned char LCDCPCTL0_H;
  };
} @ 0x0A0A;

enum {
  LCDS0           = 0x0001,
  LCDS1           = 0x0002,
  LCDS2           = 0x0004,
  LCDS3           = 0x0008,
  LCDS4           = 0x0010,
  LCDS5           = 0x0020,
  LCDS6           = 0x0040,
  LCDS7           = 0x0080,
  LCDS8           = 0x0100,
  LCDS9           = 0x0200,
  LCDS10          = 0x0400,
  LCDS11          = 0x0800,
  LCDS12          = 0x1000,
  LCDS13          = 0x2000,
  LCDS14          = 0x4000,
  LCDS15          = 0x8000
};

__no_init volatile union
{
  unsigned short LCDCPCTL1;   /* LCD_C Port Control Register 1  */

  struct
  {
    unsigned short LCDS16          : 1; /* LCD Segment 16 enable.  */
    unsigned short LCDS17          : 1; /* LCD Segment 17 enable.  */
    unsigned short LCDS18          : 1; /* LCD Segment 18 enable.  */
    unsigned short LCDS19          : 1; /* LCD Segment 19 enable.  */
    unsigned short LCDS20          : 1; /* LCD Segment 20 enable.  */
    unsigned short LCDS21          : 1; /* LCD Segment 21 enable.  */
    unsigned short LCDS22          : 1; /* LCD Segment 22 enable.  */
    unsigned short LCDS23          : 1; /* LCD Segment 23 enable.  */
    unsigned short LCDS24          : 1; /* LCD Segment 24 enable.  */
    unsigned short LCDS25          : 1; /* LCD Segment 25 enable.  */
    unsigned short LCDS26          : 1; /* LCD Segment 26 enable.  */
    unsigned short LCDS27          : 1; /* LCD Segment 27 enable.  */
    unsigned short LCDS28          : 1; /* LCD Segment 28 enable.  */
    unsigned short LCDS29          : 1; /* LCD Segment 29 enable.  */
    unsigned short LCDS30          : 1; /* LCD Segment 30 enable.  */
    unsigned short LCDS31          : 1; /* LCD Segment 31 enable.  */
  } LCDCPCTL1_bit;

  struct
  {
    unsigned char LCDCPCTL1_L;
    unsigned char LCDCPCTL1_H;
  };
} @ 0x0A0C;

enum {
  LCDS16          = 0x0001,
  LCDS17          = 0x0002,
  LCDS18          = 0x0004,
  LCDS19          = 0x0008,
  LCDS20          = 0x0010,
  LCDS21          = 0x0020,
  LCDS22          = 0x0040,
  LCDS23          = 0x0080,
  LCDS24          = 0x0100,
  LCDS25          = 0x0200,
  LCDS26          = 0x0400,
  LCDS27          = 0x0800,
  LCDS28          = 0x1000,
  LCDS29          = 0x2000,
  LCDS30          = 0x4000,
  LCDS31          = 0x8000
};

__no_init volatile union
{
  unsigned short LCDCPCTL2;   /* LCD_C Port Control Register 2  */

  struct
  {
    unsigned short LCDS32          : 1; /* LCD Segment 32 enable.  */
    unsigned short LCDS33          : 1; /* LCD Segment 33 enable.  */
    unsigned short LCDS34          : 1; /* LCD Segment 34 enable.  */
    unsigned short LCDS35          : 1; /* LCD Segment 35 enable.  */
    unsigned short LCDS36          : 1; /* LCD Segment 36 enable.  */
    unsigned short LCDS37          : 1; /* LCD Segment 37 enable.  */
    unsigned short LCDS38          : 1; /* LCD Segment 38 enable.  */
    unsigned short LCDS39          : 1; /* LCD Segment 39 enable.  */
    unsigned short LCDS40          : 1; /* LCD Segment 40 enable.  */
    unsigned short LCDS41          : 1; /* LCD Segment 41 enable.  */
    unsigned short LCDS42          : 1; /* LCD Segment 42 enable.  */
    unsigned short LCDS43          : 1; /* LCD Segment 43 enable.  */
    unsigned short LCDS44          : 1; /* LCD Segment 44 enable.  */
    unsigned short LCDS45          : 1; /* LCD Segment 45 enable.  */
    unsigned short LCDS46          : 1; /* LCD Segment 46 enable.  */
    unsigned short LCDS47          : 1; /* LCD Segment 47 enable.  */
  } LCDCPCTL2_bit;

  struct
  {
    unsigned char LCDCPCTL2_L;
    unsigned char LCDCPCTL2_H;
  };
} @ 0x0A0E;

enum {
  LCDS32          = 0x0001,
  LCDS33          = 0x0002,
  LCDS34          = 0x0004,
  LCDS35          = 0x0008,
  LCDS36          = 0x0010,
  LCDS37          = 0x0020,
  LCDS38          = 0x0040,
  LCDS39          = 0x0080,
  LCDS40          = 0x0100,
  LCDS41          = 0x0200,
  LCDS42          = 0x0400,
  LCDS43          = 0x0800,
  LCDS44          = 0x1000,
  LCDS45          = 0x2000,
  LCDS46          = 0x4000,
  LCDS47          = 0x8000
};

__no_init volatile union
{
  unsigned short LCDCCPCTL;   /* LCD_C Charge Pump Control Register 3  */

  struct
  {
    unsigned short LCDCPDIS0       : 1; /* LCD charge pump disable  */
    unsigned short LCDCPDIS1       : 1; /* LCD charge pump disable  */
    unsigned short LCDCPDIS2       : 1; /* LCD charge pump disable  */
    unsigned short LCDCPDIS3       : 1; /* LCD charge pump disable  */
    unsigned short LCDCPDIS4       : 1; /* LCD charge pump disable  */
    unsigned short LCDCPDIS5       : 1; /* LCD charge pump disable  */
    unsigned short LCDCPDIS6       : 1; /* LCD charge pump disable  */
    unsigned short LCDCPDIS7       : 1; /* LCD charge pump disable  */
    unsigned short                : 7;
    unsigned short LCDCPCLKSYNC    : 1; /* LCD charge pump clock synchronization  */
  } LCDCCPCTL_bit;

  struct
  {
    unsigned char LCDCCPCTL_L;
    unsigned char LCDCCPCTL_H;
  };
} @ 0x0A12;

enum {
  LCDCPDIS0       = 0x0001,
  LCDCPDIS1       = 0x0002,
  LCDCPDIS2       = 0x0004,
  LCDCPDIS3       = 0x0008,
  LCDCPDIS4       = 0x0010,
  LCDCPDIS5       = 0x0020,
  LCDCPDIS6       = 0x0040,
  LCDCPDIS7       = 0x0080,
  LCDCPCLKSYNC    = 0x8000
};


  /* LCD_C Interrupt Vector Register  */
__no_init volatile unsigned short LCDCIV @ 0x0A1E;



  /* LCD Memory 1  */
__no_init volatile unsigned char LCDM1 @ 0x0A20;



  /* LCD Memory 2  */
__no_init volatile unsigned char LCDM2 @ 0x0A21;



  /* LCD Memory 3  */
__no_init volatile unsigned char LCDM3 @ 0x0A22;



  /* LCD Memory 4  */
__no_init volatile unsigned char LCDM4 @ 0x0A23;



  /* LCD Memory 5  */
__no_init volatile unsigned char LCDM5 @ 0x0A24;



  /* LCD Memory 6  */
__no_init volatile unsigned char LCDM6 @ 0x0A25;



  /* LCD Memory 7  */
__no_init volatile unsigned char LCDM7 @ 0x0A26;



  /* LCD Memory 8  */
__no_init volatile unsigned char LCDM8 @ 0x0A27;



  /* LCD Memory 9  */
__no_init volatile unsigned char LCDM9 @ 0x0A28;



  /* LCD Memory 10  */
__no_init volatile unsigned char LCDM10 @ 0x0A29;



  /* LCD Memory 11  */
__no_init volatile unsigned char LCDM11 @ 0x0A2A;



  /* LCD Memory 12  */
__no_init volatile unsigned char LCDM12 @ 0x0A2B;



  /* LCD Memory 13  */
__no_init volatile unsigned char LCDM13 @ 0x0A2C;



  /* LCD Memory 14  */
__no_init volatile unsigned char LCDM14 @ 0x0A2D;



  /* LCD Memory 15  */
__no_init volatile unsigned char LCDM15 @ 0x0A2E;



  /* LCD Memory 16  */
__no_init volatile unsigned char LCDM16 @ 0x0A2F;



  /* LCD Memory 17  */
__no_init volatile unsigned char LCDM17 @ 0x0A30;



  /* LCD Memory 18  */
__no_init volatile unsigned char LCDM18 @ 0x0A31;



  /* LCD Memory 19  */
__no_init volatile unsigned char LCDM19 @ 0x0A32;



  /* LCD Memory 20  */
__no_init volatile unsigned char LCDM20 @ 0x0A33;



  /* LCD Memory 21  */
__no_init volatile unsigned char LCDM21 @ 0x0A34;



  /* LCD Memory 22  */
__no_init volatile unsigned char LCDM22 @ 0x0A35;



  /* LCD Memory 23  */
__no_init volatile unsigned char LCDM23 @ 0x0A36;



  /* LCD Memory 24  */
__no_init volatile unsigned char LCDM24 @ 0x0A37;



  /* LCD Memory 25  */
__no_init volatile unsigned char LCDM25 @ 0x0A38;



  /* LCD Memory 26  */
__no_init volatile unsigned char LCDM26 @ 0x0A39;



  /* LCD Memory 27  */
__no_init volatile unsigned char LCDM27 @ 0x0A3A;



  /* LCD Memory 28  */
__no_init volatile unsigned char LCDM28 @ 0x0A3B;



  /* LCD Memory 29  */
__no_init volatile unsigned char LCDM29 @ 0x0A3C;



  /* LCD Memory 30  */
__no_init volatile unsigned char LCDM30 @ 0x0A3D;



  /* LCD Memory 31  */
__no_init volatile unsigned char LCDM31 @ 0x0A3E;



  /* LCD Memory 32  */
__no_init volatile unsigned char LCDM32 @ 0x0A3F;


__no_init volatile union
{
  unsigned char LCDM33;   /* LCD Memory 33  */
  unsigned char LCDBM1;   /* LCD Blinking Memory 1  */
} @ 0x0A40;

__no_init volatile union
{
  unsigned char LCDM34;   /* LCD Memory 34  */
  unsigned char LCDBM2;   /* LCD Blinking Memory 2  */
} @ 0x0A41;

__no_init volatile union
{
  unsigned char LCDM35;   /* LCD Memory 35  */
  unsigned char LCDBM3;   /* LCD Blinking Memory 3  */
} @ 0x0A42;

__no_init volatile union
{
  unsigned char LCDM36;   /* LCD Memory 36  */
  unsigned char LCDBM4;   /* LCD Blinking Memory 4  */
} @ 0x0A43;

__no_init volatile union
{
  unsigned char LCDM37;   /* LCD Memory 37  */
  unsigned char LCDBM5;   /* LCD Blinking Memory 5  */
} @ 0x0A44;

__no_init volatile union
{
  unsigned char LCDM38;   /* LCD Memory 38  */
  unsigned char LCDBM6;   /* LCD Blinking Memory 6  */
} @ 0x0A45;

__no_init volatile union
{
  unsigned char LCDM39;   /* LCD Memory 39  */
  unsigned char LCDBM7;   /* LCD Blinking Memory 7  */
} @ 0x0A46;

__no_init volatile union
{
  unsigned char LCDM40;   /* LCD Memory 40  */
  unsigned char LCDBM8;   /* LCD Blinking Memory 8  */
} @ 0x0A47;


  /* LCD Blinking Memory 9  */
__no_init volatile unsigned char LCDBM9 @ 0x0A48;



  /* LCD Blinking Memory 10  */
__no_init volatile unsigned char LCDBM10 @ 0x0A49;



  /* LCD Blinking Memory 11  */
__no_init volatile unsigned char LCDBM11 @ 0x0A4A;



  /* LCD Blinking Memory 12  */
__no_init volatile unsigned char LCDBM12 @ 0x0A4B;



  /* LCD Blinking Memory 13  */
__no_init volatile unsigned char LCDBM13 @ 0x0A4C;



  /* LCD Blinking Memory 14  */
__no_init volatile unsigned char LCDBM14 @ 0x0A4D;



  /* LCD Blinking Memory 15  */
__no_init volatile unsigned char LCDBM15 @ 0x0A4E;



  /* LCD Blinking Memory 16  */
__no_init volatile unsigned char LCDBM16 @ 0x0A4F;



  /* LCD Blinking Memory 17  */
__no_init volatile unsigned char LCDBM17 @ 0x0A50;



  /* LCD Blinking Memory 18  */
__no_init volatile unsigned char LCDBM18 @ 0x0A51;



  /* LCD Blinking Memory 19  */
__no_init volatile unsigned char LCDBM19 @ 0x0A52;



  /* LCD Blinking Memory 20  */
__no_init volatile unsigned char LCDBM20 @ 0x0A53;


#define __MSP430_HAS_LCD_C__          /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_LCD_C__ 0x0A00
#define LCD_C_BASE __MSP430_BASEADDRESS_LCD_C__
#define LCDON_L             (0x0001u)  /* LCD_C LCD On */
#define LCDLP_L             (0x0002u)  /* LCD_C Low Power Waveform */
#define LCDSON_L            (0x0004u)  /* LCD_C LCD Segments On */
#define LCDMX0_L            (0x0008u)  /* LCD_C Mux Rate Bit: 0 */
#define LCDMX1_L            (0x0010u)  /* LCD_C Mux Rate Bit: 1 */
#define LCDMX2_L            (0x0020u)  /* LCD_C Mux Rate Bit: 2 */
#define LCDSSEL_L           (0x0080u)  /* LCD_C Clock Select */
#define LCDPRE0_H           (0x0001u)  /* LCD_C LCD frequency pre-scaler Bit: 0 */
#define LCDPRE1_H           (0x0002u)  /* LCD_C LCD frequency pre-scaler Bit: 1 */
#define LCDPRE2_H           (0x0004u)  /* LCD_C LCD frequency pre-scaler Bit: 2 */
#define LCDDIV0_H           (0x0008u)  /* LCD_C LCD frequency divider Bit: 0 */
#define LCDDIV1_H           (0x0010u)  /* LCD_C LCD frequency divider Bit: 1 */
#define LCDDIV2_H           (0x0020u)  /* LCD_C LCD frequency divider Bit: 2 */
#define LCDDIV3_H           (0x0040u)  /* LCD_C LCD frequency divider Bit: 3 */
#define LCDDIV4_H           (0x0080u)  /* LCD_C LCD frequency divider Bit: 4 */

#define LCDPRE_0            (0x0000u)  /* LCD_C LCD frequency pre-scaler: /1 */
#define LCDPRE_1            (0x0100u)  /* LCD_C LCD frequency pre-scaler: /2 */
#define LCDPRE_2            (0x0200u)  /* LCD_C LCD frequency pre-scaler: /4 */
#define LCDPRE_3            (0x0300u)  /* LCD_C LCD frequency pre-scaler: /8 */
#define LCDPRE_4            (0x0400u)  /* LCD_C LCD frequency pre-scaler: /16 */
#define LCDPRE_5            (0x0500u)  /* LCD_C LCD frequency pre-scaler: /32 */
#define LCDPRE__1           (0x0000u)  /* LCD_C LCD frequency pre-scaler: /1 */
#define LCDPRE__2           (0x0100u)  /* LCD_C LCD frequency pre-scaler: /2 */
#define LCDPRE__4           (0x0200u)  /* LCD_C LCD frequency pre-scaler: /4 */
#define LCDPRE__8           (0x0300u)  /* LCD_C LCD frequency pre-scaler: /8 */
#define LCDPRE__16          (0x0400u)  /* LCD_C LCD frequency pre-scaler: /16 */
#define LCDPRE__32          (0x0500u)  /* LCD_C LCD frequency pre-scaler: /32 */

#define LCDDIV_0            (0x0000u)  /* LCD_C LCD frequency divider: /1 */
#define LCDDIV_1            (0x0800u)  /* LCD_C LCD frequency divider: /2 */
#define LCDDIV_2            (0x1000u)  /* LCD_C LCD frequency divider: /3 */
#define LCDDIV_3            (0x1800u)  /* LCD_C LCD frequency divider: /4 */
#define LCDDIV_4            (0x2000u)  /* LCD_C LCD frequency divider: /5 */
#define LCDDIV_5            (0x2800u)  /* LCD_C LCD frequency divider: /6 */
#define LCDDIV_6            (0x3000u)  /* LCD_C LCD frequency divider: /7 */
#define LCDDIV_7            (0x3800u)  /* LCD_C LCD frequency divider: /8 */
#define LCDDIV_8            (0x4000u)  /* LCD_C LCD frequency divider: /9 */
#define LCDDIV_9            (0x4800u)  /* LCD_C LCD frequency divider: /10 */
#define LCDDIV_10           (0x5000u)  /* LCD_C LCD frequency divider: /11 */
#define LCDDIV_11           (0x5800u)  /* LCD_C LCD frequency divider: /12 */
#define LCDDIV_12           (0x6000u)  /* LCD_C LCD frequency divider: /13 */
#define LCDDIV_13           (0x6800u)  /* LCD_C LCD frequency divider: /14 */
#define LCDDIV_14           (0x7000u)  /* LCD_C LCD frequency divider: /15 */
#define LCDDIV_15           (0x7800u)  /* LCD_C LCD frequency divider: /16 */
#define LCDDIV_16           (0x8000u)  /* LCD_C LCD frequency divider: /17 */
#define LCDDIV_17           (0x8800u)  /* LCD_C LCD frequency divider: /18 */
#define LCDDIV_18           (0x9000u)  /* LCD_C LCD frequency divider: /19 */
#define LCDDIV_19           (0x9800u)  /* LCD_C LCD frequency divider: /20 */
#define LCDDIV_20           (0xA000u)  /* LCD_C LCD frequency divider: /21 */
#define LCDDIV_21           (0xA800u)  /* LCD_C LCD frequency divider: /22 */
#define LCDDIV_22           (0xB000u)  /* LCD_C LCD frequency divider: /23 */
#define LCDDIV_23           (0xB800u)  /* LCD_C LCD frequency divider: /24 */
#define LCDDIV_24           (0xC000u)  /* LCD_C LCD frequency divider: /25 */
#define LCDDIV_25           (0xC800u)  /* LCD_C LCD frequency divider: /26 */
#define LCDDIV_26           (0xD000u)  /* LCD_C LCD frequency divider: /27 */
#define LCDDIV_27           (0xD800u)  /* LCD_C LCD frequency divider: /28 */
#define LCDDIV_28           (0xE000u)  /* LCD_C LCD frequency divider: /29 */
#define LCDDIV_29           (0xE800u)  /* LCD_C LCD frequency divider: /30 */
#define LCDDIV_30           (0xF000u)  /* LCD_C LCD frequency divider: /31 */
#define LCDDIV_31           (0xF800u)  /* LCD_C LCD frequency divider: /32 */
#define LCDDIV__1           (0x0000u)  /* LCD_C LCD frequency divider: /1 */
#define LCDDIV__2           (0x0800u)  /* LCD_C LCD frequency divider: /2 */
#define LCDDIV__3           (0x1000u)  /* LCD_C LCD frequency divider: /3 */
#define LCDDIV__4           (0x1800u)  /* LCD_C LCD frequency divider: /4 */
#define LCDDIV__5           (0x2000u)  /* LCD_C LCD frequency divider: /5 */
#define LCDDIV__6           (0x2800u)  /* LCD_C LCD frequency divider: /6 */
#define LCDDIV__7           (0x3000u)  /* LCD_C LCD frequency divider: /7 */
#define LCDDIV__8           (0x3800u)  /* LCD_C LCD frequency divider: /8 */
#define LCDDIV__9           (0x4000u)  /* LCD_C LCD frequency divider: /9 */
#define LCDDIV__10          (0x4800u)  /* LCD_C LCD frequency divider: /10 */
#define LCDDIV__11          (0x5000u)  /* LCD_C LCD frequency divider: /11 */
#define LCDDIV__12          (0x5800u)  /* LCD_C LCD frequency divider: /12 */
#define LCDDIV__13          (0x6000u)  /* LCD_C LCD frequency divider: /13 */
#define LCDDIV__14          (0x6800u)  /* LCD_C LCD frequency divider: /14 */
#define LCDDIV__15          (0x7000u)  /* LCD_C LCD frequency divider: /15 */
#define LCDDIV__16          (0x7800u)  /* LCD_C LCD frequency divider: /16 */
#define LCDDIV__17          (0x8000u)  /* LCD_C LCD frequency divider: /17 */
#define LCDDIV__18          (0x8800u)  /* LCD_C LCD frequency divider: /18 */
#define LCDDIV__19          (0x9000u)  /* LCD_C LCD frequency divider: /19 */
#define LCDDIV__20          (0x9800u)  /* LCD_C LCD frequency divider: /20 */
#define LCDDIV__21          (0xA000u)  /* LCD_C LCD frequency divider: /21 */
#define LCDDIV__22          (0xA800u)  /* LCD_C LCD frequency divider: /22 */
#define LCDDIV__23          (0xB000u)  /* LCD_C LCD frequency divider: /23 */
#define LCDDIV__24          (0xB800u)  /* LCD_C LCD frequency divider: /24 */
#define LCDDIV__25          (0xC000u)  /* LCD_C LCD frequency divider: /25 */
#define LCDDIV__26          (0xC800u)  /* LCD_C LCD frequency divider: /26 */
#define LCDDIV__27          (0xD000u)  /* LCD_C LCD frequency divider: /27 */
#define LCDDIV__28          (0xD800u)  /* LCD_C LCD frequency divider: /28 */
#define LCDDIV__29          (0xE000u)  /* LCD_C LCD frequency divider: /29 */
#define LCDDIV__30          (0xE800u)  /* LCD_C LCD frequency divider: /30 */
#define LCDDIV__31          (0xF000u)  /* LCD_C LCD frequency divider: /31 */
#define LCDDIV__32          (0xF800u)  /* LCD_C LCD frequency divider: /32 */
/* Display modes coded with Bits 2-4 */
#define LCDSTATIC           (LCDSON)
#define LCD2MUX             (LCDMX0+LCDSON)
#define LCD3MUX             (LCDMX1+LCDSON)
#define LCD4MUX             (LCDMX1+LCDMX0+LCDSON)
#define LCD5MUX             (LCDMX2+LCDSON)
#define LCD6MUX             (LCDMX2+LCDMX0+LCDSON)
#define LCD7MUX             (LCDMX2+LCDMX1+LCDSON)
#define LCD8MUX             (LCDMX2+LCDMX1+LCDMX0+LCDSON)
#define LCDFRMIFG_L         (0x0001u)  /* LCD_C LCD frame interrupt flag */
#define LCDBLKOFFIFG_L      (0x0002u)  /* LCD_C LCD blinking off interrupt flag, */
#define LCDBLKONIFG_L       (0x0004u)  /* LCD_C LCD blinking on interrupt flag, */
#define LCDNOCAPIFG_L       (0x0008u)  /* LCD_C No cpacitance connected interrupt flag */
#define LCDFRMIE_H          (0x0001u)  /* LCD_C LCD frame interrupt enable */
#define LCDBLKOFFIE_H       (0x0002u)  /* LCD_C LCD blinking off interrupt flag, */
#define LCDBLKONIE_H        (0x0004u)  /* LCD_C LCD blinking on interrupt flag, */
#define LCDNOCAPIE_H        (0x0008u)  /* LCD_C No cpacitance connected interrupt enable */
#define LCDBLKMOD0_L        (0x0001u)  /* LCD_C Blinking mode Bit: 0 */
#define LCDBLKMOD1_L        (0x0002u)  /* LCD_C Blinking mode Bit: 1 */
#define LCDBLKPRE0_L        (0x0004u)  /* LCD_C Clock pre-scaler for blinking frequency Bit: 0 */
#define LCDBLKPRE1_L        (0x0008u)  /* LCD_C Clock pre-scaler for blinking frequency Bit: 1 */
#define LCDBLKPRE2_L        (0x0010u)  /* LCD_C Clock pre-scaler for blinking frequency Bit: 2 */
#define LCDBLKDIV0_L        (0x0020u)  /* LCD_C Clock divider for blinking frequency Bit: 0 */
#define LCDBLKDIV1_L        (0x0040u)  /* LCD_C Clock divider for blinking frequency Bit: 1 */
#define LCDBLKDIV2_L        (0x0080u)  /* LCD_C Clock divider for blinking frequency Bit: 2 */

#define LCDBLKMOD_0         (0x0000u)  /* LCD_C Blinking mode: Off */
#define LCDBLKMOD_1         (0x0001u)  /* LCD_C Blinking mode: Individual */
#define LCDBLKMOD_2         (0x0002u)  /* LCD_C Blinking mode: All */
#define LCDBLKMOD_3         (0x0003u)  /* LCD_C Blinking mode: Switching */

#define LCDBLKPRE_0         (0x0000u)  /* LCD_C Clock pre-scaler for blinking frequency: 0 */
#define LCDBLKPRE_1         (0x0004u)  /* LCD_C Clock pre-scaler for blinking frequency: 1 */
#define LCDBLKPRE_2         (0x0008u)  /* LCD_C Clock pre-scaler for blinking frequency: 2 */
#define LCDBLKPRE_3         (0x000Cu)  /* LCD_C Clock pre-scaler for blinking frequency: 3 */
#define LCDBLKPRE_4         (0x0010u)  /* LCD_C Clock pre-scaler for blinking frequency: 4 */
#define LCDBLKPRE_5         (0x0014u)  /* LCD_C Clock pre-scaler for blinking frequency: 5 */
#define LCDBLKPRE_6         (0x0018u)  /* LCD_C Clock pre-scaler for blinking frequency: 6 */
#define LCDBLKPRE_7         (0x001Cu)  /* LCD_C Clock pre-scaler for blinking frequency: 7 */

#define LCDBLKPRE__512      (0x0000u)  /* LCD_C Clock pre-scaler for blinking frequency: 512   */
#define LCDBLKPRE__1024     (0x0004u)  /* LCD_C Clock pre-scaler for blinking frequency: 1024  */
#define LCDBLKPRE__2048     (0x0008u)  /* LCD_C Clock pre-scaler for blinking frequency: 2048  */
#define LCDBLKPRE__4096     (0x000Cu)  /* LCD_C Clock pre-scaler for blinking frequency: 4096  */
#define LCDBLKPRE__8192     (0x0010u)  /* LCD_C Clock pre-scaler for blinking frequency: 8192  */
#define LCDBLKPRE__16384    (0x0014u)  /* LCD_C Clock pre-scaler for blinking frequency: 16384 */
#define LCDBLKPRE__32768    (0x0018u)  /* LCD_C Clock pre-scaler for blinking frequency: 32768 */
#define LCDBLKPRE__65536    (0x001Cu)  /* LCD_C Clock pre-scaler for blinking frequency: 65536 */

#define LCDBLKDIV_0         (0x0000u)  /* LCD_C Clock divider for blinking frequency: 0 */
#define LCDBLKDIV_1         (0x0020u)  /* LCD_C Clock divider for blinking frequency: 1 */
#define LCDBLKDIV_2         (0x0040u)  /* LCD_C Clock divider for blinking frequency: 2 */
#define LCDBLKDIV_3         (0x0060u)  /* LCD_C Clock divider for blinking frequency: 3 */
#define LCDBLKDIV_4         (0x0080u)  /* LCD_C Clock divider for blinking frequency: 4 */
#define LCDBLKDIV_5         (0x00A0u)  /* LCD_C Clock divider for blinking frequency: 5 */
#define LCDBLKDIV_6         (0x00C0u)  /* LCD_C Clock divider for blinking frequency: 6 */
#define LCDBLKDIV_7         (0x00E0u)  /* LCD_C Clock divider for blinking frequency: 7 */

#define LCDBLKDIV__1        (0x0000u)  /* LCD_C Clock divider for blinking frequency: /1 */
#define LCDBLKDIV__2        (0x0020u)  /* LCD_C Clock divider for blinking frequency: /2 */
#define LCDBLKDIV__3        (0x0040u)  /* LCD_C Clock divider for blinking frequency: /3 */
#define LCDBLKDIV__4        (0x0060u)  /* LCD_C Clock divider for blinking frequency: /4 */
#define LCDBLKDIV__5        (0x0080u)  /* LCD_C Clock divider for blinking frequency: /5 */
#define LCDBLKDIV__6        (0x00A0u)  /* LCD_C Clock divider for blinking frequency: /6 */
#define LCDBLKDIV__7        (0x00C0u)  /* LCD_C Clock divider for blinking frequency: /7 */
#define LCDBLKDIV__8        (0x00E0u)  /* LCD_C Clock divider for blinking frequency: /8 */
#define LCDDISP_L           (0x0001u)  /* LCD_C LCD memory registers for display */
#define LCDCLRM_L           (0x0002u)  /* LCD_C Clear LCD memory */
#define LCDCLRBM_L          (0x0004u)  /* LCD_C Clear LCD blinking memory */
#define LCD2B_L             (0x0001u)  /* Selects 1/2 bias. */
#define VLCDREF0_L          (0x0002u)  /* Selects reference voltage for regulated charge pump: 0 */
#define VLCDREF1_L          (0x0004u)  /* Selects reference voltage for regulated charge pump: 1 */
#define LCDCPEN_L           (0x0008u)  /* LCD Voltage Charge Pump Enable. */
#define VLCDEXT_L           (0x0010u)  /* Select external source for VLCD. */
#define LCDEXTBIAS_L        (0x0020u)  /* V2 - V4 voltage select. */
#define R03EXT_L            (0x0040u)  /* Selects external connections for LCD mid voltages. */
#define LCDREXT_L           (0x0080u)  /* Selects external connection for lowest LCD voltage. */
#define VLCD0_H             (0x0002u)  /* VLCD select: 0 */
#define VLCD1_H             (0x0004u)  /* VLCD select: 1 */
#define VLCD2_H             (0x0008u)  /* VLCD select: 2 */
#define VLCD3_H             (0x0010u)  /* VLCD select: 3 */
#define VLCD4_H             (0x0020u)  /* VLCD select: 4 */
#define VLCD5_H             (0x0040u)  /* VLCD select: 5 */
/* Reference voltage source select for the regulated charge pump */
#define VLCDREF_0              (0x0000u)       /* Internal */
#define VLCDREF_1              (0x0002u)       /* External */
#define VLCDREF_2              (0x0004u)       /* Reserved */
#define VLCDREF_3              (0x0006u)       /* Reserved */
/* Charge pump voltage selections */
#define VLCD_0                 (0x0000u)       /* Charge pump disabled */
#define VLCD_1                 (0x0200u)       /* VLCD = 2.60V */
#define VLCD_2                 (0x0400u)       /* VLCD = 2.66V */
#define VLCD_3                 (0x0600u)       /* VLCD = 2.72V */
#define VLCD_4                 (0x0800u)       /* VLCD = 2.78V */
#define VLCD_5                 (0x0A00u)       /* VLCD = 2.84V */
#define VLCD_6                 (0x0C00u)       /* VLCD = 2.90V */
#define VLCD_7                 (0x0E00u)       /* VLCD = 2.96V */
#define VLCD_8                 (0x1000u)       /* VLCD = 3.02V */
#define VLCD_9                 (0x1200u)       /* VLCD = 3.08V */
#define VLCD_10                (0x1400u)       /* VLCD = 3.14V */
#define VLCD_11                (0x1600u)       /* VLCD = 3.20V */
#define VLCD_12                (0x1800u)       /* VLCD = 3.26V */
#define VLCD_13                (0x1A00u)       /* VLCD = 3.32V */
#define VLCD_14                (0x1C00u)       /* VLCD = 3.38V */
#define VLCD_15                (0x1E00u)       /* VLCD = 3.44V */

#define VLCD_DISABLED          (0x0000u)       /* Charge pump disabled */
#define VLCD_2_60              (0x0200u)       /* VLCD = 2.60V */
#define VLCD_2_66              (0x0400u)       /* VLCD = 2.66V */
#define VLCD_2_72              (0x0600u)       /* VLCD = 2.72V */
#define VLCD_2_78              (0x0800u)       /* VLCD = 2.78V */
#define VLCD_2_84              (0x0A00u)       /* VLCD = 2.84V */
#define VLCD_2_90              (0x0C00u)       /* VLCD = 2.90V */
#define VLCD_2_96              (0x0E00u)       /* VLCD = 2.96V */
#define VLCD_3_02              (0x1000u)       /* VLCD = 3.02V */
#define VLCD_3_08              (0x1200u)       /* VLCD = 3.08V */
#define VLCD_3_14              (0x1400u)       /* VLCD = 3.14V */
#define VLCD_3_20              (0x1600u)       /* VLCD = 3.20V */
#define VLCD_3_26              (0x1800u)       /* VLCD = 3.26V */
#define VLCD_3_32              (0x1A00u)       /* VLCD = 3.32V */
#define VLCD_3_38              (0x1C00u)       /* VLCD = 3.38V */
#define VLCD_3_44              (0x1E00u)       /* VLCD = 3.44V */
#define LCDS0_L             (0x0001u)  /* LCD Segment  0 enable. */
#define LCDS1_L             (0x0002u)  /* LCD Segment  1 enable. */
#define LCDS2_L             (0x0004u)  /* LCD Segment  2 enable. */
#define LCDS3_L             (0x0008u)  /* LCD Segment  3 enable. */
#define LCDS4_L             (0x0010u)  /* LCD Segment  4 enable. */
#define LCDS5_L             (0x0020u)  /* LCD Segment  5 enable. */
#define LCDS6_L             (0x0040u)  /* LCD Segment  6 enable. */
#define LCDS7_L             (0x0080u)  /* LCD Segment  7 enable. */
#define LCDS8_H             (0x0001u)  /* LCD Segment  8 enable. */
#define LCDS9_H             (0x0002u)  /* LCD Segment  9 enable. */
#define LCDS10_H            (0x0004u)  /* LCD Segment 10 enable. */
#define LCDS11_H            (0x0008u)  /* LCD Segment 11 enable. */
#define LCDS12_H            (0x0010u)  /* LCD Segment 12 enable. */
#define LCDS13_H            (0x0020u)  /* LCD Segment 13 enable. */
#define LCDS14_H            (0x0040u)  /* LCD Segment 14 enable. */
#define LCDS15_H            (0x0080u)  /* LCD Segment 15 enable. */
#define LCDS16_L            (0x0001u)  /* LCD Segment 16 enable. */
#define LCDS17_L            (0x0002u)  /* LCD Segment 17 enable. */
#define LCDS18_L            (0x0004u)  /* LCD Segment 18 enable. */
#define LCDS19_L            (0x0008u)  /* LCD Segment 19 enable. */
#define LCDS20_L            (0x0010u)  /* LCD Segment 20 enable. */
#define LCDS21_L            (0x0020u)  /* LCD Segment 21 enable. */
#define LCDS22_L            (0x0040u)  /* LCD Segment 22 enable. */
#define LCDS23_L            (0x0080u)  /* LCD Segment 23 enable. */
#define LCDS24_H            (0x0001u)  /* LCD Segment 24 enable. */
#define LCDS25_H            (0x0002u)  /* LCD Segment 25 enable. */
#define LCDS26_H            (0x0004u)  /* LCD Segment 26 enable. */
#define LCDS27_H            (0x0008u)  /* LCD Segment 27 enable. */
#define LCDS28_H            (0x0010u)  /* LCD Segment 28 enable. */
#define LCDS29_H            (0x0020u)  /* LCD Segment 29 enable. */
#define LCDS30_H            (0x0040u)  /* LCD Segment 30 enable. */
#define LCDS31_H            (0x0080u)  /* LCD Segment 31 enable. */
#define LCDS32_L            (0x0001u)  /* LCD Segment 32 enable. */
#define LCDS33_L            (0x0002u)  /* LCD Segment 33 enable. */
#define LCDS34_L            (0x0004u)  /* LCD Segment 34 enable. */
#define LCDS35_L            (0x0008u)  /* LCD Segment 35 enable. */
#define LCDS36_L            (0x0010u)  /* LCD Segment 36 enable. */
#define LCDS37_L            (0x0020u)  /* LCD Segment 37 enable. */
#define LCDS38_L            (0x0040u)  /* LCD Segment 38 enable. */
#define LCDS39_L            (0x0080u)  /* LCD Segment 39 enable. */
#define LCDS40_H            (0x0001u)  /* LCD Segment 40 enable. */
#define LCDS41_H            (0x0002u)  /* LCD Segment 41 enable. */
#define LCDS42_H            (0x0004u)  /* LCD Segment 42 enable. */
#define LCDS43_H            (0x0008u)  /* LCD Segment 43 enable. */
#define LCDS44_H            (0x0010u)  /* LCD Segment 44 enable. */
#define LCDS45_H            (0x0020u)  /* LCD Segment 45 enable. */
#define LCDS46_H            (0x0040u)  /* LCD Segment 46 enable. */
#define LCDS47_H            (0x0080u)  /* LCD Segment 47 enable. */
#define LCDCPDIS0_L         (0x0001u)  /* LCD charge pump disable */
#define LCDCPDIS1_L         (0x0002u)  /* LCD charge pump disable */
#define LCDCPDIS2_L         (0x0004u)  /* LCD charge pump disable */
#define LCDCPDIS3_L         (0x0008u)  /* LCD charge pump disable */
#define LCDCPDIS4_L         (0x0010u)  /* LCD charge pump disable */
#define LCDCPDIS5_L         (0x0020u)  /* LCD charge pump disable */
#define LCDCPDIS6_L         (0x0040u)  /* LCD charge pump disable */
#define LCDCPDIS7_L         (0x0080u)  /* LCD charge pump disable */
#define LCDCPCLKSYNC_H      (0x0080u)  /* LCD charge pump clock synchronization */
#define LCDMEM_             LCDM1     /* LCD Memory */
#ifndef __IAR_SYSTEMS_ICC__
#define LCDMEM              LCDM1     /* LCD Memory (for assembler) */
#else
#define LCDMEM              ((char*) &LCDM1) /* LCD Memory (for C) */
#endif
#define LCDBMEM_            LCDBM1    /* LCD Blinking Memory */
#ifndef __IAR_SYSTEMS_ICC__
#define LCDBMEM             (LCDBM1)  /* LCD Blinking Memory (for assembler) */
#else
#define LCDBMEM             ((char*) &LCDBM1) /* LCD Blinking Memory (for C) */
#endif
/* LCDCIV Definitions */
#define LCDCIV_NONE         (0x0000u)    /* No Interrupt pending */
#define LCDCIV_LCDNOCAPIFG  (0x0002u)    /* No capacitor connected */
#define LCDCIV_LCDCLKOFFIFG (0x0004u)    /* Blink, segments off */
#define LCDCIV_LCDCLKONIFG  (0x0006u)    /* Blink, segments on */
#define LCDCIV_LCDFRMIFG    (0x0008u)    /* Frame interrupt */

/*-------------------------------------------------------------------------
 *   MPY 16  Multiplier  16 Bit Mode
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short MPY;   /* Multiply Unsigned/Operand 1  */
  struct
  {
    unsigned char MPY_L;
    unsigned char MPY_H;
  };
} @ 0x04C0;

__no_init volatile union
{
  unsigned short MPYS;   /* Multiply Signed/Operand 1  */
  struct
  {
    unsigned char MPYS_L;
    unsigned char MPYS_H;
  };
} @ 0x04C2;

__no_init volatile union
{
  unsigned short MAC;   /* Multiply Unsigned and Accumulate/Operand 1  */
  struct
  {
    unsigned char MAC_L;
    unsigned char MAC_H;
  };
} @ 0x04C4;

__no_init volatile union
{
  unsigned short MACS;   /* Multiply Signed and Accumulate/Operand 1  */
  struct
  {
    unsigned char MACS_L;
    unsigned char MACS_H;
  };
} @ 0x04C6;

__no_init volatile union
{
  unsigned short OP2;   /* Operand 2  */
  struct
  {
    unsigned char OP2_L;
    unsigned char OP2_H;
  };
} @ 0x04C8;

__no_init volatile union
{
  unsigned short RESLO;   /* Result Low Word  */
  struct
  {
    unsigned char RESLO_L;
    unsigned char RESLO_H;
  };
} @ 0x04CA;

__no_init volatile union
{
  unsigned short RESHI;   /* Result High Word  */
  struct
  {
    unsigned char RESHI_L;
    unsigned char RESHI_H;
  };
} @ 0x04CC;

__no_init volatile union
{
  unsigned __READ short SUMEXT;   /* Sum Extend  */
  struct
  {
    unsigned __READ char SUMEXT_L;
    unsigned __READ char SUMEXT_H;
  };
} @ 0x04CE;

__no_init volatile union
{
  unsigned short MPY32CTL0;   /* MPY32 Control Register 0  */

  struct
  {
    unsigned short MPYC            : 1; /* Carry of the multiplier  */
    unsigned short                : 1;
    unsigned short MPYFRAC         : 1; /* Fractional mode  */
    unsigned short MPYSAT          : 1; /* Saturation mode  */
    unsigned short MPYM0           : 1; /* Multiplier mode Bit:0  */
    unsigned short MPYM1           : 1; /* Multiplier mode Bit:1  */
    unsigned short OP1_32          : 1; /*  */
    unsigned short OP2_32          : 1; /*  */
    unsigned short MPYDLYWRTEN     : 1; /* Delayed write enable  */
    unsigned short MPYDLY32        : 1; /* Delayed write mode  */
  } MPY32CTL0_bit;

  struct
  {
    unsigned char MPY32CTL0_L;
    unsigned char MPY32CTL0_H;
  };
} @ 0x04EC;

enum {
  MPYC            = 0x0001,
  MPYFRAC         = 0x0004,
  MPYSAT          = 0x0008,
  MPYM0           = 0x0010,
  MPYM1           = 0x0020,
  OP1_32          = 0x0040,
  OP2_32          = 0x0080,
  MPYDLYWRTEN     = 0x0100,
  MPYDLY32        = 0x0200
};



#define __MSP430_HAS_MPY32__          /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_MPY32__ 0x04C0
#define MPY32_BASE __MSP430_BASEADDRESS_MPY32__

#define MPY_B               MPY_L      /* Multiply Unsigned/Operand 1 (Byte Access) */
#define MPYS_B              MPYS_L     /* Multiply Signed/Operand 1 (Byte Access) */
#define MAC_B               MAC_L      /* Multiply Unsigned and Accumulate/Operand 1 (Byte Access) */
#define MACS_B              MACS_L     /* Multiply Signed and Accumulate/Operand 1 (Byte Access) */
#define OP2_B               OP2_L      /* Operand 2 (Byte Access) */
#define MPY32L_B            MPY32L_L   /* 32-bit operand 1 - multiply - low word (Byte Access) */
#define MPY32H_B            MPY32H_L   /* 32-bit operand 1 - multiply - high word (Byte Access) */
#define MPYS32L_B           MPYS32L_L  /* 32-bit operand 1 - signed multiply - low word (Byte Access) */
#define MPYS32H_B           MPYS32H_L  /* 32-bit operand 1 - signed multiply - high word (Byte Access) */
#define MAC32L_B            MAC32L_L   /* 32-bit operand 1 - multiply accumulate - low word (Byte Access) */
#define MAC32H_B            MAC32H_L   /* 32-bit operand 1 - multiply accumulate - high word (Byte Access) */
#define MACS32L_B           MACS32L_L  /* 32-bit operand 1 - signed multiply accumulate - low word (Byte Access) */
#define MACS32H_B           MACS32H_L  /* 32-bit operand 1 - signed multiply accumulate - high word (Byte Access) */
#define OP2L_B              OP2L_L     /* 32-bit operand 2 - low word (Byte Access) */
#define OP2H_B              OP2H_L     /* 32-bit operand 2 - high word (Byte Access) */
/* MPY32CTL0 Control Bits */
#define MPYC_L              (0x0001u)  /* Carry of the multiplier */
#define MPYFRAC_L           (0x0004u)  /* Fractional mode */
#define MPYSAT_L            (0x0008u)  /* Saturation mode */
#define MPYM0_L             (0x0010u)  /* Multiplier mode Bit:0 */
#define MPYM1_L             (0x0020u)  /* Multiplier mode Bit:1 */
#define OP1_32_L            (0x0040u)  /* Bit-width of operand 1 0:16Bit / 1:32Bit */
#define OP2_32_L            (0x0080u)  /* Bit-width of operand 2 0:16Bit / 1:32Bit */
#define MPYDLYWRTEN_H       (0x0001u)  /* Delayed write enable */
#define MPYDLY32_H          (0x0002u)  /* Delayed write mode */

#define MPYM_0              (0x0000u)  /* Multiplier mode: MPY */
#define MPYM_1              (0x0010u)  /* Multiplier mode: MPYS */
#define MPYM_2              (0x0020u)  /* Multiplier mode: MAC */
#define MPYM_3              (0x0030u)  /* Multiplier mode: MACS */
#define MPYM__MPY           (0x0000u)  /* Multiplier mode: MPY */
#define MPYM__MPYS          (0x0010u)  /* Multiplier mode: MPYS */
#define MPYM__MAC           (0x0020u)  /* Multiplier mode: MAC */
#define MPYM__MACS          (0x0030u)  /* Multiplier mode: MACS */

/*-------------------------------------------------------------------------
 *   MPY 32  Multiplier  32 Bit Mode
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short MPY32L;   /* 32-bit operand 1 - multiply - low word  */
  struct
  {
    unsigned char MPY32L_L;
    unsigned char MPY32L_H;
  };
} @ 0x04D0;

__no_init volatile union
{
  unsigned short MPY32H;   /* 32-bit operand 1 - multiply - high word  */
  struct
  {
    unsigned char MPY32H_L;
    unsigned char MPY32H_H;
  };
} @ 0x04D2;

__no_init volatile union
{
  unsigned short MPYS32L;   /* 32-bit operand 1 - signed multiply - low word  */
  struct
  {
    unsigned char MPYS32L_L;
    unsigned char MPYS32L_H;
  };
} @ 0x04D4;

__no_init volatile union
{
  unsigned short MPYS32H;   /* 32-bit operand 1 - signed multiply - high word  */
  struct
  {
    unsigned char MPYS32H_L;
    unsigned char MPYS32H_H;
  };
} @ 0x04D6;

__no_init volatile union
{
  unsigned short MAC32L;   /* 32-bit operand 1 - multiply accumulate - low word  */
  struct
  {
    unsigned char MAC32L_L;
    unsigned char MAC32L_H;
  };
} @ 0x04D8;

__no_init volatile union
{
  unsigned short MAC32H;   /* 32-bit operand 1 - multiply accumulate - high word  */
  struct
  {
    unsigned char MAC32H_L;
    unsigned char MAC32H_H;
  };
} @ 0x04DA;

__no_init volatile union
{
  unsigned short MACS32L;   /* 32-bit operand 1 - signed multiply accumulate - low word  */
  struct
  {
    unsigned char MACS32L_L;
    unsigned char MACS32L_H;
  };
} @ 0x04DC;

__no_init volatile union
{
  unsigned short MACS32H;   /* 32-bit operand 1 - signed multiply accumulate - high word  */
  struct
  {
    unsigned char MACS32H_L;
    unsigned char MACS32H_H;
  };
} @ 0x04DE;

__no_init volatile union
{
  unsigned short OP2L;   /* 32-bit operand 2 - low word  */
  struct
  {
    unsigned char OP2L_L;
    unsigned char OP2L_H;
  };
} @ 0x04E0;

__no_init volatile union
{
  unsigned short OP2H;   /* 32-bit operand 2 - high word  */
  struct
  {
    unsigned char OP2H_L;
    unsigned char OP2H_H;
  };
} @ 0x04E2;

__no_init volatile union
{
  unsigned short RES0;   /* 32x32-bit result 0 - least significant word  */
  struct
  {
    unsigned char RES0_L;
    unsigned char RES0_H;
  };
} @ 0x04E4;

__no_init volatile union
{
  unsigned short RES1;   /* 32x32-bit result 1  */
  struct
  {
    unsigned char RES1_L;
    unsigned char RES1_H;
  };
} @ 0x04E6;

__no_init volatile union
{
  unsigned short RES2;   /* 32x32-bit result 2  */
  struct
  {
    unsigned char RES2_L;
    unsigned char RES2_H;
  };
} @ 0x04E8;

__no_init volatile union
{
  unsigned short RES3;   /* 32x32-bit result 3 - most significant word  */
  struct
  {
    unsigned char RES3_L;
    unsigned char RES3_H;
  };
} @ 0x04EA;

#define __MSP430_HAS_MPY32__          /* Definition to show that Module is available */

/*-------------------------------------------------------------------------
 *   Port A
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned __READ short PAIN;   /* Port A Input  */

  struct
  {
    unsigned __READ short PAIN0           : 1; /*  */
    unsigned __READ short PAIN1           : 1; /*  */
    unsigned __READ short PAIN2           : 1; /*  */
    unsigned __READ short PAIN3           : 1; /*  */
    unsigned __READ short PAIN4           : 1; /*  */
    unsigned __READ short PAIN5           : 1; /*  */
    unsigned __READ short PAIN6           : 1; /*  */
    unsigned __READ short PAIN7           : 1; /*  */
    unsigned __READ short PAIN8           : 1; /*  */
    unsigned __READ short PAIN9           : 1; /*  */
    unsigned __READ short PAIN10          : 1; /*  */
    unsigned __READ short PAIN11          : 1; /*  */
    unsigned __READ short PAIN12          : 1; /*  */
    unsigned __READ short PAIN13          : 1; /*  */
    unsigned __READ short PAIN14          : 1; /*  */
    unsigned __READ short PAIN15          : 1; /*  */
  } PAIN_bit;

  struct
  {
    unsigned __READ char PAIN_L;
    unsigned __READ char PAIN_H;
  };
  struct
  {
    unsigned char P1IN;   /* Port 1 Input  */
    unsigned char P2IN;   /* Port 2 Input  */
  };
  struct
  {
    struct
    {
      unsigned char P1IN0           : 1; /*  */
      unsigned char P1IN1           : 1; /*  */
      unsigned char P1IN2           : 1; /*  */
      unsigned char P1IN3           : 1; /*  */
      unsigned char P1IN4           : 1; /*  */
      unsigned char P1IN5           : 1; /*  */
      unsigned char P1IN6           : 1; /*  */
      unsigned char P1IN7           : 1; /*  */
    } P1IN_bit;

    struct
    {
      unsigned char P2IN0           : 1; /*  */
      unsigned char P2IN1           : 1; /*  */
      unsigned char P2IN2           : 1; /*  */
      unsigned char P2IN3           : 1; /*  */
      unsigned char P2IN4           : 1; /*  */
      unsigned char P2IN5           : 1; /*  */
      unsigned char P2IN6           : 1; /*  */
      unsigned char P2IN7           : 1; /*  */
    } P2IN_bit;
  }; 
} @ 0x0200;

enum {
  PAIN0           = 0x0001,
  PAIN1           = 0x0002,
  PAIN2           = 0x0004,
  PAIN3           = 0x0008,
  PAIN4           = 0x0010,
  PAIN5           = 0x0020,
  PAIN6           = 0x0040,
  PAIN7           = 0x0080,
  PAIN8           = 0x0100,
  PAIN9           = 0x0200,
  PAIN10          = 0x0400,
  PAIN11          = 0x0800,
  PAIN12          = 0x1000,
  PAIN13          = 0x2000,
  PAIN14          = 0x4000,
  PAIN15          = 0x8000
};

__no_init volatile union
{
  unsigned short PAOUT;   /* Port A Output  */

  struct
  {
    unsigned short PAOUT0          : 1; /*  */
    unsigned short PAOUT1          : 1; /*  */
    unsigned short PAOUT2          : 1; /*  */
    unsigned short PAOUT3          : 1; /*  */
    unsigned short PAOUT4          : 1; /*  */
    unsigned short PAOUT5          : 1; /*  */
    unsigned short PAOUT6          : 1; /*  */
    unsigned short PAOUT7          : 1; /*  */
    unsigned short PAOUT8          : 1; /*  */
    unsigned short PAOUT9          : 1; /*  */
    unsigned short PAOUT10         : 1; /*  */
    unsigned short PAOUT11         : 1; /*  */
    unsigned short PAOUT12         : 1; /*  */
    unsigned short PAOUT13         : 1; /*  */
    unsigned short PAOUT14         : 1; /*  */
    unsigned short PAOUT15         : 1; /*  */
  } PAOUT_bit;

  struct
  {
    unsigned char PAOUT_L;
    unsigned char PAOUT_H;
  };
  struct
  {
    unsigned char P1OUT;   /* Port 1 Output  */
    unsigned char P2OUT;   /* Port 2 Output  */
  };
  struct
  {
    struct
    {
      unsigned char P1OUT0          : 1; /*  */
      unsigned char P1OUT1          : 1; /*  */
      unsigned char P1OUT2          : 1; /*  */
      unsigned char P1OUT3          : 1; /*  */
      unsigned char P1OUT4          : 1; /*  */
      unsigned char P1OUT5          : 1; /*  */
      unsigned char P1OUT6          : 1; /*  */
      unsigned char P1OUT7          : 1; /*  */
    } P1OUT_bit;

    struct
    {
      unsigned char P2OUT0          : 1; /*  */
      unsigned char P2OUT1          : 1; /*  */
      unsigned char P2OUT2          : 1; /*  */
      unsigned char P2OUT3          : 1; /*  */
      unsigned char P2OUT4          : 1; /*  */
      unsigned char P2OUT5          : 1; /*  */
      unsigned char P2OUT6          : 1; /*  */
      unsigned char P2OUT7          : 1; /*  */
    } P2OUT_bit;
  }; 
} @ 0x0202;

enum {
  PAOUT0          = 0x0001,
  PAOUT1          = 0x0002,
  PAOUT2          = 0x0004,
  PAOUT3          = 0x0008,
  PAOUT4          = 0x0010,
  PAOUT5          = 0x0020,
  PAOUT6          = 0x0040,
  PAOUT7          = 0x0080,
  PAOUT8          = 0x0100,
  PAOUT9          = 0x0200,
  PAOUT10         = 0x0400,
  PAOUT11         = 0x0800,
  PAOUT12         = 0x1000,
  PAOUT13         = 0x2000,
  PAOUT14         = 0x4000,
  PAOUT15         = 0x8000
};

__no_init volatile union
{
  unsigned short PADIR;   /* Port A Direction  */

  struct
  {
    unsigned short PADIR0          : 1; /*  */
    unsigned short PADIR1          : 1; /*  */
    unsigned short PADIR2          : 1; /*  */
    unsigned short PADIR3          : 1; /*  */
    unsigned short PADIR4          : 1; /*  */
    unsigned short PADIR5          : 1; /*  */
    unsigned short PADIR6          : 1; /*  */
    unsigned short PADIR7          : 1; /*  */
    unsigned short PADIR8          : 1; /*  */
    unsigned short PADIR9          : 1; /*  */
    unsigned short PADIR10         : 1; /*  */
    unsigned short PADIR11         : 1; /*  */
    unsigned short PADIR12         : 1; /*  */
    unsigned short PADIR13         : 1; /*  */
    unsigned short PADIR14         : 1; /*  */
    unsigned short PADIR15         : 1; /*  */
  } PADIR_bit;

  struct
  {
    unsigned char PADIR_L;
    unsigned char PADIR_H;
  };
  struct
  {
    unsigned char P1DIR;   /* Port 1 Direction  */
    unsigned char P2DIR;   /* Port 2 Direction  */
  };
  struct
  {
    struct
    {
      unsigned char P1DIR0          : 1; /*  */
      unsigned char P1DIR1          : 1; /*  */
      unsigned char P1DIR2          : 1; /*  */
      unsigned char P1DIR3          : 1; /*  */
      unsigned char P1DIR4          : 1; /*  */
      unsigned char P1DIR5          : 1; /*  */
      unsigned char P1DIR6          : 1; /*  */
      unsigned char P1DIR7          : 1; /*  */
    } P1DIR_bit;

    struct
    {
      unsigned char P2DIR0          : 1; /*  */
      unsigned char P2DIR1          : 1; /*  */
      unsigned char P2DIR2          : 1; /*  */
      unsigned char P2DIR3          : 1; /*  */
      unsigned char P2DIR4          : 1; /*  */
      unsigned char P2DIR5          : 1; /*  */
      unsigned char P2DIR6          : 1; /*  */
      unsigned char P2DIR7          : 1; /*  */
    } P2DIR_bit;
  }; 
} @ 0x0204;

enum {
  PADIR0          = 0x0001,
  PADIR1          = 0x0002,
  PADIR2          = 0x0004,
  PADIR3          = 0x0008,
  PADIR4          = 0x0010,
  PADIR5          = 0x0020,
  PADIR6          = 0x0040,
  PADIR7          = 0x0080,
  PADIR8          = 0x0100,
  PADIR9          = 0x0200,
  PADIR10         = 0x0400,
  PADIR11         = 0x0800,
  PADIR12         = 0x1000,
  PADIR13         = 0x2000,
  PADIR14         = 0x4000,
  PADIR15         = 0x8000
};

__no_init volatile union
{
  unsigned short PAREN;   /* Port A Resistor Enable  */

  struct
  {
    unsigned short PAREN0          : 1; /*  */
    unsigned short PAREN1          : 1; /*  */
    unsigned short PAREN2          : 1; /*  */
    unsigned short PAREN3          : 1; /*  */
    unsigned short PAREN4          : 1; /*  */
    unsigned short PAREN5          : 1; /*  */
    unsigned short PAREN6          : 1; /*  */
    unsigned short PAREN7          : 1; /*  */
    unsigned short PAREN8          : 1; /*  */
    unsigned short PAREN9          : 1; /*  */
    unsigned short PAREN10         : 1; /*  */
    unsigned short PAREN11         : 1; /*  */
    unsigned short PAREN12         : 1; /*  */
    unsigned short PAREN13         : 1; /*  */
    unsigned short PAREN14         : 1; /*  */
    unsigned short PAREN15         : 1; /*  */
  } PAREN_bit;

  struct
  {
    unsigned char PAREN_L;
    unsigned char PAREN_H;
  };
  struct
  {
    unsigned char P1REN;   /* Port 1 Resistor Enable  */
    unsigned char P2REN;   /* Port 2 Resistor Enable  */
  };
  struct
  {
    struct
    {
      unsigned char P1REN0          : 1; /*  */
      unsigned char P1REN1          : 1; /*  */
      unsigned char P1REN2          : 1; /*  */
      unsigned char P1REN3          : 1; /*  */
      unsigned char P1REN4          : 1; /*  */
      unsigned char P1REN5          : 1; /*  */
      unsigned char P1REN6          : 1; /*  */
      unsigned char P1REN7          : 1; /*  */
    } P1REN_bit;

    struct
    {
      unsigned char P2REN0          : 1; /*  */
      unsigned char P2REN1          : 1; /*  */
      unsigned char P2REN2          : 1; /*  */
      unsigned char P2REN3          : 1; /*  */
      unsigned char P2REN4          : 1; /*  */
      unsigned char P2REN5          : 1; /*  */
      unsigned char P2REN6          : 1; /*  */
      unsigned char P2REN7          : 1; /*  */
    } P2REN_bit;
  }; 
} @ 0x0206;

enum {
  PAREN0          = 0x0001,
  PAREN1          = 0x0002,
  PAREN2          = 0x0004,
  PAREN3          = 0x0008,
  PAREN4          = 0x0010,
  PAREN5          = 0x0020,
  PAREN6          = 0x0040,
  PAREN7          = 0x0080,
  PAREN8          = 0x0100,
  PAREN9          = 0x0200,
  PAREN10         = 0x0400,
  PAREN11         = 0x0800,
  PAREN12         = 0x1000,
  PAREN13         = 0x2000,
  PAREN14         = 0x4000,
  PAREN15         = 0x8000
};

__no_init volatile union
{
  unsigned short PADS;   /* Port A Drive Strenght  */

  struct
  {
    unsigned short PADS0           : 1; /*  */
    unsigned short PADS1           : 1; /*  */
    unsigned short PADS2           : 1; /*  */
    unsigned short PADS3           : 1; /*  */
    unsigned short PADS4           : 1; /*  */
    unsigned short PADS5           : 1; /*  */
    unsigned short PADS6           : 1; /*  */
    unsigned short PADS7           : 1; /*  */
    unsigned short PADS8           : 1; /*  */
    unsigned short PADS9           : 1; /*  */
    unsigned short PADS10          : 1; /*  */
    unsigned short PADS11          : 1; /*  */
    unsigned short PADS12          : 1; /*  */
    unsigned short PADS13          : 1; /*  */
    unsigned short PADS14          : 1; /*  */
    unsigned short PADS15          : 1; /*  */
  } PADS_bit;

  struct
  {
    unsigned char PADS_L;
    unsigned char PADS_H;
  };
  struct
  {
    unsigned char P1DS;   /* Port 1 Drive Strenght  */
    unsigned char P2DS;   /* Port 2 Drive Strenght  */
  };
  struct
  {
    struct
    {
      unsigned char P1DS0           : 1; /*  */
      unsigned char P1DS1           : 1; /*  */
      unsigned char P1DS2           : 1; /*  */
      unsigned char P1DS3           : 1; /*  */
      unsigned char P1DS4           : 1; /*  */
      unsigned char P1DS5           : 1; /*  */
      unsigned char P1DS6           : 1; /*  */
      unsigned char P1DS7           : 1; /*  */
    } P1DS_bit;

    struct
    {
      unsigned char P2DS0           : 1; /*  */
      unsigned char P2DS1           : 1; /*  */
      unsigned char P2DS2           : 1; /*  */
      unsigned char P2DS3           : 1; /*  */
      unsigned char P2DS4           : 1; /*  */
      unsigned char P2DS5           : 1; /*  */
      unsigned char P2DS6           : 1; /*  */
      unsigned char P2DS7           : 1; /*  */
    } P2DS_bit;
  }; 
} @ 0x0208;

enum {
  PADS0           = 0x0001,
  PADS1           = 0x0002,
  PADS2           = 0x0004,
  PADS3           = 0x0008,
  PADS4           = 0x0010,
  PADS5           = 0x0020,
  PADS6           = 0x0040,
  PADS7           = 0x0080,
  PADS8           = 0x0100,
  PADS9           = 0x0200,
  PADS10          = 0x0400,
  PADS11          = 0x0800,
  PADS12          = 0x1000,
  PADS13          = 0x2000,
  PADS14          = 0x4000,
  PADS15          = 0x8000
};

__no_init volatile union
{
  unsigned short PASEL;   /* Port A Selection  */

  struct
  {
    unsigned short PASEL0          : 1; /*  */
    unsigned short PASEL1          : 1; /*  */
    unsigned short PASEL2          : 1; /*  */
    unsigned short PASEL3          : 1; /*  */
    unsigned short PASEL4          : 1; /*  */
    unsigned short PASEL5          : 1; /*  */
    unsigned short PASEL6          : 1; /*  */
    unsigned short PASEL7          : 1; /*  */
    unsigned short PASEL8          : 1; /*  */
    unsigned short PASEL9          : 1; /*  */
    unsigned short PASEL10         : 1; /*  */
    unsigned short PASEL11         : 1; /*  */
    unsigned short PASEL12         : 1; /*  */
    unsigned short PASEL13         : 1; /*  */
    unsigned short PASEL14         : 1; /*  */
    unsigned short PASEL15         : 1; /*  */
  } PASEL_bit;

  struct
  {
    unsigned char PASEL_L;
    unsigned char PASEL_H;
  };
  struct
  {
    unsigned char P1SEL;   /* Port 1 Selection  */
    unsigned char P2SEL;   /* Port 2 Selection  */
  };
  struct
  {
    struct
    {
      unsigned char P1SEL0          : 1; /*  */
      unsigned char P1SEL1          : 1; /*  */
      unsigned char P1SEL2          : 1; /*  */
      unsigned char P1SEL3          : 1; /*  */
      unsigned char P1SEL4          : 1; /*  */
      unsigned char P1SEL5          : 1; /*  */
      unsigned char P1SEL6          : 1; /*  */
      unsigned char P1SEL7          : 1; /*  */
    } P1SEL_bit;

    struct
    {
      unsigned char P2SEL0          : 1; /*  */
      unsigned char P2SEL1          : 1; /*  */
      unsigned char P2SEL2          : 1; /*  */
      unsigned char P2SEL3          : 1; /*  */
      unsigned char P2SEL4          : 1; /*  */
      unsigned char P2SEL5          : 1; /*  */
      unsigned char P2SEL6          : 1; /*  */
      unsigned char P2SEL7          : 1; /*  */
    } P2SEL_bit;
  }; 
} @ 0x020A;

enum {
  PASEL0          = 0x0001,
  PASEL1          = 0x0002,
  PASEL2          = 0x0004,
  PASEL3          = 0x0008,
  PASEL4          = 0x0010,
  PASEL5          = 0x0020,
  PASEL6          = 0x0040,
  PASEL7          = 0x0080,
  PASEL8          = 0x0100,
  PASEL9          = 0x0200,
  PASEL10         = 0x0400,
  PASEL11         = 0x0800,
  PASEL12         = 0x1000,
  PASEL13         = 0x2000,
  PASEL14         = 0x4000,
  PASEL15         = 0x8000
};

__no_init volatile union
{
  unsigned short PAIES;   /* Port A Interrupt Edge Select  */

  struct
  {
    unsigned short PAIES0          : 1; /*  */
    unsigned short PAIES1          : 1; /*  */
    unsigned short PAIES2          : 1; /*  */
    unsigned short PAIES3          : 1; /*  */
    unsigned short PAIES4          : 1; /*  */
    unsigned short PAIES5          : 1; /*  */
    unsigned short PAIES6          : 1; /*  */
    unsigned short PAIES7          : 1; /*  */
    unsigned short PAIES8          : 1; /*  */
    unsigned short PAIES9          : 1; /*  */
    unsigned short PAIES10         : 1; /*  */
    unsigned short PAIES11         : 1; /*  */
    unsigned short PAIES12         : 1; /*  */
    unsigned short PAIES13         : 1; /*  */
    unsigned short PAIES14         : 1; /*  */
    unsigned short PAIES15         : 1; /*  */
  } PAIES_bit;

  struct
  {
    unsigned char PAIES_L;
    unsigned char PAIES_H;
  };
  struct
  {
    unsigned char P1IES;   /* Port 1 Interrupt Edge Select  */
    unsigned char P2IES;   /* Port 2 Interrupt Edge Select  */
  };
  struct
  {
    struct
    {
      unsigned char P1IES0          : 1; /*  */
      unsigned char P1IES1          : 1; /*  */
      unsigned char P1IES2          : 1; /*  */
      unsigned char P1IES3          : 1; /*  */
      unsigned char P1IES4          : 1; /*  */
      unsigned char P1IES5          : 1; /*  */
      unsigned char P1IES6          : 1; /*  */
      unsigned char P1IES7          : 1; /*  */
    } P1IES_bit;

    struct
    {
      unsigned char P2IES0          : 1; /*  */
      unsigned char P2IES1          : 1; /*  */
      unsigned char P2IES2          : 1; /*  */
      unsigned char P2IES3          : 1; /*  */
      unsigned char P2IES4          : 1; /*  */
      unsigned char P2IES5          : 1; /*  */
      unsigned char P2IES6          : 1; /*  */
      unsigned char P2IES7          : 1; /*  */
    } P2IES_bit;
  }; 
} @ 0x0218;

enum {
  PAIES0          = 0x0001,
  PAIES1          = 0x0002,
  PAIES2          = 0x0004,
  PAIES3          = 0x0008,
  PAIES4          = 0x0010,
  PAIES5          = 0x0020,
  PAIES6          = 0x0040,
  PAIES7          = 0x0080,
  PAIES8          = 0x0100,
  PAIES9          = 0x0200,
  PAIES10         = 0x0400,
  PAIES11         = 0x0800,
  PAIES12         = 0x1000,
  PAIES13         = 0x2000,
  PAIES14         = 0x4000,
  PAIES15         = 0x8000
};

__no_init volatile union
{
  unsigned short PAIE;   /* Port A Interrupt Enable  */

  struct
  {
    unsigned short PAIE0           : 1; /*  */
    unsigned short PAIE1           : 1; /*  */
    unsigned short PAIE2           : 1; /*  */
    unsigned short PAIE3           : 1; /*  */
    unsigned short PAIE4           : 1; /*  */
    unsigned short PAIE5           : 1; /*  */
    unsigned short PAIE6           : 1; /*  */
    unsigned short PAIE7           : 1; /*  */
    unsigned short PAIE8           : 1; /*  */
    unsigned short PAIE9           : 1; /*  */
    unsigned short PAIE10          : 1; /*  */
    unsigned short PAIE11          : 1; /*  */
    unsigned short PAIE12          : 1; /*  */
    unsigned short PAIE13          : 1; /*  */
    unsigned short PAIE14          : 1; /*  */
    unsigned short PAIE15          : 1; /*  */
  } PAIE_bit;

  struct
  {
    unsigned char PAIE_L;
    unsigned char PAIE_H;
  };
  struct
  {
    unsigned char P1IE;   /* Port 1 Interrupt Enable  */
    unsigned char P2IE;   /* Port 2 Interrupt Enable  */
  };
  struct
  {
    struct
    {
      unsigned char P1IE0           : 1; /*  */
      unsigned char P1IE1           : 1; /*  */
      unsigned char P1IE2           : 1; /*  */
      unsigned char P1IE3           : 1; /*  */
      unsigned char P1IE4           : 1; /*  */
      unsigned char P1IE5           : 1; /*  */
      unsigned char P1IE6           : 1; /*  */
      unsigned char P1IE7           : 1; /*  */
    } P1IE_bit;

    struct
    {
      unsigned char P2IE0           : 1; /*  */
      unsigned char P2IE1           : 1; /*  */
      unsigned char P2IE2           : 1; /*  */
      unsigned char P2IE3           : 1; /*  */
      unsigned char P2IE4           : 1; /*  */
      unsigned char P2IE5           : 1; /*  */
      unsigned char P2IE6           : 1; /*  */
      unsigned char P2IE7           : 1; /*  */
    } P2IE_bit;
  }; 
} @ 0x021A;

enum {
  PAIE0           = 0x0001,
  PAIE1           = 0x0002,
  PAIE2           = 0x0004,
  PAIE3           = 0x0008,
  PAIE4           = 0x0010,
  PAIE5           = 0x0020,
  PAIE6           = 0x0040,
  PAIE7           = 0x0080,
  PAIE8           = 0x0100,
  PAIE9           = 0x0200,
  PAIE10          = 0x0400,
  PAIE11          = 0x0800,
  PAIE12          = 0x1000,
  PAIE13          = 0x2000,
  PAIE14          = 0x4000,
  PAIE15          = 0x8000
};

__no_init volatile union
{
  unsigned short PAIFG;   /* Port A Interrupt Flag  */

  struct
  {
    unsigned short PAIFG0          : 1; /*  */
    unsigned short PAIFG1          : 1; /*  */
    unsigned short PAIFG2          : 1; /*  */
    unsigned short PAIFG3          : 1; /*  */
    unsigned short PAIFG4          : 1; /*  */
    unsigned short PAIFG5          : 1; /*  */
    unsigned short PAIFG6          : 1; /*  */
    unsigned short PAIFG7          : 1; /*  */
    unsigned short PAIFG8          : 1; /*  */
    unsigned short PAIFG9          : 1; /*  */
    unsigned short PAIFG10         : 1; /*  */
    unsigned short PAIFG11         : 1; /*  */
    unsigned short PAIFG12         : 1; /*  */
    unsigned short PAIFG13         : 1; /*  */
    unsigned short PAIFG14         : 1; /*  */
    unsigned short PAIFG15         : 1; /*  */
  } PAIFG_bit;

  struct
  {
    unsigned char PAIFG_L;
    unsigned char PAIFG_H;
  };
  struct
  {
    unsigned char P1IFG;   /* Port 1 Interrupt Flag  */
    unsigned char P2IFG;   /* Port 2 Interrupt Flag  */
  };
  struct
  {
    struct
    {
      unsigned char P1IFG0          : 1; /*  */
      unsigned char P1IFG1          : 1; /*  */
      unsigned char P1IFG2          : 1; /*  */
      unsigned char P1IFG3          : 1; /*  */
      unsigned char P1IFG4          : 1; /*  */
      unsigned char P1IFG5          : 1; /*  */
      unsigned char P1IFG6          : 1; /*  */
      unsigned char P1IFG7          : 1; /*  */
    } P1IFG_bit;

    struct
    {
      unsigned char P2IFG0          : 1; /*  */
      unsigned char P2IFG1          : 1; /*  */
      unsigned char P2IFG2          : 1; /*  */
      unsigned char P2IFG3          : 1; /*  */
      unsigned char P2IFG4          : 1; /*  */
      unsigned char P2IFG5          : 1; /*  */
      unsigned char P2IFG6          : 1; /*  */
      unsigned char P2IFG7          : 1; /*  */
    } P2IFG_bit;
  }; 
} @ 0x021C;

enum {
  PAIFG0          = 0x0001,
  PAIFG1          = 0x0002,
  PAIFG2          = 0x0004,
  PAIFG3          = 0x0008,
  PAIFG4          = 0x0010,
  PAIFG5          = 0x0020,
  PAIFG6          = 0x0040,
  PAIFG7          = 0x0080,
  PAIFG8          = 0x0100,
  PAIFG9          = 0x0200,
  PAIFG10         = 0x0400,
  PAIFG11         = 0x0800,
  PAIFG12         = 0x1000,
  PAIFG13         = 0x2000,
  PAIFG14         = 0x4000,
  PAIFG15         = 0x8000
};



#define __MSP430_HAS_PORT1_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_PORT2_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_PORTA_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_P1SEL__          /* Define for DriverLib */
#define __MSP430_HAS_P2SEL__          /* Define for DriverLib */
#define __MSP430_HAS_PASEL__          /* Define for DriverLib */
#define __MSP430_BASEADDRESS_PORT1_R__ 0x0200
#define P1_BASE __MSP430_BASEADDRESS_PORT1_R__
#define __MSP430_BASEADDRESS_PORT2_R__ 0x0200
#define P2_BASE __MSP430_BASEADDRESS_PORT2_R__
#define __MSP430_BASEADDRESS_PORTA_R__ 0x0200
#define PA_BASE __MSP430_BASEADDRESS_PORTA_R__
#define P1IV_NONE            (0x0000u)    /* No Interrupt pending */
#define P1IV_P1IFG0          (0x0002u)    /* P1IV P1IFG.0 */
#define P1IV_P1IFG1          (0x0004u)    /* P1IV P1IFG.1 */
#define P1IV_P1IFG2          (0x0006u)    /* P1IV P1IFG.2 */
#define P1IV_P1IFG3          (0x0008u)    /* P1IV P1IFG.3 */
#define P1IV_P1IFG4          (0x000Au)    /* P1IV P1IFG.4 */
#define P1IV_P1IFG5          (0x000Cu)    /* P1IV P1IFG.5 */
#define P1IV_P1IFG6          (0x000Eu)    /* P1IV P1IFG.6 */
#define P1IV_P1IFG7          (0x0010u)    /* P1IV P1IFG.7 */
#define P2IV_NONE            (0x0000u)    /* No Interrupt pending */
#define P2IV_P2IFG0          (0x0002u)    /* P2IV P2IFG.0 */
#define P2IV_P2IFG1          (0x0004u)    /* P2IV P2IFG.1 */
#define P2IV_P2IFG2          (0x0006u)    /* P2IV P2IFG.2 */
#define P2IV_P2IFG3          (0x0008u)    /* P2IV P2IFG.3 */
#define P2IV_P2IFG4          (0x000Au)    /* P2IV P2IFG.4 */
#define P2IV_P2IFG5          (0x000Cu)    /* P2IV P2IFG.5 */
#define P2IV_P2IFG6          (0x000Eu)    /* P2IV P2IFG.6 */
#define P2IV_P2IFG7          (0x0010u)    /* P2IV P2IFG.7 */

/*-------------------------------------------------------------------------
 *   Port 1/2
 *-------------------------------------------------------------------------*/


enum {
  P1IN0           = 0x0001,
  P1IN1           = 0x0002,
  P1IN2           = 0x0004,
  P1IN3           = 0x0008,
  P1IN4           = 0x0010,
  P1IN5           = 0x0020,
  P1IN6           = 0x0040,
  P1IN7           = 0x0080
};

enum {
  P1OUT0          = 0x0001,
  P1OUT1          = 0x0002,
  P1OUT2          = 0x0004,
  P1OUT3          = 0x0008,
  P1OUT4          = 0x0010,
  P1OUT5          = 0x0020,
  P1OUT6          = 0x0040,
  P1OUT7          = 0x0080
};

enum {
  P1DIR0          = 0x0001,
  P1DIR1          = 0x0002,
  P1DIR2          = 0x0004,
  P1DIR3          = 0x0008,
  P1DIR4          = 0x0010,
  P1DIR5          = 0x0020,
  P1DIR6          = 0x0040,
  P1DIR7          = 0x0080
};

enum {
  P1REN0          = 0x0001,
  P1REN1          = 0x0002,
  P1REN2          = 0x0004,
  P1REN3          = 0x0008,
  P1REN4          = 0x0010,
  P1REN5          = 0x0020,
  P1REN6          = 0x0040,
  P1REN7          = 0x0080
};

enum {
  P1DS0           = 0x0001,
  P1DS1           = 0x0002,
  P1DS2           = 0x0004,
  P1DS3           = 0x0008,
  P1DS4           = 0x0010,
  P1DS5           = 0x0020,
  P1DS6           = 0x0040,
  P1DS7           = 0x0080
};

enum {
  P1SEL0          = 0x0001,
  P1SEL1          = 0x0002,
  P1SEL2          = 0x0004,
  P1SEL3          = 0x0008,
  P1SEL4          = 0x0010,
  P1SEL5          = 0x0020,
  P1SEL6          = 0x0040,
  P1SEL7          = 0x0080
};


  /* Port 1 Interrupt Vector Word  */
__no_init volatile unsigned short P1IV @ 0x020E;


enum {
  P1IES0          = 0x0001,
  P1IES1          = 0x0002,
  P1IES2          = 0x0004,
  P1IES3          = 0x0008,
  P1IES4          = 0x0010,
  P1IES5          = 0x0020,
  P1IES6          = 0x0040,
  P1IES7          = 0x0080
};

enum {
  P1IE0           = 0x0001,
  P1IE1           = 0x0002,
  P1IE2           = 0x0004,
  P1IE3           = 0x0008,
  P1IE4           = 0x0010,
  P1IE5           = 0x0020,
  P1IE6           = 0x0040,
  P1IE7           = 0x0080
};

enum {
  P1IFG0          = 0x0001,
  P1IFG1          = 0x0002,
  P1IFG2          = 0x0004,
  P1IFG3          = 0x0008,
  P1IFG4          = 0x0010,
  P1IFG5          = 0x0020,
  P1IFG6          = 0x0040,
  P1IFG7          = 0x0080
};

enum {
  P2IN0           = 0x0001,
  P2IN1           = 0x0002,
  P2IN2           = 0x0004,
  P2IN3           = 0x0008,
  P2IN4           = 0x0010,
  P2IN5           = 0x0020,
  P2IN6           = 0x0040,
  P2IN7           = 0x0080
};

enum {
  P2OUT0          = 0x0001,
  P2OUT1          = 0x0002,
  P2OUT2          = 0x0004,
  P2OUT3          = 0x0008,
  P2OUT4          = 0x0010,
  P2OUT5          = 0x0020,
  P2OUT6          = 0x0040,
  P2OUT7          = 0x0080
};

enum {
  P2DIR0          = 0x0001,
  P2DIR1          = 0x0002,
  P2DIR2          = 0x0004,
  P2DIR3          = 0x0008,
  P2DIR4          = 0x0010,
  P2DIR5          = 0x0020,
  P2DIR6          = 0x0040,
  P2DIR7          = 0x0080
};

enum {
  P2REN0          = 0x0001,
  P2REN1          = 0x0002,
  P2REN2          = 0x0004,
  P2REN3          = 0x0008,
  P2REN4          = 0x0010,
  P2REN5          = 0x0020,
  P2REN6          = 0x0040,
  P2REN7          = 0x0080
};

enum {
  P2DS0           = 0x0001,
  P2DS1           = 0x0002,
  P2DS2           = 0x0004,
  P2DS3           = 0x0008,
  P2DS4           = 0x0010,
  P2DS5           = 0x0020,
  P2DS6           = 0x0040,
  P2DS7           = 0x0080
};

enum {
  P2SEL0          = 0x0001,
  P2SEL1          = 0x0002,
  P2SEL2          = 0x0004,
  P2SEL3          = 0x0008,
  P2SEL4          = 0x0010,
  P2SEL5          = 0x0020,
  P2SEL6          = 0x0040,
  P2SEL7          = 0x0080
};


  /* Port 2 Interrupt Vector Word  */
__no_init volatile unsigned short P2IV @ 0x021E;


enum {
  P2IES0          = 0x0001,
  P2IES1          = 0x0002,
  P2IES2          = 0x0004,
  P2IES3          = 0x0008,
  P2IES4          = 0x0010,
  P2IES5          = 0x0020,
  P2IES6          = 0x0040,
  P2IES7          = 0x0080
};

enum {
  P2IE0           = 0x0001,
  P2IE1           = 0x0002,
  P2IE2           = 0x0004,
  P2IE3           = 0x0008,
  P2IE4           = 0x0010,
  P2IE5           = 0x0020,
  P2IE6           = 0x0040,
  P2IE7           = 0x0080
};

enum {
  P2IFG0          = 0x0001,
  P2IFG1          = 0x0002,
  P2IFG2          = 0x0004,
  P2IFG3          = 0x0008,
  P2IFG4          = 0x0010,
  P2IFG5          = 0x0020,
  P2IFG6          = 0x0040,
  P2IFG7          = 0x0080
};



/*-------------------------------------------------------------------------
 *   Port B
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned __READ short PBIN;   /* Port B Input  */

  struct
  {
    unsigned __READ short PBIN0           : 1; /*  */
    unsigned __READ short PBIN1           : 1; /*  */
    unsigned __READ short PBIN2           : 1; /*  */
    unsigned __READ short PBIN3           : 1; /*  */
    unsigned __READ short PBIN4           : 1; /*  */
    unsigned __READ short PBIN5           : 1; /*  */
    unsigned __READ short PBIN6           : 1; /*  */
    unsigned __READ short PBIN7           : 1; /*  */
    unsigned __READ short PBIN8           : 1; /*  */
    unsigned __READ short PBIN9           : 1; /*  */
    unsigned __READ short PBIN10          : 1; /*  */
    unsigned __READ short PBIN11          : 1; /*  */
    unsigned __READ short PBIN12          : 1; /*  */
    unsigned __READ short PBIN13          : 1; /*  */
    unsigned __READ short PBIN14          : 1; /*  */
    unsigned __READ short PBIN15          : 1; /*  */
  } PBIN_bit;

  struct
  {
    unsigned __READ char PBIN_L;
    unsigned __READ char PBIN_H;
  };
  struct
  {
    unsigned char P3IN;   /* Port 3 Input  */
    unsigned char P4IN;   /* Port 4 Input  */
  };
  struct
  {
    struct
    {
      unsigned char P3IN0           : 1; /*  */
      unsigned char P3IN1           : 1; /*  */
      unsigned char P3IN2           : 1; /*  */
      unsigned char P3IN3           : 1; /*  */
      unsigned char P3IN4           : 1; /*  */
      unsigned char P3IN5           : 1; /*  */
      unsigned char P3IN6           : 1; /*  */
      unsigned char P3IN7           : 1; /*  */
    } P3IN_bit;

    struct
    {
      unsigned char P4IN0           : 1; /*  */
      unsigned char P4IN1           : 1; /*  */
      unsigned char P4IN2           : 1; /*  */
      unsigned char P4IN3           : 1; /*  */
      unsigned char P4IN4           : 1; /*  */
      unsigned char P4IN5           : 1; /*  */
      unsigned char P4IN6           : 1; /*  */
      unsigned char P4IN7           : 1; /*  */
    } P4IN_bit;
  }; 
} @ 0x0220;

enum {
  PBIN0           = 0x0001,
  PBIN1           = 0x0002,
  PBIN2           = 0x0004,
  PBIN3           = 0x0008,
  PBIN4           = 0x0010,
  PBIN5           = 0x0020,
  PBIN6           = 0x0040,
  PBIN7           = 0x0080,
  PBIN8           = 0x0100,
  PBIN9           = 0x0200,
  PBIN10          = 0x0400,
  PBIN11          = 0x0800,
  PBIN12          = 0x1000,
  PBIN13          = 0x2000,
  PBIN14          = 0x4000,
  PBIN15          = 0x8000
};

__no_init volatile union
{
  unsigned short PBOUT;   /* Port B Output  */

  struct
  {
    unsigned short PBOUT0          : 1; /*  */
    unsigned short PBOUT1          : 1; /*  */
    unsigned short PBOUT2          : 1; /*  */
    unsigned short PBOUT3          : 1; /*  */
    unsigned short PBOUT4          : 1; /*  */
    unsigned short PBOUT5          : 1; /*  */
    unsigned short PBOUT6          : 1; /*  */
    unsigned short PBOUT7          : 1; /*  */
    unsigned short PBOUT8          : 1; /*  */
    unsigned short PBOUT9          : 1; /*  */
    unsigned short PBOUT10         : 1; /*  */
    unsigned short PBOUT11         : 1; /*  */
    unsigned short PBOUT12         : 1; /*  */
    unsigned short PBOUT13         : 1; /*  */
    unsigned short PBOUT14         : 1; /*  */
    unsigned short PBOUT15         : 1; /*  */
  } PBOUT_bit;

  struct
  {
    unsigned char PBOUT_L;
    unsigned char PBOUT_H;
  };
  struct
  {
    unsigned char P3OUT;   /* Port 3 Output  */
    unsigned char P4OUT;   /* Port 4 Output  */
  };
  struct
  {
    struct
    {
      unsigned char P3OUT0          : 1; /*  */
      unsigned char P3OUT1          : 1; /*  */
      unsigned char P3OUT2          : 1; /*  */
      unsigned char P3OUT3          : 1; /*  */
      unsigned char P3OUT4          : 1; /*  */
      unsigned char P3OUT5          : 1; /*  */
      unsigned char P3OUT6          : 1; /*  */
      unsigned char P3OUT7          : 1; /*  */
    } P3OUT_bit;

    struct
    {
      unsigned char P4OUT0          : 1; /*  */
      unsigned char P4OUT1          : 1; /*  */
      unsigned char P4OUT2          : 1; /*  */
      unsigned char P4OUT3          : 1; /*  */
      unsigned char P4OUT4          : 1; /*  */
      unsigned char P4OUT5          : 1; /*  */
      unsigned char P4OUT6          : 1; /*  */
      unsigned char P4OUT7          : 1; /*  */
    } P4OUT_bit;
  }; 
} @ 0x0222;

enum {
  PBOUT0          = 0x0001,
  PBOUT1          = 0x0002,
  PBOUT2          = 0x0004,
  PBOUT3          = 0x0008,
  PBOUT4          = 0x0010,
  PBOUT5          = 0x0020,
  PBOUT6          = 0x0040,
  PBOUT7          = 0x0080,
  PBOUT8          = 0x0100,
  PBOUT9          = 0x0200,
  PBOUT10         = 0x0400,
  PBOUT11         = 0x0800,
  PBOUT12         = 0x1000,
  PBOUT13         = 0x2000,
  PBOUT14         = 0x4000,
  PBOUT15         = 0x8000
};

__no_init volatile union
{
  unsigned short PBDIR;   /* Port B Direction  */

  struct
  {
    unsigned short PBDIR0          : 1; /*  */
    unsigned short PBDIR1          : 1; /*  */
    unsigned short PBDIR2          : 1; /*  */
    unsigned short PBDIR3          : 1; /*  */
    unsigned short PBDIR4          : 1; /*  */
    unsigned short PBDIR5          : 1; /*  */
    unsigned short PBDIR6          : 1; /*  */
    unsigned short PBDIR7          : 1; /*  */
    unsigned short PBDIR8          : 1; /*  */
    unsigned short PBDIR9          : 1; /*  */
    unsigned short PBDIR10         : 1; /*  */
    unsigned short PBDIR11         : 1; /*  */
    unsigned short PBDIR12         : 1; /*  */
    unsigned short PBDIR13         : 1; /*  */
    unsigned short PBDIR14         : 1; /*  */
    unsigned short PBDIR15         : 1; /*  */
  } PBDIR_bit;

  struct
  {
    unsigned char PBDIR_L;
    unsigned char PBDIR_H;
  };
  struct
  {
    unsigned char P3DIR;   /* Port 3 Direction  */
    unsigned char P4DIR;   /* Port 4 Direction  */
  };
  struct
  {
    struct
    {
      unsigned char P3DIR0          : 1; /*  */
      unsigned char P3DIR1          : 1; /*  */
      unsigned char P3DIR2          : 1; /*  */
      unsigned char P3DIR3          : 1; /*  */
      unsigned char P3DIR4          : 1; /*  */
      unsigned char P3DIR5          : 1; /*  */
      unsigned char P3DIR6          : 1; /*  */
      unsigned char P3DIR7          : 1; /*  */
    } P3DIR_bit;

    struct
    {
      unsigned char P4DIR0          : 1; /*  */
      unsigned char P4DIR1          : 1; /*  */
      unsigned char P4DIR2          : 1; /*  */
      unsigned char P4DIR3          : 1; /*  */
      unsigned char P4DIR4          : 1; /*  */
      unsigned char P4DIR5          : 1; /*  */
      unsigned char P4DIR6          : 1; /*  */
      unsigned char P4DIR7          : 1; /*  */
    } P4DIR_bit;
  }; 
} @ 0x0224;

enum {
  PBDIR0          = 0x0001,
  PBDIR1          = 0x0002,
  PBDIR2          = 0x0004,
  PBDIR3          = 0x0008,
  PBDIR4          = 0x0010,
  PBDIR5          = 0x0020,
  PBDIR6          = 0x0040,
  PBDIR7          = 0x0080,
  PBDIR8          = 0x0100,
  PBDIR9          = 0x0200,
  PBDIR10         = 0x0400,
  PBDIR11         = 0x0800,
  PBDIR12         = 0x1000,
  PBDIR13         = 0x2000,
  PBDIR14         = 0x4000,
  PBDIR15         = 0x8000
};

__no_init volatile union
{
  unsigned short PBREN;   /* Port B Resistor Enable  */

  struct
  {
    unsigned short PBREN0          : 1; /*  */
    unsigned short PBREN1          : 1; /*  */
    unsigned short PBREN2          : 1; /*  */
    unsigned short PBREN3          : 1; /*  */
    unsigned short PBREN4          : 1; /*  */
    unsigned short PBREN5          : 1; /*  */
    unsigned short PBREN6          : 1; /*  */
    unsigned short PBREN7          : 1; /*  */
    unsigned short PBREN8          : 1; /*  */
    unsigned short PBREN9          : 1; /*  */
    unsigned short PBREN10         : 1; /*  */
    unsigned short PBREN11         : 1; /*  */
    unsigned short PBREN12         : 1; /*  */
    unsigned short PBREN13         : 1; /*  */
    unsigned short PBREN14         : 1; /*  */
    unsigned short PBREN15         : 1; /*  */
  } PBREN_bit;

  struct
  {
    unsigned char PBREN_L;
    unsigned char PBREN_H;
  };
  struct
  {
    unsigned char P3REN;   /* Port 3 Resistor Enable  */
    unsigned char P4REN;   /* Port 4 Resistor Enable  */
  };
  struct
  {
    struct
    {
      unsigned char P3REN0          : 1; /*  */
      unsigned char P3REN1          : 1; /*  */
      unsigned char P3REN2          : 1; /*  */
      unsigned char P3REN3          : 1; /*  */
      unsigned char P3REN4          : 1; /*  */
      unsigned char P3REN5          : 1; /*  */
      unsigned char P3REN6          : 1; /*  */
      unsigned char P3REN7          : 1; /*  */
    } P3REN_bit;

    struct
    {
      unsigned char P4REN0          : 1; /*  */
      unsigned char P4REN1          : 1; /*  */
      unsigned char P4REN2          : 1; /*  */
      unsigned char P4REN3          : 1; /*  */
      unsigned char P4REN4          : 1; /*  */
      unsigned char P4REN5          : 1; /*  */
      unsigned char P4REN6          : 1; /*  */
      unsigned char P4REN7          : 1; /*  */
    } P4REN_bit;
  }; 
} @ 0x0226;

enum {
  PBREN0          = 0x0001,
  PBREN1          = 0x0002,
  PBREN2          = 0x0004,
  PBREN3          = 0x0008,
  PBREN4          = 0x0010,
  PBREN5          = 0x0020,
  PBREN6          = 0x0040,
  PBREN7          = 0x0080,
  PBREN8          = 0x0100,
  PBREN9          = 0x0200,
  PBREN10         = 0x0400,
  PBREN11         = 0x0800,
  PBREN12         = 0x1000,
  PBREN13         = 0x2000,
  PBREN14         = 0x4000,
  PBREN15         = 0x8000
};

__no_init volatile union
{
  unsigned short PBDS;   /* Port B Drive Strenght  */

  struct
  {
    unsigned short PBDS0           : 1; /*  */
    unsigned short PBDS1           : 1; /*  */
    unsigned short PBDS2           : 1; /*  */
    unsigned short PBDS3           : 1; /*  */
    unsigned short PBDS4           : 1; /*  */
    unsigned short PBDS5           : 1; /*  */
    unsigned short PBDS6           : 1; /*  */
    unsigned short PBDS7           : 1; /*  */
    unsigned short PBDS8           : 1; /*  */
    unsigned short PBDS9           : 1; /*  */
    unsigned short PBDS10          : 1; /*  */
    unsigned short PBDS11          : 1; /*  */
    unsigned short PBDS12          : 1; /*  */
    unsigned short PBDS13          : 1; /*  */
    unsigned short PBDS14          : 1; /*  */
    unsigned short PBDS15          : 1; /*  */
  } PBDS_bit;

  struct
  {
    unsigned char PBDS_L;
    unsigned char PBDS_H;
  };
  struct
  {
    unsigned char P3DS;   /* Port 3 Drive Strenght  */
    unsigned char P4DS;   /* Port 4 Drive Strenght  */
  };
  struct
  {
    struct
    {
      unsigned char P3DS0           : 1; /*  */
      unsigned char P3DS1           : 1; /*  */
      unsigned char P3DS2           : 1; /*  */
      unsigned char P3DS3           : 1; /*  */
      unsigned char P3DS4           : 1; /*  */
      unsigned char P3DS5           : 1; /*  */
      unsigned char P3DS6           : 1; /*  */
      unsigned char P3DS7           : 1; /*  */
    } P3DS_bit;

    struct
    {
      unsigned char P4DS0           : 1; /*  */
      unsigned char P4DS1           : 1; /*  */
      unsigned char P4DS2           : 1; /*  */
      unsigned char P4DS3           : 1; /*  */
      unsigned char P4DS4           : 1; /*  */
      unsigned char P4DS5           : 1; /*  */
      unsigned char P4DS6           : 1; /*  */
      unsigned char P4DS7           : 1; /*  */
    } P4DS_bit;
  }; 
} @ 0x0228;

enum {
  PBDS0           = 0x0001,
  PBDS1           = 0x0002,
  PBDS2           = 0x0004,
  PBDS3           = 0x0008,
  PBDS4           = 0x0010,
  PBDS5           = 0x0020,
  PBDS6           = 0x0040,
  PBDS7           = 0x0080,
  PBDS8           = 0x0100,
  PBDS9           = 0x0200,
  PBDS10          = 0x0400,
  PBDS11          = 0x0800,
  PBDS12          = 0x1000,
  PBDS13          = 0x2000,
  PBDS14          = 0x4000,
  PBDS15          = 0x8000
};

__no_init volatile union
{
  unsigned short PBSEL;   /* Port B Selection  */

  struct
  {
    unsigned short PBSEL0          : 1; /*  */
    unsigned short PBSEL1          : 1; /*  */
    unsigned short PBSEL2          : 1; /*  */
    unsigned short PBSEL3          : 1; /*  */
    unsigned short PBSEL4          : 1; /*  */
    unsigned short PBSEL5          : 1; /*  */
    unsigned short PBSEL6          : 1; /*  */
    unsigned short PBSEL7          : 1; /*  */
    unsigned short PBSEL8          : 1; /*  */
    unsigned short PBSEL9          : 1; /*  */
    unsigned short PBSEL10         : 1; /*  */
    unsigned short PBSEL11         : 1; /*  */
    unsigned short PBSEL12         : 1; /*  */
    unsigned short PBSEL13         : 1; /*  */
    unsigned short PBSEL14         : 1; /*  */
    unsigned short PBSEL15         : 1; /*  */
  } PBSEL_bit;

  struct
  {
    unsigned char PBSEL_L;
    unsigned char PBSEL_H;
  };
  struct
  {
    unsigned char P3SEL;   /* Port 3 Selection  */
    unsigned char P4SEL;   /* Port 4 Selection  */
  };
  struct
  {
    struct
    {
      unsigned char P3SEL0          : 1; /*  */
      unsigned char P3SEL1          : 1; /*  */
      unsigned char P3SEL2          : 1; /*  */
      unsigned char P3SEL3          : 1; /*  */
      unsigned char P3SEL4          : 1; /*  */
      unsigned char P3SEL5          : 1; /*  */
      unsigned char P3SEL6          : 1; /*  */
      unsigned char P3SEL7          : 1; /*  */
    } P3SEL_bit;

    struct
    {
      unsigned char P4SEL0          : 1; /*  */
      unsigned char P4SEL1          : 1; /*  */
      unsigned char P4SEL2          : 1; /*  */
      unsigned char P4SEL3          : 1; /*  */
      unsigned char P4SEL4          : 1; /*  */
      unsigned char P4SEL5          : 1; /*  */
      unsigned char P4SEL6          : 1; /*  */
      unsigned char P4SEL7          : 1; /*  */
    } P4SEL_bit;
  }; 
} @ 0x022A;

enum {
  PBSEL0          = 0x0001,
  PBSEL1          = 0x0002,
  PBSEL2          = 0x0004,
  PBSEL3          = 0x0008,
  PBSEL4          = 0x0010,
  PBSEL5          = 0x0020,
  PBSEL6          = 0x0040,
  PBSEL7          = 0x0080,
  PBSEL8          = 0x0100,
  PBSEL9          = 0x0200,
  PBSEL10         = 0x0400,
  PBSEL11         = 0x0800,
  PBSEL12         = 0x1000,
  PBSEL13         = 0x2000,
  PBSEL14         = 0x4000,
  PBSEL15         = 0x8000
};



#define __MSP430_HAS_PORT3_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_PORT4_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_PORTB_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_P3SEL__          /* Define for DriverLib */
#define __MSP430_HAS_P4SEL__          /* Define for DriverLib */
#define __MSP430_HAS_PBSEL__          /* Define for DriverLib */
#define __MSP430_BASEADDRESS_PORT3_R__ 0x0220
#define P3_BASE __MSP430_BASEADDRESS_PORT3_R__
#define __MSP430_BASEADDRESS_PORT4_R__ 0x0220
#define P4_BASE __MSP430_BASEADDRESS_PORT4_R__
#define __MSP430_BASEADDRESS_PORTB_R__ 0x0220
#define PB_BASE __MSP430_BASEADDRESS_PORTB_R__

/*-------------------------------------------------------------------------
 *   Port 3/4
 *-------------------------------------------------------------------------*/


enum {
  P3IN0           = 0x0001,
  P3IN1           = 0x0002,
  P3IN2           = 0x0004,
  P3IN3           = 0x0008,
  P3IN4           = 0x0010,
  P3IN5           = 0x0020,
  P3IN6           = 0x0040,
  P3IN7           = 0x0080
};

enum {
  P3OUT0          = 0x0001,
  P3OUT1          = 0x0002,
  P3OUT2          = 0x0004,
  P3OUT3          = 0x0008,
  P3OUT4          = 0x0010,
  P3OUT5          = 0x0020,
  P3OUT6          = 0x0040,
  P3OUT7          = 0x0080
};

enum {
  P3DIR0          = 0x0001,
  P3DIR1          = 0x0002,
  P3DIR2          = 0x0004,
  P3DIR3          = 0x0008,
  P3DIR4          = 0x0010,
  P3DIR5          = 0x0020,
  P3DIR6          = 0x0040,
  P3DIR7          = 0x0080
};

enum {
  P3REN0          = 0x0001,
  P3REN1          = 0x0002,
  P3REN2          = 0x0004,
  P3REN3          = 0x0008,
  P3REN4          = 0x0010,
  P3REN5          = 0x0020,
  P3REN6          = 0x0040,
  P3REN7          = 0x0080
};

enum {
  P3DS0           = 0x0001,
  P3DS1           = 0x0002,
  P3DS2           = 0x0004,
  P3DS3           = 0x0008,
  P3DS4           = 0x0010,
  P3DS5           = 0x0020,
  P3DS6           = 0x0040,
  P3DS7           = 0x0080
};

enum {
  P3SEL0          = 0x0001,
  P3SEL1          = 0x0002,
  P3SEL2          = 0x0004,
  P3SEL3          = 0x0008,
  P3SEL4          = 0x0010,
  P3SEL5          = 0x0020,
  P3SEL6          = 0x0040,
  P3SEL7          = 0x0080
};

enum {
  P4IN0           = 0x0001,
  P4IN1           = 0x0002,
  P4IN2           = 0x0004,
  P4IN3           = 0x0008,
  P4IN4           = 0x0010,
  P4IN5           = 0x0020,
  P4IN6           = 0x0040,
  P4IN7           = 0x0080
};

enum {
  P4OUT0          = 0x0001,
  P4OUT1          = 0x0002,
  P4OUT2          = 0x0004,
  P4OUT3          = 0x0008,
  P4OUT4          = 0x0010,
  P4OUT5          = 0x0020,
  P4OUT6          = 0x0040,
  P4OUT7          = 0x0080
};

enum {
  P4DIR0          = 0x0001,
  P4DIR1          = 0x0002,
  P4DIR2          = 0x0004,
  P4DIR3          = 0x0008,
  P4DIR4          = 0x0010,
  P4DIR5          = 0x0020,
  P4DIR6          = 0x0040,
  P4DIR7          = 0x0080
};

enum {
  P4REN0          = 0x0001,
  P4REN1          = 0x0002,
  P4REN2          = 0x0004,
  P4REN3          = 0x0008,
  P4REN4          = 0x0010,
  P4REN5          = 0x0020,
  P4REN6          = 0x0040,
  P4REN7          = 0x0080
};

enum {
  P4DS0           = 0x0001,
  P4DS1           = 0x0002,
  P4DS2           = 0x0004,
  P4DS3           = 0x0008,
  P4DS4           = 0x0010,
  P4DS5           = 0x0020,
  P4DS6           = 0x0040,
  P4DS7           = 0x0080
};

enum {
  P4SEL0          = 0x0001,
  P4SEL1          = 0x0002,
  P4SEL2          = 0x0004,
  P4SEL3          = 0x0008,
  P4SEL4          = 0x0010,
  P4SEL5          = 0x0020,
  P4SEL6          = 0x0040,
  P4SEL7          = 0x0080
};



/*-------------------------------------------------------------------------
 *   Port C
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned __READ short PCIN;   /* Port C Input  */

  struct
  {
    unsigned __READ short PCIN0           : 1; /*  */
    unsigned __READ short PCIN1           : 1; /*  */
    unsigned __READ short PCIN2           : 1; /*  */
    unsigned __READ short PCIN3           : 1; /*  */
    unsigned __READ short PCIN4           : 1; /*  */
    unsigned __READ short PCIN5           : 1; /*  */
    unsigned __READ short PCIN6           : 1; /*  */
    unsigned __READ short PCIN7           : 1; /*  */
    unsigned __READ short PCIN8           : 1; /*  */
    unsigned __READ short PCIN9           : 1; /*  */
    unsigned __READ short PCIN10          : 1; /*  */
    unsigned __READ short PCIN11          : 1; /*  */
    unsigned __READ short PCIN12          : 1; /*  */
    unsigned __READ short PCIN13          : 1; /*  */
    unsigned __READ short PCIN14          : 1; /*  */
    unsigned __READ short PCIN15          : 1; /*  */
  } PCIN_bit;

  struct
  {
    unsigned __READ char PCIN_L;
    unsigned __READ char PCIN_H;
  };
  struct
  {
    unsigned char P5IN;   /* Port 5 Input  */
    unsigned char P6IN;   /* Port 6 Input  */
  };
  struct
  {
    struct
    {
      unsigned char P5IN0           : 1; /*  */
      unsigned char P5IN1           : 1; /*  */
      unsigned char P5IN2           : 1; /*  */
      unsigned char P5IN3           : 1; /*  */
      unsigned char P5IN4           : 1; /*  */
      unsigned char P5IN5           : 1; /*  */
      unsigned char P5IN6           : 1; /*  */
      unsigned char P5IN7           : 1; /*  */
    } P5IN_bit;

    struct
    {
      unsigned char P6IN0           : 1; /*  */
      unsigned char P6IN1           : 1; /*  */
      unsigned char P6IN2           : 1; /*  */
      unsigned char P6IN3           : 1; /*  */
      unsigned char P6IN4           : 1; /*  */
      unsigned char P6IN5           : 1; /*  */
      unsigned char P6IN6           : 1; /*  */
      unsigned char P6IN7           : 1; /*  */
    } P6IN_bit;
  }; 
} @ 0x0240;

enum {
  PCIN0           = 0x0001,
  PCIN1           = 0x0002,
  PCIN2           = 0x0004,
  PCIN3           = 0x0008,
  PCIN4           = 0x0010,
  PCIN5           = 0x0020,
  PCIN6           = 0x0040,
  PCIN7           = 0x0080,
  PCIN8           = 0x0100,
  PCIN9           = 0x0200,
  PCIN10          = 0x0400,
  PCIN11          = 0x0800,
  PCIN12          = 0x1000,
  PCIN13          = 0x2000,
  PCIN14          = 0x4000,
  PCIN15          = 0x8000
};

__no_init volatile union
{
  unsigned short PCOUT;   /* Port C Output  */

  struct
  {
    unsigned short PCOUT0          : 1; /*  */
    unsigned short PCOUT1          : 1; /*  */
    unsigned short PCOUT2          : 1; /*  */
    unsigned short PCOUT3          : 1; /*  */
    unsigned short PCOUT4          : 1; /*  */
    unsigned short PCOUT5          : 1; /*  */
    unsigned short PCOUT6          : 1; /*  */
    unsigned short PCOUT7          : 1; /*  */
    unsigned short PCOUT8          : 1; /*  */
    unsigned short PCOUT9          : 1; /*  */
    unsigned short PCOUT10         : 1; /*  */
    unsigned short PCOUT11         : 1; /*  */
    unsigned short PCOUT12         : 1; /*  */
    unsigned short PCOUT13         : 1; /*  */
    unsigned short PCOUT14         : 1; /*  */
    unsigned short PCOUT15         : 1; /*  */
  } PCOUT_bit;

  struct
  {
    unsigned char PCOUT_L;
    unsigned char PCOUT_H;
  };
  struct
  {
    unsigned char P5OUT;   /* Port 5 Output  */
    unsigned char P6OUT;   /* Port 6 Output  */
  };
  struct
  {
    struct
    {
      unsigned char P5OUT0          : 1; /*  */
      unsigned char P5OUT1          : 1; /*  */
      unsigned char P5OUT2          : 1; /*  */
      unsigned char P5OUT3          : 1; /*  */
      unsigned char P5OUT4          : 1; /*  */
      unsigned char P5OUT5          : 1; /*  */
      unsigned char P5OUT6          : 1; /*  */
      unsigned char P5OUT7          : 1; /*  */
    } P5OUT_bit;

    struct
    {
      unsigned char P6OUT0          : 1; /*  */
      unsigned char P6OUT1          : 1; /*  */
      unsigned char P6OUT2          : 1; /*  */
      unsigned char P6OUT3          : 1; /*  */
      unsigned char P6OUT4          : 1; /*  */
      unsigned char P6OUT5          : 1; /*  */
      unsigned char P6OUT6          : 1; /*  */
      unsigned char P6OUT7          : 1; /*  */
    } P6OUT_bit;
  }; 
} @ 0x0242;

enum {
  PCOUT0          = 0x0001,
  PCOUT1          = 0x0002,
  PCOUT2          = 0x0004,
  PCOUT3          = 0x0008,
  PCOUT4          = 0x0010,
  PCOUT5          = 0x0020,
  PCOUT6          = 0x0040,
  PCOUT7          = 0x0080,
  PCOUT8          = 0x0100,
  PCOUT9          = 0x0200,
  PCOUT10         = 0x0400,
  PCOUT11         = 0x0800,
  PCOUT12         = 0x1000,
  PCOUT13         = 0x2000,
  PCOUT14         = 0x4000,
  PCOUT15         = 0x8000
};

__no_init volatile union
{
  unsigned short PCDIR;   /* Port C Direction  */

  struct
  {
    unsigned short PCDIR0          : 1; /*  */
    unsigned short PCDIR1          : 1; /*  */
    unsigned short PCDIR2          : 1; /*  */
    unsigned short PCDIR3          : 1; /*  */
    unsigned short PCDIR4          : 1; /*  */
    unsigned short PCDIR5          : 1; /*  */
    unsigned short PCDIR6          : 1; /*  */
    unsigned short PCDIR7          : 1; /*  */
    unsigned short PCDIR8          : 1; /*  */
    unsigned short PCDIR9          : 1; /*  */
    unsigned short PCDIR10         : 1; /*  */
    unsigned short PCDIR11         : 1; /*  */
    unsigned short PCDIR12         : 1; /*  */
    unsigned short PCDIR13         : 1; /*  */
    unsigned short PCDIR14         : 1; /*  */
    unsigned short PCDIR15         : 1; /*  */
  } PCDIR_bit;

  struct
  {
    unsigned char PCDIR_L;
    unsigned char PCDIR_H;
  };
  struct
  {
    unsigned char P5DIR;   /* Port 5 Direction  */
    unsigned char P6DIR;   /* Port 6 Direction  */
  };
  struct
  {
    struct
    {
      unsigned char P5DIR0          : 1; /*  */
      unsigned char P5DIR1          : 1; /*  */
      unsigned char P5DIR2          : 1; /*  */
      unsigned char P5DIR3          : 1; /*  */
      unsigned char P5DIR4          : 1; /*  */
      unsigned char P5DIR5          : 1; /*  */
      unsigned char P5DIR6          : 1; /*  */
      unsigned char P5DIR7          : 1; /*  */
    } P5DIR_bit;

    struct
    {
      unsigned char P6DIR0          : 1; /*  */
      unsigned char P6DIR1          : 1; /*  */
      unsigned char P6DIR2          : 1; /*  */
      unsigned char P6DIR3          : 1; /*  */
      unsigned char P6DIR4          : 1; /*  */
      unsigned char P6DIR5          : 1; /*  */
      unsigned char P6DIR6          : 1; /*  */
      unsigned char P6DIR7          : 1; /*  */
    } P6DIR_bit;
  }; 
} @ 0x0244;

enum {
  PCDIR0          = 0x0001,
  PCDIR1          = 0x0002,
  PCDIR2          = 0x0004,
  PCDIR3          = 0x0008,
  PCDIR4          = 0x0010,
  PCDIR5          = 0x0020,
  PCDIR6          = 0x0040,
  PCDIR7          = 0x0080,
  PCDIR8          = 0x0100,
  PCDIR9          = 0x0200,
  PCDIR10         = 0x0400,
  PCDIR11         = 0x0800,
  PCDIR12         = 0x1000,
  PCDIR13         = 0x2000,
  PCDIR14         = 0x4000,
  PCDIR15         = 0x8000
};

__no_init volatile union
{
  unsigned short PCREN;   /* Port C Resistor Enable  */

  struct
  {
    unsigned short PCREN0          : 1; /*  */
    unsigned short PCREN1          : 1; /*  */
    unsigned short PCREN2          : 1; /*  */
    unsigned short PCREN3          : 1; /*  */
    unsigned short PCREN4          : 1; /*  */
    unsigned short PCREN5          : 1; /*  */
    unsigned short PCREN6          : 1; /*  */
    unsigned short PCREN7          : 1; /*  */
    unsigned short PCREN8          : 1; /*  */
    unsigned short PCREN9          : 1; /*  */
    unsigned short PCREN10         : 1; /*  */
    unsigned short PCREN11         : 1; /*  */
    unsigned short PCREN12         : 1; /*  */
    unsigned short PCREN13         : 1; /*  */
    unsigned short PCREN14         : 1; /*  */
    unsigned short PCREN15         : 1; /*  */
  } PCREN_bit;

  struct
  {
    unsigned char PCREN_L;
    unsigned char PCREN_H;
  };
  struct
  {
    unsigned char P5REN;   /* Port 5 Resistor Enable  */
    unsigned char P6REN;   /* Port 6 Resistor Enable  */
  };
  struct
  {
    struct
    {
      unsigned char P5REN0          : 1; /*  */
      unsigned char P5REN1          : 1; /*  */
      unsigned char P5REN2          : 1; /*  */
      unsigned char P5REN3          : 1; /*  */
      unsigned char P5REN4          : 1; /*  */
      unsigned char P5REN5          : 1; /*  */
      unsigned char P5REN6          : 1; /*  */
      unsigned char P5REN7          : 1; /*  */
    } P5REN_bit;

    struct
    {
      unsigned char P6REN0          : 1; /*  */
      unsigned char P6REN1          : 1; /*  */
      unsigned char P6REN2          : 1; /*  */
      unsigned char P6REN3          : 1; /*  */
      unsigned char P6REN4          : 1; /*  */
      unsigned char P6REN5          : 1; /*  */
      unsigned char P6REN6          : 1; /*  */
      unsigned char P6REN7          : 1; /*  */
    } P6REN_bit;
  }; 
} @ 0x0246;

enum {
  PCREN0          = 0x0001,
  PCREN1          = 0x0002,
  PCREN2          = 0x0004,
  PCREN3          = 0x0008,
  PCREN4          = 0x0010,
  PCREN5          = 0x0020,
  PCREN6          = 0x0040,
  PCREN7          = 0x0080,
  PCREN8          = 0x0100,
  PCREN9          = 0x0200,
  PCREN10         = 0x0400,
  PCREN11         = 0x0800,
  PCREN12         = 0x1000,
  PCREN13         = 0x2000,
  PCREN14         = 0x4000,
  PCREN15         = 0x8000
};

__no_init volatile union
{
  unsigned short PCDS;   /* Port C Drive Strenght  */

  struct
  {
    unsigned short PCDS0           : 1; /*  */
    unsigned short PCDS1           : 1; /*  */
    unsigned short PCDS2           : 1; /*  */
    unsigned short PCDS3           : 1; /*  */
    unsigned short PCDS4           : 1; /*  */
    unsigned short PCDS5           : 1; /*  */
    unsigned short PCDS6           : 1; /*  */
    unsigned short PCDS7           : 1; /*  */
    unsigned short PCDS8           : 1; /*  */
    unsigned short PCDS9           : 1; /*  */
    unsigned short PCDS10          : 1; /*  */
    unsigned short PCDS11          : 1; /*  */
    unsigned short PCDS12          : 1; /*  */
    unsigned short PCDS13          : 1; /*  */
    unsigned short PCDS14          : 1; /*  */
    unsigned short PCDS15          : 1; /*  */
  } PCDS_bit;

  struct
  {
    unsigned char PCDS_L;
    unsigned char PCDS_H;
  };
  struct
  {
    unsigned char P5DS;   /* Port 5 Drive Strenght  */
    unsigned char P6DS;   /* Port 6 Drive Strenght  */
  };
  struct
  {
    struct
    {
      unsigned char P5DS0           : 1; /*  */
      unsigned char P5DS1           : 1; /*  */
      unsigned char P5DS2           : 1; /*  */
      unsigned char P5DS3           : 1; /*  */
      unsigned char P5DS4           : 1; /*  */
      unsigned char P5DS5           : 1; /*  */
      unsigned char P5DS6           : 1; /*  */
      unsigned char P5DS7           : 1; /*  */
    } P5DS_bit;

    struct
    {
      unsigned char P6DS0           : 1; /*  */
      unsigned char P6DS1           : 1; /*  */
      unsigned char P6DS2           : 1; /*  */
      unsigned char P6DS3           : 1; /*  */
      unsigned char P6DS4           : 1; /*  */
      unsigned char P6DS5           : 1; /*  */
      unsigned char P6DS6           : 1; /*  */
      unsigned char P6DS7           : 1; /*  */
    } P6DS_bit;
  }; 
} @ 0x0248;

enum {
  PCDS0           = 0x0001,
  PCDS1           = 0x0002,
  PCDS2           = 0x0004,
  PCDS3           = 0x0008,
  PCDS4           = 0x0010,
  PCDS5           = 0x0020,
  PCDS6           = 0x0040,
  PCDS7           = 0x0080,
  PCDS8           = 0x0100,
  PCDS9           = 0x0200,
  PCDS10          = 0x0400,
  PCDS11          = 0x0800,
  PCDS12          = 0x1000,
  PCDS13          = 0x2000,
  PCDS14          = 0x4000,
  PCDS15          = 0x8000
};

__no_init volatile union
{
  unsigned short PCSEL;   /* Port C Selection  */

  struct
  {
    unsigned short PCSEL0          : 1; /*  */
    unsigned short PCSEL1          : 1; /*  */
    unsigned short PCSEL2          : 1; /*  */
    unsigned short PCSEL3          : 1; /*  */
    unsigned short PCSEL4          : 1; /*  */
    unsigned short PCSEL5          : 1; /*  */
    unsigned short PCSEL6          : 1; /*  */
    unsigned short PCSEL7          : 1; /*  */
    unsigned short PCSEL8          : 1; /*  */
    unsigned short PCSEL9          : 1; /*  */
    unsigned short PCSEL10         : 1; /*  */
    unsigned short PCSEL11         : 1; /*  */
    unsigned short PCSEL12         : 1; /*  */
    unsigned short PCSEL13         : 1; /*  */
    unsigned short PCSEL14         : 1; /*  */
    unsigned short PCSEL15         : 1; /*  */
  } PCSEL_bit;

  struct
  {
    unsigned char PCSEL_L;
    unsigned char PCSEL_H;
  };
  struct
  {
    unsigned char P5SEL;   /* Port 5 Selection  */
    unsigned char P6SEL;   /* Port 6 Selection  */
  };
  struct
  {
    struct
    {
      unsigned char P5SEL0          : 1; /*  */
      unsigned char P5SEL1          : 1; /*  */
      unsigned char P5SEL2          : 1; /*  */
      unsigned char P5SEL3          : 1; /*  */
      unsigned char P5SEL4          : 1; /*  */
      unsigned char P5SEL5          : 1; /*  */
      unsigned char P5SEL6          : 1; /*  */
      unsigned char P5SEL7          : 1; /*  */
    } P5SEL_bit;

    struct
    {
      unsigned char P6SEL0          : 1; /*  */
      unsigned char P6SEL1          : 1; /*  */
      unsigned char P6SEL2          : 1; /*  */
      unsigned char P6SEL3          : 1; /*  */
      unsigned char P6SEL4          : 1; /*  */
      unsigned char P6SEL5          : 1; /*  */
      unsigned char P6SEL6          : 1; /*  */
      unsigned char P6SEL7          : 1; /*  */
    } P6SEL_bit;
  }; 
} @ 0x024A;

enum {
  PCSEL0          = 0x0001,
  PCSEL1          = 0x0002,
  PCSEL2          = 0x0004,
  PCSEL3          = 0x0008,
  PCSEL4          = 0x0010,
  PCSEL5          = 0x0020,
  PCSEL6          = 0x0040,
  PCSEL7          = 0x0080,
  PCSEL8          = 0x0100,
  PCSEL9          = 0x0200,
  PCSEL10         = 0x0400,
  PCSEL11         = 0x0800,
  PCSEL12         = 0x1000,
  PCSEL13         = 0x2000,
  PCSEL14         = 0x4000,
  PCSEL15         = 0x8000
};



#define __MSP430_HAS_PORT5_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_PORT6_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_PORTC_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_P5SEL__          /* Define for DriverLib */
#define __MSP430_HAS_P6SEL__          /* Define for DriverLib */
#define __MSP430_HAS_PCSEL__          /* Define for DriverLib */
#define __MSP430_BASEADDRESS_PORT5_R__ 0x0240
#define P5_BASE __MSP430_BASEADDRESS_PORT5_R__
#define __MSP430_BASEADDRESS_PORT6_R__ 0x0240
#define P6_BASE __MSP430_BASEADDRESS_PORT6_R__
#define __MSP430_BASEADDRESS_PORTC_R__ 0x0240
#define PC_BASE __MSP430_BASEADDRESS_PORTC_R__

/*-------------------------------------------------------------------------
 *   Port 5/6
 *-------------------------------------------------------------------------*/


enum {
  P5IN0           = 0x0001,
  P5IN1           = 0x0002,
  P5IN2           = 0x0004,
  P5IN3           = 0x0008,
  P5IN4           = 0x0010,
  P5IN5           = 0x0020,
  P5IN6           = 0x0040,
  P5IN7           = 0x0080
};

enum {
  P5OUT0          = 0x0001,
  P5OUT1          = 0x0002,
  P5OUT2          = 0x0004,
  P5OUT3          = 0x0008,
  P5OUT4          = 0x0010,
  P5OUT5          = 0x0020,
  P5OUT6          = 0x0040,
  P5OUT7          = 0x0080
};

enum {
  P5DIR0          = 0x0001,
  P5DIR1          = 0x0002,
  P5DIR2          = 0x0004,
  P5DIR3          = 0x0008,
  P5DIR4          = 0x0010,
  P5DIR5          = 0x0020,
  P5DIR6          = 0x0040,
  P5DIR7          = 0x0080
};

enum {
  P5REN0          = 0x0001,
  P5REN1          = 0x0002,
  P5REN2          = 0x0004,
  P5REN3          = 0x0008,
  P5REN4          = 0x0010,
  P5REN5          = 0x0020,
  P5REN6          = 0x0040,
  P5REN7          = 0x0080
};

enum {
  P5DS0           = 0x0001,
  P5DS1           = 0x0002,
  P5DS2           = 0x0004,
  P5DS3           = 0x0008,
  P5DS4           = 0x0010,
  P5DS5           = 0x0020,
  P5DS6           = 0x0040,
  P5DS7           = 0x0080
};

enum {
  P5SEL0          = 0x0001,
  P5SEL1          = 0x0002,
  P5SEL2          = 0x0004,
  P5SEL3          = 0x0008,
  P5SEL4          = 0x0010,
  P5SEL5          = 0x0020,
  P5SEL6          = 0x0040,
  P5SEL7          = 0x0080
};

enum {
  P6IN0           = 0x0001,
  P6IN1           = 0x0002,
  P6IN2           = 0x0004,
  P6IN3           = 0x0008,
  P6IN4           = 0x0010,
  P6IN5           = 0x0020,
  P6IN6           = 0x0040,
  P6IN7           = 0x0080
};

enum {
  P6OUT0          = 0x0001,
  P6OUT1          = 0x0002,
  P6OUT2          = 0x0004,
  P6OUT3          = 0x0008,
  P6OUT4          = 0x0010,
  P6OUT5          = 0x0020,
  P6OUT6          = 0x0040,
  P6OUT7          = 0x0080
};

enum {
  P6DIR0          = 0x0001,
  P6DIR1          = 0x0002,
  P6DIR2          = 0x0004,
  P6DIR3          = 0x0008,
  P6DIR4          = 0x0010,
  P6DIR5          = 0x0020,
  P6DIR6          = 0x0040,
  P6DIR7          = 0x0080
};

enum {
  P6REN0          = 0x0001,
  P6REN1          = 0x0002,
  P6REN2          = 0x0004,
  P6REN3          = 0x0008,
  P6REN4          = 0x0010,
  P6REN5          = 0x0020,
  P6REN6          = 0x0040,
  P6REN7          = 0x0080
};

enum {
  P6DS0           = 0x0001,
  P6DS1           = 0x0002,
  P6DS2           = 0x0004,
  P6DS3           = 0x0008,
  P6DS4           = 0x0010,
  P6DS5           = 0x0020,
  P6DS6           = 0x0040,
  P6DS7           = 0x0080
};

enum {
  P6SEL0          = 0x0001,
  P6SEL1          = 0x0002,
  P6SEL2          = 0x0004,
  P6SEL3          = 0x0008,
  P6SEL4          = 0x0010,
  P6SEL5          = 0x0020,
  P6SEL6          = 0x0040,
  P6SEL7          = 0x0080
};



/*-------------------------------------------------------------------------
 *   Port D
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned __READ short PDIN;   /* Port D Input  */

  struct
  {
    unsigned __READ short PDIN0           : 1; /*  */
    unsigned __READ short PDIN1           : 1; /*  */
    unsigned __READ short PDIN2           : 1; /*  */
    unsigned __READ short PDIN3           : 1; /*  */
    unsigned __READ short PDIN4           : 1; /*  */
    unsigned __READ short PDIN5           : 1; /*  */
    unsigned __READ short PDIN6           : 1; /*  */
    unsigned __READ short PDIN7           : 1; /*  */
    unsigned __READ short PDIN8           : 1; /*  */
    unsigned __READ short PDIN9           : 1; /*  */
    unsigned __READ short PDIN10          : 1; /*  */
    unsigned __READ short PDIN11          : 1; /*  */
    unsigned __READ short PDIN12          : 1; /*  */
    unsigned __READ short PDIN13          : 1; /*  */
    unsigned __READ short PDIN14          : 1; /*  */
    unsigned __READ short PDIN15          : 1; /*  */
  } PDIN_bit;

  struct
  {
    unsigned __READ char PDIN_L;
    unsigned __READ char PDIN_H;
  };
  struct
  {
    unsigned char P7IN;   /* Port 7 Input  */
    unsigned char P8IN;   /* Port 8 Input  */
  };
  struct
  {
    struct
    {
      unsigned char P7IN0           : 1; /*  */
      unsigned char P7IN1           : 1; /*  */
      unsigned char P7IN2           : 1; /*  */
      unsigned char P7IN3           : 1; /*  */
      unsigned char P7IN4           : 1; /*  */
      unsigned char P7IN5           : 1; /*  */
      unsigned char P7IN6           : 1; /*  */
      unsigned char P7IN7           : 1; /*  */
    } P7IN_bit;

    struct
    {
      unsigned char P8IN0           : 1; /*  */
      unsigned char P8IN1           : 1; /*  */
      unsigned char P8IN2           : 1; /*  */
      unsigned char P8IN3           : 1; /*  */
      unsigned char P8IN4           : 1; /*  */
      unsigned char P8IN5           : 1; /*  */
      unsigned char P8IN6           : 1; /*  */
      unsigned char P8IN7           : 1; /*  */
    } P8IN_bit;
  }; 
} @ 0x0260;

enum {
  PDIN0           = 0x0001,
  PDIN1           = 0x0002,
  PDIN2           = 0x0004,
  PDIN3           = 0x0008,
  PDIN4           = 0x0010,
  PDIN5           = 0x0020,
  PDIN6           = 0x0040,
  PDIN7           = 0x0080,
  PDIN8           = 0x0100,
  PDIN9           = 0x0200,
  PDIN10          = 0x0400,
  PDIN11          = 0x0800,
  PDIN12          = 0x1000,
  PDIN13          = 0x2000,
  PDIN14          = 0x4000,
  PDIN15          = 0x8000
};

__no_init volatile union
{
  unsigned short PDOUT;   /* Port D Output  */

  struct
  {
    unsigned short PDOUT0          : 1; /*  */
    unsigned short PDOUT1          : 1; /*  */
    unsigned short PDOUT2          : 1; /*  */
    unsigned short PDOUT3          : 1; /*  */
    unsigned short PDOUT4          : 1; /*  */
    unsigned short PDOUT5          : 1; /*  */
    unsigned short PDOUT6          : 1; /*  */
    unsigned short PDOUT7          : 1; /*  */
    unsigned short PDOUT8          : 1; /*  */
    unsigned short PDOUT9          : 1; /*  */
    unsigned short PDOUT10         : 1; /*  */
    unsigned short PDOUT11         : 1; /*  */
    unsigned short PDOUT12         : 1; /*  */
    unsigned short PDOUT13         : 1; /*  */
    unsigned short PDOUT14         : 1; /*  */
    unsigned short PDOUT15         : 1; /*  */
  } PDOUT_bit;

  struct
  {
    unsigned char PDOUT_L;
    unsigned char PDOUT_H;
  };
  struct
  {
    unsigned char P7OUT;   /* Port 7 Output  */
    unsigned char P8OUT;   /* Port 8 Output  */
  };
  struct
  {
    struct
    {
      unsigned char P7OUT0          : 1; /*  */
      unsigned char P7OUT1          : 1; /*  */
      unsigned char P7OUT2          : 1; /*  */
      unsigned char P7OUT3          : 1; /*  */
      unsigned char P7OUT4          : 1; /*  */
      unsigned char P7OUT5          : 1; /*  */
      unsigned char P7OUT6          : 1; /*  */
      unsigned char P7OUT7          : 1; /*  */
    } P7OUT_bit;

    struct
    {
      unsigned char P8OUT0          : 1; /*  */
      unsigned char P8OUT1          : 1; /*  */
      unsigned char P8OUT2          : 1; /*  */
      unsigned char P8OUT3          : 1; /*  */
      unsigned char P8OUT4          : 1; /*  */
      unsigned char P8OUT5          : 1; /*  */
      unsigned char P8OUT6          : 1; /*  */
      unsigned char P8OUT7          : 1; /*  */
    } P8OUT_bit;
  }; 
} @ 0x0262;

enum {
  PDOUT0          = 0x0001,
  PDOUT1          = 0x0002,
  PDOUT2          = 0x0004,
  PDOUT3          = 0x0008,
  PDOUT4          = 0x0010,
  PDOUT5          = 0x0020,
  PDOUT6          = 0x0040,
  PDOUT7          = 0x0080,
  PDOUT8          = 0x0100,
  PDOUT9          = 0x0200,
  PDOUT10         = 0x0400,
  PDOUT11         = 0x0800,
  PDOUT12         = 0x1000,
  PDOUT13         = 0x2000,
  PDOUT14         = 0x4000,
  PDOUT15         = 0x8000
};

__no_init volatile union
{
  unsigned short PDDIR;   /* Port D Direction  */

  struct
  {
    unsigned short PDDIR0          : 1; /*  */
    unsigned short PDDIR1          : 1; /*  */
    unsigned short PDDIR2          : 1; /*  */
    unsigned short PDDIR3          : 1; /*  */
    unsigned short PDDIR4          : 1; /*  */
    unsigned short PDDIR5          : 1; /*  */
    unsigned short PDDIR6          : 1; /*  */
    unsigned short PDDIR7          : 1; /*  */
    unsigned short PDDIR8          : 1; /*  */
    unsigned short PDDIR9          : 1; /*  */
    unsigned short PDDIR10         : 1; /*  */
    unsigned short PDDIR11         : 1; /*  */
    unsigned short PDDIR12         : 1; /*  */
    unsigned short PDDIR13         : 1; /*  */
    unsigned short PDDIR14         : 1; /*  */
    unsigned short PDDIR15         : 1; /*  */
  } PDDIR_bit;

  struct
  {
    unsigned char PDDIR_L;
    unsigned char PDDIR_H;
  };
  struct
  {
    unsigned char P7DIR;   /* Port 7 Direction  */
    unsigned char P8DIR;   /* Port 8 Direction  */
  };
  struct
  {
    struct
    {
      unsigned char P7DIR0          : 1; /*  */
      unsigned char P7DIR1          : 1; /*  */
      unsigned char P7DIR2          : 1; /*  */
      unsigned char P7DIR3          : 1; /*  */
      unsigned char P7DIR4          : 1; /*  */
      unsigned char P7DIR5          : 1; /*  */
      unsigned char P7DIR6          : 1; /*  */
      unsigned char P7DIR7          : 1; /*  */
    } P7DIR_bit;

    struct
    {
      unsigned char P8DIR0          : 1; /*  */
      unsigned char P8DIR1          : 1; /*  */
      unsigned char P8DIR2          : 1; /*  */
      unsigned char P8DIR3          : 1; /*  */
      unsigned char P8DIR4          : 1; /*  */
      unsigned char P8DIR5          : 1; /*  */
      unsigned char P8DIR6          : 1; /*  */
      unsigned char P8DIR7          : 1; /*  */
    } P8DIR_bit;
  }; 
} @ 0x0264;

enum {
  PDDIR0          = 0x0001,
  PDDIR1          = 0x0002,
  PDDIR2          = 0x0004,
  PDDIR3          = 0x0008,
  PDDIR4          = 0x0010,
  PDDIR5          = 0x0020,
  PDDIR6          = 0x0040,
  PDDIR7          = 0x0080,
  PDDIR8          = 0x0100,
  PDDIR9          = 0x0200,
  PDDIR10         = 0x0400,
  PDDIR11         = 0x0800,
  PDDIR12         = 0x1000,
  PDDIR13         = 0x2000,
  PDDIR14         = 0x4000,
  PDDIR15         = 0x8000
};

__no_init volatile union
{
  unsigned short PDREN;   /* Port D Resistor Enable  */

  struct
  {
    unsigned short PDREN0          : 1; /*  */
    unsigned short PDREN1          : 1; /*  */
    unsigned short PDREN2          : 1; /*  */
    unsigned short PDREN3          : 1; /*  */
    unsigned short PDREN4          : 1; /*  */
    unsigned short PDREN5          : 1; /*  */
    unsigned short PDREN6          : 1; /*  */
    unsigned short PDREN7          : 1; /*  */
    unsigned short PDREN8          : 1; /*  */
    unsigned short PDREN9          : 1; /*  */
    unsigned short PDREN10         : 1; /*  */
    unsigned short PDREN11         : 1; /*  */
    unsigned short PDREN12         : 1; /*  */
    unsigned short PDREN13         : 1; /*  */
    unsigned short PDREN14         : 1; /*  */
    unsigned short PDREN15         : 1; /*  */
  } PDREN_bit;

  struct
  {
    unsigned char PDREN_L;
    unsigned char PDREN_H;
  };
  struct
  {
    unsigned char P7REN;   /* Port 7 Resistor Enable  */
    unsigned char P8REN;   /* Port 8 Resistor Enable  */
  };
  struct
  {
    struct
    {
      unsigned char P7REN0          : 1; /*  */
      unsigned char P7REN1          : 1; /*  */
      unsigned char P7REN2          : 1; /*  */
      unsigned char P7REN3          : 1; /*  */
      unsigned char P7REN4          : 1; /*  */
      unsigned char P7REN5          : 1; /*  */
      unsigned char P7REN6          : 1; /*  */
      unsigned char P7REN7          : 1; /*  */
    } P7REN_bit;

    struct
    {
      unsigned char P8REN0          : 1; /*  */
      unsigned char P8REN1          : 1; /*  */
      unsigned char P8REN2          : 1; /*  */
      unsigned char P8REN3          : 1; /*  */
      unsigned char P8REN4          : 1; /*  */
      unsigned char P8REN5          : 1; /*  */
      unsigned char P8REN6          : 1; /*  */
      unsigned char P8REN7          : 1; /*  */
    } P8REN_bit;
  }; 
} @ 0x0266;

enum {
  PDREN0          = 0x0001,
  PDREN1          = 0x0002,
  PDREN2          = 0x0004,
  PDREN3          = 0x0008,
  PDREN4          = 0x0010,
  PDREN5          = 0x0020,
  PDREN6          = 0x0040,
  PDREN7          = 0x0080,
  PDREN8          = 0x0100,
  PDREN9          = 0x0200,
  PDREN10         = 0x0400,
  PDREN11         = 0x0800,
  PDREN12         = 0x1000,
  PDREN13         = 0x2000,
  PDREN14         = 0x4000,
  PDREN15         = 0x8000
};

__no_init volatile union
{
  unsigned short PDDS;   /* Port D Drive Strenght  */

  struct
  {
    unsigned short PDDS0           : 1; /*  */
    unsigned short PDDS1           : 1; /*  */
    unsigned short PDDS2           : 1; /*  */
    unsigned short PDDS3           : 1; /*  */
    unsigned short PDDS4           : 1; /*  */
    unsigned short PDDS5           : 1; /*  */
    unsigned short PDDS6           : 1; /*  */
    unsigned short PDDS7           : 1; /*  */
    unsigned short PDDS8           : 1; /*  */
    unsigned short PDDS9           : 1; /*  */
    unsigned short PDDS10          : 1; /*  */
    unsigned short PDDS11          : 1; /*  */
    unsigned short PDDS12          : 1; /*  */
    unsigned short PDDS13          : 1; /*  */
    unsigned short PDDS14          : 1; /*  */
    unsigned short PDDS15          : 1; /*  */
  } PDDS_bit;

  struct
  {
    unsigned char PDDS_L;
    unsigned char PDDS_H;
  };
  struct
  {
    unsigned char P7DS;   /* Port 7 Drive Strenght  */
    unsigned char P8DS;   /* Port 8 Drive Strenght  */
  };
  struct
  {
    struct
    {
      unsigned char P7DS0           : 1; /*  */
      unsigned char P7DS1           : 1; /*  */
      unsigned char P7DS2           : 1; /*  */
      unsigned char P7DS3           : 1; /*  */
      unsigned char P7DS4           : 1; /*  */
      unsigned char P7DS5           : 1; /*  */
      unsigned char P7DS6           : 1; /*  */
      unsigned char P7DS7           : 1; /*  */
    } P7DS_bit;

    struct
    {
      unsigned char P8DS0           : 1; /*  */
      unsigned char P8DS1           : 1; /*  */
      unsigned char P8DS2           : 1; /*  */
      unsigned char P8DS3           : 1; /*  */
      unsigned char P8DS4           : 1; /*  */
      unsigned char P8DS5           : 1; /*  */
      unsigned char P8DS6           : 1; /*  */
      unsigned char P8DS7           : 1; /*  */
    } P8DS_bit;
  }; 
} @ 0x0268;

enum {
  PDDS0           = 0x0001,
  PDDS1           = 0x0002,
  PDDS2           = 0x0004,
  PDDS3           = 0x0008,
  PDDS4           = 0x0010,
  PDDS5           = 0x0020,
  PDDS6           = 0x0040,
  PDDS7           = 0x0080,
  PDDS8           = 0x0100,
  PDDS9           = 0x0200,
  PDDS10          = 0x0400,
  PDDS11          = 0x0800,
  PDDS12          = 0x1000,
  PDDS13          = 0x2000,
  PDDS14          = 0x4000,
  PDDS15          = 0x8000
};

__no_init volatile union
{
  unsigned short PDSEL;   /* Port D Selection  */

  struct
  {
    unsigned short PDSEL0          : 1; /*  */
    unsigned short PDSEL1          : 1; /*  */
    unsigned short PDSEL2          : 1; /*  */
    unsigned short PDSEL3          : 1; /*  */
    unsigned short PDSEL4          : 1; /*  */
    unsigned short PDSEL5          : 1; /*  */
    unsigned short PDSEL6          : 1; /*  */
    unsigned short PDSEL7          : 1; /*  */
    unsigned short PDSEL8          : 1; /*  */
    unsigned short PDSEL9          : 1; /*  */
    unsigned short PDSEL10         : 1; /*  */
    unsigned short PDSEL11         : 1; /*  */
    unsigned short PDSEL12         : 1; /*  */
    unsigned short PDSEL13         : 1; /*  */
    unsigned short PDSEL14         : 1; /*  */
    unsigned short PDSEL15         : 1; /*  */
  } PDSEL_bit;

  struct
  {
    unsigned char PDSEL_L;
    unsigned char PDSEL_H;
  };
  struct
  {
    unsigned char P7SEL;   /* Port 7 Selection  */
    unsigned char P8SEL;   /* Port 8 Selection  */
  };
  struct
  {
    struct
    {
      unsigned char P7SEL0          : 1; /*  */
      unsigned char P7SEL1          : 1; /*  */
      unsigned char P7SEL2          : 1; /*  */
      unsigned char P7SEL3          : 1; /*  */
      unsigned char P7SEL4          : 1; /*  */
      unsigned char P7SEL5          : 1; /*  */
      unsigned char P7SEL6          : 1; /*  */
      unsigned char P7SEL7          : 1; /*  */
    } P7SEL_bit;

    struct
    {
      unsigned char P8SEL0          : 1; /*  */
      unsigned char P8SEL1          : 1; /*  */
      unsigned char P8SEL2          : 1; /*  */
      unsigned char P8SEL3          : 1; /*  */
      unsigned char P8SEL4          : 1; /*  */
      unsigned char P8SEL5          : 1; /*  */
      unsigned char P8SEL6          : 1; /*  */
      unsigned char P8SEL7          : 1; /*  */
    } P8SEL_bit;
  }; 
} @ 0x026A;

enum {
  PDSEL0          = 0x0001,
  PDSEL1          = 0x0002,
  PDSEL2          = 0x0004,
  PDSEL3          = 0x0008,
  PDSEL4          = 0x0010,
  PDSEL5          = 0x0020,
  PDSEL6          = 0x0040,
  PDSEL7          = 0x0080,
  PDSEL8          = 0x0100,
  PDSEL9          = 0x0200,
  PDSEL10         = 0x0400,
  PDSEL11         = 0x0800,
  PDSEL12         = 0x1000,
  PDSEL13         = 0x2000,
  PDSEL14         = 0x4000,
  PDSEL15         = 0x8000
};



#define __MSP430_HAS_PORT7_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_PORT8_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_PORTD_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_P7SEL__          /* Define for DriverLib */
#define __MSP430_HAS_P8SEL__          /* Define for DriverLib */
#define __MSP430_HAS_PDSEL__          /* Define for DriverLib */
#define __MSP430_BASEADDRESS_PORT7_R__ 0x0260
#define P7_BASE __MSP430_BASEADDRESS_PORT7_R__
#define __MSP430_BASEADDRESS_PORT8_R__ 0x0260
#define P8_BASE __MSP430_BASEADDRESS_PORT8_R__
#define __MSP430_BASEADDRESS_PORTD_R__ 0x0260
#define PD_BASE __MSP430_BASEADDRESS_PORTD_R__

/*-------------------------------------------------------------------------
 *   Port 7/8
 *-------------------------------------------------------------------------*/


enum {
  P7IN0           = 0x0001,
  P7IN1           = 0x0002,
  P7IN2           = 0x0004,
  P7IN3           = 0x0008,
  P7IN4           = 0x0010,
  P7IN5           = 0x0020,
  P7IN6           = 0x0040,
  P7IN7           = 0x0080
};

enum {
  P7OUT0          = 0x0001,
  P7OUT1          = 0x0002,
  P7OUT2          = 0x0004,
  P7OUT3          = 0x0008,
  P7OUT4          = 0x0010,
  P7OUT5          = 0x0020,
  P7OUT6          = 0x0040,
  P7OUT7          = 0x0080
};

enum {
  P7DIR0          = 0x0001,
  P7DIR1          = 0x0002,
  P7DIR2          = 0x0004,
  P7DIR3          = 0x0008,
  P7DIR4          = 0x0010,
  P7DIR5          = 0x0020,
  P7DIR6          = 0x0040,
  P7DIR7          = 0x0080
};

enum {
  P7REN0          = 0x0001,
  P7REN1          = 0x0002,
  P7REN2          = 0x0004,
  P7REN3          = 0x0008,
  P7REN4          = 0x0010,
  P7REN5          = 0x0020,
  P7REN6          = 0x0040,
  P7REN7          = 0x0080
};

enum {
  P7DS0           = 0x0001,
  P7DS1           = 0x0002,
  P7DS2           = 0x0004,
  P7DS3           = 0x0008,
  P7DS4           = 0x0010,
  P7DS5           = 0x0020,
  P7DS6           = 0x0040,
  P7DS7           = 0x0080
};

enum {
  P7SEL0          = 0x0001,
  P7SEL1          = 0x0002,
  P7SEL2          = 0x0004,
  P7SEL3          = 0x0008,
  P7SEL4          = 0x0010,
  P7SEL5          = 0x0020,
  P7SEL6          = 0x0040,
  P7SEL7          = 0x0080
};

enum {
  P8IN0           = 0x0001,
  P8IN1           = 0x0002,
  P8IN2           = 0x0004,
  P8IN3           = 0x0008,
  P8IN4           = 0x0010,
  P8IN5           = 0x0020,
  P8IN6           = 0x0040,
  P8IN7           = 0x0080
};

enum {
  P8OUT0          = 0x0001,
  P8OUT1          = 0x0002,
  P8OUT2          = 0x0004,
  P8OUT3          = 0x0008,
  P8OUT4          = 0x0010,
  P8OUT5          = 0x0020,
  P8OUT6          = 0x0040,
  P8OUT7          = 0x0080
};

enum {
  P8DIR0          = 0x0001,
  P8DIR1          = 0x0002,
  P8DIR2          = 0x0004,
  P8DIR3          = 0x0008,
  P8DIR4          = 0x0010,
  P8DIR5          = 0x0020,
  P8DIR6          = 0x0040,
  P8DIR7          = 0x0080
};

enum {
  P8REN0          = 0x0001,
  P8REN1          = 0x0002,
  P8REN2          = 0x0004,
  P8REN3          = 0x0008,
  P8REN4          = 0x0010,
  P8REN5          = 0x0020,
  P8REN6          = 0x0040,
  P8REN7          = 0x0080
};

enum {
  P8DS0           = 0x0001,
  P8DS1           = 0x0002,
  P8DS2           = 0x0004,
  P8DS3           = 0x0008,
  P8DS4           = 0x0010,
  P8DS5           = 0x0020,
  P8DS6           = 0x0040,
  P8DS7           = 0x0080
};

enum {
  P8SEL0          = 0x0001,
  P8SEL1          = 0x0002,
  P8SEL2          = 0x0004,
  P8SEL3          = 0x0008,
  P8SEL4          = 0x0010,
  P8SEL5          = 0x0020,
  P8SEL6          = 0x0040,
  P8SEL7          = 0x0080
};



/*-------------------------------------------------------------------------
 *   Port E
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned __READ short PEIN;   /* Port E Input  */

  struct
  {
    unsigned __READ short PEIN0           : 1; /*  */
    unsigned __READ short PEIN1           : 1; /*  */
    unsigned __READ short PEIN2           : 1; /*  */
    unsigned __READ short PEIN3           : 1; /*  */
    unsigned __READ short PEIN4           : 1; /*  */
    unsigned __READ short PEIN5           : 1; /*  */
    unsigned __READ short PEIN6           : 1; /*  */
    unsigned __READ short PEIN7           : 1; /*  */
    unsigned __READ short PEIN8           : 1; /*  */
    unsigned __READ short PEIN9           : 1; /*  */
    unsigned __READ short PEIN10          : 1; /*  */
    unsigned __READ short PEIN11          : 1; /*  */
    unsigned __READ short PEIN12          : 1; /*  */
    unsigned __READ short PEIN13          : 1; /*  */
    unsigned __READ short PEIN14          : 1; /*  */
    unsigned __READ short PEIN15          : 1; /*  */
  } PEIN_bit;

  struct
  {
    unsigned __READ char PEIN_L;
    unsigned __READ char PEIN_H;
  };
  struct
  {
    unsigned char P9IN;   /* Port 9 Input  */
  };
  struct
  {
    struct
    {
      unsigned char P9IN0           : 1; /*  */
      unsigned char P9IN1           : 1; /*  */
      unsigned char P9IN2           : 1; /*  */
      unsigned char P9IN3           : 1; /*  */
      unsigned char P9IN4           : 1; /*  */
      unsigned char P9IN5           : 1; /*  */
      unsigned char P9IN6           : 1; /*  */
      unsigned char P9IN7           : 1; /*  */
    } P9IN_bit;

  }; 
} @ 0x0280;

enum {
  PEIN0           = 0x0001,
  PEIN1           = 0x0002,
  PEIN2           = 0x0004,
  PEIN3           = 0x0008,
  PEIN4           = 0x0010,
  PEIN5           = 0x0020,
  PEIN6           = 0x0040,
  PEIN7           = 0x0080,
  PEIN8           = 0x0100,
  PEIN9           = 0x0200,
  PEIN10          = 0x0400,
  PEIN11          = 0x0800,
  PEIN12          = 0x1000,
  PEIN13          = 0x2000,
  PEIN14          = 0x4000,
  PEIN15          = 0x8000
};

__no_init volatile union
{
  unsigned short PEOUT;   /* Port E Output  */

  struct
  {
    unsigned short PEOUT0          : 1; /*  */
    unsigned short PEOUT1          : 1; /*  */
    unsigned short PEOUT2          : 1; /*  */
    unsigned short PEOUT3          : 1; /*  */
    unsigned short PEOUT4          : 1; /*  */
    unsigned short PEOUT5          : 1; /*  */
    unsigned short PEOUT6          : 1; /*  */
    unsigned short PEOUT7          : 1; /*  */
    unsigned short PEOUT8          : 1; /*  */
    unsigned short PEOUT9          : 1; /*  */
    unsigned short PEOUT10         : 1; /*  */
    unsigned short PEOUT11         : 1; /*  */
    unsigned short PEOUT12         : 1; /*  */
    unsigned short PEOUT13         : 1; /*  */
    unsigned short PEOUT14         : 1; /*  */
    unsigned short PEOUT15         : 1; /*  */
  } PEOUT_bit;

  struct
  {
    unsigned char PEOUT_L;
    unsigned char PEOUT_H;
  };
  struct
  {
    unsigned char P9OUT;   /* Port 9 Output  */
  };
  struct
  {
    struct
    {
      unsigned char P9OUT0          : 1; /*  */
      unsigned char P9OUT1          : 1; /*  */
      unsigned char P9OUT2          : 1; /*  */
      unsigned char P9OUT3          : 1; /*  */
      unsigned char P9OUT4          : 1; /*  */
      unsigned char P9OUT5          : 1; /*  */
      unsigned char P9OUT6          : 1; /*  */
      unsigned char P9OUT7          : 1; /*  */
    } P9OUT_bit;

  }; 
} @ 0x0282;

enum {
  PEOUT0          = 0x0001,
  PEOUT1          = 0x0002,
  PEOUT2          = 0x0004,
  PEOUT3          = 0x0008,
  PEOUT4          = 0x0010,
  PEOUT5          = 0x0020,
  PEOUT6          = 0x0040,
  PEOUT7          = 0x0080,
  PEOUT8          = 0x0100,
  PEOUT9          = 0x0200,
  PEOUT10         = 0x0400,
  PEOUT11         = 0x0800,
  PEOUT12         = 0x1000,
  PEOUT13         = 0x2000,
  PEOUT14         = 0x4000,
  PEOUT15         = 0x8000
};

__no_init volatile union
{
  unsigned short PEDIR;   /* Port E Direction  */

  struct
  {
    unsigned short PEDIR0          : 1; /*  */
    unsigned short PEDIR1          : 1; /*  */
    unsigned short PEDIR2          : 1; /*  */
    unsigned short PEDIR3          : 1; /*  */
    unsigned short PEDIR4          : 1; /*  */
    unsigned short PEDIR5          : 1; /*  */
    unsigned short PEDIR6          : 1; /*  */
    unsigned short PEDIR7          : 1; /*  */
    unsigned short PEDIR8          : 1; /*  */
    unsigned short PEDIR9          : 1; /*  */
    unsigned short PEDIR10         : 1; /*  */
    unsigned short PEDIR11         : 1; /*  */
    unsigned short PEDIR12         : 1; /*  */
    unsigned short PEDIR13         : 1; /*  */
    unsigned short PEDIR14         : 1; /*  */
    unsigned short PEDIR15         : 1; /*  */
  } PEDIR_bit;

  struct
  {
    unsigned char PEDIR_L;
    unsigned char PEDIR_H;
  };
  struct
  {
    unsigned char P9DIR;   /* Port 9 Direction  */
  };
  struct
  {
    struct
    {
      unsigned char P9DIR0          : 1; /*  */
      unsigned char P9DIR1          : 1; /*  */
      unsigned char P9DIR2          : 1; /*  */
      unsigned char P9DIR3          : 1; /*  */
      unsigned char P9DIR4          : 1; /*  */
      unsigned char P9DIR5          : 1; /*  */
      unsigned char P9DIR6          : 1; /*  */
      unsigned char P9DIR7          : 1; /*  */
    } P9DIR_bit;

  }; 
} @ 0x0284;

enum {
  PEDIR0          = 0x0001,
  PEDIR1          = 0x0002,
  PEDIR2          = 0x0004,
  PEDIR3          = 0x0008,
  PEDIR4          = 0x0010,
  PEDIR5          = 0x0020,
  PEDIR6          = 0x0040,
  PEDIR7          = 0x0080,
  PEDIR8          = 0x0100,
  PEDIR9          = 0x0200,
  PEDIR10         = 0x0400,
  PEDIR11         = 0x0800,
  PEDIR12         = 0x1000,
  PEDIR13         = 0x2000,
  PEDIR14         = 0x4000,
  PEDIR15         = 0x8000
};

__no_init volatile union
{
  unsigned short PEREN;   /* Port E Resistor Enable  */

  struct
  {
    unsigned short PEREN0          : 1; /*  */
    unsigned short PEREN1          : 1; /*  */
    unsigned short PEREN2          : 1; /*  */
    unsigned short PEREN3          : 1; /*  */
    unsigned short PEREN4          : 1; /*  */
    unsigned short PEREN5          : 1; /*  */
    unsigned short PEREN6          : 1; /*  */
    unsigned short PEREN7          : 1; /*  */
    unsigned short PEREN8          : 1; /*  */
    unsigned short PEREN9          : 1; /*  */
    unsigned short PEREN10         : 1; /*  */
    unsigned short PEREN11         : 1; /*  */
    unsigned short PEREN12         : 1; /*  */
    unsigned short PEREN13         : 1; /*  */
    unsigned short PEREN14         : 1; /*  */
    unsigned short PEREN15         : 1; /*  */
  } PEREN_bit;

  struct
  {
    unsigned char PEREN_L;
    unsigned char PEREN_H;
  };
  struct
  {
    unsigned char P9REN;   /* Port 9 Resistor Enable  */
  };
  struct
  {
    struct
    {
      unsigned char P9REN0          : 1; /*  */
      unsigned char P9REN1          : 1; /*  */
      unsigned char P9REN2          : 1; /*  */
      unsigned char P9REN3          : 1; /*  */
      unsigned char P9REN4          : 1; /*  */
      unsigned char P9REN5          : 1; /*  */
      unsigned char P9REN6          : 1; /*  */
      unsigned char P9REN7          : 1; /*  */
    } P9REN_bit;

  }; 
} @ 0x0286;

enum {
  PEREN0          = 0x0001,
  PEREN1          = 0x0002,
  PEREN2          = 0x0004,
  PEREN3          = 0x0008,
  PEREN4          = 0x0010,
  PEREN5          = 0x0020,
  PEREN6          = 0x0040,
  PEREN7          = 0x0080,
  PEREN8          = 0x0100,
  PEREN9          = 0x0200,
  PEREN10         = 0x0400,
  PEREN11         = 0x0800,
  PEREN12         = 0x1000,
  PEREN13         = 0x2000,
  PEREN14         = 0x4000,
  PEREN15         = 0x8000
};

__no_init volatile union
{
  unsigned short PEDS;   /* Port E Drive Strenght  */

  struct
  {
    unsigned short PEDS0           : 1; /*  */
    unsigned short PEDS1           : 1; /*  */
    unsigned short PEDS2           : 1; /*  */
    unsigned short PEDS3           : 1; /*  */
    unsigned short PEDS4           : 1; /*  */
    unsigned short PEDS5           : 1; /*  */
    unsigned short PEDS6           : 1; /*  */
    unsigned short PEDS7           : 1; /*  */
    unsigned short PEDS8           : 1; /*  */
    unsigned short PEDS9           : 1; /*  */
    unsigned short PEDS10          : 1; /*  */
    unsigned short PEDS11          : 1; /*  */
    unsigned short PEDS12          : 1; /*  */
    unsigned short PEDS13          : 1; /*  */
    unsigned short PEDS14          : 1; /*  */
    unsigned short PEDS15          : 1; /*  */
  } PEDS_bit;

  struct
  {
    unsigned char PEDS_L;
    unsigned char PEDS_H;
  };
  struct
  {
    unsigned char P9DS;   /* Port 9 Drive Strenght  */
  };
  struct
  {
    struct
    {
      unsigned char P9DS0           : 1; /*  */
      unsigned char P9DS1           : 1; /*  */
      unsigned char P9DS2           : 1; /*  */
      unsigned char P9DS3           : 1; /*  */
      unsigned char P9DS4           : 1; /*  */
      unsigned char P9DS5           : 1; /*  */
      unsigned char P9DS6           : 1; /*  */
      unsigned char P9DS7           : 1; /*  */
    } P9DS_bit;

  }; 
} @ 0x0288;

enum {
  PEDS0           = 0x0001,
  PEDS1           = 0x0002,
  PEDS2           = 0x0004,
  PEDS3           = 0x0008,
  PEDS4           = 0x0010,
  PEDS5           = 0x0020,
  PEDS6           = 0x0040,
  PEDS7           = 0x0080,
  PEDS8           = 0x0100,
  PEDS9           = 0x0200,
  PEDS10          = 0x0400,
  PEDS11          = 0x0800,
  PEDS12          = 0x1000,
  PEDS13          = 0x2000,
  PEDS14          = 0x4000,
  PEDS15          = 0x8000
};

__no_init volatile union
{
  unsigned short PESEL;   /* Port E Selection  */

  struct
  {
    unsigned short PESEL0          : 1; /*  */
    unsigned short PESEL1          : 1; /*  */
    unsigned short PESEL2          : 1; /*  */
    unsigned short PESEL3          : 1; /*  */
    unsigned short PESEL4          : 1; /*  */
    unsigned short PESEL5          : 1; /*  */
    unsigned short PESEL6          : 1; /*  */
    unsigned short PESEL7          : 1; /*  */
    unsigned short PESEL8          : 1; /*  */
    unsigned short PESEL9          : 1; /*  */
    unsigned short PESEL10         : 1; /*  */
    unsigned short PESEL11         : 1; /*  */
    unsigned short PESEL12         : 1; /*  */
    unsigned short PESEL13         : 1; /*  */
    unsigned short PESEL14         : 1; /*  */
    unsigned short PESEL15         : 1; /*  */
  } PESEL_bit;

  struct
  {
    unsigned char PESEL_L;
    unsigned char PESEL_H;
  };
  struct
  {
    unsigned char P9SEL;   /* Port 9 Selection  */
  };
  struct
  {
    struct
    {
      unsigned char P9SEL0          : 1; /*  */
      unsigned char P9SEL1          : 1; /*  */
      unsigned char P9SEL2          : 1; /*  */
      unsigned char P9SEL3          : 1; /*  */
      unsigned char P9SEL4          : 1; /*  */
      unsigned char P9SEL5          : 1; /*  */
      unsigned char P9SEL6          : 1; /*  */
      unsigned char P9SEL7          : 1; /*  */
    } P9SEL_bit;

  }; 
} @ 0x028A;

enum {
  PESEL0          = 0x0001,
  PESEL1          = 0x0002,
  PESEL2          = 0x0004,
  PESEL3          = 0x0008,
  PESEL4          = 0x0010,
  PESEL5          = 0x0020,
  PESEL6          = 0x0040,
  PESEL7          = 0x0080,
  PESEL8          = 0x0100,
  PESEL9          = 0x0200,
  PESEL10         = 0x0400,
  PESEL11         = 0x0800,
  PESEL12         = 0x1000,
  PESEL13         = 0x2000,
  PESEL14         = 0x4000,
  PESEL15         = 0x8000
};



#define __MSP430_HAS_PORT9_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_PORTE_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_P9SEL__          /* Define for DriverLib */
#define __MSP430_HAS_PESEL__          /* Define for DriverLib */
#define __MSP430_BASEADDRESS_PORT9_R__ 0x0280
#define P9_BASE __MSP430_BASEADDRESS_PORT9_R__
#define __MSP430_BASEADDRESS_PORTE_R__ 0x0280
#define PE_BASE __MSP430_BASEADDRESS_PORTE_R__

/*-------------------------------------------------------------------------
 *   Port 9
 *-------------------------------------------------------------------------*/


enum {
  P9IN0           = 0x0001,
  P9IN1           = 0x0002,
  P9IN2           = 0x0004,
  P9IN3           = 0x0008,
  P9IN4           = 0x0010,
  P9IN5           = 0x0020,
  P9IN6           = 0x0040,
  P9IN7           = 0x0080
};

enum {
  P9OUT0          = 0x0001,
  P9OUT1          = 0x0002,
  P9OUT2          = 0x0004,
  P9OUT3          = 0x0008,
  P9OUT4          = 0x0010,
  P9OUT5          = 0x0020,
  P9OUT6          = 0x0040,
  P9OUT7          = 0x0080
};

enum {
  P9DIR0          = 0x0001,
  P9DIR1          = 0x0002,
  P9DIR2          = 0x0004,
  P9DIR3          = 0x0008,
  P9DIR4          = 0x0010,
  P9DIR5          = 0x0020,
  P9DIR6          = 0x0040,
  P9DIR7          = 0x0080
};

enum {
  P9REN0          = 0x0001,
  P9REN1          = 0x0002,
  P9REN2          = 0x0004,
  P9REN3          = 0x0008,
  P9REN4          = 0x0010,
  P9REN5          = 0x0020,
  P9REN6          = 0x0040,
  P9REN7          = 0x0080
};

enum {
  P9DS0           = 0x0001,
  P9DS1           = 0x0002,
  P9DS2           = 0x0004,
  P9DS3           = 0x0008,
  P9DS4           = 0x0010,
  P9DS5           = 0x0020,
  P9DS6           = 0x0040,
  P9DS7           = 0x0080
};

enum {
  P9SEL0          = 0x0001,
  P9SEL1          = 0x0002,
  P9SEL2          = 0x0004,
  P9SEL3          = 0x0008,
  P9SEL4          = 0x0010,
  P9SEL5          = 0x0020,
  P9SEL6          = 0x0040,
  P9SEL7          = 0x0080
};



/*-------------------------------------------------------------------------
 *   Port J
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned __READ short PJIN;   /* Port J Input  */

  struct
  {
    unsigned __READ short PJIN0           : 1; /*  */
    unsigned __READ short PJIN1           : 1; /*  */
    unsigned __READ short PJIN2           : 1; /*  */
    unsigned __READ short PJIN3           : 1; /*  */
  } PJIN_bit;

  struct
  {
    unsigned __READ char PJIN_L;
    unsigned __READ char PJIN_H;
  };
} @ 0x0320;

enum {
  PJIN0           = 0x0001,
  PJIN1           = 0x0002,
  PJIN2           = 0x0004,
  PJIN3           = 0x0008
};

__no_init volatile union
{
  unsigned short PJOUT;   /* Port J Output  */

  struct
  {
    unsigned short PJOUT0          : 1; /*  */
    unsigned short PJOUT1          : 1; /*  */
    unsigned short PJOUT2          : 1; /*  */
    unsigned short PJOUT3          : 1; /*  */
  } PJOUT_bit;

  struct
  {
    unsigned char PJOUT_L;
    unsigned char PJOUT_H;
  };
} @ 0x0322;

enum {
  PJOUT0          = 0x0001,
  PJOUT1          = 0x0002,
  PJOUT2          = 0x0004,
  PJOUT3          = 0x0008
};

__no_init volatile union
{
  unsigned short PJDIR;   /* Port J Direction  */

  struct
  {
    unsigned short PJDIR0          : 1; /*  */
    unsigned short PJDIR1          : 1; /*  */
    unsigned short PJDIR2          : 1; /*  */
    unsigned short PJDIR3          : 1; /*  */
  } PJDIR_bit;

  struct
  {
    unsigned char PJDIR_L;
    unsigned char PJDIR_H;
  };
} @ 0x0324;

enum {
  PJDIR0          = 0x0001,
  PJDIR1          = 0x0002,
  PJDIR2          = 0x0004,
  PJDIR3          = 0x0008
};

__no_init volatile union
{
  unsigned short PJREN;   /* Port J Resistor Enable  */

  struct
  {
    unsigned short PJREN0          : 1; /*  */
    unsigned short PJREN1          : 1; /*  */
    unsigned short PJREN2          : 1; /*  */
    unsigned short PJREN3          : 1; /*  */
  } PJREN_bit;

  struct
  {
    unsigned char PJREN_L;
    unsigned char PJREN_H;
  };
} @ 0x0326;

enum {
  PJREN0          = 0x0001,
  PJREN1          = 0x0002,
  PJREN2          = 0x0004,
  PJREN3          = 0x0008
};

__no_init volatile union
{
  unsigned short PJDS;   /* Port J Drive Strenght  */

  struct
  {
    unsigned short PJDS0           : 1; /*  */
    unsigned short PJDS1           : 1; /*  */
    unsigned short PJDS2           : 1; /*  */
    unsigned short PJDS3           : 1; /*  */
  } PJDS_bit;

  struct
  {
    unsigned char PJDS_L;
    unsigned char PJDS_H;
  };
} @ 0x0328;

enum {
  PJDS0           = 0x0001,
  PJDS1           = 0x0002,
  PJDS2           = 0x0004,
  PJDS3           = 0x0008
};

__no_init volatile union
{
  unsigned short PJSEL;   /* Port J Selection  */

  struct
  {
    unsigned short PJSEL0          : 1; /*  */
    unsigned short PJSEL1          : 1; /*  */
    unsigned short PJSEL2          : 1; /*  */
    unsigned short PJSEL3          : 1; /*  */
  } PJSEL_bit;

  struct
  {
    unsigned char PJSEL_L;
    unsigned char PJSEL_H;
  };
} @ 0x032A;

enum {
  PJSEL0          = 0x0001,
  PJSEL1          = 0x0002,
  PJSEL2          = 0x0004,
  PJSEL3          = 0x0008
};



#define __MSP430_HAS_PORTJ_R__        /* Definition to show that Module is available */
#define __MSP430_HAS_PJSEL__           /* Define for DriverLib */
#define __MSP430_BASEADDRESS_PORTJ_R__ 0x0320
#define PJ_BASE __MSP430_BASEADDRESS_PORTJ_R__

/*-------------------------------------------------------------------------
 *   Port Mapping Control
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short PMAPKEYID;   /* Port Mapping Key register  */
  struct
  {
    unsigned char PMAPKEYID_L;
    unsigned char PMAPKEYID_H;
  };
} @ 0x01C0;

__no_init volatile union
{
  unsigned short PMAPCTL;   /* Port Mapping control register  */

  struct
  {
    unsigned short PMAPLOCKED      : 1; /* Port Mapping Lock bit. Read only  */
    unsigned short PMAPRECFG       : 1; /* Port Mapping re-configuration control bit  */
  } PMAPCTL_bit;

  struct
  {
    unsigned char PMAPCTL_L;
    unsigned char PMAPCTL_H;
  };
} @ 0x01C2;

enum {
  PMAPLOCKED      = 0x0001,
  PMAPRECFG       = 0x0002
};



#define __MSP430_HAS_PORT_MAPPING__   /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_PORT_MAPPING__ 0x01C0
#define PMAP_CTRL_BASE __MSP430_BASEADDRESS_PORT_MAPPING__

#define  PMAPKEY             (0x2D52u)  /* Port Mapping Key */
#define  PMAPPWD             PMAPKEYID /* Legacy Definition: Mapping Key register */
#define  PMAPPW              (0x2D52u)  /* Legacy Definition: Port Mapping Password */
/* PMAPCTL Control Bits */
#define PMAPLOCKED_L        (0x0001u)  /* Port Mapping Lock bit. Read only */
#define PMAPRECFG_L         (0x0002u)  /* Port Mapping re-configuration control bit */

/*-------------------------------------------------------------------------
 *   Port Mapping Port 1
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short P1MAP01;   /* Port P1.0/1 mapping register  */

  struct
  {
    unsigned short PMAP01_0        : 1; /*  */
    unsigned short PMAP01_1        : 1; /*  */
    unsigned short PMAP01_2        : 1; /*  */
    unsigned short PMAP01_3        : 1; /*  */
    unsigned short PMAP01_4        : 1; /*  */
    unsigned short PMAP01_5        : 1; /*  */
    unsigned short PMAP01_6        : 1; /*  */
    unsigned short PMAP01_7        : 1; /*  */
    unsigned short PMAP01_8        : 1; /*  */
    unsigned short PMAP01_9        : 1; /*  */
    unsigned short PMAP01_10       : 1; /*  */
    unsigned short PMAP01_11       : 1; /*  */
    unsigned short PMAP01_12       : 1; /*  */
    unsigned short PMAP01_13       : 1; /*  */
    unsigned short PMAP01_14       : 1; /*  */
    unsigned short PMAP01_15       : 1; /*  */
  } P1MAP01_bit;

  struct
  {
    unsigned char P1MAP01_L;
    unsigned char P1MAP01_H;
  };
  struct
  {
    unsigned char P1MAP0;   /* Port P1.0 mapping register  */
    unsigned char P1MAP1;   /* Port P1.1 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P1MAP0_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P1MAP1_bit;
  }; 
} @ 0x01C8;

enum {
  PMAP01_0        = 0x0001,
  PMAP01_1        = 0x0002,
  PMAP01_2        = 0x0004,
  PMAP01_3        = 0x0008,
  PMAP01_4        = 0x0010,
  PMAP01_5        = 0x0020,
  PMAP01_6        = 0x0040,
  PMAP01_7        = 0x0080,
  PMAP01_8        = 0x0100,
  PMAP01_9        = 0x0200,
  PMAP01_10       = 0x0400,
  PMAP01_11       = 0x0800,
  PMAP01_12       = 0x1000,
  PMAP01_13       = 0x2000,
  PMAP01_14       = 0x4000,
  PMAP01_15       = 0x8000
};

__no_init volatile union
{
  unsigned short P1MAP23;   /* Port P1.2/3 mapping register  */

  struct
  {
    unsigned short PMAP23_0        : 1; /*  */
    unsigned short PMAP23_1        : 1; /*  */
    unsigned short PMAP23_2        : 1; /*  */
    unsigned short PMAP23_3        : 1; /*  */
    unsigned short PMAP23_4        : 1; /*  */
    unsigned short PMAP23_5        : 1; /*  */
    unsigned short PMAP23_6        : 1; /*  */
    unsigned short PMAP23_7        : 1; /*  */
    unsigned short PMAP23_8        : 1; /*  */
    unsigned short PMAP23_9        : 1; /*  */
    unsigned short PMAP23_10       : 1; /*  */
    unsigned short PMAP23_11       : 1; /*  */
    unsigned short PMAP23_12       : 1; /*  */
    unsigned short PMAP23_13       : 1; /*  */
    unsigned short PMAP23_14       : 1; /*  */
    unsigned short PMAP23_15       : 1; /*  */
  } P1MAP23_bit;

  struct
  {
    unsigned char P1MAP23_L;
    unsigned char P1MAP23_H;
  };
  struct
  {
    unsigned char P1MAP2;   /* Port P1.2 mapping register  */
    unsigned char P1MAP3;   /* Port P1.3 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P1MAP2_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P1MAP3_bit;
  }; 
} @ 0x01CA;

enum {
  PMAP23_0        = 0x0001,
  PMAP23_1        = 0x0002,
  PMAP23_2        = 0x0004,
  PMAP23_3        = 0x0008,
  PMAP23_4        = 0x0010,
  PMAP23_5        = 0x0020,
  PMAP23_6        = 0x0040,
  PMAP23_7        = 0x0080,
  PMAP23_8        = 0x0100,
  PMAP23_9        = 0x0200,
  PMAP23_10       = 0x0400,
  PMAP23_11       = 0x0800,
  PMAP23_12       = 0x1000,
  PMAP23_13       = 0x2000,
  PMAP23_14       = 0x4000,
  PMAP23_15       = 0x8000
};

__no_init volatile union
{
  unsigned short P1MAP45;   /* Port P1.4/5 mapping register  */

  struct
  {
    unsigned short PMAP45_0        : 1; /*  */
    unsigned short PMAP45_1        : 1; /*  */
    unsigned short PMAP45_2        : 1; /*  */
    unsigned short PMAP45_3        : 1; /*  */
    unsigned short PMAP45_4        : 1; /*  */
    unsigned short PMAP45_5        : 1; /*  */
    unsigned short PMAP45_6        : 1; /*  */
    unsigned short PMAP45_7        : 1; /*  */
    unsigned short PMAP45_8        : 1; /*  */
    unsigned short PMAP45_9        : 1; /*  */
    unsigned short PMAP45_10       : 1; /*  */
    unsigned short PMAP45_11       : 1; /*  */
    unsigned short PMAP45_12       : 1; /*  */
    unsigned short PMAP45_13       : 1; /*  */
    unsigned short PMAP45_14       : 1; /*  */
    unsigned short PMAP45_15       : 1; /*  */
  } P1MAP45_bit;

  struct
  {
    unsigned char P1MAP45_L;
    unsigned char P1MAP45_H;
  };
  struct
  {
    unsigned char P1MAP4;   /* Port P1.4 mapping register  */
    unsigned char P1MAP5;   /* Port P1.5 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P1MAP4_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P1MAP5_bit;
  }; 
} @ 0x01CC;

enum {
  PMAP45_0        = 0x0001,
  PMAP45_1        = 0x0002,
  PMAP45_2        = 0x0004,
  PMAP45_3        = 0x0008,
  PMAP45_4        = 0x0010,
  PMAP45_5        = 0x0020,
  PMAP45_6        = 0x0040,
  PMAP45_7        = 0x0080,
  PMAP45_8        = 0x0100,
  PMAP45_9        = 0x0200,
  PMAP45_10       = 0x0400,
  PMAP45_11       = 0x0800,
  PMAP45_12       = 0x1000,
  PMAP45_13       = 0x2000,
  PMAP45_14       = 0x4000,
  PMAP45_15       = 0x8000
};

__no_init volatile union
{
  unsigned short P1MAP67;   /* Port P1.6/7 mapping register  */

  struct
  {
    unsigned short PMAP67_0        : 1; /*  */
    unsigned short PMAP67_1        : 1; /*  */
    unsigned short PMAP67_2        : 1; /*  */
    unsigned short PMAP67_3        : 1; /*  */
    unsigned short PMAP67_4        : 1; /*  */
    unsigned short PMAP67_5        : 1; /*  */
    unsigned short PMAP67_6        : 1; /*  */
    unsigned short PMAP67_7        : 1; /*  */
    unsigned short PMAP67_8        : 1; /*  */
    unsigned short PMAP67_9        : 1; /*  */
    unsigned short PMAP67_10       : 1; /*  */
    unsigned short PMAP67_11       : 1; /*  */
    unsigned short PMAP67_12       : 1; /*  */
    unsigned short PMAP67_13       : 1; /*  */
    unsigned short PMAP67_14       : 1; /*  */
    unsigned short PMAP67_15       : 1; /*  */
  } P1MAP67_bit;

  struct
  {
    unsigned char P1MAP67_L;
    unsigned char P1MAP67_H;
  };
  struct
  {
    unsigned char P1MAP6;   /* Port P1.6 mapping register  */
    unsigned char P1MAP7;   /* Port P1.7 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P1MAP6_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P1MAP7_bit;
  }; 
} @ 0x01CE;

enum {
  PMAP67_0        = 0x0001,
  PMAP67_1        = 0x0002,
  PMAP67_2        = 0x0004,
  PMAP67_3        = 0x0008,
  PMAP67_4        = 0x0010,
  PMAP67_5        = 0x0020,
  PMAP67_6        = 0x0040,
  PMAP67_7        = 0x0080,
  PMAP67_8        = 0x0100,
  PMAP67_9        = 0x0200,
  PMAP67_10       = 0x0400,
  PMAP67_11       = 0x0800,
  PMAP67_12       = 0x1000,
  PMAP67_13       = 0x2000,
  PMAP67_14       = 0x4000,
  PMAP67_15       = 0x8000
};

enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080
};

/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080
};
*/



#define __MSP430_HAS_PORT1_MAPPING__   /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_PORT1_MAPPING__ 0x01C8
#define P1MAP_BASE __MSP430_BASEADDRESS_PORT1_MAPPING__

/*-------------------------------------------------------------------------
 *   Port Mapping Port 2
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short P2MAP01;   /* Port P2.0/1 mapping register  */

  struct
  {
    unsigned short PMAP01_0        : 1; /*  */
    unsigned short PMAP01_1        : 1; /*  */
    unsigned short PMAP01_2        : 1; /*  */
    unsigned short PMAP01_3        : 1; /*  */
    unsigned short PMAP01_4        : 1; /*  */
    unsigned short PMAP01_5        : 1; /*  */
    unsigned short PMAP01_6        : 1; /*  */
    unsigned short PMAP01_7        : 1; /*  */
    unsigned short PMAP01_8        : 1; /*  */
    unsigned short PMAP01_9        : 1; /*  */
    unsigned short PMAP01_10       : 1; /*  */
    unsigned short PMAP01_11       : 1; /*  */
    unsigned short PMAP01_12       : 1; /*  */
    unsigned short PMAP01_13       : 1; /*  */
    unsigned short PMAP01_14       : 1; /*  */
    unsigned short PMAP01_15       : 1; /*  */
  } P2MAP01_bit;

  struct
  {
    unsigned char P2MAP01_L;
    unsigned char P2MAP01_H;
  };
  struct
  {
    unsigned char P2MAP0;   /* Port P2.0 mapping register  */
    unsigned char P2MAP1;   /* Port P2.1 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P2MAP0_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P2MAP1_bit;
  }; 
} @ 0x01D0;

/*
enum {
  PMAP01_0        = 0x0001,
  PMAP01_1        = 0x0002,
  PMAP01_2        = 0x0004,
  PMAP01_3        = 0x0008,
  PMAP01_4        = 0x0010,
  PMAP01_5        = 0x0020,
  PMAP01_6        = 0x0040,
  PMAP01_7        = 0x0080,
  PMAP01_8        = 0x0100,
  PMAP01_9        = 0x0200,
  PMAP01_10       = 0x0400,
  PMAP01_11       = 0x0800,
  PMAP01_12       = 0x1000,
  PMAP01_13       = 0x2000,
  PMAP01_14       = 0x4000,
  PMAP01_15       = 0x8000,
};

*/
__no_init volatile union
{
  unsigned short P2MAP23;   /* Port P2.2/3 mapping register  */

  struct
  {
    unsigned short PMAP23_0        : 1; /*  */
    unsigned short PMAP23_1        : 1; /*  */
    unsigned short PMAP23_2        : 1; /*  */
    unsigned short PMAP23_3        : 1; /*  */
    unsigned short PMAP23_4        : 1; /*  */
    unsigned short PMAP23_5        : 1; /*  */
    unsigned short PMAP23_6        : 1; /*  */
    unsigned short PMAP23_7        : 1; /*  */
    unsigned short PMAP23_8        : 1; /*  */
    unsigned short PMAP23_9        : 1; /*  */
    unsigned short PMAP23_10       : 1; /*  */
    unsigned short PMAP23_11       : 1; /*  */
    unsigned short PMAP23_12       : 1; /*  */
    unsigned short PMAP23_13       : 1; /*  */
    unsigned short PMAP23_14       : 1; /*  */
    unsigned short PMAP23_15       : 1; /*  */
  } P2MAP23_bit;

  struct
  {
    unsigned char P2MAP23_L;
    unsigned char P2MAP23_H;
  };
  struct
  {
    unsigned char P2MAP2;   /* Port P2.2 mapping register  */
    unsigned char P2MAP3;   /* Port P2.3 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P2MAP2_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P2MAP3_bit;
  }; 
} @ 0x01D2;

/*
enum {
  PMAP23_0        = 0x0001,
  PMAP23_1        = 0x0002,
  PMAP23_2        = 0x0004,
  PMAP23_3        = 0x0008,
  PMAP23_4        = 0x0010,
  PMAP23_5        = 0x0020,
  PMAP23_6        = 0x0040,
  PMAP23_7        = 0x0080,
  PMAP23_8        = 0x0100,
  PMAP23_9        = 0x0200,
  PMAP23_10       = 0x0400,
  PMAP23_11       = 0x0800,
  PMAP23_12       = 0x1000,
  PMAP23_13       = 0x2000,
  PMAP23_14       = 0x4000,
  PMAP23_15       = 0x8000,
};

*/
__no_init volatile union
{
  unsigned short P2MAP45;   /* Port P2.4/5 mapping register  */

  struct
  {
    unsigned short PMAP45_0        : 1; /*  */
    unsigned short PMAP45_1        : 1; /*  */
    unsigned short PMAP45_2        : 1; /*  */
    unsigned short PMAP45_3        : 1; /*  */
    unsigned short PMAP45_4        : 1; /*  */
    unsigned short PMAP45_5        : 1; /*  */
    unsigned short PMAP45_6        : 1; /*  */
    unsigned short PMAP45_7        : 1; /*  */
    unsigned short PMAP45_8        : 1; /*  */
    unsigned short PMAP45_9        : 1; /*  */
    unsigned short PMAP45_10       : 1; /*  */
    unsigned short PMAP45_11       : 1; /*  */
    unsigned short PMAP45_12       : 1; /*  */
    unsigned short PMAP45_13       : 1; /*  */
    unsigned short PMAP45_14       : 1; /*  */
    unsigned short PMAP45_15       : 1; /*  */
  } P2MAP45_bit;

  struct
  {
    unsigned char P2MAP45_L;
    unsigned char P2MAP45_H;
  };
  struct
  {
    unsigned char P2MAP4;   /* Port P2.4 mapping register  */
    unsigned char P2MAP5;   /* Port P2.5 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P2MAP4_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P2MAP5_bit;
  }; 
} @ 0x01D4;

/*
enum {
  PMAP45_0        = 0x0001,
  PMAP45_1        = 0x0002,
  PMAP45_2        = 0x0004,
  PMAP45_3        = 0x0008,
  PMAP45_4        = 0x0010,
  PMAP45_5        = 0x0020,
  PMAP45_6        = 0x0040,
  PMAP45_7        = 0x0080,
  PMAP45_8        = 0x0100,
  PMAP45_9        = 0x0200,
  PMAP45_10       = 0x0400,
  PMAP45_11       = 0x0800,
  PMAP45_12       = 0x1000,
  PMAP45_13       = 0x2000,
  PMAP45_14       = 0x4000,
  PMAP45_15       = 0x8000,
};

*/
__no_init volatile union
{
  unsigned short P2MAP67;   /* Port P2.6/7 mapping register  */

  struct
  {
    unsigned short PMAP67_0        : 1; /*  */
    unsigned short PMAP67_1        : 1; /*  */
    unsigned short PMAP67_2        : 1; /*  */
    unsigned short PMAP67_3        : 1; /*  */
    unsigned short PMAP67_4        : 1; /*  */
    unsigned short PMAP67_5        : 1; /*  */
    unsigned short PMAP67_6        : 1; /*  */
    unsigned short PMAP67_7        : 1; /*  */
    unsigned short PMAP67_8        : 1; /*  */
    unsigned short PMAP67_9        : 1; /*  */
    unsigned short PMAP67_10       : 1; /*  */
    unsigned short PMAP67_11       : 1; /*  */
    unsigned short PMAP67_12       : 1; /*  */
    unsigned short PMAP67_13       : 1; /*  */
    unsigned short PMAP67_14       : 1; /*  */
    unsigned short PMAP67_15       : 1; /*  */
  } P2MAP67_bit;

  struct
  {
    unsigned char P2MAP67_L;
    unsigned char P2MAP67_H;
  };
  struct
  {
    unsigned char P2MAP6;   /* Port P2.6 mapping register  */
    unsigned char P2MAP7;   /* Port P2.7 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P2MAP6_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P2MAP7_bit;
  }; 
} @ 0x01D6;

/*
enum {
  PMAP67_0        = 0x0001,
  PMAP67_1        = 0x0002,
  PMAP67_2        = 0x0004,
  PMAP67_3        = 0x0008,
  PMAP67_4        = 0x0010,
  PMAP67_5        = 0x0020,
  PMAP67_6        = 0x0040,
  PMAP67_7        = 0x0080,
  PMAP67_8        = 0x0100,
  PMAP67_9        = 0x0200,
  PMAP67_10       = 0x0400,
  PMAP67_11       = 0x0800,
  PMAP67_12       = 0x1000,
  PMAP67_13       = 0x2000,
  PMAP67_14       = 0x4000,
  PMAP67_15       = 0x8000,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080
};
*/



#define __MSP430_HAS_PORT2_MAPPING__   /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_PORT2_MAPPING__ 0x01D0
#define P2MAP_BASE __MSP430_BASEADDRESS_PORT2_MAPPING__

/*-------------------------------------------------------------------------
 *   Port Mapping Port 3
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short P3MAP01;   /* Port P3.0/1 mapping register  */

  struct
  {
    unsigned short PMAP01_0        : 1; /*  */
    unsigned short PMAP01_1        : 1; /*  */
    unsigned short PMAP01_2        : 1; /*  */
    unsigned short PMAP01_3        : 1; /*  */
    unsigned short PMAP01_4        : 1; /*  */
    unsigned short PMAP01_5        : 1; /*  */
    unsigned short PMAP01_6        : 1; /*  */
    unsigned short PMAP01_7        : 1; /*  */
    unsigned short PMAP01_8        : 1; /*  */
    unsigned short PMAP01_9        : 1; /*  */
    unsigned short PMAP01_10       : 1; /*  */
    unsigned short PMAP01_11       : 1; /*  */
    unsigned short PMAP01_12       : 1; /*  */
    unsigned short PMAP01_13       : 1; /*  */
    unsigned short PMAP01_14       : 1; /*  */
    unsigned short PMAP01_15       : 1; /*  */
  } P3MAP01_bit;

  struct
  {
    unsigned char P3MAP01_L;
    unsigned char P3MAP01_H;
  };
  struct
  {
    unsigned char P3MAP0;   /* Port P3.0 mapping register  */
    unsigned char P3MAP1;   /* Port P3.1 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P3MAP0_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P3MAP1_bit;
  }; 
} @ 0x01D8;

/*
enum {
  PMAP01_0        = 0x0001,
  PMAP01_1        = 0x0002,
  PMAP01_2        = 0x0004,
  PMAP01_3        = 0x0008,
  PMAP01_4        = 0x0010,
  PMAP01_5        = 0x0020,
  PMAP01_6        = 0x0040,
  PMAP01_7        = 0x0080,
  PMAP01_8        = 0x0100,
  PMAP01_9        = 0x0200,
  PMAP01_10       = 0x0400,
  PMAP01_11       = 0x0800,
  PMAP01_12       = 0x1000,
  PMAP01_13       = 0x2000,
  PMAP01_14       = 0x4000,
  PMAP01_15       = 0x8000,
};

*/
__no_init volatile union
{
  unsigned short P3MAP23;   /* Port P3.2/3 mapping register  */

  struct
  {
    unsigned short PMAP23_0        : 1; /*  */
    unsigned short PMAP23_1        : 1; /*  */
    unsigned short PMAP23_2        : 1; /*  */
    unsigned short PMAP23_3        : 1; /*  */
    unsigned short PMAP23_4        : 1; /*  */
    unsigned short PMAP23_5        : 1; /*  */
    unsigned short PMAP23_6        : 1; /*  */
    unsigned short PMAP23_7        : 1; /*  */
    unsigned short PMAP23_8        : 1; /*  */
    unsigned short PMAP23_9        : 1; /*  */
    unsigned short PMAP23_10       : 1; /*  */
    unsigned short PMAP23_11       : 1; /*  */
    unsigned short PMAP23_12       : 1; /*  */
    unsigned short PMAP23_13       : 1; /*  */
    unsigned short PMAP23_14       : 1; /*  */
    unsigned short PMAP23_15       : 1; /*  */
  } P3MAP23_bit;

  struct
  {
    unsigned char P3MAP23_L;
    unsigned char P3MAP23_H;
  };
  struct
  {
    unsigned char P3MAP2;   /* Port P3.2 mapping register  */
    unsigned char P3MAP3;   /* Port P3.3 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P3MAP2_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P3MAP3_bit;
  }; 
} @ 0x01DA;

/*
enum {
  PMAP23_0        = 0x0001,
  PMAP23_1        = 0x0002,
  PMAP23_2        = 0x0004,
  PMAP23_3        = 0x0008,
  PMAP23_4        = 0x0010,
  PMAP23_5        = 0x0020,
  PMAP23_6        = 0x0040,
  PMAP23_7        = 0x0080,
  PMAP23_8        = 0x0100,
  PMAP23_9        = 0x0200,
  PMAP23_10       = 0x0400,
  PMAP23_11       = 0x0800,
  PMAP23_12       = 0x1000,
  PMAP23_13       = 0x2000,
  PMAP23_14       = 0x4000,
  PMAP23_15       = 0x8000,
};

*/
__no_init volatile union
{
  unsigned short P3MAP45;   /* Port P3.4/5 mapping register  */

  struct
  {
    unsigned short PMAP45_0        : 1; /*  */
    unsigned short PMAP45_1        : 1; /*  */
    unsigned short PMAP45_2        : 1; /*  */
    unsigned short PMAP45_3        : 1; /*  */
    unsigned short PMAP45_4        : 1; /*  */
    unsigned short PMAP45_5        : 1; /*  */
    unsigned short PMAP45_6        : 1; /*  */
    unsigned short PMAP45_7        : 1; /*  */
    unsigned short PMAP45_8        : 1; /*  */
    unsigned short PMAP45_9        : 1; /*  */
    unsigned short PMAP45_10       : 1; /*  */
    unsigned short PMAP45_11       : 1; /*  */
    unsigned short PMAP45_12       : 1; /*  */
    unsigned short PMAP45_13       : 1; /*  */
    unsigned short PMAP45_14       : 1; /*  */
    unsigned short PMAP45_15       : 1; /*  */
  } P3MAP45_bit;

  struct
  {
    unsigned char P3MAP45_L;
    unsigned char P3MAP45_H;
  };
  struct
  {
    unsigned char P3MAP4;   /* Port P3.4 mapping register  */
    unsigned char P3MAP5;   /* Port P3.5 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P3MAP4_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P3MAP5_bit;
  }; 
} @ 0x01DC;

/*
enum {
  PMAP45_0        = 0x0001,
  PMAP45_1        = 0x0002,
  PMAP45_2        = 0x0004,
  PMAP45_3        = 0x0008,
  PMAP45_4        = 0x0010,
  PMAP45_5        = 0x0020,
  PMAP45_6        = 0x0040,
  PMAP45_7        = 0x0080,
  PMAP45_8        = 0x0100,
  PMAP45_9        = 0x0200,
  PMAP45_10       = 0x0400,
  PMAP45_11       = 0x0800,
  PMAP45_12       = 0x1000,
  PMAP45_13       = 0x2000,
  PMAP45_14       = 0x4000,
  PMAP45_15       = 0x8000,
};

*/
__no_init volatile union
{
  unsigned short P3MAP67;   /* Port P3.6/7 mapping register  */

  struct
  {
    unsigned short PMAP67_0        : 1; /*  */
    unsigned short PMAP67_1        : 1; /*  */
    unsigned short PMAP67_2        : 1; /*  */
    unsigned short PMAP67_3        : 1; /*  */
    unsigned short PMAP67_4        : 1; /*  */
    unsigned short PMAP67_5        : 1; /*  */
    unsigned short PMAP67_6        : 1; /*  */
    unsigned short PMAP67_7        : 1; /*  */
    unsigned short PMAP67_8        : 1; /*  */
    unsigned short PMAP67_9        : 1; /*  */
    unsigned short PMAP67_10       : 1; /*  */
    unsigned short PMAP67_11       : 1; /*  */
    unsigned short PMAP67_12       : 1; /*  */
    unsigned short PMAP67_13       : 1; /*  */
    unsigned short PMAP67_14       : 1; /*  */
    unsigned short PMAP67_15       : 1; /*  */
  } P3MAP67_bit;

  struct
  {
    unsigned char P3MAP67_L;
    unsigned char P3MAP67_H;
  };
  struct
  {
    unsigned char P3MAP6;   /* Port P3.6 mapping register  */
    unsigned char P3MAP7;   /* Port P3.7 mapping register  */
  };
  struct
  {
    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P3MAP6_bit;

    struct
    {
      unsigned char PMAP0           : 1; /*  */
      unsigned char PMAP1           : 1; /*  */
      unsigned char PMAP2           : 1; /*  */
      unsigned char PMAP3           : 1; /*  */
      unsigned char PMAP4           : 1; /*  */
      unsigned char PMAP5           : 1; /*  */
      unsigned char PMAP6           : 1; /*  */
      unsigned char PMAP7           : 1; /*  */
    } P3MAP7_bit;
  }; 
} @ 0x01DE;

/*
enum {
  PMAP67_0        = 0x0001,
  PMAP67_1        = 0x0002,
  PMAP67_2        = 0x0004,
  PMAP67_3        = 0x0008,
  PMAP67_4        = 0x0010,
  PMAP67_5        = 0x0020,
  PMAP67_6        = 0x0040,
  PMAP67_7        = 0x0080,
  PMAP67_8        = 0x0100,
  PMAP67_9        = 0x0200,
  PMAP67_10       = 0x0400,
  PMAP67_11       = 0x0800,
  PMAP67_12       = 0x1000,
  PMAP67_13       = 0x2000,
  PMAP67_14       = 0x4000,
  PMAP67_15       = 0x8000,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080,
};

*/
/*
enum {
  PMAP0           = 0x0001,
  PMAP1           = 0x0002,
  PMAP2           = 0x0004,
  PMAP3           = 0x0008,
  PMAP4           = 0x0010,
  PMAP5           = 0x0020,
  PMAP6           = 0x0040,
  PMAP7           = 0x0080
};
*/



#define __MSP430_HAS_PORT3_MAPPING__   /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_PORT3_MAPPING__ 0x01D8
#define P3MAP_BASE __MSP430_BASEADDRESS_PORT3_MAPPING__

#define PM_NONE       0
#define PM_UCA0RXD    1
#define PM_UCA0SOMI   1
#define PM_UCA0TXD    2
#define PM_UCA0SIMO   2
#define PM_UCA0CLK    3
#define PM_UCA0STE    4
#define PM_UCA1RXD    5
#define PM_UCA1SOMI   5
#define PM_UCA1TXD    6
#define PM_UCA1SIMO   6
#define PM_UCA1CLK    7
#define PM_UCA1STE    8
#define PM_UCA2RXD    9
#define PM_UCA2SOMI   9
#define PM_UCA2TXD    10
#define PM_UCA2SIMO   10
#define PM_UCA2CLK    11
#define PM_UCA2STE    12
#define PM_UCB0SIMO   13
#define PM_UCB0SDA    13
#define PM_UCB0SOMI   14
#define PM_UCB0SCL    14
#define PM_UCB0CLK    15
#define PM_UCB0STE    16
#define PM_TA0_0      17
#define PM_TA0_1      18
#define PM_TA0_2      19
#define PM_TA1_0      20
#define PM_TA1_1      21
#define PM_TA2_0      22
#define PM_TA2_1      23
#define PM_TA3_0      24
#define PM_TA3_1      25
#define PM_TACLK      26
#define PM_RTCCLK     26
#define PM_SDCLK      27
#define PM_SD0DIO     28
#define PM_SD1DIO     29
#define PM_SD2DIO     30
#define PM_ANALOG     31

/*-------------------------------------------------------------------------
 *   PMM  Power Management System
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short PMMCTL0;   /* PMM Control 0  */

  struct
  {
    unsigned short PMMCOREV0       : 1; /* PMM Core Voltage Bit: 0  */
    unsigned short PMMCOREV1       : 1; /* PMM Core Voltage Bit: 1  */
    unsigned short PMMSWBOR        : 1; /* PMM Software BOR  */
    unsigned short PMMSWPOR        : 1; /* PMM Software POR  */
    unsigned short PMMREGOFF       : 1; /* PMM Turn Regulator off  */
    unsigned short                : 2;
    unsigned short PMMHPMRE        : 1; /* PMM Global High Power Module Request Enable  */
  } PMMCTL0_bit;

  struct
  {
    unsigned char PMMCTL0_L;
    unsigned char PMMCTL0_H;
  };
} @ 0x0120;

enum {
  PMMCOREV0       = 0x0001,
  PMMCOREV1       = 0x0002,
  PMMSWBOR        = 0x0004,
  PMMSWPOR        = 0x0008,
  PMMREGOFF       = 0x0010,
  PMMHPMRE        = 0x0080
};

__no_init volatile union
{
  unsigned short PMMCTL1;   /* PMM Control 1  */

  struct
  {
    unsigned short PMMREFMD        : 1; /* PMM Reference Mode  */
    unsigned short                : 3;
    unsigned short PMMCMD0         : 1; /* PMM Voltage Regulator Current Mode Bit: 0  */
    unsigned short PMMCMD1         : 1; /* PMM Voltage Regulator Current Mode Bit: 1  */
  } PMMCTL1_bit;

  struct
  {
    unsigned char PMMCTL1_L;
    unsigned char PMMCTL1_H;
  };
} @ 0x0122;

enum {
  PMMREFMD        = 0x0001,
  PMMCMD0         = 0x0010,
  PMMCMD1         = 0x0020
};

__no_init volatile union
{
  unsigned short SVSMHCTL;   /* SVS and SVM high side control register  */

  struct
  {
    unsigned short SVSMHRRL0       : 1; /* SVS and SVM high side Reset Release Voltage Level Bit: 0  */
    unsigned short SVSMHRRL1       : 1; /* SVS and SVM high side Reset Release Voltage Level Bit: 1  */
    unsigned short SVSMHRRL2       : 1; /* SVS and SVM high side Reset Release Voltage Level Bit: 2  */
    unsigned short SVSMHDLYST      : 1; /* SVS and SVM high side delay status  */
    unsigned short SVSHMD          : 1; /* SVS high side mode  */
    unsigned short                : 1;
    unsigned short SVSMHEVM        : 1; /* SVS and SVM high side event mask  */
    unsigned short SVSMHACE        : 1; /* SVS and SVM high side auto control enable  */
    unsigned short SVSHRVL0        : 1; /* SVS high side reset voltage level Bit: 0  */
    unsigned short SVSHRVL1        : 1; /* SVS high side reset voltage level Bit: 1  */
    unsigned short SVSHE           : 1; /* SVS high side enable  */
    unsigned short SVSHFP          : 1; /* SVS high side full performace mode  */
    unsigned short SVMHOVPE        : 1; /* SVM high side over-voltage enable  */
    unsigned short                : 1;
    unsigned short SVMHE           : 1; /* SVM high side enable  */
    unsigned short SVMHFP          : 1; /* SVM high side full performace mode  */
  } SVSMHCTL_bit;

  struct
  {
    unsigned char SVSMHCTL_L;
    unsigned char SVSMHCTL_H;
  };
} @ 0x0124;

enum {
  SVSMHRRL0       = 0x0001,
  SVSMHRRL1       = 0x0002,
  SVSMHRRL2       = 0x0004,
  SVSMHDLYST      = 0x0008,
  SVSHMD          = 0x0010,
  SVSMHEVM        = 0x0040,
  SVSMHACE        = 0x0080,
  SVSHRVL0        = 0x0100,
  SVSHRVL1        = 0x0200,
  SVSHE           = 0x0400,
  SVSHFP          = 0x0800,
  SVMHOVPE        = 0x1000,
  SVMHE           = 0x4000,
  SVMHFP          = 0x8000
};

__no_init volatile union
{
  unsigned short SVSMLCTL;   /* SVS and SVM low side control register  */

  struct
  {
    unsigned short SVSMLRRL0       : 1; /* SVS and SVM low side Reset Release Voltage Level Bit: 0  */
    unsigned short SVSMLRRL1       : 1; /* SVS and SVM low side Reset Release Voltage Level Bit: 1  */
    unsigned short SVSMLRRL2       : 1; /* SVS and SVM low side Reset Release Voltage Level Bit: 2  */
    unsigned short SVSMLDLYST      : 1; /* SVS and SVM low side delay status  */
    unsigned short SVSLMD          : 1; /* SVS low side mode  */
    unsigned short                : 1;
    unsigned short SVSMLEVM        : 1; /* SVS and SVM low side event mask  */
    unsigned short SVSMLACE        : 1; /* SVS and SVM low side auto control enable  */
    unsigned short SVSLRVL0        : 1; /* SVS low side reset voltage level Bit: 0  */
    unsigned short SVSLRVL1        : 1; /* SVS low side reset voltage level Bit: 1  */
    unsigned short SVSLE           : 1; /* SVS low side enable  */
    unsigned short SVSLFP          : 1; /* SVS low side full performace mode  */
    unsigned short SVMLOVPE        : 1; /* SVM low side over-voltage enable  */
    unsigned short                : 1;
    unsigned short SVMLE           : 1; /* SVM low side enable  */
    unsigned short SVMLFP          : 1; /* SVM low side full performace mode  */
  } SVSMLCTL_bit;

  struct
  {
    unsigned char SVSMLCTL_L;
    unsigned char SVSMLCTL_H;
  };
} @ 0x0126;

enum {
  SVSMLRRL0       = 0x0001,
  SVSMLRRL1       = 0x0002,
  SVSMLRRL2       = 0x0004,
  SVSMLDLYST      = 0x0008,
  SVSLMD          = 0x0010,
  SVSMLEVM        = 0x0040,
  SVSMLACE        = 0x0080,
  SVSLRVL0        = 0x0100,
  SVSLRVL1        = 0x0200,
  SVSLE           = 0x0400,
  SVSLFP          = 0x0800,
  SVMLOVPE        = 0x1000,
  SVMLE           = 0x4000,
  SVMLFP          = 0x8000
};

__no_init volatile union
{
  unsigned short SVSMIO;   /* SVSIN and SVSOUT control register  */

  struct
  {
    unsigned short                : 3;
    unsigned short SVMLOE          : 1; /* SVM low side output enable  */
    unsigned short SVMLVLROE       : 1; /* SVM low side voltage level reached output enable  */
    unsigned short SVMOUTPOL       : 1; /* SVMOUT pin polarity  */
    unsigned short                : 5;
    unsigned short SVMHOE          : 1; /* SVM high side output enable  */
    unsigned short SVMHVLROE       : 1; /* SVM high side voltage level reached output enable  */
  } SVSMIO_bit;

  struct
  {
    unsigned char SVSMIO_L;
    unsigned char SVSMIO_H;
  };
} @ 0x0128;

enum {
  SVMLOE          = 0x0008,
  SVMLVLROE       = 0x0010,
  SVMOUTPOL       = 0x0020,
  SVMHOE          = 0x0800,
  SVMHVLROE       = 0x1000
};

__no_init volatile union
{
  unsigned short PMMIFG;   /* PMM Interrupt Flag  */

  struct
  {
    unsigned short SVSMLDLYIFG     : 1; /* SVS and SVM low side Delay expired interrupt flag  */
    unsigned short SVMLIFG         : 1; /* SVM low side interrupt flag  */
    unsigned short SVMLVLRIFG      : 1; /* SVM low side Voltage Level Reached interrupt flag  */
    unsigned short                : 1;
    unsigned short SVSMHDLYIFG     : 1; /* SVS and SVM high side Delay expired interrupt flag  */
    unsigned short SVMHIFG         : 1; /* SVM high side interrupt flag  */
    unsigned short SVMHVLRIFG      : 1; /* SVM high side Voltage Level Reached interrupt flag  */
    unsigned short                : 1;
    unsigned short PMMBORIFG       : 1; /* PMM Software BOR interrupt flag  */
    unsigned short PMMRSTIFG       : 1; /* PMM RESET pin interrupt flag  */
    unsigned short PMMPORIFG       : 1; /* PMM Software POR interrupt flag  */
    unsigned short                : 1;
    unsigned short SVSHIFG         : 1; /* SVS low side interrupt flag  */
    unsigned short SVSLIFG         : 1; /* SVS high side interrupt flag  */
    unsigned short                : 1;
    unsigned short PMMLPM5IFG      : 1; /* LPM5 indication Flag  */
  } PMMIFG_bit;

  struct
  {
    unsigned char PMMIFG_L;
    unsigned char PMMIFG_H;
  };
} @ 0x012C;

enum {
  SVSMLDLYIFG     = 0x0001,
  SVMLIFG         = 0x0002,
  SVMLVLRIFG      = 0x0004,
  SVSMHDLYIFG     = 0x0010,
  SVMHIFG         = 0x0020,
  SVMHVLRIFG      = 0x0040,
  PMMBORIFG       = 0x0100,
  PMMRSTIFG       = 0x0200,
  PMMPORIFG       = 0x0400,
  SVSHIFG         = 0x1000,
  SVSLIFG         = 0x2000,
  PMMLPM5IFG      = 0x8000
};

__no_init volatile union
{
  unsigned short PMMRIE;   /* PMM and RESET Interrupt Enable  */

  struct
  {
    unsigned short SVSMLDLYIE      : 1; /* SVS and SVM low side Delay expired interrupt enable  */
    unsigned short SVMLIE          : 1; /* SVM low side interrupt enable  */
    unsigned short SVMLVLRIE       : 1; /* SVM low side Voltage Level Reached interrupt enable  */
    unsigned short                : 1;
    unsigned short SVSMHDLYIE      : 1; /* SVS and SVM high side Delay expired interrupt enable  */
    unsigned short SVMHIE          : 1; /* SVM high side interrupt enable  */
    unsigned short SVMHVLRIE       : 1; /* SVM high side Voltage Level Reached interrupt enable  */
    unsigned short                : 1;
    unsigned short SVSLPE          : 1; /* SVS low side POR enable  */
    unsigned short SVMLVLRPE       : 1; /* SVM low side Voltage Level reached POR enable  */
    unsigned short                : 2;
    unsigned short SVSHPE          : 1; /* SVS high side POR enable  */
    unsigned short SVMHVLRPE       : 1; /* SVM high side Voltage Level reached POR enable  */
  } PMMRIE_bit;

  struct
  {
    unsigned char PMMRIE_L;
    unsigned char PMMRIE_H;
  };
} @ 0x012E;

enum {
  SVSMLDLYIE      = 0x0001,
  SVMLIE          = 0x0002,
  SVMLVLRIE       = 0x0004,
  SVSMHDLYIE      = 0x0010,
  SVMHIE          = 0x0020,
  SVMHVLRIE       = 0x0040,
  SVSLPE          = 0x0100,
  SVMLVLRPE       = 0x0200,
  SVSHPE          = 0x1000,
  SVMHVLRPE       = 0x2000
};

__no_init volatile union
{
  unsigned short PM5CTL0;   /* PMM Power Mode 5 Control Register 0  */

  struct
  {
    unsigned short LOCKLPM5        : 1; /* Lock I/O pin configuration upon entry/exit to/from LPM5  */
  } PM5CTL0_bit;

  struct
  {
    unsigned char PM5CTL0_L;
    unsigned char PM5CTL0_H;
  };
} @ 0x0130;

enum {
  LOCKLPM5        = 0x0001
};



#define __MSP430_HAS_PMM__            /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_PMM__ 0x0120
#define PMM_BASE __MSP430_BASEADDRESS_PMM__

#define PMMPW               (0xA500u)  /* PMM Register Write Password */
#define PMMPW_H             (0xA5)    /* PMM Register Write Password for high word access */
/* PMMCTL0 Control Bits */
#define PMMCOREV0_L         (0x0001u)  /* PMM Core Voltage Bit: 0 */
#define PMMCOREV1_L         (0x0002u)  /* PMM Core Voltage Bit: 1 */
#define PMMSWBOR_L          (0x0004u)  /* PMM Software BOR */
#define PMMSWPOR_L          (0x0008u)  /* PMM Software POR */
#define PMMREGOFF_L         (0x0010u)  /* PMM Turn Regulator off */
#define PMMHPMRE_L          (0x0080u)  /* PMM Global High Power Module Request Enable */

#define PMMCOREV_0          (0x0000u)  /* PMM Core Voltage 0 (1.35V) */
#define PMMCOREV_1          (0x0001u)  /* PMM Core Voltage 1 (1.55V) */
#define PMMCOREV_2          (0x0002u)  /* PMM Core Voltage 2 (1.75V) */
#define PMMCOREV_3          (0x0003u)  /* PMM Core Voltage 3 (1.85V) */
/* PMMCTL1 Control Bits */
#define PMMREFMD_L          (0x0001u)  /* PMM Reference Mode */
#define PMMCMD0_L           (0x0010u)  /* PMM Voltage Regulator Current Mode Bit: 0 */
#define PMMCMD1_L           (0x0020u)  /* PMM Voltage Regulator Current Mode Bit: 1 */
/* SVSMHCTL Control Bits */
#define SVSMHRRL0_L         (0x0001u)  /* SVS and SVM high side Reset Release Voltage Level Bit: 0 */
#define SVSMHRRL1_L         (0x0002u)  /* SVS and SVM high side Reset Release Voltage Level Bit: 1 */
#define SVSMHRRL2_L         (0x0004u)  /* SVS and SVM high side Reset Release Voltage Level Bit: 2 */
#define SVSMHDLYST_L        (0x0008u)  /* SVS and SVM high side delay status */
#define SVSHMD_L            (0x0010u)  /* SVS high side mode */
#define SVSMHEVM_L          (0x0040u)  /* SVS and SVM high side event mask */
#define SVSMHACE_L          (0x0080u)  /* SVS and SVM high side auto control enable */
/* SVSMHCTL Control Bits */
#define SVSHRVL0_H          (0x0001u)  /* SVS high side reset voltage level Bit: 0 */
#define SVSHRVL1_H          (0x0002u)  /* SVS high side reset voltage level Bit: 1 */
#define SVSHE_H             (0x0004u)  /* SVS high side enable */
#define SVSHFP_H            (0x0008u)  /* SVS high side full performace mode */
#define SVMHOVPE_H          (0x0010u)  /* SVM high side over-voltage enable */
#define SVMHE_H             (0x0040u)  /* SVM high side enable */
#define SVMHFP_H            (0x0080u)  /* SVM high side full performace mode */

#define SVSMHRRL_0          (0x0000u)  /* SVS and SVM high side Reset Release Voltage Level 0 */
#define SVSMHRRL_1          (0x0001u)  /* SVS and SVM high side Reset Release Voltage Level 1 */
#define SVSMHRRL_2          (0x0002u)  /* SVS and SVM high side Reset Release Voltage Level 2 */
#define SVSMHRRL_3          (0x0003u)  /* SVS and SVM high side Reset Release Voltage Level 3 */
#define SVSMHRRL_4          (0x0004u)  /* SVS and SVM high side Reset Release Voltage Level 4 */
#define SVSMHRRL_5          (0x0005u)  /* SVS and SVM high side Reset Release Voltage Level 5 */
#define SVSMHRRL_6          (0x0006u)  /* SVS and SVM high side Reset Release Voltage Level 6 */
#define SVSMHRRL_7          (0x0007u)  /* SVS and SVM high side Reset Release Voltage Level 7 */

#define SVSHRVL_0           (0x0000u)  /* SVS high side Reset Release Voltage Level 0 */
#define SVSHRVL_1           (0x0100u)  /* SVS high side Reset Release Voltage Level 1 */
#define SVSHRVL_2           (0x0200u)  /* SVS high side Reset Release Voltage Level 2 */
#define SVSHRVL_3           (0x0300u)  /* SVS high side Reset Release Voltage Level 3 */
/* SVSMLCTL Control Bits */
#define SVSMLRRL0_L         (0x0001u)  /* SVS and SVM low side Reset Release Voltage Level Bit: 0 */
#define SVSMLRRL1_L         (0x0002u)  /* SVS and SVM low side Reset Release Voltage Level Bit: 1 */
#define SVSMLRRL2_L         (0x0004u)  /* SVS and SVM low side Reset Release Voltage Level Bit: 2 */
#define SVSMLDLYST_L        (0x0008u)  /* SVS and SVM low side delay status */
#define SVSLMD_L            (0x0010u)  /* SVS low side mode */
#define SVSMLEVM_L          (0x0040u)  /* SVS and SVM low side event mask */
#define SVSMLACE_L          (0x0080u)  /* SVS and SVM low side auto control enable */
/* SVSMLCTL Control Bits */
#define SVSLRVL0_H          (0x0001u)  /* SVS low side reset voltage level Bit: 0 */
#define SVSLRVL1_H          (0x0002u)  /* SVS low side reset voltage level Bit: 1 */
#define SVSLE_H             (0x0004u)  /* SVS low side enable */
#define SVSLFP_H            (0x0008u)  /* SVS low side full performace mode */
#define SVMLOVPE_H          (0x0010u)  /* SVM low side over-voltage enable */
#define SVMLE_H             (0x0040u)  /* SVM low side enable */
#define SVMLFP_H            (0x0080u)  /* SVM low side full performace mode */

#define SVSMLRRL_0          (0x0000u)  /* SVS and SVM low side Reset Release Voltage Level 0 */
#define SVSMLRRL_1          (0x0001u)  /* SVS and SVM low side Reset Release Voltage Level 1 */
#define SVSMLRRL_2          (0x0002u)  /* SVS and SVM low side Reset Release Voltage Level 2 */
#define SVSMLRRL_3          (0x0003u)  /* SVS and SVM low side Reset Release Voltage Level 3 */
#define SVSMLRRL_4          (0x0004u)  /* SVS and SVM low side Reset Release Voltage Level 4 */
#define SVSMLRRL_5          (0x0005u)  /* SVS and SVM low side Reset Release Voltage Level 5 */
#define SVSMLRRL_6          (0x0006u)  /* SVS and SVM low side Reset Release Voltage Level 6 */
#define SVSMLRRL_7          (0x0007u)  /* SVS and SVM low side Reset Release Voltage Level 7 */

#define SVSLRVL_0           (0x0000u)  /* SVS low side Reset Release Voltage Level 0 */
#define SVSLRVL_1           (0x0100u)  /* SVS low side Reset Release Voltage Level 1 */
#define SVSLRVL_2           (0x0200u)  /* SVS low side Reset Release Voltage Level 2 */
#define SVSLRVL_3           (0x0300u)  /* SVS low side Reset Release Voltage Level 3 */
/* SVSMIO Control Bits */
#define SVMLOE_L            (0x0008u)  /* SVM low side output enable */
#define SVMLVLROE_L         (0x0010u)  /* SVM low side voltage level reached output enable */
#define SVMOUTPOL_L         (0x0020u)  /* SVMOUT pin polarity */
/* SVSMIO Control Bits */
#define SVMHOE_H            (0x0008u)  /* SVM high side output enable */
#define SVMHVLROE_H         (0x0010u)  /* SVM high side voltage level reached output enable */
/* PMMIFG Control Bits */
#define SVSMLDLYIFG_L       (0x0001u)  /* SVS and SVM low side Delay expired interrupt flag */
#define SVMLIFG_L           (0x0002u)  /* SVM low side interrupt flag */
#define SVMLVLRIFG_L        (0x0004u)  /* SVM low side Voltage Level Reached interrupt flag */
#define SVSMHDLYIFG_L       (0x0010u)  /* SVS and SVM high side Delay expired interrupt flag */
#define SVMHIFG_L           (0x0020u)  /* SVM high side interrupt flag */
#define SVMHVLRIFG_L        (0x0040u)  /* SVM high side Voltage Level Reached interrupt flag */
/* PMMIFG Control Bits */
#define PMMBORIFG_H         (0x0001u)  /* PMM Software BOR interrupt flag */
#define PMMRSTIFG_H         (0x0002u)  /* PMM RESET pin interrupt flag */
#define PMMPORIFG_H         (0x0004u)  /* PMM Software POR interrupt flag */
#define SVSHIFG_H           (0x0010u)  /* SVS low side interrupt flag */
#define SVSLIFG_H           (0x0020u)  /* SVS high side interrupt flag */
#define PMMLPM5IFG_H        (0x0080u)  /* LPM5 indication Flag */

#define PMMRSTLPM5IFG       PMMLPM5IFG /* LPM5 indication Flag */
/* PMMIE and RESET Control Bits */
#define SVSMLDLYIE_L        (0x0001u)  /* SVS and SVM low side Delay expired interrupt enable */
#define SVMLIE_L            (0x0002u)  /* SVM low side interrupt enable */
#define SVMLVLRIE_L         (0x0004u)  /* SVM low side Voltage Level Reached interrupt enable */
#define SVSMHDLYIE_L        (0x0010u)  /* SVS and SVM high side Delay expired interrupt enable */
#define SVMHIE_L            (0x0020u)  /* SVM high side interrupt enable */
#define SVMHVLRIE_L         (0x0040u)  /* SVM high side Voltage Level Reached interrupt enable */
/* PMMIE and RESET Control Bits */
#define SVSLPE_H            (0x0001u)  /* SVS low side POR enable */
#define SVMLVLRPE_H         (0x0002u)  /* SVM low side Voltage Level reached POR enable */
#define SVSHPE_H            (0x0010u)  /* SVS high side POR enable */
#define SVMHVLRPE_H         (0x0020u)  /* SVM high side Voltage Level reached POR enable */
/* PM5CTL0 Power Mode 5 Control Bits */
#define LOCKLPM5_L          (0x0001u)  /* Lock I/O pin configuration upon entry/exit to/from LPM5 */

#define LOCKIO              LOCKLPM5  /* Lock I/O pin configuration upon entry/exit to/from LPM5 */

/*-------------------------------------------------------------------------
 *   RC  RAM Control Module
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short RCCTL0;   /* Ram Controller Control Register  */

  struct
  {
    unsigned short RCRS0OFF        : 1; /* RAM Controller RAM Sector 0 Off  */
    unsigned short RCRS1OFF        : 1; /* RAM Controller RAM Sector 1 Off  */
    unsigned short RCRS2OFF        : 1; /* RAM Controller RAM Sector 2 Off  */
    unsigned short RCRS3OFF        : 1; /* RAM Controller RAM Sector 3 Off  */
  } RCCTL0_bit;

  struct
  {
    unsigned char RCCTL0_L;
    unsigned char RCCTL0_H;
  };
} @ 0x0158;

enum {
  RCRS0OFF        = 0x0001,
  RCRS1OFF        = 0x0002,
  RCRS2OFF        = 0x0004,
  RCRS3OFF        = 0x0008
};



#define __MSP430_HAS_RC__             /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_RC__ 0x0158
#define RAM_BASE __MSP430_BASEADDRESS_RC__
/* RCCTL0 Control Bits */
#define RCRS0OFF_L          (0x0001u)  /* RAM Controller RAM Sector 0 Off */
#define RCRS1OFF_L          (0x0002u)  /* RAM Controller RAM Sector 1 Off */
#define RCRS2OFF_L          (0x0004u)  /* RAM Controller RAM Sector 2 Off */
#define RCRS3OFF_L          (0x0008u)  /* RAM Controller RAM Sector 3 Off */

#define RCKEY               (0x5A00u)

/*-------------------------------------------------------------------------
 *   Shared Reference
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short REFCTL0;   /* REF Shared Reference control register 0  */

  struct
  {
    unsigned short REFON           : 1; /* REF Reference On  */
    unsigned short REFOUT          : 1; /* REF Reference output Buffer On  */
    unsigned short                : 1;
    unsigned short REFTCOFF        : 1; /* REF Temp.Sensor off  */
    unsigned short REFVSEL0        : 1; /* REF Reference Voltage Level Select Bit:0  */
    unsigned short REFVSEL1        : 1; /* REF Reference Voltage Level Select Bit:1  */
    unsigned short                : 1;
    unsigned short REFMSTR         : 1; /* REF Master Control  */
    unsigned short REFGENACT       : 1; /* REF Reference generator active  */
    unsigned short REFBGACT        : 1; /* REF Reference bandgap active  */
    unsigned short REFGENBUSY      : 1; /* REF Reference generator busy  */
    unsigned short BGMODE          : 1; /* REF Bandgap mode  */
  } REFCTL0_bit;

  struct
  {
    unsigned char REFCTL0_L;
    unsigned char REFCTL0_H;
  };
} @ 0x01B0;

enum {
  REFON           = 0x0001,
  REFOUT          = 0x0002,
  REFTCOFF        = 0x0008,
  REFVSEL0        = 0x0010,
  REFVSEL1        = 0x0020,
  REFMSTR         = 0x0080,
  REFGENACT       = 0x0100,
  REFBGACT        = 0x0200,
  REFGENBUSY      = 0x0400,
  BGMODE          = 0x0800
};



#define __MSP430_HAS_REF__          /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_REF__ 0x01B0
#define REF_BASE __MSP430_BASEADDRESS_REF__
/* REFCTL0 Control Bits */
#define REFON_L             (0x0001u)  /* REF Reference On */
#define REFOUT_L            (0x0002u)  /* REF Reference output Buffer On */
#define REFTCOFF_L          (0x0008u)  /* REF Temp.Sensor off */
#define REFVSEL0_L          (0x0010u)  /* REF Reference Voltage Level Select Bit:0 */
#define REFVSEL1_L          (0x0020u)  /* REF Reference Voltage Level Select Bit:1 */
#define REFMSTR_L           (0x0080u)  /* REF Master Control */
#define REFGENACT_H         (0x0001u)  /* REF Reference generator active */
#define REFBGACT_H          (0x0002u)  /* REF Reference bandgap active */
#define REFGENBUSY_H        (0x0004u)  /* REF Reference generator busy */
#define BGMODE_H            (0x0008u)  /* REF Bandgap mode */

#define REFVSEL_0           (0x0000u)  /* REF Reference Voltage Level Select 1.5V */
#define REFVSEL_1           (0x0010u)  /* REF Reference Voltage Level Select 2.0V */
#define REFVSEL_2           (0x0020u)  /* REF Reference Voltage Level Select 2.5V */
#define REFVSEL_3           (0x0030u)  /* REF Reference Voltage Level Select 2.5V */

/*-------------------------------------------------------------------------
 *   RTC_C  Real Time Clock
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short RTCCTL0;   /* Real Timer Clock Control 0/Key  */

  struct
  {
    unsigned short RTCRDYIFG       : 1; /* RTC Ready Interrupt Flag  */
    unsigned short RTCAIFG         : 1; /* RTC Alarm Interrupt Flag  */
    unsigned short RTCTEVIFG       : 1; /* RTC Time Event Interrupt Flag  */
    unsigned short RTCOFIFG        : 1; /* RTC 32kHz cyrstal oscillator fault interrupt flag  */
    unsigned short RTCRDYIE        : 1; /* RTC Ready Interrupt Enable Flag  */
    unsigned short RTCAIE          : 1; /* RTC Alarm Interrupt Enable Flag  */
    unsigned short RTCTEVIE        : 1; /* RTC Time Event Interrupt Enable Flag  */
    unsigned short RTCOFIE         : 1; /* RTC 32kHz cyrstal oscillator fault interrupt enable  */
  } RTCCTL0_bit;

  struct
  {
    unsigned char RTCCTL0_L;
    unsigned char RTCCTL0_H;
  };
} @ 0x04A0;

enum {
  RTCRDYIFG       = 0x0001,
  RTCAIFG         = 0x0002,
  RTCTEVIFG       = 0x0004,
  RTCOFIFG        = 0x0008,
  RTCRDYIE        = 0x0010,
  RTCAIE          = 0x0020,
  RTCTEVIE        = 0x0040,
  RTCOFIE         = 0x0080
};

__no_init volatile union
{
  unsigned short RTCCTL13;   /* Real Timer Clock Control 1/3  */

  struct
  {
    unsigned short RTCTEV0         : 1; /* RTC Time Event 0  */
    unsigned short RTCTEV1         : 1; /* RTC Time Event 1  */
    unsigned short RTCSSEL0        : 1; /* RTC Source Select 0  */
    unsigned short RTCSSEL1        : 1; /* RTC Source Select 1  */
    unsigned short RTCRDY          : 1; /* RTC Ready  */
    unsigned short RTCMODE         : 1; /* RTC Mode 0:Counter / 1: Calendar  */
    unsigned short RTCHOLD         : 1; /* RTC Hold  */
    unsigned short RTCBCD          : 1; /* RTC BCD  0:Binary / 1:BCD  */
    unsigned short RTCCALF0        : 1; /* RTC Calibration Frequency Bit 0  */
    unsigned short RTCCALF1        : 1; /* RTC Calibration Frequency Bit 1  */
  } RTCCTL13_bit;

  struct
  {
    unsigned char RTCCTL13_L;
    unsigned char RTCCTL13_H;
  };
} @ 0x04A2;

enum {
  RTCTEV0         = 0x0001,
  RTCTEV1         = 0x0002,
  RTCSSEL0        = 0x0004,
  RTCSSEL1        = 0x0008,
  RTCRDY          = 0x0010,
  RTCMODE         = 0x0020,
  RTCHOLD         = 0x0040,
  RTCBCD          = 0x0080,
  RTCCALF0        = 0x0100,
  RTCCALF1        = 0x0200
};

__no_init volatile union
{
  unsigned short RTCOCAL;   /* Real Timer Clock Offset Calibartion  */

  struct
  {
    unsigned short RTCOCAL0        : 1; /* RTC Offset Calibration Bit 0  */
    unsigned short RTCOCAL1        : 1; /* RTC Offset Calibration Bit 1  */
    unsigned short RTCOCAL2        : 1; /* RTC Offset Calibration Bit 2  */
    unsigned short RTCOCAL3        : 1; /* RTC Offset Calibration Bit 3  */
    unsigned short RTCOCAL4        : 1; /* RTC Offset Calibration Bit 4  */
    unsigned short RTCOCAL5        : 1; /* RTC Offset Calibration Bit 5  */
    unsigned short RTCOCAL6        : 1; /* RTC Offset Calibration Bit 6  */
    unsigned short RTCOCAL7        : 1; /* RTC Offset Calibration Bit 7  */
    unsigned short                : 7;
    unsigned short RTCOCALS        : 1; /* RTC Offset Calibration Sign  */
  } RTCOCAL_bit;

  struct
  {
    unsigned char RTCOCAL_L;
    unsigned char RTCOCAL_H;
  };
} @ 0x04A4;

enum {
  RTCOCAL0        = 0x0001,
  RTCOCAL1        = 0x0002,
  RTCOCAL2        = 0x0004,
  RTCOCAL3        = 0x0008,
  RTCOCAL4        = 0x0010,
  RTCOCAL5        = 0x0020,
  RTCOCAL6        = 0x0040,
  RTCOCAL7        = 0x0080,
  RTCOCALS        = 0x8000
};

__no_init volatile union
{
  unsigned short RTCTCMP;   /* Real Timer Temperature Compensation  */

  struct
  {
    unsigned short RTCTCMP0        : 1; /* RTC Temperature Compensation Bit 0  */
    unsigned short RTCTCMP1        : 1; /* RTC Temperature Compensation Bit 1  */
    unsigned short RTCTCMP2        : 1; /* RTC Temperature Compensation Bit 2  */
    unsigned short RTCTCMP3        : 1; /* RTC Temperature Compensation Bit 3  */
    unsigned short RTCTCMP4        : 1; /* RTC Temperature Compensation Bit 4  */
    unsigned short RTCTCMP5        : 1; /* RTC Temperature Compensation Bit 5  */
    unsigned short RTCTCMP6        : 1; /* RTC Temperature Compensation Bit 6  */
    unsigned short RTCTCMP7        : 1; /* RTC Temperature Compensation Bit 7  */
    unsigned short                : 5;
    unsigned short RTCTCOK         : 1; /* RTC Temperature compensation write OK  */
    unsigned short RTCTCRDY        : 1; /* RTC Temperature compensation ready  */
    unsigned short RTCTCMPS        : 1; /* RTC Temperature Compensation Sign  */
  } RTCTCMP_bit;

  struct
  {
    unsigned char RTCTCMP_L;
    unsigned char RTCTCMP_H;
  };
} @ 0x04A6;

enum {
  RTCTCMP0        = 0x0001,
  RTCTCMP1        = 0x0002,
  RTCTCMP2        = 0x0004,
  RTCTCMP3        = 0x0008,
  RTCTCMP4        = 0x0010,
  RTCTCMP5        = 0x0020,
  RTCTCMP6        = 0x0040,
  RTCTCMP7        = 0x0080,
  RTCTCOK         = 0x2000,
  RTCTCRDY        = 0x4000,
  RTCTCMPS        = 0x8000
};

__no_init volatile union
{
  unsigned short RTCPS0CTL;   /* Real Timer Prescale Timer 0 Control  */

  struct
  {
    unsigned short RT0PSIFG        : 1; /* RTC Prescale Timer 0 Interrupt Flag  */
    unsigned short RT0PSIE         : 1; /* RTC Prescale Timer 0 Interrupt Enable Flag  */
    unsigned short RT0IP0          : 1; /* RTC Prescale Timer 0 Interrupt Interval Bit: 0  */
    unsigned short RT0IP1          : 1; /* RTC Prescale Timer 0 Interrupt Interval Bit: 1  */
    unsigned short RT0IP2          : 1; /* RTC Prescale Timer 0 Interrupt Interval Bit: 2  */
  } RTCPS0CTL_bit;

  struct
  {
    unsigned char RTCPS0CTL_L;
    unsigned char RTCPS0CTL_H;
  };
} @ 0x04A8;

enum {
  RT0PSIFG        = 0x0001,
  RT0PSIE         = 0x0002,
  RT0IP0          = 0x0004,
  RT0IP1          = 0x0008,
  RT0IP2          = 0x0010
};

__no_init volatile union
{
  unsigned short RTCPS1CTL;   /* Real Timer Prescale Timer 1 Control  */

  struct
  {
    unsigned short RT1PSIFG        : 1; /* RTC Prescale Timer 1 Interrupt Flag  */
    unsigned short RT1PSIE         : 1; /* RTC Prescale Timer 1 Interrupt Enable Flag  */
    unsigned short RT1IP0          : 1; /* RTC Prescale Timer 1 Interrupt Interval Bit: 0  */
    unsigned short RT1IP1          : 1; /* RTC Prescale Timer 1 Interrupt Interval Bit: 1  */
    unsigned short RT1IP2          : 1; /* RTC Prescale Timer 1 Interrupt Interval Bit: 2  */
  } RTCPS1CTL_bit;

  struct
  {
    unsigned char RTCPS1CTL_L;
    unsigned char RTCPS1CTL_H;
  };
} @ 0x04AA;

enum {
  RT1PSIFG        = 0x0001,
  RT1PSIE         = 0x0002,
  RT1IP0          = 0x0004,
  RT1IP1          = 0x0008,
  RT1IP2          = 0x0010
};

__no_init volatile union
{
  unsigned short RTCPS;   /* Real Timer Prescale Timer Control  */
  struct
  {
    unsigned char RTCPS_L;
    unsigned char RTCPS_H;
  };
} @ 0x04AC;


  /* Real Time Clock Interrupt Vector  */
__no_init volatile unsigned short RTCIV @ 0x04AE;


__no_init volatile union
{
  unsigned short RTCTIM0;   /* Real Time Clock Time 0  */
  struct
  {
    unsigned char RTCTIM0_L;
    unsigned char RTCTIM0_H;
  };
  struct
  {
    unsigned char RTCSEC;   /*  */
    unsigned char RTCMIN;   /*  */
  };
  struct
  {
    struct
    {
      unsigned char SECONDS0        : 1; /*  */
      unsigned char SECONDS1        : 1; /*  */
      unsigned char SECONDS2        : 1; /*  */
      unsigned char SECONDS3        : 1; /*  */
      unsigned char SECONDS4        : 1; /*  */
      unsigned char SECONDS5        : 1; /*  */
      unsigned char SECONDS6        : 1; /*  */
    } RTCSEC_bit;

    struct
    {
      unsigned char MINUTES0        : 1; /*  */
      unsigned char MINUTES1        : 1; /*  */
      unsigned char MINUTES2        : 1; /*  */
      unsigned char MINUTES3        : 1; /*  */
      unsigned char MINUTES4        : 1; /*  */
      unsigned char MINUTES5        : 1; /*  */
      unsigned char MINUTES6        : 1; /*  */
    } RTCMIN_bit;
  }; 
} @ 0x04B0;

__no_init volatile union
{
  unsigned short RTCTIM1;   /* Real Time Clock Time 1  */
  struct
  {
    unsigned char RTCTIM1_L;
    unsigned char RTCTIM1_H;
  };
  struct
  {
    unsigned char RTCHOUR;   /*  */
    unsigned char RTCDOW;   /*  */
  };
  struct
  {
    struct
    {
      unsigned char HOUR0           : 1; /*  */
      unsigned char HOUR1           : 1; /*  */
      unsigned char HOUR2           : 1; /*  */
      unsigned char HOUR3           : 1; /*  */
      unsigned char HOUR4           : 1; /*  */
      unsigned char HOUR5           : 1; /*  */
      unsigned char HOUR6           : 1; /*  */
    } RTCHOUR_bit;

    struct
    {
      unsigned char DOW0            : 1; /*  */
      unsigned char DOW1            : 1; /*  */
      unsigned char DOW2            : 1; /*  */
      unsigned char DOW3            : 1; /*  */
      unsigned char DOW4            : 1; /*  */
      unsigned char DOW5            : 1; /*  */
      unsigned char DOW6            : 1; /*  */
    } RTCDOW_bit;
  }; 
} @ 0x04B2;

__no_init volatile union
{
  unsigned short RTCDATE;   /* Real Time Clock Date  */
  struct
  {
    unsigned char RTCDATE_L;
    unsigned char RTCDATE_H;
  };
  struct
  {
    unsigned char RTCDAY;   /*  */
    unsigned char RTCMON;   /*  */
  };
  struct
  {
    struct
    {
      unsigned char DAY0            : 1; /*  */
      unsigned char DAY1            : 1; /*  */
      unsigned char DAY2            : 1; /*  */
      unsigned char DAY3            : 1; /*  */
      unsigned char DAY4            : 1; /*  */
      unsigned char DAY5            : 1; /*  */
      unsigned char DAY6            : 1; /*  */
    } RTCDAY_bit;

    struct
    {
      unsigned char MONTH0          : 1; /*  */
      unsigned char MONTH1          : 1; /*  */
      unsigned char MONTH2          : 1; /*  */
      unsigned char MONTH3          : 1; /*  */
      unsigned char MONTH4          : 1; /*  */
      unsigned char MONTH5          : 1; /*  */
      unsigned char MONTH6          : 1; /*  */
    } RTCMON_bit;
  }; 
} @ 0x04B4;

__no_init volatile union
{
  unsigned short RTCYEAR;   /* Real Time Clock Year  */
  struct
  {
    unsigned char RTCYEAR_L;
    unsigned char RTCYEAR_H;
  };
} @ 0x04B6;

__no_init volatile union
{
  unsigned short RTCAMINHR;   /* Real Time Clock Alarm Min/Hour  */
  struct
  {
    unsigned char RTCAMINHR_L;
    unsigned char RTCAMINHR_H;
  };
  struct
  {
    unsigned char RTCAMIN;   /* Real Time Clock Alarm Min  */
    unsigned char RTCAHOUR;   /* Real Time Clock Alarm Hour  */
  };
  struct
  {
    struct
    {
      unsigned char MINUTES0        : 1; /*  */
      unsigned char MINUTES1        : 1; /*  */
      unsigned char MINUTES2        : 1; /*  */
      unsigned char MINUTES3        : 1; /*  */
      unsigned char MINUTES4        : 1; /*  */
      unsigned char MINUTES5        : 1; /*  */
      unsigned char MINUTES6        : 1; /*  */
      unsigned char RTCAE           : 1; /* Real Time Clock Alarm enable  */
    } RTCAMIN_bit;

    struct
    {
      unsigned char HOUR0           : 1; /*  */
      unsigned char HOUR1           : 1; /*  */
      unsigned char HOUR2           : 1; /*  */
      unsigned char HOUR3           : 1; /*  */
      unsigned char HOUR4           : 1; /*  */
      unsigned char HOUR5           : 1; /*  */
      unsigned char HOUR6           : 1; /*  */
      unsigned char RTCAE           : 1; /* Real Time Clock Alarm enable  */
    } RTCAHOUR_bit;
  }; 
} @ 0x04B8;

__no_init volatile union
{
  unsigned short RTCADOWDAY;   /* Real Time Clock Alarm day of week/day  */
  struct
  {
    unsigned char RTCADOWDAY_L;
    unsigned char RTCADOWDAY_H;
  };
  struct
  {
    unsigned char RTCADOW;   /* Real Time Clock Alarm day of week  */
    unsigned char RTCADAY;   /* Real Time Clock Alarm day  */
  };
  struct
  {
    struct
    {
      unsigned char DOW0            : 1; /*  */
      unsigned char DOW1            : 1; /*  */
      unsigned char DOW2            : 1; /*  */
      unsigned char DOW3            : 1; /*  */
      unsigned char DOW4            : 1; /*  */
      unsigned char DOW5            : 1; /*  */
      unsigned char DOW6            : 1; /*  */
      unsigned char RTCAE           : 1; /* Real Time Clock Alarm enable  */
    } RTCADOW_bit;

    struct
    {
      unsigned char DAY0            : 1; /*  */
      unsigned char DAY1            : 1; /*  */
      unsigned char DAY2            : 1; /*  */
      unsigned char DAY3            : 1; /*  */
      unsigned char DAY4            : 1; /*  */
      unsigned char DAY5            : 1; /*  */
      unsigned char DAY6            : 1; /*  */
      unsigned char RTCAE           : 1; /* Real Time Clock Alarm enable  */
    } RTCADAY_bit;
  }; 
} @ 0x04BA;


  /* Real Time Binary-to-BCD conversion register  */
__no_init volatile unsigned short BIN2BCD @ 0x04BC;



  /* Real Time BCD-to-binary conversion register  */
__no_init volatile unsigned short BCD2BIN @ 0x04BE;


enum {
  SECONDS0        = 0x0001,
  SECONDS1        = 0x0002,
  SECONDS2        = 0x0004,
  SECONDS3        = 0x0008,
  SECONDS4        = 0x0010,
  SECONDS5        = 0x0020,
  SECONDS6        = 0x0040
};

enum {
  MINUTES0        = 0x0001,
  MINUTES1        = 0x0002,
  MINUTES2        = 0x0004,
  MINUTES3        = 0x0008,
  MINUTES4        = 0x0010,
  MINUTES5        = 0x0020,
  MINUTES6        = 0x0040
};

enum {
  HOUR0           = 0x0001,
  HOUR1           = 0x0002,
  HOUR2           = 0x0004,
  HOUR3           = 0x0008,
  HOUR4           = 0x0010,
  HOUR5           = 0x0020,
  HOUR6           = 0x0040
};

enum {
  DOW0            = 0x0001,
  DOW1            = 0x0002,
  DOW2            = 0x0004,
  DOW3            = 0x0008,
  DOW4            = 0x0010,
  DOW5            = 0x0020,
  DOW6            = 0x0040
};

enum {
  DAY0            = 0x0001,
  DAY1            = 0x0002,
  DAY2            = 0x0004,
  DAY3            = 0x0008,
  DAY4            = 0x0010,
  DAY5            = 0x0020,
  DAY6            = 0x0040
};

enum {
  MONTH0          = 0x0001,
  MONTH1          = 0x0002,
  MONTH2          = 0x0004,
  MONTH3          = 0x0008,
  MONTH4          = 0x0010,
  MONTH5          = 0x0020,
  MONTH6          = 0x0040
};

enum {
/*  MINUTES0        = 0x0001, */
/*  MINUTES1        = 0x0002, */
/*  MINUTES2        = 0x0004, */
/*  MINUTES3        = 0x0008, */
/*  MINUTES4        = 0x0010, */
/*  MINUTES5        = 0x0020, */
/*  MINUTES6        = 0x0040, */
  RTCAE           = 0x0080
};

/*
enum {
  HOUR0           = 0x0001,
  HOUR1           = 0x0002,
  HOUR2           = 0x0004,
  HOUR3           = 0x0008,
  HOUR4           = 0x0010,
  HOUR5           = 0x0020,
  HOUR6           = 0x0040,
  RTCAE           = 0x0080,
};

*/
/*
enum {
  DOW0            = 0x0001,
  DOW1            = 0x0002,
  DOW2            = 0x0004,
  DOW3            = 0x0008,
  DOW4            = 0x0010,
  DOW5            = 0x0020,
  DOW6            = 0x0040,
  RTCAE           = 0x0080,
};

*/
/*
enum {
  DAY0            = 0x0001,
  DAY1            = 0x0002,
  DAY2            = 0x0004,
  DAY3            = 0x0008,
  DAY4            = 0x0010,
  DAY5            = 0x0020,
  DAY6            = 0x0040,
  RTCAE           = 0x0080
};
*/



#define __MSP430_HAS_RTC_C__          /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_RTC_C__ 0x04A0
#define RTC_C_BASE __MSP430_BASEADDRESS_RTC_C__
#define RTCPWD              RTCCTL0_H
#define RTCCTL1             RTCCTL13_L
#define RTCCTL3             RTCCTL13_H
#define RTCYEARL            RTCYEAR_L
#define RT0PS               RTCPS_L
#define RT1PS               RTCPS_H
/* RTCCTL0 Control Bits */
#define RTCOFIE_L           (0x0080u)   /* RTC 32kHz cyrstal oscillator fault interrupt enable */
#define RTCTEVIE_L          (0x0040u)   /* RTC Time Event Interrupt Enable Flag */
#define RTCAIE_L            (0x0020u)   /* RTC Alarm Interrupt Enable Flag */
#define RTCRDYIE_L          (0x0010u)   /* RTC Ready Interrupt Enable Flag */
#define RTCOFIFG_L          (0x0008u)   /* RTC 32kHz cyrstal oscillator fault interrupt flag */
#define RTCTEVIFG_L         (0x0004u)   /* RTC Time Event Interrupt Flag */
#define RTCAIFG_L           (0x0002u)   /* RTC Alarm Interrupt Flag */
#define RTCRDYIFG_L         (0x0001u)   /* RTC Ready Interrupt Flag */

#define RTCKEY              (0xA500u)   /* RTC Key for RTC write access */
#define RTCKEY_H            (0xA5)     /* RTC Key for RTC write access (high word) */
/* RTCCTL13 Control Bits */
#define RTCBCD_L            (0x0080u)   /* RTC BCD  0:Binary / 1:BCD */
#define RTCHOLD_L           (0x0040u)   /* RTC Hold */
#define RTCMODE_L           (0x0020u)   /* RTC Mode 0:Counter / 1: Calendar */
#define RTCRDY_L            (0x0010u)   /* RTC Ready */
#define RTCSSEL1_L          (0x0008u)   /* RTC Source Select 1 */
#define RTCSSEL0_L          (0x0004u)   /* RTC Source Select 0 */
#define RTCTEV1_L           (0x0002u)   /* RTC Time Event 1 */
#define RTCTEV0_L           (0x0001u)   /* RTC Time Event 0 */
/* RTCCTL13 Control Bits */
#define RTCCALF1_H          (0x0002u)   /* RTC Calibration Frequency Bit 1 */
#define RTCCALF0_H          (0x0001u)   /* RTC Calibration Frequency Bit 0 */

#define RTCSSEL_0           (0x0000u)   /* RTC Source Select ACLK */
#define RTCSSEL_1           (0x0004u)   /* RTC Source Select SMCLK */
#define RTCSSEL_2           (0x0008u)   /* RTC Source Select RT1PS */
#define RTCSSEL_3           (0x000Cu)   /* RTC Source Select RT1PS */
#define RTCSSEL__LFXT       (0x0000u)   /* RTC Source Select LFXT */
#define RTCSSEL__RT1PS      (0x0008u)   /* RTC Source Select RT1PS */

#define RTCSSEL__ACLK       (0x0000u)   /* Legacy define */

#define RTCTEV_0            (0x0000u)   /* RTC Time Event: 0 (Min. changed) */
#define RTCTEV_1            (0x0001u)   /* RTC Time Event: 1 (Hour changed) */
#define RTCTEV_2            (0x0002u)   /* RTC Time Event: 2 (12:00 changed) */
#define RTCTEV_3            (0x0003u)   /* RTC Time Event: 3 (00:00 changed) */
#define RTCTEV__MIN         (0x0000u)   /* RTC Time Event: 0 (Min. changed) */
#define RTCTEV__HOUR        (0x0001u)   /* RTC Time Event: 1 (Hour changed) */
#define RTCTEV__0000        (0x0002u)   /* RTC Time Event: 2 (00:00 changed) */
#define RTCTEV__1200        (0x0003u)   /* RTC Time Event: 3 (12:00 changed) */

#define RTCCALF_0           (0x0000u)   /* RTC Calibration Frequency: No Output */
#define RTCCALF_1           (0x0100u)   /* RTC Calibration Frequency: 512 Hz */
#define RTCCALF_2           (0x0200u)   /* RTC Calibration Frequency: 256 Hz */
#define RTCCALF_3           (0x0300u)   /* RTC Calibration Frequency: 1 Hz */
/* RTCOCAL Control Bits */
#define RTCOCAL7_L          (0x0080u)   /* RTC Offset Calibration Bit 7 */
#define RTCOCAL6_L          (0x0040u)   /* RTC Offset Calibration Bit 6 */
#define RTCOCAL5_L          (0x0020u)   /* RTC Offset Calibration Bit 5 */
#define RTCOCAL4_L          (0x0010u)   /* RTC Offset Calibration Bit 4 */
#define RTCOCAL3_L          (0x0008u)   /* RTC Offset Calibration Bit 3 */
#define RTCOCAL2_L          (0x0004u)   /* RTC Offset Calibration Bit 2 */
#define RTCOCAL1_L          (0x0002u)   /* RTC Offset Calibration Bit 1 */
#define RTCOCAL0_L          (0x0001u)   /* RTC Offset Calibration Bit 0 */
/* RTCOCAL Control Bits */
#define RTCOCALS_H          (0x0080u)   /* RTC Offset Calibration Sign */
/* RTCTCMP Control Bits */
#define RTCTCMP7_L          (0x0080u)   /* RTC Temperature Compensation Bit 7 */
#define RTCTCMP6_L          (0x0040u)   /* RTC Temperature Compensation Bit 6 */
#define RTCTCMP5_L          (0x0020u)   /* RTC Temperature Compensation Bit 5 */
#define RTCTCMP4_L          (0x0010u)   /* RTC Temperature Compensation Bit 4 */
#define RTCTCMP3_L          (0x0008u)   /* RTC Temperature Compensation Bit 3 */
#define RTCTCMP2_L          (0x0004u)   /* RTC Temperature Compensation Bit 2 */
#define RTCTCMP1_L          (0x0002u)   /* RTC Temperature Compensation Bit 1 */
#define RTCTCMP0_L          (0x0001u)   /* RTC Temperature Compensation Bit 0 */
/* RTCTCMP Control Bits */
#define RTCTCMPS_H          (0x0080u)   /* RTC Temperature Compensation Sign */
#define RTCTCRDY_H          (0x0040u)   /* RTC Temperature compensation ready */
#define RTCTCOK_H           (0x0020u)   /* RTC Temperature compensation write OK */
#define RT0IP2_L            (0x0010u)   /* RTC Prescale Timer 0 Interrupt Interval Bit: 2 */
#define RT0IP1_L            (0x0008u)   /* RTC Prescale Timer 0 Interrupt Interval Bit: 1 */
#define RT0IP0_L            (0x0004u)   /* RTC Prescale Timer 0 Interrupt Interval Bit: 0 */
#define RT0PSIE_L           (0x0002u)   /* RTC Prescale Timer 0 Interrupt Enable Flag */
#define RT0PSIFG_L          (0x0001u)   /* RTC Prescale Timer 0 Interrupt Flag */

#define RT0IP_0             (0x0000u)   /* RTC Prescale Timer 0 Interrupt Interval /2 */
#define RT0IP_1             (0x0004u)   /* RTC Prescale Timer 0 Interrupt Interval /4 */
#define RT0IP_2             (0x0008u)   /* RTC Prescale Timer 0 Interrupt Interval /8 */
#define RT0IP_3             (0x000Cu)   /* RTC Prescale Timer 0 Interrupt Interval /16 */
#define RT0IP_4             (0x0010u)   /* RTC Prescale Timer 0 Interrupt Interval /32 */
#define RT0IP_5             (0x0014u)   /* RTC Prescale Timer 0 Interrupt Interval /64 */
#define RT0IP_6             (0x0018u)   /* RTC Prescale Timer 0 Interrupt Interval /128 */
#define RT0IP_7             (0x001Cu)   /* RTC Prescale Timer 0 Interrupt Interval /256 */
#define RT1IP2_L            (0x0010u)   /* RTC Prescale Timer 1 Interrupt Interval Bit: 2 */
#define RT1IP1_L            (0x0008u)   /* RTC Prescale Timer 1 Interrupt Interval Bit: 1 */
#define RT1IP0_L            (0x0004u)   /* RTC Prescale Timer 1 Interrupt Interval Bit: 0 */
#define RT1PSIE_L           (0x0002u)   /* RTC Prescale Timer 1 Interrupt Enable Flag */
#define RT1PSIFG_L          (0x0001u)   /* RTC Prescale Timer 1 Interrupt Flag */

#define RT1IP_0             (0x0000u)   /* RTC Prescale Timer 1 Interrupt Interval /2 */
#define RT1IP_1             (0x0004u)   /* RTC Prescale Timer 1 Interrupt Interval /4 */
#define RT1IP_2             (0x0008u)   /* RTC Prescale Timer 1 Interrupt Interval /8 */
#define RT1IP_3             (0x000Cu)   /* RTC Prescale Timer 1 Interrupt Interval /16 */
#define RT1IP_4             (0x0010u)   /* RTC Prescale Timer 1 Interrupt Interval /32 */
#define RT1IP_5             (0x0014u)   /* RTC Prescale Timer 1 Interrupt Interval /64 */
#define RT1IP_6             (0x0018u)   /* RTC Prescale Timer 1 Interrupt Interval /128 */
#define RT1IP_7             (0x001Cu)   /* RTC Prescale Timer 1 Interrupt Interval /256 */
/* RTC Definitions */
#define RTCIV_NONE         (0x0000u)    /* No Interrupt pending */
#define RTCIV_RTCOFIFG     (0x0002u)    /* RTC Osc fault: RTCOFIFG */
#define RTCIV_RTCRDYIFG    (0x0004u)    /* RTC ready: RTCRDYIFG */
#define RTCIV_RTCTEVIFG    (0x0006u)    /* RTC interval timer: RTCTEVIFG */
#define RTCIV_RTCAIFG      (0x0008u)    /* RTC user alarm: RTCAIFG */
#define RTCIV_RT0PSIFG     (0x000Au)    /* RTC prescaler 0: RT0PSIFG */
#define RTCIV_RT1PSIFG     (0x000Cu)    /* RTC prescaler 1: RT1PSIFG */
/* Legacy Definitions */
#define RTC_NONE           (0x0000u)    /* No Interrupt pending */
#define RTC_RTCOFIFG       (0x0002u)    /* RTC Osc fault: RTCOFIFG */
#define RTC_RTCRDYIFG      (0x0004u)    /* RTC ready: RTCRDYIFG */
#define RTC_RTCTEVIFG      (0x0006u)    /* RTC interval timer: RTCTEVIFG */
#define RTC_RTCAIFG        (0x0008u)    /* RTC user alarm: RTCAIFG */
#define RTC_RT0PSIFG       (0x000Au)    /* RTC prescaler 0: RT0PSIFG */
#define RTC_RT1PSIFG       (0x000Cu)    /* RTC prescaler 1: RT1PSIFG */

/*-------------------------------------------------------------------------
 *   SD24_B3
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short SD24BCTL0;   /* SD24B Control Register 0  */

  struct
  {
    unsigned short                : 1;
    unsigned short SD24OV32        : 1; /* SD24B Overflow Control  */
    unsigned short SD24REFS        : 1; /* SD24B Reference Select  */
    unsigned short                : 1;
    unsigned short SD24SSEL0       : 1; /* SD24B Clock Source Select 0  */
    unsigned short SD24SSEL1       : 1; /* SD24B Clock Source Select 1  */
    unsigned short SD24M4          : 1; /* SD24B Modulator clock to Manchester decoder clock ratio  */
    unsigned short SD24CLKOS       : 1; /* SD24B Clock Output Select  */
    unsigned short SD24PDIV0       : 1; /* SD24B Frequency pre-scaler Bit 0  */
    unsigned short SD24PDIV1       : 1; /* SD24B Frequency pre-scaler Bit 1  */
    unsigned short SD24PDIV2       : 1; /* SD24B Frequency pre-scaler Bit 2  */
    unsigned short SD24DIV0        : 1; /* SD24B Frequency Divider Bit 0  */
    unsigned short SD24DIV1        : 1; /* SD24B Frequency Divider Bit 1  */
    unsigned short SD24DIV2        : 1; /* SD24B Frequency Divider Bit 2  */
    unsigned short SD24DIV3        : 1; /* SD24B Frequency Divider Bit 3  */
    unsigned short SD24DIV4        : 1; /* SD24B Frequency Divider Bit 4  */
  } SD24BCTL0_bit;

  struct
  {
    unsigned char SD24BCTL0_L;
    unsigned char SD24BCTL0_H;
  };
} @ 0x0800;

enum {
  SD24OV32        = 0x0002,
  SD24REFS        = 0x0004,
  SD24SSEL0       = 0x0010,
  SD24SSEL1       = 0x0020,
  SD24M4          = 0x0040,
  SD24CLKOS       = 0x0080,
  SD24PDIV0       = 0x0100,
  SD24PDIV1       = 0x0200,
  SD24PDIV2       = 0x0400,
  SD24DIV0        = 0x0800,
  SD24DIV1        = 0x1000,
  SD24DIV2        = 0x2000,
  SD24DIV3        = 0x4000,
  SD24DIV4        = 0x8000
};

__no_init volatile union
{
  unsigned short SD24BCTL1;   /* SD24B Control Register 1  */

  struct
  {
    unsigned short SD24GRP0SC      : 1; /* SD24B Group 0 Start Conversion  */
    unsigned short SD24GRP1SC      : 1; /* SD24B Group 1 Start Conversion  */
    unsigned short SD24GRP2SC      : 1; /* SD24B Group 2 Start Conversion  */
    unsigned short SD24GRP3SC      : 1; /* SD24B Group 3 Start Conversion  */
    unsigned short                : 4;
    unsigned short SD24DMA0        : 1; /* SD24B DMA Trigger Select Bit 0  */
    unsigned short SD24DMA1        : 1; /* SD24B DMA Trigger Select Bit 1  */
    unsigned short SD24DMA2        : 1; /* SD24B DMA Trigger Select Bit 2  */
    unsigned short SD24DMA3        : 1; /* SD24B DMA Trigger Select Bit 3  */
  } SD24BCTL1_bit;

  struct
  {
    unsigned char SD24BCTL1_L;
    unsigned char SD24BCTL1_H;
  };
} @ 0x0802;

enum {
  SD24GRP0SC      = 0x0001,
  SD24GRP1SC      = 0x0002,
  SD24GRP2SC      = 0x0004,
  SD24GRP3SC      = 0x0008,
  SD24DMA0        = 0x0100,
  SD24DMA1        = 0x0200,
  SD24DMA2        = 0x0400,
  SD24DMA3        = 0x0800
};

__no_init volatile union
{
  unsigned short SD24BIFG;   /* SD24B Interrupt Flag Register  */

  struct
  {
    unsigned short SD24IFG0        : 1; /* SD24B Channel 0 Interrupt Flag  */
    unsigned short SD24IFG1        : 1; /* SD24B Channel 1 Interrupt Flag  */
    unsigned short SD24IFG2        : 1; /* SD24B Channel 2 Interrupt Flag  */
    unsigned short                : 5;
    unsigned short SD24OVIFG0      : 1; /* SD24B Channel 0 Overflow Interrupt Flag  */
    unsigned short SD24OVIFG1      : 1; /* SD24B Channel 1 Overflow Interrupt Flag  */
    unsigned short SD24OVIFG2      : 1; /* SD24B Channel 2 Overflow Interrupt Flag  */
  } SD24BIFG_bit;

  struct
  {
    unsigned char SD24BIFG_L;
    unsigned char SD24BIFG_H;
  };
} @ 0x080A;

enum {
  SD24IFG0        = 0x0001,
  SD24IFG1        = 0x0002,
  SD24IFG2        = 0x0004,
  SD24OVIFG0      = 0x0100,
  SD24OVIFG1      = 0x0200,
  SD24OVIFG2      = 0x0400
};

__no_init volatile union
{
  unsigned short SD24BIE;   /* SD24B Interrupt Enable Register  */

  struct
  {
    unsigned short SD24IE0         : 1; /* SD24B Channel 0 Interrupt Enable  */
    unsigned short SD24IE1         : 1; /* SD24B Channel 1 Interrupt Enable  */
    unsigned short SD24IE2         : 1; /* SD24B Channel 2 Interrupt Enable  */
    unsigned short                : 5;
    unsigned short SD24OVIE0       : 1; /* SD24B Channel 0 Overflow Interrupt Enable  */
    unsigned short SD24OVIE1       : 1; /* SD24B Channel 1 Overflow Interrupt Enable  */
    unsigned short SD24OVIE2       : 1; /* SD24B Channel 2 Overflow Interrupt Enable  */
  } SD24BIE_bit;

  struct
  {
    unsigned char SD24BIE_L;
    unsigned char SD24BIE_H;
  };
} @ 0x080C;

enum {
  SD24IE0         = 0x0001,
  SD24IE1         = 0x0002,
  SD24IE2         = 0x0004,
  SD24OVIE0       = 0x0100,
  SD24OVIE1       = 0x0200,
  SD24OVIE2       = 0x0400
};

__no_init volatile union
{
  unsigned short SD24BIV;   /* SD24B Interrupt Vector Register  */
  struct
  {
    unsigned char SD24BIV_L;
    unsigned char SD24BIV_H;
  };
} @ 0x080E;

__no_init volatile union
{
  unsigned short SD24BCCTL0;   /* SD24B Channel 0 Control Register  */

  struct
  {
    unsigned short SD24SC          : 1; /* SD24B Start Conversion  */
    unsigned short SD24SCS0        : 1; /* SD24B Start Conversion Select Bit 0  */
    unsigned short SD24SCS1        : 1; /* SD24B Start Conversion Select Bit 1  */
    unsigned short SD24SCS2        : 1; /* SD24B Start Conversion Select Bit 2  */
    unsigned short SD24DF0         : 1; /* SD24B Data Format Bit: 0  */
    unsigned short SD24DF1         : 1; /* SD24B Data Format Bit: 1  */
    unsigned short SD24ALGN        : 1; /* SD24B Data Alignment  */
    unsigned short                : 1;
    unsigned short SD24SNGL        : 1; /* SD24B Single Trigger Mode  */
    unsigned short SD24CAL         : 1; /* SD24B Calibration  */
    unsigned short SD24DFS0        : 1; /* SD24B Digital Filter Bit: 0  */
    unsigned short SD24DFS1        : 1; /* SD24B Digital Filter Bit: 1  */
    unsigned short SD24DI          : 1; /* SD24B Digital Bitstream Input  */
    unsigned short SD24MC0         : 1; /* SD24B Manchaster Encoding Bit: 0  */
    unsigned short SD24MC1         : 1; /* SD24B Manchaster Encoding Bit: 1  */
  } SD24BCCTL0_bit;

  struct
  {
    unsigned char SD24BCCTL0_L;
    unsigned char SD24BCCTL0_H;
  };
} @ 0x0810;

enum {
  SD24SC          = 0x0001,
  SD24SCS0        = 0x0002,
  SD24SCS1        = 0x0004,
  SD24SCS2        = 0x0008,
  SD24DF0         = 0x0010,
  SD24DF1         = 0x0020,
  SD24ALGN        = 0x0040,
  SD24SNGL        = 0x0100,
  SD24CAL         = 0x0200,
  SD24DFS0        = 0x0400,
  SD24DFS1        = 0x0800,
  SD24DI          = 0x1000,
  SD24MC0         = 0x2000,
  SD24MC1         = 0x4000
};

__no_init volatile union
{
  unsigned short SD24BINCTL0;   /* SD24B Channel 0 Input Control Register  */

  struct
  {
    unsigned short                : 3;
    unsigned short SD24GAIN0       : 1; /* SD24B Input Pre-Amplifier Gain Select 0  */
    unsigned short SD24GAIN1       : 1; /* SD24B Input Pre-Amplifier Gain Select 1  */
    unsigned short SD24GAIN2       : 1; /* SD24B Input Pre-Amplifier Gain Select 2  */
    unsigned short SD24INTDLY0     : 1; /* SD24B Interrupt Delay after 1.Conversion 0  */
    unsigned short SD24INTDLY1     : 1; /* SD24B Interrupt Delay after 1.Conversion 1  */
  } SD24BINCTL0_bit;

  struct
  {
    unsigned char SD24BINCTL0_L;
    unsigned char SD24BINCTL0_H;
  };
} @ 0x0812;

enum {
  SD24GAIN0       = 0x0008,
  SD24GAIN1       = 0x0010,
  SD24GAIN2       = 0x0020,
  SD24INTDLY0     = 0x0040,
  SD24INTDLY1     = 0x0080
};

__no_init volatile union
{
  unsigned short SD24BOSR0;   /* SD24B Channel 0 OSR Control Register  */

  struct
  {
    unsigned short OSR0            : 1; /* SD24B Oversampling Rate Bit: 0  */
    unsigned short OSR1            : 1; /* SD24B Oversampling Rate Bit: 1  */
    unsigned short OSR2            : 1; /* SD24B Oversampling Rate Bit: 2  */
    unsigned short OSR3            : 1; /* SD24B Oversampling Rate Bit: 3  */
    unsigned short OSR4            : 1; /* SD24B Oversampling Rate Bit: 4  */
    unsigned short OSR5            : 1; /* SD24B Oversampling Rate Bit: 5  */
    unsigned short OSR6            : 1; /* SD24B Oversampling Rate Bit: 6  */
    unsigned short OSR7            : 1; /* SD24B Oversampling Rate Bit: 7  */
    unsigned short OSR8            : 1; /* SD24B Oversampling Rate Bit: 8  */
    unsigned short OSR9            : 1; /* SD24B Oversampling Rate Bit: 9  */
    unsigned short OSR10           : 1; /* SD24B Oversampling Rate Bit: 10  */
  } SD24BOSR0_bit;

  struct
  {
    unsigned char SD24BOSR0_L;
    unsigned char SD24BOSR0_H;
  };
} @ 0x0814;

enum {
  OSR0            = 0x0001,
  OSR1            = 0x0002,
  OSR2            = 0x0004,
  OSR3            = 0x0008,
  OSR4            = 0x0010,
  OSR5            = 0x0020,
  OSR6            = 0x0040,
  OSR7            = 0x0080,
  OSR8            = 0x0100,
  OSR9            = 0x0200,
  OSR10           = 0x0400
};

__no_init volatile union
{
  unsigned short SD24BPRE0;   /* SD24B Channel 0 Preload Register  */
  struct
  {
    unsigned char SD24BPRE0_L;
    unsigned char SD24BPRE0_H;
  };
} @ 0x0816;

__no_init volatile union
{
  unsigned short SD24BCCTL1;   /* SD24B Channel 1 Control Register  */

  struct
  {
    unsigned short SD24SC          : 1; /* SD24B Start Conversion  */
    unsigned short SD24SCS0        : 1; /* SD24B Start Conversion Select Bit 0  */
    unsigned short SD24SCS1        : 1; /* SD24B Start Conversion Select Bit 1  */
    unsigned short SD24SCS2        : 1; /* SD24B Start Conversion Select Bit 2  */
    unsigned short SD24DF0         : 1; /* SD24B Data Format Bit: 0  */
    unsigned short SD24DF1         : 1; /* SD24B Data Format Bit: 1  */
    unsigned short SD24ALGN        : 1; /* SD24B Data Alignment  */
    unsigned short                : 1;
    unsigned short SD24SNGL        : 1; /* SD24B Single Trigger Mode  */
    unsigned short SD24CAL         : 1; /* SD24B Calibration  */
    unsigned short SD24DFS0        : 1; /* SD24B Digital Filter Bit: 0  */
    unsigned short SD24DFS1        : 1; /* SD24B Digital Filter Bit: 1  */
    unsigned short SD24DI          : 1; /* SD24B Digital Bitstream Input  */
    unsigned short SD24MC0         : 1; /* SD24B Manchaster Encoding Bit: 0  */
    unsigned short SD24MC1         : 1; /* SD24B Manchaster Encoding Bit: 1  */
  } SD24BCCTL1_bit;

  struct
  {
    unsigned char SD24BCCTL1_L;
    unsigned char SD24BCCTL1_H;
  };
} @ 0x0818;

/*
enum {
  SD24SC          = 0x0001,
  SD24SCS0        = 0x0002,
  SD24SCS1        = 0x0004,
  SD24SCS2        = 0x0008,
  SD24DF0         = 0x0010,
  SD24DF1         = 0x0020,
  SD24ALGN        = 0x0040,
  SD24SNGL        = 0x0100,
  SD24CAL         = 0x0200,
  SD24DFS0        = 0x0400,
  SD24DFS1        = 0x0800,
  SD24DI          = 0x1000,
  SD24MC0         = 0x2000,
  SD24MC1         = 0x4000,
};

*/
__no_init volatile union
{
  unsigned short SD24BINCTL1;   /* SD24B Channel 1 Input Control Register  */

  struct
  {
    unsigned short                : 3;
    unsigned short SD24GAIN0       : 1; /* SD24B Input Pre-Amplifier Gain Select 0  */
    unsigned short SD24GAIN1       : 1; /* SD24B Input Pre-Amplifier Gain Select 1  */
    unsigned short SD24GAIN2       : 1; /* SD24B Input Pre-Amplifier Gain Select 2  */
    unsigned short SD24INTDLY0     : 1; /* SD24B Interrupt Delay after 1.Conversion 0  */
    unsigned short SD24INTDLY1     : 1; /* SD24B Interrupt Delay after 1.Conversion 1  */
  } SD24BINCTL1_bit;

  struct
  {
    unsigned char SD24BINCTL1_L;
    unsigned char SD24BINCTL1_H;
  };
} @ 0x081A;

/*
enum {
  SD24GAIN0       = 0x0008,
  SD24GAIN1       = 0x0010,
  SD24GAIN2       = 0x0020,
  SD24INTDLY0     = 0x0040,
  SD24INTDLY1     = 0x0080,
};

*/
__no_init volatile union
{
  unsigned short SD24BOSR1;   /* SD24B Channel 1 OSR Control Register  */

  struct
  {
    unsigned short OSR0            : 1; /* SD24B Oversampling Rate Bit: 0  */
    unsigned short OSR1            : 1; /* SD24B Oversampling Rate Bit: 1  */
    unsigned short OSR2            : 1; /* SD24B Oversampling Rate Bit: 2  */
    unsigned short OSR3            : 1; /* SD24B Oversampling Rate Bit: 3  */
    unsigned short OSR4            : 1; /* SD24B Oversampling Rate Bit: 4  */
    unsigned short OSR5            : 1; /* SD24B Oversampling Rate Bit: 5  */
    unsigned short OSR6            : 1; /* SD24B Oversampling Rate Bit: 6  */
    unsigned short OSR7            : 1; /* SD24B Oversampling Rate Bit: 7  */
    unsigned short OSR8            : 1; /* SD24B Oversampling Rate Bit: 8  */
    unsigned short OSR9            : 1; /* SD24B Oversampling Rate Bit: 9  */
    unsigned short OSR10           : 1; /* SD24B Oversampling Rate Bit: 10  */
  } SD24BOSR1_bit;

  struct
  {
    unsigned char SD24BOSR1_L;
    unsigned char SD24BOSR1_H;
  };
} @ 0x081C;

/*
enum {
  OSR0            = 0x0001,
  OSR1            = 0x0002,
  OSR2            = 0x0004,
  OSR3            = 0x0008,
  OSR4            = 0x0010,
  OSR5            = 0x0020,
  OSR6            = 0x0040,
  OSR7            = 0x0080,
  OSR8            = 0x0100,
  OSR9            = 0x0200,
  OSR10           = 0x0400,
};

*/
__no_init volatile union
{
  unsigned short SD24BPRE1;   /* SD24B Channel 1 Preload Register  */
  struct
  {
    unsigned char SD24BPRE1_L;
    unsigned char SD24BPRE1_H;
  };
} @ 0x081E;

__no_init volatile union
{
  unsigned short SD24BCCTL2;   /* SD24B Channel 2 Control Register  */

  struct
  {
    unsigned short SD24SC          : 1; /* SD24B Start Conversion  */
    unsigned short SD24SCS0        : 1; /* SD24B Start Conversion Select Bit 0  */
    unsigned short SD24SCS1        : 1; /* SD24B Start Conversion Select Bit 1  */
    unsigned short SD24SCS2        : 1; /* SD24B Start Conversion Select Bit 2  */
    unsigned short SD24DF0         : 1; /* SD24B Data Format Bit: 0  */
    unsigned short SD24DF1         : 1; /* SD24B Data Format Bit: 1  */
    unsigned short SD24ALGN        : 1; /* SD24B Data Alignment  */
    unsigned short                : 1;
    unsigned short SD24SNGL        : 1; /* SD24B Single Trigger Mode  */
    unsigned short SD24CAL         : 1; /* SD24B Calibration  */
    unsigned short SD24DFS0        : 1; /* SD24B Digital Filter Bit: 0  */
    unsigned short SD24DFS1        : 1; /* SD24B Digital Filter Bit: 1  */
    unsigned short SD24DI          : 1; /* SD24B Digital Bitstream Input  */
    unsigned short SD24MC0         : 1; /* SD24B Manchaster Encoding Bit: 0  */
    unsigned short SD24MC1         : 1; /* SD24B Manchaster Encoding Bit: 1  */
  } SD24BCCTL2_bit;

  struct
  {
    unsigned char SD24BCCTL2_L;
    unsigned char SD24BCCTL2_H;
  };
} @ 0x0820;

/*
enum {
  SD24SC          = 0x0001,
  SD24SCS0        = 0x0002,
  SD24SCS1        = 0x0004,
  SD24SCS2        = 0x0008,
  SD24DF0         = 0x0010,
  SD24DF1         = 0x0020,
  SD24ALGN        = 0x0040,
  SD24SNGL        = 0x0100,
  SD24CAL         = 0x0200,
  SD24DFS0        = 0x0400,
  SD24DFS1        = 0x0800,
  SD24DI          = 0x1000,
  SD24MC0         = 0x2000,
  SD24MC1         = 0x4000,
};

*/
__no_init volatile union
{
  unsigned short SD24BINCTL2;   /* SD24B Channel 2 Input Control Register  */

  struct
  {
    unsigned short                : 3;
    unsigned short SD24GAIN0       : 1; /* SD24B Input Pre-Amplifier Gain Select 0  */
    unsigned short SD24GAIN1       : 1; /* SD24B Input Pre-Amplifier Gain Select 1  */
    unsigned short SD24GAIN2       : 1; /* SD24B Input Pre-Amplifier Gain Select 2  */
    unsigned short SD24INTDLY0     : 1; /* SD24B Interrupt Delay after 1.Conversion 0  */
    unsigned short SD24INTDLY1     : 1; /* SD24B Interrupt Delay after 1.Conversion 1  */
  } SD24BINCTL2_bit;

  struct
  {
    unsigned char SD24BINCTL2_L;
    unsigned char SD24BINCTL2_H;
  };
} @ 0x0822;

/*
enum {
  SD24GAIN0       = 0x0008,
  SD24GAIN1       = 0x0010,
  SD24GAIN2       = 0x0020,
  SD24INTDLY0     = 0x0040,
  SD24INTDLY1     = 0x0080,
};

*/
__no_init volatile union
{
  unsigned short SD24BOSR2;   /* SD24B Channel 2 OSR Control Register  */

  struct
  {
    unsigned short OSR0            : 1; /* SD24B Oversampling Rate Bit: 0  */
    unsigned short OSR1            : 1; /* SD24B Oversampling Rate Bit: 1  */
    unsigned short OSR2            : 1; /* SD24B Oversampling Rate Bit: 2  */
    unsigned short OSR3            : 1; /* SD24B Oversampling Rate Bit: 3  */
    unsigned short OSR4            : 1; /* SD24B Oversampling Rate Bit: 4  */
    unsigned short OSR5            : 1; /* SD24B Oversampling Rate Bit: 5  */
    unsigned short OSR6            : 1; /* SD24B Oversampling Rate Bit: 6  */
    unsigned short OSR7            : 1; /* SD24B Oversampling Rate Bit: 7  */
    unsigned short OSR8            : 1; /* SD24B Oversampling Rate Bit: 8  */
    unsigned short OSR9            : 1; /* SD24B Oversampling Rate Bit: 9  */
    unsigned short OSR10           : 1; /* SD24B Oversampling Rate Bit: 10  */
  } SD24BOSR2_bit;

  struct
  {
    unsigned char SD24BOSR2_L;
    unsigned char SD24BOSR2_H;
  };
} @ 0x0824;

/*
enum {
  OSR0            = 0x0001,
  OSR1            = 0x0002,
  OSR2            = 0x0004,
  OSR3            = 0x0008,
  OSR4            = 0x0010,
  OSR5            = 0x0020,
  OSR6            = 0x0040,
  OSR7            = 0x0080,
  OSR8            = 0x0100,
  OSR9            = 0x0200,
  OSR10           = 0x0400,
};

*/
__no_init volatile union
{
  unsigned short SD24BPRE2;   /* SD24B Channel 2 Preload Register  */
  struct
  {
    unsigned char SD24BPRE2_L;
    unsigned char SD24BPRE2_H;
  };
} @ 0x0826;

__no_init volatile union
{
  unsigned short SD24BMEML0;   /* SD24B Channel 0 Conversion Memory Low word  */
  struct
  {
    unsigned char SD24BMEML0_L;
    unsigned char SD24BMEML0_H;
  };
} @ 0x0850;

__no_init volatile union
{
  unsigned short SD24BMEMH0;   /* SD24B Channel 0 Conversion Memory High Word  */
  struct
  {
    unsigned char SD24BMEMH0_L;
    unsigned char SD24BMEMH0_H;
  };
} @ 0x0852;

__no_init volatile union
{
  unsigned short SD24BMEML1;   /* SD24B Channel 1 Conversion Memory Low word  */
  struct
  {
    unsigned char SD24BMEML1_L;
    unsigned char SD24BMEML1_H;
  };
} @ 0x0854;

__no_init volatile union
{
  unsigned short SD24BMEMH1;   /* SD24B Channel 1 Conversion Memory High Word  */
  struct
  {
    unsigned char SD24BMEMH1_L;
    unsigned char SD24BMEMH1_H;
  };
} @ 0x0856;

__no_init volatile union
{
  unsigned short SD24BMEML2;   /* SD24B Channel 2 Conversion Memory Low word  */
  struct
  {
    unsigned char SD24BMEML2_L;
    unsigned char SD24BMEML2_H;
  };
} @ 0x0858;

__no_init volatile union
{
  unsigned short SD24BMEMH2;   /* SD24B Channel 2 Conversion Memory High Word  */
  struct
  {
    unsigned char SD24BMEMH2_L;
    unsigned char SD24BMEMH2_H;
  };
} @ 0x085A;

#define __MSP430_HAS_SD24_B__         /* Definition to show that Module is available */
#define __MSP430_HAS_SD24_B3__        /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_SD24_B__ 0x0800
#define SD24_BASE __MSP430_BASEADDRESS_SD24_B__

#define SD24OV32_L          (0x0002u)  /* SD24B Overflow Control */
#define SD24REFS_L          (0x0004u)  /* SD24B Reference Select */
#define SD24SSEL0_L         (0x0010u)  /* SD24B Clock Source Select 0 */
#define SD24SSEL1_L         (0x0020u)  /* SD24B Clock Source Select 1 */
#define SD24M4_L            (0x0040u)  /* SD24B Modulator clock to Manchester decoder clock ratio */
#define SD24CLKOS_L         (0x0080u)  /* SD24B Clock Output Select */

#define SD24PDIV0_H         (0x0001u)  /* SD24B Frequency pre-scaler Bit 0 */
#define SD24PDIV1_H         (0x0002u)  /* SD24B Frequency pre-scaler Bit 1 */
#define SD24PDIV2_H         (0x0004u)  /* SD24B Frequency pre-scaler Bit 2 */
#define SD24DIV0_H          (0x0008u)  /* SD24B Frequency Divider Bit 0 */
#define SD24DIV1_H          (0x0010u)  /* SD24B Frequency Divider Bit 1 */
#define SD24DIV2_H          (0x0020u)  /* SD24B Frequency Divider Bit 2 */
#define SD24DIV3_H          (0x0040u)  /* SD24B Frequency Divider Bit 3 */
#define SD24DIV4_H          (0x0080u)  /* SD24B Frequency Divider Bit 4 */

#define SD24SSEL_0          (0x0000u)  /* SD24B Clock Source Select MCLK  */
#define SD24SSEL_1          (0x0010u)  /* SD24B Clock Source Select SMCLK */
#define SD24SSEL_2          (0x0020u)  /* SD24B Clock Source Select ACLK  */
#define SD24SSEL_3          (0x0030u)  /* SD24B Clock Source Select TACLK */
#define SD24SSEL__MCLK      (0x0000u)  /* SD24B Clock Source Select MCLK  */
#define SD24SSEL__SMCLK     (0x0010u)  /* SD24B Clock Source Select SMCLK */
#define SD24SSEL__ACLK      (0x0020u)  /* SD24B Clock Source Select ACLK  */
#define SD24SSEL__SD24CLK   (0x0030u)  /* SD24B Clock Source Select SD24CLK */

#define SD24PDIV_0          (0x0000u)  /* SD24B Frequency pre-scaler  /1 */
#define SD24PDIV_1          (0x0100u)  /* SD24B Frequency pre-scaler  /2 */
#define SD24PDIV_2          (0x0200u)  /* SD24B Frequency pre-scaler  /4 */
#define SD24PDIV_3          (0x0300u)  /* SD24B Frequency pre-scaler  /8 */
#define SD24PDIV_4          (0x0400u)  /* SD24B Frequency pre-scaler  /16 */
#define SD24PDIV_5          (0x0500u)  /* SD24B Frequency pre-scaler  /32 */
#define SD24PDIV_6          (0x0600u)  /* SD24B Frequency pre-scaler  /64 */
#define SD24PDIV_7          (0x0700u)  /* SD24B Frequency pre-scaler  /128 */

#define SD24GRP0SC_L        (0x0001u)  /* SD24B Group 0 Start Conversion */
#define SD24GRP1SC_L        (0x0002u)  /* SD24B Group 1 Start Conversion */
#define SD24GRP2SC_L        (0x0004u)  /* SD24B Group 2 Start Conversion */
#define SD24GRP3SC_L        (0x0008u)  /* SD24B Group 3 Start Conversion */

#define SD24DMA0_H          (0x0001u)  /* SD24B DMA Trigger Select Bit 0 */
#define SD24DMA1_H          (0x0002u)  /* SD24B DMA Trigger Select Bit 1 */
#define SD24DMA2_H          (0x0004u)  /* SD24B DMA Trigger Select Bit 2 */
#define SD24DMA3_H          (0x0008u)  /* SD24B DMA Trigger Select Bit 3 */

#define SD24DMA_0           (0x0000u)  /* SD24B DMA Trigger: 0 */
#define SD24DMA_1           (0x0100u)  /* SD24B DMA Trigger: 1 */
#define SD24DMA_2           (0x0200u)  /* SD24B DMA Trigger: 2 */
#define SD24DMA_3           (0x0300u)  /* SD24B DMA Trigger: 3 */
#define SD24DMA_4           (0x0400u)  /* SD24B DMA Trigger: 4 */
#define SD24DMA_5           (0x0500u)  /* SD24B DMA Trigger: 5 */
#define SD24DMA_6           (0x0600u)  /* SD24B DMA Trigger: 6 */
#define SD24DMA_7           (0x0700u)  /* SD24B DMA Trigger: 7 */
#define SD24DMA_8           (0x0800u)  /* SD24B DMA Trigger: 8 */

#define SD24IFG0_L          (0x0001u)  /* SD24B Channel 0 Interrupt Flag */
#define SD24IFG1_L          (0x0002u)  /* SD24B Channel 1 Interrupt Flag */
#define SD24IFG2_L          (0x0004u)  /* SD24B Channel 2 Interrupt Flag */

#define SD24OVIFG0_H        (0x0001u)  /* SD24B Channel 0 Overflow Interrupt Flag */
#define SD24OVIFG1_H        (0x0002u)  /* SD24B Channel 1 Overflow Interrupt Flag */
#define SD24OVIFG2_H        (0x0004u)  /* SD24B Channel 2 Overflow Interrupt Flag */

#define SD24IE0_L           (0x0001u)  /* SD24B Channel 0 Interrupt Enable */
#define SD24IE1_L           (0x0002u)  /* SD24B Channel 1 Interrupt Enable */
#define SD24IE2_L           (0x0004u)  /* SD24B Channel 2 Interrupt Enable */

#define SD24OVIE0_H         (0x0001u)  /* SD24B Channel 0 Overflow Interrupt Enable */
#define SD24OVIE1_H         (0x0002u)  /* SD24B Channel 1 Overflow Interrupt Enable */
#define SD24OVIE2_H         (0x0004u)  /* SD24B Channel 2 Overflow Interrupt Enable */
/* SD24BIV Definitions */
#define SD24BIV_NONE         (0x0000u)    /* No Interrupt pending */
#define SD24BIV_SD24OVIFG    (0x0002u)    /* SD24OVIFG */
#define SD24BIV_SD24TRGIFG   (0x0004u)    /* SD24TRGIFG */
#define SD24BIV_SD24IFG0     (0x0006u)    /* SD24IFG0 */
#define SD24BIV_SD24IFG1     (0x0008u)    /* SD24IFG1 */
#define SD24BIV_SD24IFG2     (0x000Au)    /* SD24IFG2 */

#define SD24SC_L            (0x0001u)  /* SD24B Start Conversion */
#define SD24SCS0_L          (0x0002u)  /* SD24B Start Conversion Select Bit 0 */
#define SD24SCS1_L          (0x0004u)  /* SD24B Start Conversion Select Bit 1 */
#define SD24SCS2_L          (0x0008u)  /* SD24B Start Conversion Select Bit 2 */
#define SD24DF0_L           (0x0010u)  /* SD24B Data Format Bit: 0 */
#define SD24DF1_L           (0x0020u)  /* SD24B Data Format Bit: 1 */
#define SD24ALGN_L          (0x0040u)  /* SD24B Data Alignment */

#define SD24SNGL_H          (0x0001u)  /* SD24B Single Trigger Mode */
#define SD24CAL_H           (0x0002u)  /* SD24B Calibration */
#define SD24DFS0_H          (0x0004u)  /* SD24B Digital Filter Bit: 0 */
#define SD24DFS1_H          (0x0008u)  /* SD24B Digital Filter Bit: 1 */
#define SD24DI_H            (0x0010u)  /* SD24B Digital Bitstream Input */
#define SD24MC0_H           (0x0020u)  /* SD24B Manchaster Encoding Bit: 0 */
#define SD24MC1_H           (0x0040u)  /* SD24B Manchaster Encoding Bit: 1 */

#define SD24SCS_0            (0x0000u)  /* SD24B Start Conversion Select: 0 */
#define SD24SCS_1            (0x0002u)  /* SD24B Start Conversion Select: 1 */
#define SD24SCS_2            (0x0004u)  /* SD24B Start Conversion Select: 2 */
#define SD24SCS_3            (0x0006u)  /* SD24B Start Conversion Select: 3 */
#define SD24SCS_4            (0x0008u)  /* SD24B Start Conversion Select: 4 */
#define SD24SCS_5            (0x000Au)  /* SD24B Start Conversion Select: 5 */
#define SD24SCS_6            (0x000Cu)  /* SD24B Start Conversion Select: 6 */
#define SD24SCS_7            (0x000Eu)  /* SD24B Start Conversion Select: 7 */
#define SD24SCS__SD24SC      (0x0000u)  /* SD24B Start Conversion Select: SD24SC */
#define SD24SCS__EXT1        (0x0002u)  /* SD24B Start Conversion Select: EXT1   */
#define SD24SCS__EXT2        (0x0004u)  /* SD24B Start Conversion Select: EXT2   */
#define SD24SCS__EXT3        (0x0006u)  /* SD24B Start Conversion Select: EXT3   */
#define SD24SCS__GROUP0      (0x0008u)  /* SD24B Start Conversion Select: GROUP0 */
#define SD24SCS__GROUP1      (0x000Au)  /* SD24B Start Conversion Select: GROUP1 */
#define SD24SCS__GROUP2      (0x000Cu)  /* SD24B Start Conversion Select: GROUP2 */
#define SD24SCS__GROUP3      (0x000Eu)  /* SD24B Start Conversion Select: GROUP3 */

#define SD24DF_0             (0x0000u)  /* SD24B Data Format: Offset Binary  */
#define SD24DF_1             (0x0010u)  /* SD24B Data Format: 2's complement */

#define SD24DFS_0            (0x0000u)  /* SD24B Digital Filter 0 */
#define SD24DFS_1            (0x0400u)  /* SD24B Digital Filter 1 */
#define SD24DFS_2            (0x0800u)  /* SD24B Digital Filter 2 */
#define SD24DFS_3            (0x0C00u)  /* SD24B Digital Filter 3 */

#define SD24MC_0             (0x0000u)  /* SD24B Manchaster Encoding 0 */
#define SD24MC_1             (0x2000u)  /* SD24B Manchaster Encoding 1 */
#define SD24MC_2             (0x4000u)  /* SD24B Manchaster Encoding 2 */
#define SD24MC_3             (0x6000u)  /* SD24B Manchaster Encoding 3 */

#define SD24GAIN0_L         (0x0008u)  /* SD24B Input Pre-Amplifier Gain Select 0 */
#define SD24GAIN1_L         (0x0010u)  /* SD24B Input Pre-Amplifier Gain Select 1 */
#define SD24GAIN2_L         (0x0020u)  /* SD24B Input Pre-Amplifier Gain Select 2 */
#define SD24INTDLY0_L       (0x0040u)  /* SD24B Interrupt Delay after 1.Conversion 0 */
#define SD24INTDLY1_L       (0x0080u)  /* SD24B Interrupt Delay after 1.Conversion 1 */

#define SD24GAIN_1          (0x0000u)  /* SD24B Input Pre-Amplifier Gain Select *1  */
#define SD24GAIN_2          (0x0008u)  /* SD24B Input Pre-Amplifier Gain Select *2  */
#define SD24GAIN_4          (0x0010u)  /* SD24B Input Pre-Amplifier Gain Select *4  */
#define SD24GAIN_8          (0x0018u)  /* SD24B Input Pre-Amplifier Gain Select *8  */
#define SD24GAIN_16         (0x0020u)  /* SD24B Input Pre-Amplifier Gain Select *16 */
#define SD24GAIN_32         (0x0028u)  /* SD24B Input Pre-Amplifier Gain Select *32 */
#define SD24GAIN_64         (0x0030u)  /* SD24B Input Pre-Amplifier Gain Select *64 */
#define SD24GAIN_128        (0x0038u)  /* SD24B Input Pre-Amplifier Gain Select *128 */

#define SD24INTDLY_0        (0x0000u)  /* SD24B Interrupt Delay: Int. after 4.Conversion  */
#define SD24INTDLY_1        (0x0040u)  /* SD24B Interrupt Delay: Int. after 3.Conversion  */
#define SD24INTDLY_2        (0x0080u)  /* SD24B Interrupt Delay: Int. after 2.Conversion  */
#define SD24INTDLY_3        (0x00C0u)  /* SD24B Interrupt Delay: Int. after 1.Conversion  */

#define OSR0_L              (0x0001u)  /* SD24B Oversampling Rate Bit: 0 */
#define OSR1_L              (0x0002u)  /* SD24B Oversampling Rate Bit: 1 */
#define OSR2_L              (0x0004u)  /* SD24B Oversampling Rate Bit: 2 */
#define OSR3_L              (0x0008u)  /* SD24B Oversampling Rate Bit: 3 */
#define OSR4_L              (0x0010u)  /* SD24B Oversampling Rate Bit: 4 */
#define OSR5_L              (0x0020u)  /* SD24B Oversampling Rate Bit: 5 */
#define OSR6_L              (0x0040u)  /* SD24B Oversampling Rate Bit: 6 */
#define OSR7_L              (0x0080u)  /* SD24B Oversampling Rate Bit: 7 */

#define OSR8_H              (0x0001u)  /* SD24B Oversampling Rate Bit: 8 */
#define OSR9_H              (0x0002u)  /* SD24B Oversampling Rate Bit: 9 */
#define OSR10_H             (0x0004u)  /* SD24B Oversampling Rate Bit: 10 */

#define OSR__32             (32-1)    /* SD24B Oversampling Rate: 32 */
#define OSR__64             (64-1)    /* SD24B Oversampling Rate: 64 */
#define OSR__128            (128-1)   /* SD24B Oversampling Rate: 128 */
#define OSR__256            (256-1)   /* SD24B Oversampling Rate: 256 */
#define OSR__512            (512-1)   /* SD24B Oversampling Rate: 512 */
#define OSR__1024           (1024-1)  /* SD24B Oversampling Rate: 1024 */

/*-------------------------------------------------------------------------
 *   SFR  Special Function Registers
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short SFRIE1;   /* Interrupt Enable 1  */

  struct
  {
    unsigned short WDTIE           : 1; /* WDT Interrupt Enable  */
    unsigned short OFIE            : 1; /* Osc Fault Enable  */
    unsigned short                : 1;
    unsigned short VMAIE           : 1; /* Vacant Memory Interrupt Enable  */
    unsigned short NMIIE           : 1; /* NMI Interrupt Enable  */
    unsigned short ACCVIE          : 1; /* Flash Access Violation Interrupt Enable  */
    unsigned short JMBINIE         : 1; /* JTAG Mail Box input Interrupt Enable  */
    unsigned short JMBOUTIE        : 1; /* JTAG Mail Box output Interrupt Enable  */
  } SFRIE1_bit;

  struct
  {
    unsigned char SFRIE1_L;
    unsigned char SFRIE1_H;
  };
} @ 0x0100;

enum {
  WDTIE           = 0x0001,
  OFIE            = 0x0002,
  VMAIE           = 0x0008,
  NMIIE           = 0x0010,
  ACCVIE          = 0x0020,
  JMBINIE         = 0x0040,
  JMBOUTIE        = 0x0080
};

__no_init volatile union
{
  unsigned short SFRIFG1;   /* Interrupt Flag 1  */

  struct
  {
    unsigned short WDTIFG          : 1; /* WDT Interrupt Flag  */
    unsigned short OFIFG           : 1; /* Osc Fault Flag  */
    unsigned short                : 1;
    unsigned short VMAIFG          : 1; /* Vacant Memory Interrupt Flag  */
    unsigned short NMIIFG          : 1; /* NMI Interrupt Flag  */
    unsigned short                : 1;
    unsigned short JMBINIFG        : 1; /* JTAG Mail Box input Interrupt Flag  */
    unsigned short JMBOUTIFG       : 1; /* JTAG Mail Box output Interrupt Flag  */
  } SFRIFG1_bit;

  struct
  {
    unsigned char SFRIFG1_L;
    unsigned char SFRIFG1_H;
  };
} @ 0x0102;

enum {
  WDTIFG          = 0x0001,
  OFIFG           = 0x0002,
  VMAIFG          = 0x0008,
  NMIIFG          = 0x0010,
  JMBINIFG        = 0x0040,
  JMBOUTIFG       = 0x0080
};

__no_init volatile union
{
  unsigned short SFRRPCR;   /* RESET Pin Control Register  */

  struct
  {
    unsigned short SYSNMI          : 1; /* NMI select  */
    unsigned short SYSNMIIES       : 1; /* NMI edge select  */
    unsigned short SYSRSTUP        : 1; /* RESET Pin pull down/up select  */
    unsigned short SYSRSTRE        : 1; /* RESET Pin Resistor enable  */
  } SFRRPCR_bit;

  struct
  {
    unsigned char SFRRPCR_L;
    unsigned char SFRRPCR_H;
  };
} @ 0x0104;

enum {
  SYSNMI          = 0x0001,
  SYSNMIIES       = 0x0002,
  SYSRSTUP        = 0x0004,
  SYSRSTRE        = 0x0008
};



#define __MSP430_HAS_SFR__            /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_SFR__ 0x0100
#define SFR_BASE __MSP430_BASEADDRESS_SFR__

#define WDTIE_L             (0x0001u)  /* WDT Interrupt Enable */
#define OFIE_L              (0x0002u)  /* Osc Fault Enable */
#define VMAIE_L             (0x0008u)  /* Vacant Memory Interrupt Enable */
#define NMIIE_L             (0x0010u)  /* NMI Interrupt Enable */
#define ACCVIE_L            (0x0020u)  /* Flash Access Violation Interrupt Enable */
#define JMBINIE_L           (0x0040u)  /* JTAG Mail Box input Interrupt Enable */
#define JMBOUTIE_L          (0x0080u)  /* JTAG Mail Box output Interrupt Enable */

#define WDTIFG_L            (0x0001u)  /* WDT Interrupt Flag */
#define OFIFG_L             (0x0002u)  /* Osc Fault Flag */
#define VMAIFG_L            (0x0008u)  /* Vacant Memory Interrupt Flag */
#define NMIIFG_L            (0x0010u)  /* NMI Interrupt Flag */
#define JMBINIFG_L          (0x0040u)  /* JTAG Mail Box input Interrupt Flag */
#define JMBOUTIFG_L         (0x0080u)  /* JTAG Mail Box output Interrupt Flag */

#define SYSNMI_L            (0x0001u)  /* NMI select */
#define SYSNMIIES_L         (0x0002u)  /* NMI edge select */
#define SYSRSTUP_L          (0x0004u)  /* RESET Pin pull down/up select */
#define SYSRSTRE_L          (0x0008u)  /* RESET Pin Resistor enable */

/*-------------------------------------------------------------------------
 *   SYS  System Module
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short SYSCTL;   /* System control  */

  struct
  {
    unsigned short SYSRIVECT       : 1; /* SYS - RAM based interrupt vectors  */
    unsigned short                : 1;
    unsigned short SYSPMMPE        : 1; /* SYS - PMM access protect  */
    unsigned short                : 1;
    unsigned short SYSBSLIND       : 1; /* SYS - TCK/RST indication detected  */
    unsigned short SYSJTAGPIN      : 1; /* SYS - Dedicated JTAG pins enabled  */
  } SYSCTL_bit;

  struct
  {
    unsigned char SYSCTL_L;
    unsigned char SYSCTL_H;
  };
} @ 0x0180;

enum {
  SYSRIVECT       = 0x0001,
  SYSPMMPE        = 0x0004,
  SYSBSLIND       = 0x0010,
  SYSJTAGPIN      = 0x0020
};

__no_init volatile union
{
  unsigned short SYSBSLC;   /* Boot strap configuration area  */

  struct
  {
    unsigned short SYSBSLSIZE0     : 1; /* SYS - BSL Protection Size 0  */
    unsigned short SYSBSLSIZE1     : 1; /* SYS - BSL Protection Size 1  */
    unsigned short SYSBSLR         : 1; /* SYS - RAM assigned to BSL  */
    unsigned short                : 11;
    unsigned short SYSBSLOFF       : 1; /* SYS - BSL Memory disabled  */
    unsigned short SYSBSLPE        : 1; /* SYS - BSL Memory protection enabled  */
  } SYSBSLC_bit;

  struct
  {
    unsigned char SYSBSLC_L;
    unsigned char SYSBSLC_H;
  };
} @ 0x0182;

enum {
  SYSBSLSIZE0     = 0x0001,
  SYSBSLSIZE1     = 0x0002,
  SYSBSLR         = 0x0004,
  SYSBSLOFF       = 0x4000,
  SYSBSLPE        = 0x8000
};

__no_init volatile union
{
  unsigned short SYSJMBC;   /* JTAG mailbox control  */

  struct
  {
    unsigned short JMBIN0FG        : 1; /* SYS - Incoming JTAG Mailbox 0 Flag  */
    unsigned short JMBIN1FG        : 1; /* SYS - Incoming JTAG Mailbox 1 Flag  */
    unsigned short JMBOUT0FG       : 1; /* SYS - Outgoing JTAG Mailbox 0 Flag  */
    unsigned short JMBOUT1FG       : 1; /* SYS - Outgoing JTAG Mailbox 1 Flag  */
    unsigned short JMBMODE         : 1; /* SYS - JMB 16/32 Bit Mode  */
    unsigned short                : 1;
    unsigned short JMBCLR0OFF      : 1; /* SYS - Incoming JTAG Mailbox 0 Flag auto-clear disalbe  */
    unsigned short JMBCLR1OFF      : 1; /* SYS - Incoming JTAG Mailbox 1 Flag auto-clear disalbe  */
  } SYSJMBC_bit;

  struct
  {
    unsigned char SYSJMBC_L;
    unsigned char SYSJMBC_H;
  };
} @ 0x0186;

enum {
  JMBIN0FG        = 0x0001,
  JMBIN1FG        = 0x0002,
  JMBOUT0FG       = 0x0004,
  JMBOUT1FG       = 0x0008,
  JMBMODE         = 0x0010,
  JMBCLR0OFF      = 0x0040,
  JMBCLR1OFF      = 0x0080
};

__no_init volatile union
{
  unsigned short SYSJMBI0;   /* JTAG mailbox input 0  */
  struct
  {
    unsigned char SYSJMBI0_L;
    unsigned char SYSJMBI0_H;
  };
} @ 0x0188;

__no_init volatile union
{
  unsigned short SYSJMBI1;   /* JTAG mailbox input 1  */
  struct
  {
    unsigned char SYSJMBI1_L;
    unsigned char SYSJMBI1_H;
  };
} @ 0x018A;

__no_init volatile union
{
  unsigned short SYSJMBO0;   /* JTAG mailbox output 0  */
  struct
  {
    unsigned char SYSJMBO0_L;
    unsigned char SYSJMBO0_H;
  };
} @ 0x018C;

__no_init volatile union
{
  unsigned short SYSJMBO1;   /* JTAG mailbox output 1  */
  struct
  {
    unsigned char SYSJMBO1_L;
    unsigned char SYSJMBO1_H;
  };
} @ 0x018E;

__no_init volatile union
{
  unsigned short SYSBERRIV;   /* Bus Error vector generator  */
  struct
  {
    unsigned char SYSBERRIV_L;
    unsigned char SYSBERRIV_H;
  };
} @ 0x0198;

__no_init volatile union
{
  unsigned short SYSUNIV;   /* User NMI vector generator  */
  struct
  {
    unsigned char SYSUNIV_L;
    unsigned char SYSUNIV_H;
  };
} @ 0x019A;

__no_init volatile union
{
  unsigned short SYSSNIV;   /* System NMI vector generator  */
  struct
  {
    unsigned char SYSSNIV_L;
    unsigned char SYSSNIV_H;
  };
} @ 0x019C;

__no_init volatile union
{
  unsigned short SYSRSTIV;   /* Reset vector generator  */
  struct
  {
    unsigned char SYSRSTIV_L;
    unsigned char SYSRSTIV_H;
  };
} @ 0x019E;

#define __MSP430_HAS_SYS__            /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_SYS__ 0x0180
#define SYS_BASE __MSP430_BASEADDRESS_SYS__
/* SYSCTL Control Bits */
#define SYSRIVECT_L         (0x0001u)  /* SYS - RAM based interrupt vectors */
#define SYSPMMPE_L          (0x0004u)  /* SYS - PMM access protect */
#define SYSBSLIND_L         (0x0010u)  /* SYS - TCK/RST indication detected */
#define SYSJTAGPIN_L        (0x0020u)  /* SYS - Dedicated JTAG pins enabled */
/* SYSBSLC Control Bits */
#define SYSBSLSIZE0_L       (0x0001u)  /* SYS - BSL Protection Size 0 */
#define SYSBSLSIZE1_L       (0x0002u)  /* SYS - BSL Protection Size 1 */
#define SYSBSLR_L           (0x0004u)  /* SYS - RAM assigned to BSL */
#define SYSBSLOFF_H         (0x0040u)  /* SYS - BSL Memory disabled */
#define SYSBSLPE_H          (0x0080u)  /* SYS - BSL Memory protection enabled */
/* SYSJMBC Control Bits */
#define JMBIN0FG_L          (0x0001u)  /* SYS - Incoming JTAG Mailbox 0 Flag */
#define JMBIN1FG_L          (0x0002u)  /* SYS - Incoming JTAG Mailbox 1 Flag */
#define JMBOUT0FG_L         (0x0004u)  /* SYS - Outgoing JTAG Mailbox 0 Flag */
#define JMBOUT1FG_L         (0x0008u)  /* SYS - Outgoing JTAG Mailbox 1 Flag */
#define JMBMODE_L           (0x0010u)  /* SYS - JMB 16/32 Bit Mode */
#define JMBCLR0OFF_L        (0x0040u)  /* SYS - Incoming JTAG Mailbox 0 Flag auto-clear disalbe */
#define JMBCLR1OFF_L        (0x0080u)  /* SYS - Incoming JTAG Mailbox 1 Flag auto-clear disalbe */
/* SYSUNIV Definitions */
#define SYSUNIV_NONE       (0x0000u)    /* No Interrupt pending */
#define SYSUNIV_NMIIFG     (0x0002u)    /* SYSUNIV   : NMIIFG */
#define SYSUNIV_OFIFG      (0x0004u)    /* SYSUNIV   : Osc. Fail - OFIFG */
#define SYSUNIV_ACCVIFG    (0x0006u)    /* SYSUNIV   : Access Violation - ACCVIFG */
#define SYSUNIV_AUXSWGIFG  (0x0008u)    /* AUXSWGIFG : AUX supply */
/* SYSSNIV Definitions */
#define SYSSNIV_NONE       (0x0000u)    /* No Interrupt pending */
#define SYSSNIV_SVMLIFG    (0x0002u)    /* SYSSNIV : SVMLIFG */
#define SYSSNIV_SVMHIFG    (0x0004u)    /* SYSSNIV : SVMHIFG */
#define SYSSNIV_DLYLIFG    (0x0006u)    /* SYSSNIV : DLYLIFG */
#define SYSSNIV_DLYHIFG    (0x0008u)    /* SYSSNIV : DLYHIFG */
#define SYSSNIV_VMAIFG     (0x000Au)    /* SYSSNIV : VMAIFG */
#define SYSSNIV_JMBINIFG   (0x000Cu)    /* SYSSNIV : JMBINIFG */
#define SYSSNIV_JMBOUTIFG  (0x000Eu)    /* SYSSNIV : JMBOUTIFG */
#define SYSSNIV_VLRLIFG    (0x0010u)    /* SYSSNIV : VLRLIFG */
#define SYSSNIV_VLRHIFG    (0x0012u)    /* SYSSNIV : VLRHIFG */
/* SYSRSTIV Definitions */
#define SYSRSTIV_NONE      (0x0000u)    /* No Interrupt pending */
#define SYSRSTIV_BOR       (0x0002u)    /* SYSRSTIV : BOR */
#define SYSRSTIV_RSTNMI    (0x0004u)    /* SYSRSTIV : RST/NMI */
#define SYSRSTIV_DOBOR     (0x0006u)    /* SYSRSTIV : Do BOR */
#define SYSRSTIV_LPM5WU    (0x0008u)    /* SYSRSTIV : Port LPM5 Wake Up */
#define SYSRSTIV_SECYV     (0x000Au)    /* SYSRSTIV : Security violation */
#define SYSRSTIV_SVSL      (0x000Cu)    /* SYSRSTIV : SVSL */
#define SYSRSTIV_SVSH      (0x000Eu)    /* SYSRSTIV : SVSH */
#define SYSRSTIV_SVML_OVP  (0x0010u)    /* SYSRSTIV : SVML_OVP */
#define SYSRSTIV_SVMH_OVP  (0x0012u)    /* SYSRSTIV : SVMH_OVP */
#define SYSRSTIV_DOPOR     (0x0014u)    /* SYSRSTIV : Do POR */
#define SYSRSTIV_WDTTO     (0x0016u)    /* SYSRSTIV : WDT Time out */
#define SYSRSTIV_WDTKEY    (0x0018u)    /* SYSRSTIV : WDTKEY violation */
#define SYSRSTIV_KEYV      (0x001Au)    /* SYSRSTIV : Flash Key violation */
#define SYSRSTIV_FLLUL     (0x001Cu)    /* SYSRSTIV : FLL unlock */
#define SYSRSTIV_PERF      (0x001Eu)    /* SYSRSTIV : peripheral/config area fetch */
#define SYSRSTIV_PMMKEY    (0x0020u)    /* SYSRSTIV : PMMKEY violation */

/*-------------------------------------------------------------------------
 *   Timer0_A3
 *-------------------------------------------------------------------------*/



__no_init volatile union
{
  unsigned short TA0CTL;   /* Timer0_A3 Control  */

  struct
  {
    unsigned short TAIFG           : 1; /* Timer A counter interrupt flag  */
    unsigned short TAIE            : 1; /* Timer A counter interrupt enable  */
    unsigned short TACLR           : 1; /* Timer A counter clear  */
    unsigned short                : 1;
    unsigned short MC0             : 1; /* Timer A mode control 0  */
    unsigned short MC1             : 1; /* Timer A mode control 1  */
    unsigned short ID0             : 1; /* Timer A clock input divider 0  */
    unsigned short ID1             : 1; /* Timer A clock input divider 1  */
    unsigned short TASSEL0         : 1; /* Timer A clock source select 0  */
    unsigned short TASSEL1         : 1; /* Timer A clock source select 1  */
  }TA0CTL_bit;
} @ 0x0340;


enum {
  TAIFG           = 0x0001,
  TAIE            = 0x0002,
  TACLR           = 0x0004,
  MC0             = 0x0010,
  MC1             = 0x0020,
  ID0             = 0x0040,
  ID1             = 0x0080,
  TASSEL0         = 0x0100,
  TASSEL1         = 0x0200
};


__no_init volatile union
{
  unsigned short TA0CCTL0;   /* Timer0_A3 Capture/Compare Control 0  */

  struct
  {
    unsigned short CCIFG           : 1; /* Capture/compare interrupt flag  */
    unsigned short COV             : 1; /* Capture/compare overflow flag  */
    unsigned short OUT             : 1; /* PWM Output signal if output mode 0  */
    unsigned short CCI             : 1; /* Capture input signal (read)  */
    unsigned short CCIE            : 1; /* Capture/compare interrupt enable  */
    unsigned short OUTMOD0         : 1; /* Output mode 0  */
    unsigned short OUTMOD1         : 1; /* Output mode 1  */
    unsigned short OUTMOD2         : 1; /* Output mode 2  */
    unsigned short CAP             : 1; /* Capture mode: 1 /Compare mode : 0  */
    unsigned short                : 1;
    unsigned short SCCI            : 1; /* Latched capture signal (read)  */
    unsigned short SCS             : 1; /* Capture sychronize  */
    unsigned short CCIS0           : 1; /* Capture input select 0  */
    unsigned short CCIS1           : 1; /* Capture input select 1  */
    unsigned short CM0             : 1; /* Capture mode 0  */
    unsigned short CM1             : 1; /* Capture mode 1  */
  }TA0CCTL0_bit;
} @ 0x0342;


enum {
  CCIFG           = 0x0001,
  COV             = 0x0002,
  OUT             = 0x0004,
  CCI             = 0x0008,
  CCIE            = 0x0010,
  OUTMOD0         = 0x0020,
  OUTMOD1         = 0x0040,
  OUTMOD2         = 0x0080,
  CAP             = 0x0100,
  SCCI            = 0x0400,
  SCS             = 0x0800,
  CCIS0           = 0x1000,
  CCIS1           = 0x2000,
  CM0             = 0x4000,
  CM1             = 0x8000
};


__no_init volatile union
{
  unsigned short TA0CCTL1;   /* Timer0_A3 Capture/Compare Control 1  */

  struct
  {
    unsigned short CCIFG           : 1; /* Capture/compare interrupt flag  */
    unsigned short COV             : 1; /* Capture/compare overflow flag  */
    unsigned short OUT             : 1; /* PWM Output signal if output mode 0  */
    unsigned short CCI             : 1; /* Capture input signal (read)  */
    unsigned short CCIE            : 1; /* Capture/compare interrupt enable  */
    unsigned short OUTMOD0         : 1; /* Output mode 0  */
    unsigned short OUTMOD1         : 1; /* Output mode 1  */
    unsigned short OUTMOD2         : 1; /* Output mode 2  */
    unsigned short CAP             : 1; /* Capture mode: 1 /Compare mode : 0  */
    unsigned short                : 1;
    unsigned short SCCI            : 1; /* Latched capture signal (read)  */
    unsigned short SCS             : 1; /* Capture sychronize  */
    unsigned short CCIS0           : 1; /* Capture input select 0  */
    unsigned short CCIS1           : 1; /* Capture input select 1  */
    unsigned short CM0             : 1; /* Capture mode 0  */
    unsigned short CM1             : 1; /* Capture mode 1  */
  }TA0CCTL1_bit;
} @ 0x0344;


/*
enum {
  CCIFG           = 0x0001,
  COV             = 0x0002,
  OUT             = 0x0004,
  CCI             = 0x0008,
  CCIE            = 0x0010,
  OUTMOD0         = 0x0020,
  OUTMOD1         = 0x0040,
  OUTMOD2         = 0x0080,
  CAP             = 0x0100,
  SCCI            = 0x0400,
  SCS             = 0x0800,
  CCIS0           = 0x1000,
  CCIS1           = 0x2000,
  CM0             = 0x4000,
  CM1             = 0x8000,
};

*/

__no_init volatile union
{
  unsigned short TA0CCTL2;   /* Timer0_A3 Capture/Compare Control 2  */

  struct
  {
    unsigned short CCIFG           : 1; /* Capture/compare interrupt flag  */
    unsigned short COV             : 1; /* Capture/compare overflow flag  */
    unsigned short OUT             : 1; /* PWM Output signal if output mode 0  */
    unsigned short CCI             : 1; /* Capture input signal (read)  */
    unsigned short CCIE            : 1; /* Capture/compare interrupt enable  */
    unsigned short OUTMOD0         : 1; /* Output mode 0  */
    unsigned short OUTMOD1         : 1; /* Output mode 1  */
    unsigned short OUTMOD2         : 1; /* Output mode 2  */
    unsigned short CAP             : 1; /* Capture mode: 1 /Compare mode : 0  */
    unsigned short                : 1;
    unsigned short SCCI            : 1; /* Latched capture signal (read)  */
    unsigned short SCS             : 1; /* Capture sychronize  */
    unsigned short CCIS0           : 1; /* Capture input select 0  */
    unsigned short CCIS1           : 1; /* Capture input select 1  */
    unsigned short CM0             : 1; /* Capture mode 0  */
    unsigned short CM1             : 1; /* Capture mode 1  */
  }TA0CCTL2_bit;
} @ 0x0346;


/*
enum {
  CCIFG           = 0x0001,
  COV             = 0x0002,
  OUT             = 0x0004,
  CCI             = 0x0008,
  CCIE            = 0x0010,
  OUTMOD0         = 0x0020,
  OUTMOD1         = 0x0040,
  OUTMOD2         = 0x0080,
  CAP             = 0x0100,
  SCCI            = 0x0400,
  SCS             = 0x0800,
  CCIS0           = 0x1000,
  CCIS1           = 0x2000,
  CM0             = 0x4000,
  CM1             = 0x8000,
};

*/

  /* Timer0_A3  */
__no_init volatile unsigned short TA0R @ 0x0350;



  /* Timer0_A3 Capture/Compare 0  */
__no_init volatile unsigned short TA0CCR0 @ 0x0352;



  /* Timer0_A3 Capture/Compare 1  */
__no_init volatile unsigned short TA0CCR1 @ 0x0354;



  /* Timer0_A3 Capture/Compare 2  */
__no_init volatile unsigned short TA0CCR2 @ 0x0356;



  /* Timer0_A3 Interrupt Vector Word  */
__no_init volatile unsigned short TA0IV @ 0x036E;



__no_init volatile union
{
  unsigned short TA0EX0;   /* Timer0_A3 Expansion Register 0  */

  struct
  {
    unsigned short TAIDEX0         : 1; /* Timer A Input divider expansion Bit: 0  */
    unsigned short TAIDEX1         : 1; /* Timer A Input divider expansion Bit: 1  */
    unsigned short TAIDEX2         : 1; /* Timer A Input divider expansion Bit: 2  */
  }TA0EX0_bit;
} @ 0x0360;


enum {
  TAIDEX0         = 0x0001,
  TAIDEX1         = 0x0002,
  TAIDEX2         = 0x0004
};



#define __MSP430_HAS_T0A3__           /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_T0A3__ 0x0340
#define TIMER_A0_BASE __MSP430_BASEADDRESS_T0A3__

#define MC_0                (0*0x10u)  /* Timer A mode control: 0 - Stop */
#define MC_1                (1*0x10u)  /* Timer A mode control: 1 - Up to CCR0 */
#define MC_2                (2*0x10u)  /* Timer A mode control: 2 - Continuous up */
#define MC_3                (3*0x10u)  /* Timer A mode control: 3 - Up/Down */
#define ID_0                (0*0x40u)  /* Timer A input divider: 0 - /1 */
#define ID_1                (1*0x40u)  /* Timer A input divider: 1 - /2 */
#define ID_2                (2*0x40u)  /* Timer A input divider: 2 - /4 */
#define ID_3                (3*0x40u)  /* Timer A input divider: 3 - /8 */
#define TASSEL_0            (0*0x100u) /* Timer A clock source select: 0 - TACLK */
#define TASSEL_1            (1*0x100u) /* Timer A clock source select: 1 - ACLK  */
#define TASSEL_2            (2*0x100u) /* Timer A clock source select: 2 - SMCLK */
#define TASSEL_3            (3*0x100u) /* Timer A clock source select: 3 - INCLK */
#define MC__STOP            (0*0x10u)  /* Timer A mode control: 0 - Stop */
#define MC__UP              (1*0x10u)  /* Timer A mode control: 1 - Up to CCR0 */
#define MC__CONTINUOUS      (2*0x10u)  /* Timer A mode control: 2 - Continuous up */
#define MC__CONTINOUS       (2*0x10u)  /* Legacy define */
#define MC__UPDOWN          (3*0x10u)  /* Timer A mode control: 3 - Up/Down */
#define ID__1               (0*0x40u)  /* Timer A input divider: 0 - /1 */
#define ID__2               (1*0x40u)  /* Timer A input divider: 1 - /2 */
#define ID__4               (2*0x40u)  /* Timer A input divider: 2 - /4 */
#define ID__8               (3*0x40u)  /* Timer A input divider: 3 - /8 */
#define TASSEL__TACLK       (0*0x100u) /* Timer A clock source select: 0 - TACLK */
#define TASSEL__ACLK        (1*0x100u) /* Timer A clock source select: 1 - ACLK  */
#define TASSEL__SMCLK       (2*0x100u) /* Timer A clock source select: 2 - SMCLK */
#define TASSEL__INCLK       (3*0x100u) /* Timer A clock source select: 3 - INCLK */

#define OUTMOD_0            (0*0x20u)  /* PWM output mode: 0 - output only */
#define OUTMOD_1            (1*0x20u)  /* PWM output mode: 1 - set */
#define OUTMOD_2            (2*0x20u)  /* PWM output mode: 2 - PWM toggle/reset */
#define OUTMOD_3            (3*0x20u)  /* PWM output mode: 3 - PWM set/reset */
#define OUTMOD_4            (4*0x20u)  /* PWM output mode: 4 - toggle */
#define OUTMOD_5            (5*0x20u)  /* PWM output mode: 5 - Reset */
#define OUTMOD_6            (6*0x20u)  /* PWM output mode: 6 - PWM toggle/set */
#define OUTMOD_7            (7*0x20u)  /* PWM output mode: 7 - PWM reset/set */
#define CCIS_0              (0*0x1000u) /* Capture input select: 0 - CCIxA */
#define CCIS_1              (1*0x1000u) /* Capture input select: 1 - CCIxB */
#define CCIS_2              (2*0x1000u) /* Capture input select: 2 - GND */
#define CCIS_3              (3*0x1000u) /* Capture input select: 3 - Vcc */
#define CM_0                (0*0x4000u) /* Capture mode: 0 - disabled */
#define CM_1                (1*0x4000u) /* Capture mode: 1 - pos. edge */
#define CM_2                (2*0x4000u) /* Capture mode: 1 - neg. edge */
#define CM_3                (3*0x4000u) /* Capture mode: 1 - both edges */

#define TAIDEX_0            (0*0x0001u) /* Timer A Input divider expansion : /1 */
#define TAIDEX_1            (1*0x0001u) /* Timer A Input divider expansion : /2 */
#define TAIDEX_2            (2*0x0001u) /* Timer A Input divider expansion : /3 */
#define TAIDEX_3            (3*0x0001u) /* Timer A Input divider expansion : /4 */
#define TAIDEX_4            (4*0x0001u) /* Timer A Input divider expansion : /5 */
#define TAIDEX_5            (5*0x0001u) /* Timer A Input divider expansion : /6 */
#define TAIDEX_6            (6*0x0001u) /* Timer A Input divider expansion : /7 */
#define TAIDEX_7            (7*0x0001u) /* Timer A Input divider expansion : /8 */
/* T0A3IV Definitions */
#define TA0IV_NONE          (0x0000u)    /* No Interrupt pending */
#define TA0IV_TACCR1        (0x0002u)    /* TA0CCR1_CCIFG */
#define TA0IV_TACCR2        (0x0004u)    /* TA0CCR2_CCIFG */
#define TA0IV_3             (0x0006u)    /* Reserved */
#define TA0IV_4             (0x0008u)    /* Reserved */
#define TA0IV_5             (0x000Au)    /* Reserved */
#define TA0IV_6             (0x000Cu)    /* Reserved */
#define TA0IV_TAIFG         (0x000Eu)    /* TA0IFG */
/* Legacy Defines */
#define TA0IV_TA0CCR1       (0x0002u)    /* TA0CCR1_CCIFG */
#define TA0IV_TA0CCR2       (0x0004u)    /* TA0CCR2_CCIFG */
#define TA0IV_TA0IFG        (0x000Eu)    /* TA0IFG */

/*-------------------------------------------------------------------------
 *   Timer1_A2
 *-------------------------------------------------------------------------*/



__no_init volatile union
{
  unsigned short TA1CTL;   /* Timer1_A2 Control  */

  struct
  {
    unsigned short TAIFG           : 1; /* Timer A counter interrupt flag  */
    unsigned short TAIE            : 1; /* Timer A counter interrupt enable  */
    unsigned short TACLR           : 1; /* Timer A counter clear  */
    unsigned short                : 1;
    unsigned short MC0             : 1; /* Timer A mode control 0  */
    unsigned short MC1             : 1; /* Timer A mode control 1  */
    unsigned short ID0             : 1; /* Timer A clock input divider 0  */
    unsigned short ID1             : 1; /* Timer A clock input divider 1  */
    unsigned short TASSEL0         : 1; /* Timer A clock source select 0  */
    unsigned short TASSEL1         : 1; /* Timer A clock source select 1  */
  }TA1CTL_bit;
} @ 0x0380;


/*
enum {
  TAIFG           = 0x0001,
  TAIE            = 0x0002,
  TACLR           = 0x0004,
  MC0             = 0x0010,
  MC1             = 0x0020,
  ID0             = 0x0040,
  ID1             = 0x0080,
  TASSEL0         = 0x0100,
  TASSEL1         = 0x0200,
};

*/

__no_init volatile union
{
  unsigned short TA1CCTL0;   /* Timer1_A2 Capture/Compare Control 0  */

  struct
  {
    unsigned short CCIFG           : 1; /* Capture/compare interrupt flag  */
    unsigned short COV             : 1; /* Capture/compare overflow flag  */
    unsigned short OUT             : 1; /* PWM Output signal if output mode 0  */
    unsigned short CCI             : 1; /* Capture input signal (read)  */
    unsigned short CCIE            : 1; /* Capture/compare interrupt enable  */
    unsigned short OUTMOD0         : 1; /* Output mode 0  */
    unsigned short OUTMOD1         : 1; /* Output mode 1  */
    unsigned short OUTMOD2         : 1; /* Output mode 2  */
    unsigned short CAP             : 1; /* Capture mode: 1 /Compare mode : 0  */
    unsigned short                : 1;
    unsigned short SCCI            : 1; /* Latched capture signal (read)  */
    unsigned short SCS             : 1; /* Capture sychronize  */
    unsigned short CCIS0           : 1; /* Capture input select 0  */
    unsigned short CCIS1           : 1; /* Capture input select 1  */
    unsigned short CM0             : 1; /* Capture mode 0  */
    unsigned short CM1             : 1; /* Capture mode 1  */
  }TA1CCTL0_bit;
} @ 0x0382;


/*
enum {
  CCIFG           = 0x0001,
  COV             = 0x0002,
  OUT             = 0x0004,
  CCI             = 0x0008,
  CCIE            = 0x0010,
  OUTMOD0         = 0x0020,
  OUTMOD1         = 0x0040,
  OUTMOD2         = 0x0080,
  CAP             = 0x0100,
  SCCI            = 0x0400,
  SCS             = 0x0800,
  CCIS0           = 0x1000,
  CCIS1           = 0x2000,
  CM0             = 0x4000,
  CM1             = 0x8000,
};

*/

__no_init volatile union
{
  unsigned short TA1CCTL1;   /* Timer1_A2 Capture/Compare Control 1  */

  struct
  {
    unsigned short CCIFG           : 1; /* Capture/compare interrupt flag  */
    unsigned short COV             : 1; /* Capture/compare overflow flag  */
    unsigned short OUT             : 1; /* PWM Output signal if output mode 0  */
    unsigned short CCI             : 1; /* Capture input signal (read)  */
    unsigned short CCIE            : 1; /* Capture/compare interrupt enable  */
    unsigned short OUTMOD0         : 1; /* Output mode 0  */
    unsigned short OUTMOD1         : 1; /* Output mode 1  */
    unsigned short OUTMOD2         : 1; /* Output mode 2  */
    unsigned short CAP             : 1; /* Capture mode: 1 /Compare mode : 0  */
    unsigned short                : 1;
    unsigned short SCCI            : 1; /* Latched capture signal (read)  */
    unsigned short SCS             : 1; /* Capture sychronize  */
    unsigned short CCIS0           : 1; /* Capture input select 0  */
    unsigned short CCIS1           : 1; /* Capture input select 1  */
    unsigned short CM0             : 1; /* Capture mode 0  */
    unsigned short CM1             : 1; /* Capture mode 1  */
  }TA1CCTL1_bit;
} @ 0x0384;


/*
enum {
  CCIFG           = 0x0001,
  COV             = 0x0002,
  OUT             = 0x0004,
  CCI             = 0x0008,
  CCIE            = 0x0010,
  OUTMOD0         = 0x0020,
  OUTMOD1         = 0x0040,
  OUTMOD2         = 0x0080,
  CAP             = 0x0100,
  SCCI            = 0x0400,
  SCS             = 0x0800,
  CCIS0           = 0x1000,
  CCIS1           = 0x2000,
  CM0             = 0x4000,
  CM1             = 0x8000,
};

*/

  /* Timer1_A2  */
__no_init volatile unsigned short TA1R @ 0x0390;



  /* Timer1_A2 Capture/Compare 0  */
__no_init volatile unsigned short TA1CCR0 @ 0x0392;



  /* Timer1_A2 Capture/Compare 1  */
__no_init volatile unsigned short TA1CCR1 @ 0x0394;



  /* Timer1_A2 Interrupt Vector Word  */
__no_init volatile unsigned short TA1IV @ 0x03AE;



__no_init volatile union
{
  unsigned short TA1EX0;   /* Timer1_A2 Expansion Register 0  */

  struct
  {
    unsigned short TAIDEX0         : 1; /* Timer A Input divider expansion Bit: 0  */
    unsigned short TAIDEX1         : 1; /* Timer A Input divider expansion Bit: 1  */
    unsigned short TAIDEX2         : 1; /* Timer A Input divider expansion Bit: 2  */
  }TA1EX0_bit;
} @ 0x03A0;


/*
enum {
  TAIDEX0         = 0x0001,
  TAIDEX1         = 0x0002,
  TAIDEX2         = 0x0004
};
*/



#define __MSP430_HAS_T1A2__            /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_T1A2__ 0x0380
#define TIMER_A1_BASE __MSP430_BASEADDRESS_T1A2__
/* TA1IV Definitions */
#define TA1IV_NONE          (0x0000u)    /* No Interrupt pending */
#define TA1IV_TACCR1        (0x0002u)    /* TA1CCR1_CCIFG */
#define TA1IV_3             (0x0006u)    /* Reserved */
#define TA1IV_4             (0x0008u)    /* Reserved */
#define TA1IV_5             (0x000Au)    /* Reserved */
#define TA1IV_6             (0x000Cu)    /* Reserved */
#define TA1IV_TAIFG         (0x000Eu)    /* TA1IFG */
/* Legacy Defines */
#define TA1IV_TA1CCR1      (0x0002u)    /* TA1CCR1_CCIFG */
#define TA1IV_TA1IFG       (0x000Eu)    /* TA1IFG */

/*-------------------------------------------------------------------------
 *   Timer2_A2
 *-------------------------------------------------------------------------*/



__no_init volatile union
{
  unsigned short TA2CTL;   /* Timer2_A2 Control  */

  struct
  {
    unsigned short TAIFG           : 1; /* Timer A counter interrupt flag  */
    unsigned short TAIE            : 1; /* Timer A counter interrupt enable  */
    unsigned short TACLR           : 1; /* Timer A counter clear  */
    unsigned short                : 1;
    unsigned short MC0             : 1; /* Timer A mode control 0  */
    unsigned short MC1             : 1; /* Timer A mode control 1  */
    unsigned short ID0             : 1; /* Timer A clock input divider 0  */
    unsigned short ID1             : 1; /* Timer A clock input divider 1  */
    unsigned short TASSEL0         : 1; /* Timer A clock source select 0  */
    unsigned short TASSEL1         : 1; /* Timer A clock source select 1  */
  }TA2CTL_bit;
} @ 0x0400;


/*
enum {
  TAIFG           = 0x0001,
  TAIE            = 0x0002,
  TACLR           = 0x0004,
  MC0             = 0x0010,
  MC1             = 0x0020,
  ID0             = 0x0040,
  ID1             = 0x0080,
  TASSEL0         = 0x0100,
  TASSEL1         = 0x0200,
};

*/

__no_init volatile union
{
  unsigned short TA2CCTL0;   /* Timer2_A2 Capture/Compare Control 0  */

  struct
  {
    unsigned short CCIFG           : 1; /* Capture/compare interrupt flag  */
    unsigned short COV             : 1; /* Capture/compare overflow flag  */
    unsigned short OUT             : 1; /* PWM Output signal if output mode 0  */
    unsigned short CCI             : 1; /* Capture input signal (read)  */
    unsigned short CCIE            : 1; /* Capture/compare interrupt enable  */
    unsigned short OUTMOD0         : 1; /* Output mode 0  */
    unsigned short OUTMOD1         : 1; /* Output mode 1  */
    unsigned short OUTMOD2         : 1; /* Output mode 2  */
    unsigned short CAP             : 1; /* Capture mode: 1 /Compare mode : 0  */
    unsigned short                : 1;
    unsigned short SCCI            : 1; /* Latched capture signal (read)  */
    unsigned short SCS             : 1; /* Capture sychronize  */
    unsigned short CCIS0           : 1; /* Capture input select 0  */
    unsigned short CCIS1           : 1; /* Capture input select 1  */
    unsigned short CM0             : 1; /* Capture mode 0  */
    unsigned short CM1             : 1; /* Capture mode 1  */
  }TA2CCTL0_bit;
} @ 0x0402;


/*
enum {
  CCIFG           = 0x0001,
  COV             = 0x0002,
  OUT             = 0x0004,
  CCI             = 0x0008,
  CCIE            = 0x0010,
  OUTMOD0         = 0x0020,
  OUTMOD1         = 0x0040,
  OUTMOD2         = 0x0080,
  CAP             = 0x0100,
  SCCI            = 0x0400,
  SCS             = 0x0800,
  CCIS0           = 0x1000,
  CCIS1           = 0x2000,
  CM0             = 0x4000,
  CM1             = 0x8000,
};

*/

__no_init volatile union
{
  unsigned short TA2CCTL1;   /* Timer2_A2 Capture/Compare Control 1  */

  struct
  {
    unsigned short CCIFG           : 1; /* Capture/compare interrupt flag  */
    unsigned short COV             : 1; /* Capture/compare overflow flag  */
    unsigned short OUT             : 1; /* PWM Output signal if output mode 0  */
    unsigned short CCI             : 1; /* Capture input signal (read)  */
    unsigned short CCIE            : 1; /* Capture/compare interrupt enable  */
    unsigned short OUTMOD0         : 1; /* Output mode 0  */
    unsigned short OUTMOD1         : 1; /* Output mode 1  */
    unsigned short OUTMOD2         : 1; /* Output mode 2  */
    unsigned short CAP             : 1; /* Capture mode: 1 /Compare mode : 0  */
    unsigned short                : 1;
    unsigned short SCCI            : 1; /* Latched capture signal (read)  */
    unsigned short SCS             : 1; /* Capture sychronize  */
    unsigned short CCIS0           : 1; /* Capture input select 0  */
    unsigned short CCIS1           : 1; /* Capture input select 1  */
    unsigned short CM0             : 1; /* Capture mode 0  */
    unsigned short CM1             : 1; /* Capture mode 1  */
  }TA2CCTL1_bit;
} @ 0x0404;


/*
enum {
  CCIFG           = 0x0001,
  COV             = 0x0002,
  OUT             = 0x0004,
  CCI             = 0x0008,
  CCIE            = 0x0010,
  OUTMOD0         = 0x0020,
  OUTMOD1         = 0x0040,
  OUTMOD2         = 0x0080,
  CAP             = 0x0100,
  SCCI            = 0x0400,
  SCS             = 0x0800,
  CCIS0           = 0x1000,
  CCIS1           = 0x2000,
  CM0             = 0x4000,
  CM1             = 0x8000,
};

*/

  /* Timer2_A2  */
__no_init volatile unsigned short TA2R @ 0x0410;



  /* Timer2_A2 Capture/Compare 0  */
__no_init volatile unsigned short TA2CCR0 @ 0x0412;



  /* Timer2_A2 Capture/Compare 1  */
__no_init volatile unsigned short TA2CCR1 @ 0x0414;



  /* Timer2_A2 Interrupt Vector Word  */
__no_init volatile unsigned short TA2IV @ 0x042E;



__no_init volatile union
{
  unsigned short TA2EX0;   /* Timer2_A2 Expansion Register 0  */

  struct
  {
    unsigned short TAIDEX0         : 1; /* Timer A Input divider expansion Bit: 0  */
    unsigned short TAIDEX1         : 1; /* Timer A Input divider expansion Bit: 1  */
    unsigned short TAIDEX2         : 1; /* Timer A Input divider expansion Bit: 2  */
  }TA2EX0_bit;
} @ 0x0420;


/*
enum {
  TAIDEX0         = 0x0001,
  TAIDEX1         = 0x0002,
  TAIDEX2         = 0x0004
};
*/



#define __MSP430_HAS_T2A2__            /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_T2A2__ 0x0400
#define TIMER_A2_BASE __MSP430_BASEADDRESS_T2A2__
/* TA2IV Definitions */
#define TA2IV_NONE          (0x0000u)    /* No Interrupt pending */
#define TA2IV_TACCR1        (0x0002u)    /* TA2CCR1_CCIFG */
#define TA2IV_3             (0x0006u)    /* Reserved */
#define TA2IV_4             (0x0008u)    /* Reserved */
#define TA2IV_5             (0x000Au)    /* Reserved */
#define TA2IV_6             (0x000Cu)    /* Reserved */
#define TA2IV_TAIFG         (0x000Eu)    /* TA2IFG */
/* Legacy Defines */
#define TA2IV_TA2CCR1      (0x0002u)    /* TA2CCR1_CCIFG */
#define TA2IV_TA2IFG       (0x000Eu)    /* TA2IFG */

/*-------------------------------------------------------------------------
 *   Timer3_A2
 *-------------------------------------------------------------------------*/



__no_init volatile union
{
  unsigned short TA3CTL;   /* Timer3_A2 Control  */

  struct
  {
    unsigned short TAIFG           : 1; /* Timer A counter interrupt flag  */
    unsigned short TAIE            : 1; /* Timer A counter interrupt enable  */
    unsigned short TACLR           : 1; /* Timer A counter clear  */
    unsigned short                : 1;
    unsigned short MC0             : 1; /* Timer A mode control 0  */
    unsigned short MC1             : 1; /* Timer A mode control 1  */
    unsigned short ID0             : 1; /* Timer A clock input divider 0  */
    unsigned short ID1             : 1; /* Timer A clock input divider 1  */
    unsigned short TASSEL0         : 1; /* Timer A clock source select 0  */
    unsigned short TASSEL1         : 1; /* Timer A clock source select 1  */
  }TA3CTL_bit;
} @ 0x0440;


/*
enum {
  TAIFG           = 0x0001,
  TAIE            = 0x0002,
  TACLR           = 0x0004,
  MC0             = 0x0010,
  MC1             = 0x0020,
  ID0             = 0x0040,
  ID1             = 0x0080,
  TASSEL0         = 0x0100,
  TASSEL1         = 0x0200,
};

*/

__no_init volatile union
{
  unsigned short TA3CCTL0;   /* Timer3_A2 Capture/Compare Control 0  */

  struct
  {
    unsigned short CCIFG           : 1; /* Capture/compare interrupt flag  */
    unsigned short COV             : 1; /* Capture/compare overflow flag  */
    unsigned short OUT             : 1; /* PWM Output signal if output mode 0  */
    unsigned short CCI             : 1; /* Capture input signal (read)  */
    unsigned short CCIE            : 1; /* Capture/compare interrupt enable  */
    unsigned short OUTMOD0         : 1; /* Output mode 0  */
    unsigned short OUTMOD1         : 1; /* Output mode 1  */
    unsigned short OUTMOD2         : 1; /* Output mode 2  */
    unsigned short CAP             : 1; /* Capture mode: 1 /Compare mode : 0  */
    unsigned short                : 1;
    unsigned short SCCI            : 1; /* Latched capture signal (read)  */
    unsigned short SCS             : 1; /* Capture sychronize  */
    unsigned short CCIS0           : 1; /* Capture input select 0  */
    unsigned short CCIS1           : 1; /* Capture input select 1  */
    unsigned short CM0             : 1; /* Capture mode 0  */
    unsigned short CM1             : 1; /* Capture mode 1  */
  }TA3CCTL0_bit;
} @ 0x0442;


/*
enum {
  CCIFG           = 0x0001,
  COV             = 0x0002,
  OUT             = 0x0004,
  CCI             = 0x0008,
  CCIE            = 0x0010,
  OUTMOD0         = 0x0020,
  OUTMOD1         = 0x0040,
  OUTMOD2         = 0x0080,
  CAP             = 0x0100,
  SCCI            = 0x0400,
  SCS             = 0x0800,
  CCIS0           = 0x1000,
  CCIS1           = 0x2000,
  CM0             = 0x4000,
  CM1             = 0x8000,
};

*/

__no_init volatile union
{
  unsigned short TA3CCTL1;   /* Timer3_A2 Capture/Compare Control 1  */

  struct
  {
    unsigned short CCIFG           : 1; /* Capture/compare interrupt flag  */
    unsigned short COV             : 1; /* Capture/compare overflow flag  */
    unsigned short OUT             : 1; /* PWM Output signal if output mode 0  */
    unsigned short CCI             : 1; /* Capture input signal (read)  */
    unsigned short CCIE            : 1; /* Capture/compare interrupt enable  */
    unsigned short OUTMOD0         : 1; /* Output mode 0  */
    unsigned short OUTMOD1         : 1; /* Output mode 1  */
    unsigned short OUTMOD2         : 1; /* Output mode 2  */
    unsigned short CAP             : 1; /* Capture mode: 1 /Compare mode : 0  */
    unsigned short                : 1;
    unsigned short SCCI            : 1; /* Latched capture signal (read)  */
    unsigned short SCS             : 1; /* Capture sychronize  */
    unsigned short CCIS0           : 1; /* Capture input select 0  */
    unsigned short CCIS1           : 1; /* Capture input select 1  */
    unsigned short CM0             : 1; /* Capture mode 0  */
    unsigned short CM1             : 1; /* Capture mode 1  */
  }TA3CCTL1_bit;
} @ 0x0444;


/*
enum {
  CCIFG           = 0x0001,
  COV             = 0x0002,
  OUT             = 0x0004,
  CCI             = 0x0008,
  CCIE            = 0x0010,
  OUTMOD0         = 0x0020,
  OUTMOD1         = 0x0040,
  OUTMOD2         = 0x0080,
  CAP             = 0x0100,
  SCCI            = 0x0400,
  SCS             = 0x0800,
  CCIS0           = 0x1000,
  CCIS1           = 0x2000,
  CM0             = 0x4000,
  CM1             = 0x8000,
};

*/

  /* Timer3_A2  */
__no_init volatile unsigned short TA3R @ 0x0450;



  /* Timer3_A2 Capture/Compare 0  */
__no_init volatile unsigned short TA3CCR0 @ 0x0452;



  /* Timer3_A2 Capture/Compare 1  */
__no_init volatile unsigned short TA3CCR1 @ 0x0454;



  /* Timer3_A2 Interrupt Vector Word  */
__no_init volatile unsigned short TA3IV @ 0x046E;



__no_init volatile union
{
  unsigned short TA3EX0;   /* Timer3_A2 Expansion Register 0  */

  struct
  {
    unsigned short TAIDEX0         : 1; /* Timer A Input divider expansion Bit: 0  */
    unsigned short TAIDEX1         : 1; /* Timer A Input divider expansion Bit: 1  */
    unsigned short TAIDEX2         : 1; /* Timer A Input divider expansion Bit: 2  */
  }TA3EX0_bit;
} @ 0x0460;


/*
enum {
  TAIDEX0         = 0x0001,
  TAIDEX1         = 0x0002,
  TAIDEX2         = 0x0004
};
*/



#define __MSP430_HAS_T3A2__            /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_T3A2__ 0x0440
#define TIMER_A3_BASE __MSP430_BASEADDRESS_T3A2__
/* TA3IV Definitions */
#define TA3IV_NONE          (0x0000u)    /* No Interrupt pending */
#define TA3IV_TACCR1        (0x0002u)    /* TA3CCR1_CCIFG */
#define TA3IV_3             (0x0006u)    /* Reserved */
#define TA3IV_4             (0x0008u)    /* Reserved */
#define TA3IV_5             (0x000Au)    /* Reserved */
#define TA3IV_6             (0x000Cu)    /* Reserved */
#define TA3IV_TAIFG         (0x000Eu)    /* TA3IFG */
/* Legacy Defines */
#define TA3IV_TA3CCR1      (0x0002u)    /* TA3CCR1_CCIFG */
#define TA3IV_TA3IFG       (0x000Eu)    /* TA3IFG */

/*-------------------------------------------------------------------------
 *   UCS  Unified System Clock
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short UCSCTL0;   /* UCS Control Register 0  */

  struct
  {
    unsigned short                : 3;
    unsigned short MOD0            : 1; /* Modulation Bit Counter Bit : 0  */
    unsigned short MOD1            : 1; /* Modulation Bit Counter Bit : 1  */
    unsigned short MOD2            : 1; /* Modulation Bit Counter Bit : 2  */
    unsigned short MOD3            : 1; /* Modulation Bit Counter Bit : 3  */
    unsigned short MOD4            : 1; /* Modulation Bit Counter Bit : 4  */
    unsigned short DCO0            : 1; /* DCO TAP Bit : 0  */
    unsigned short DCO1            : 1; /* DCO TAP Bit : 1  */
    unsigned short DCO2            : 1; /* DCO TAP Bit : 2  */
    unsigned short DCO3            : 1; /* DCO TAP Bit : 3  */
    unsigned short DCO4            : 1; /* DCO TAP Bit : 4  */
  } UCSCTL0_bit;

  struct
  {
    unsigned char UCSCTL0_L;
    unsigned char UCSCTL0_H;
  };
} @ 0x0160;

enum {
  MOD0            = 0x0008,
  MOD1            = 0x0010,
  MOD2            = 0x0020,
  MOD3            = 0x0040,
  MOD4            = 0x0080,
  DCO0            = 0x0100,
  DCO1            = 0x0200,
  DCO2            = 0x0400,
  DCO3            = 0x0800,
  DCO4            = 0x1000
};

__no_init volatile union
{
  unsigned short UCSCTL1;   /* UCS Control Register 1  */

  struct
  {
    unsigned short DISMOD          : 1; /* Disable Modulation  */
    unsigned short                : 3;
    unsigned short DCORSEL0        : 1; /* DCO Freq. Range Select Bit : 0  */
    unsigned short DCORSEL1        : 1; /* DCO Freq. Range Select Bit : 1  */
    unsigned short DCORSEL2        : 1; /* DCO Freq. Range Select Bit : 2  */
  } UCSCTL1_bit;

  struct
  {
    unsigned char UCSCTL1_L;
    unsigned char UCSCTL1_H;
  };
} @ 0x0162;

enum {
  DISMOD          = 0x0001,
  DCORSEL0        = 0x0010,
  DCORSEL1        = 0x0020,
  DCORSEL2        = 0x0040
};

__no_init volatile union
{
  unsigned short UCSCTL2;   /* UCS Control Register 2  */

  struct
  {
    unsigned short FLLN0           : 1; /* FLL Multipier Bit : 0  */
    unsigned short FLLN1           : 1; /* FLL Multipier Bit : 1  */
    unsigned short FLLN2           : 1; /* FLL Multipier Bit : 2  */
    unsigned short FLLN3           : 1; /* FLL Multipier Bit : 3  */
    unsigned short FLLN4           : 1; /* FLL Multipier Bit : 4  */
    unsigned short FLLN5           : 1; /* FLL Multipier Bit : 5  */
    unsigned short FLLN6           : 1; /* FLL Multipier Bit : 6  */
    unsigned short FLLN7           : 1; /* FLL Multipier Bit : 7  */
    unsigned short FLLN8           : 1; /* FLL Multipier Bit : 8  */
    unsigned short FLLN9           : 1; /* FLL Multipier Bit : 9  */
    unsigned short                : 2;
    unsigned short FLLD0           : 1; /* Loop Divider Bit : 0  */
    unsigned short FLLD1           : 1; /* Loop Divider Bit : 1  */
    unsigned short FLLD2           : 1; /* Loop Divider Bit : 1  */
  } UCSCTL2_bit;

  struct
  {
    unsigned char UCSCTL2_L;
    unsigned char UCSCTL2_H;
  };
} @ 0x0164;

enum {
  FLLN0           = 0x0001,
  FLLN1           = 0x0002,
  FLLN2           = 0x0004,
  FLLN3           = 0x0008,
  FLLN4           = 0x0010,
  FLLN5           = 0x0020,
  FLLN6           = 0x0040,
  FLLN7           = 0x0080,
  FLLN8           = 0x0100,
  FLLN9           = 0x0200,
  FLLD0           = 0x1000,
  FLLD1           = 0x2000,
  FLLD2           = 0x4000
};

__no_init volatile union
{
  unsigned short UCSCTL3;   /* UCS Control Register 3  */

  struct
  {
    unsigned short FLLREFDIV0      : 1; /* Reference Divider Bit : 0  */
    unsigned short FLLREFDIV1      : 1; /* Reference Divider Bit : 1  */
    unsigned short FLLREFDIV2      : 1; /* Reference Divider Bit : 2  */
    unsigned short                : 1;
    unsigned short SELREF0         : 1; /* FLL Reference Clock Select Bit : 0  */
    unsigned short SELREF1         : 1; /* FLL Reference Clock Select Bit : 1  */
    unsigned short SELREF2         : 1; /* FLL Reference Clock Select Bit : 2  */
  } UCSCTL3_bit;

  struct
  {
    unsigned char UCSCTL3_L;
    unsigned char UCSCTL3_H;
  };
} @ 0x0166;

enum {
  FLLREFDIV0      = 0x0001,
  FLLREFDIV1      = 0x0002,
  FLLREFDIV2      = 0x0004,
  SELREF0         = 0x0010,
  SELREF1         = 0x0020,
  SELREF2         = 0x0040
};

__no_init volatile union
{
  unsigned short UCSCTL4;   /* UCS Control Register 4  */

  struct
  {
    unsigned short SELM0           : 1; /* MCLK Source Select Bit: 0  */
    unsigned short SELM1           : 1; /* MCLK Source Select Bit: 1  */
    unsigned short SELM2           : 1; /* MCLK Source Select Bit: 2  */
    unsigned short                : 1;
    unsigned short SELS0           : 1; /* SMCLK Source Select Bit: 0  */
    unsigned short SELS1           : 1; /* SMCLK Source Select Bit: 1  */
    unsigned short SELS2           : 1; /* SMCLK Source Select Bit: 2  */
    unsigned short                : 1;
    unsigned short SELA0           : 1; /* ACLK Source Select Bit: 0  */
    unsigned short SELA1           : 1; /* ACLK Source Select Bit: 1  */
    unsigned short SELA2           : 1; /* ACLK Source Select Bit: 2  */
  } UCSCTL4_bit;

  struct
  {
    unsigned char UCSCTL4_L;
    unsigned char UCSCTL4_H;
  };
} @ 0x0168;

enum {
  SELM0           = 0x0001,
  SELM1           = 0x0002,
  SELM2           = 0x0004,
  SELS0           = 0x0010,
  SELS1           = 0x0020,
  SELS2           = 0x0040,
  SELA0           = 0x0100,
  SELA1           = 0x0200,
  SELA2           = 0x0400
};

__no_init volatile union
{
  unsigned short UCSCTL5;   /* UCS Control Register 5  */

  struct
  {
    unsigned short DIVM0           : 1; /* MCLK Divider Bit: 0  */
    unsigned short DIVM1           : 1; /* MCLK Divider Bit: 1  */
    unsigned short DIVM2           : 1; /* MCLK Divider Bit: 2  */
    unsigned short                : 1;
    unsigned short DIVS0           : 1; /* SMCLK Divider Bit: 0  */
    unsigned short DIVS1           : 1; /* SMCLK Divider Bit: 1  */
    unsigned short DIVS2           : 1; /* SMCLK Divider Bit: 2  */
    unsigned short                : 1;
    unsigned short DIVA0           : 1; /* ACLK Divider Bit: 0  */
    unsigned short DIVA1           : 1; /* ACLK Divider Bit: 1  */
    unsigned short DIVA2           : 1; /* ACLK Divider Bit: 2  */
    unsigned short                : 1;
    unsigned short DIVPA0          : 1; /* ACLK from Pin Divider Bit: 0  */
    unsigned short DIVPA1          : 1; /* ACLK from Pin Divider Bit: 1  */
    unsigned short DIVPA2          : 1; /* ACLK from Pin Divider Bit: 2  */
  } UCSCTL5_bit;

  struct
  {
    unsigned char UCSCTL5_L;
    unsigned char UCSCTL5_H;
  };
} @ 0x016A;

enum {
  DIVM0           = 0x0001,
  DIVM1           = 0x0002,
  DIVM2           = 0x0004,
  DIVS0           = 0x0010,
  DIVS1           = 0x0020,
  DIVS2           = 0x0040,
  DIVA0           = 0x0100,
  DIVA1           = 0x0200,
  DIVA2           = 0x0400,
  DIVPA0          = 0x1000,
  DIVPA1          = 0x2000,
  DIVPA2          = 0x4000
};

__no_init volatile union
{
  unsigned short UCSCTL6;   /* UCS Control Register 6  */

  struct
  {
    unsigned short XT1OFF          : 1; /* High Frequency Oscillator 1 (XT1) disable  */
    unsigned short SMCLKOFF        : 1; /* SMCLK Off  */
    unsigned short XCAP0           : 1; /* XIN/XOUT Cap Bit: 0  */
    unsigned short XCAP1           : 1; /* XIN/XOUT Cap Bit: 1  */
    unsigned short XT1BYPASS       : 1; /* XT1 bypass mode : 0: internal 1:sourced from external pin  */
    unsigned short XTS             : 1; /* 1: Selects high-freq. oscillator  */
    unsigned short XT1DRIVE0       : 1; /* XT1 Drive Level mode Bit 0  */
    unsigned short XT1DRIVE1       : 1; /* XT1 Drive Level mode Bit 1  */
    unsigned short XT2OFF          : 1; /* High Frequency Oscillator 2 (XT2) disable  */
    unsigned short                : 3;
    unsigned short XT2BYPASS       : 1; /* XT2 bypass mode : 0: internal 1:sourced from external pin  */
    unsigned short                : 1;
    unsigned short XT2DRIVE0       : 1; /* XT2 Drive Level mode Bit 0  */
    unsigned short XT2DRIVE1       : 1; /* XT2 Drive Level mode Bit 1  */
  } UCSCTL6_bit;

  struct
  {
    unsigned char UCSCTL6_L;
    unsigned char UCSCTL6_H;
  };
} @ 0x016C;

enum {
  XT1OFF          = 0x0001,
  SMCLKOFF        = 0x0002,
  XCAP0           = 0x0004,
  XCAP1           = 0x0008,
  XT1BYPASS       = 0x0010,
  XTS             = 0x0020,
  XT1DRIVE0       = 0x0040,
  XT1DRIVE1       = 0x0080,
  XT2OFF          = 0x0100,
  XT2BYPASS       = 0x1000,
  XT2DRIVE0       = 0x4000,
  XT2DRIVE1       = 0x8000
};

__no_init volatile union
{
  unsigned short UCSCTL7;   /* UCS Control Register 7  */

  struct
  {
    unsigned short DCOFFG          : 1; /* DCO Fault Flag  */
    unsigned short XT1LFOFFG       : 1; /* XT1 Low Frequency Oscillator Fault Flag  */
    unsigned short                : 1;
    unsigned short XT2OFFG         : 1; /* High Frequency Oscillator 2 Fault Flag  */
  } UCSCTL7_bit;

  struct
  {
    unsigned char UCSCTL7_L;
    unsigned char UCSCTL7_H;
  };
} @ 0x016E;

enum {
  DCOFFG          = 0x0001,
  XT1LFOFFG       = 0x0002,
  XT2OFFG         = 0x0008
};

__no_init volatile union
{
  unsigned short UCSCTL8;   /* UCS Control Register 8  */

  struct
  {
    unsigned short ACLKREQEN       : 1; /* ACLK Clock Request Enable  */
    unsigned short MCLKREQEN       : 1; /* MCLK Clock Request Enable  */
    unsigned short SMCLKREQEN      : 1; /* SMCLK Clock Request Enable  */
    unsigned short MODOSCREQEN     : 1; /* MODOSC Clock Request Enable  */
  } UCSCTL8_bit;

  struct
  {
    unsigned char UCSCTL8_L;
    unsigned char UCSCTL8_H;
  };
} @ 0x0170;

enum {
  ACLKREQEN       = 0x0001,
  MCLKREQEN       = 0x0002,
  SMCLKREQEN      = 0x0004,
  MODOSCREQEN     = 0x0008
};



#define __MSP430_HAS_UCS__            /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_UCS__ 0x0160
#define UCS_BASE __MSP430_BASEADDRESS_UCS__
#define MOD0_L              (0x0008u)    /* Modulation Bit Counter Bit : 0 */
#define MOD1_L              (0x0010u)    /* Modulation Bit Counter Bit : 1 */
#define MOD2_L              (0x0020u)    /* Modulation Bit Counter Bit : 2 */
#define MOD3_L              (0x0040u)    /* Modulation Bit Counter Bit : 3 */
#define MOD4_L              (0x0080u)    /* Modulation Bit Counter Bit : 4 */
#define DCO0_H              (0x0001u)    /* DCO TAP Bit : 0 */
#define DCO1_H              (0x0002u)    /* DCO TAP Bit : 1 */
#define DCO2_H              (0x0004u)    /* DCO TAP Bit : 2 */
#define DCO3_H              (0x0008u)    /* DCO TAP Bit : 3 */
#define DCO4_H              (0x0010u)    /* DCO TAP Bit : 4 */
/* UCSCTL1 Control Bits */
#define DISMOD_L            (0x0001u)    /* Disable Modulation */
#define DCORSEL0_L          (0x0010u)    /* DCO Freq. Range Select Bit : 0 */
#define DCORSEL1_L          (0x0020u)    /* DCO Freq. Range Select Bit : 1 */
#define DCORSEL2_L          (0x0040u)    /* DCO Freq. Range Select Bit : 2 */

#define DCORSEL_0           (0x0000u)    /* DCO RSEL 0 */
#define DCORSEL_1           (0x0010u)    /* DCO RSEL 1 */
#define DCORSEL_2           (0x0020u)    /* DCO RSEL 2 */
#define DCORSEL_3           (0x0030u)    /* DCO RSEL 3 */
#define DCORSEL_4           (0x0040u)    /* DCO RSEL 4 */
#define DCORSEL_5           (0x0050u)    /* DCO RSEL 5 */
#define DCORSEL_6           (0x0060u)    /* DCO RSEL 6 */
#define DCORSEL_7           (0x0070u)    /* DCO RSEL 7 */
/* UCSCTL2 Control Bits */
#define FLLN0_L             (0x0001u)    /* FLL Multipier Bit : 0 */
#define FLLN1_L             (0x0002u)    /* FLL Multipier Bit : 1 */
#define FLLN2_L             (0x0004u)    /* FLL Multipier Bit : 2 */
#define FLLN3_L             (0x0008u)    /* FLL Multipier Bit : 3 */
#define FLLN4_L             (0x0010u)    /* FLL Multipier Bit : 4 */
#define FLLN5_L             (0x0020u)    /* FLL Multipier Bit : 5 */
#define FLLN6_L             (0x0040u)    /* FLL Multipier Bit : 6 */
#define FLLN7_L             (0x0080u)    /* FLL Multipier Bit : 7 */
/* UCSCTL2 Control Bits */
#define FLLN8_H             (0x0001u)    /* FLL Multipier Bit : 8 */
#define FLLN9_H             (0x0002u)    /* FLL Multipier Bit : 9 */
#define FLLD0_H             (0x0010u)    /* Loop Divider Bit : 0 */
#define FLLD1_H             (0x0020u)    /* Loop Divider Bit : 1 */
#define FLLD2_H             (0x0040u)    /* Loop Divider Bit : 1 */

#define FLLD_0             (0x0000u)    /* Multiply Selected Loop Freq. 1 */
#define FLLD_1             (0x1000u)    /* Multiply Selected Loop Freq. 2 */
#define FLLD_2             (0x2000u)    /* Multiply Selected Loop Freq. 4 */
#define FLLD_3             (0x3000u)    /* Multiply Selected Loop Freq. 8 */
#define FLLD_4             (0x4000u)    /* Multiply Selected Loop Freq. 16 */
#define FLLD_5             (0x5000u)    /* Multiply Selected Loop Freq. 32 */
#define FLLD_6             (0x6000u)    /* Multiply Selected Loop Freq. 32 */
#define FLLD_7             (0x7000u)    /* Multiply Selected Loop Freq. 32 */
#define FLLD__1            (0x0000u)    /* Multiply Selected Loop Freq. By 1 */
#define FLLD__2            (0x1000u)    /* Multiply Selected Loop Freq. By 2 */
#define FLLD__4            (0x2000u)    /* Multiply Selected Loop Freq. By 4 */
#define FLLD__8            (0x3000u)    /* Multiply Selected Loop Freq. By 8 */
#define FLLD__16           (0x4000u)    /* Multiply Selected Loop Freq. By 16 */
#define FLLD__32           (0x5000u)    /* Multiply Selected Loop Freq. By 32 */
/* UCSCTL3 Control Bits */
#define FLLREFDIV0_L        (0x0001u)    /* Reference Divider Bit : 0 */
#define FLLREFDIV1_L        (0x0002u)    /* Reference Divider Bit : 1 */
#define FLLREFDIV2_L        (0x0004u)    /* Reference Divider Bit : 2 */
#define SELREF0_L           (0x0010u)    /* FLL Reference Clock Select Bit : 0 */
#define SELREF1_L           (0x0020u)    /* FLL Reference Clock Select Bit : 1 */
#define SELREF2_L           (0x0040u)    /* FLL Reference Clock Select Bit : 2 */

#define FLLREFDIV_0         (0x0000u)    /* Reference Divider: f(LFCLK)/1 */
#define FLLREFDIV_1         (0x0001u)    /* Reference Divider: f(LFCLK)/2 */
#define FLLREFDIV_2         (0x0002u)    /* Reference Divider: f(LFCLK)/4 */
#define FLLREFDIV_3         (0x0003u)    /* Reference Divider: f(LFCLK)/8 */
#define FLLREFDIV_4         (0x0004u)    /* Reference Divider: f(LFCLK)/12 */
#define FLLREFDIV_5         (0x0005u)    /* Reference Divider: f(LFCLK)/16 */
#define FLLREFDIV_6         (0x0006u)    /* Reference Divider: f(LFCLK)/16 */
#define FLLREFDIV_7         (0x0007u)    /* Reference Divider: f(LFCLK)/16 */
#define FLLREFDIV__1        (0x0000u)    /* Reference Divider: f(LFCLK)/1 */
#define FLLREFDIV__2        (0x0001u)    /* Reference Divider: f(LFCLK)/2 */
#define FLLREFDIV__4        (0x0002u)    /* Reference Divider: f(LFCLK)/4 */
#define FLLREFDIV__8        (0x0003u)    /* Reference Divider: f(LFCLK)/8 */
#define FLLREFDIV__12       (0x0004u)    /* Reference Divider: f(LFCLK)/12 */
#define FLLREFDIV__16       (0x0005u)    /* Reference Divider: f(LFCLK)/16 */
#define SELREF_0            (0x0000u)    /* FLL Reference Clock Select 0 */
#define SELREF_1            (0x0010u)    /* FLL Reference Clock Select 1 */
#define SELREF_2            (0x0020u)    /* FLL Reference Clock Select 2 */
#define SELREF_3            (0x0030u)    /* FLL Reference Clock Select 3 */
#define SELREF_4            (0x0040u)    /* FLL Reference Clock Select 4 */
#define SELREF_5            (0x0050u)    /* FLL Reference Clock Select 5 */
#define SELREF_6            (0x0060u)    /* FLL Reference Clock Select 6 */
#define SELREF_7            (0x0070u)    /* FLL Reference Clock Select 7 */
#define SELREF__XT1CLK      (0x0000u)    /* Multiply Selected Loop Freq. By XT1CLK */
#define SELREF__REFOCLK     (0x0020u)    /* Multiply Selected Loop Freq. By REFOCLK */
#define SELREF__XT2CLK      (0x0050u)    /* Multiply Selected Loop Freq. By XT2CLK */
/* UCSCTL4 Control Bits */
#define SELM0_L             (0x0001u)   /* MCLK Source Select Bit: 0 */
#define SELM1_L             (0x0002u)   /* MCLK Source Select Bit: 1 */
#define SELM2_L             (0x0004u)   /* MCLK Source Select Bit: 2 */
#define SELS0_L             (0x0010u)   /* SMCLK Source Select Bit: 0 */
#define SELS1_L             (0x0020u)   /* SMCLK Source Select Bit: 1 */
#define SELS2_L             (0x0040u)   /* SMCLK Source Select Bit: 2 */
#define SELA0_H             (0x0001u)   /* ACLK Source Select Bit: 0 */
#define SELA1_H             (0x0002u)   /* ACLK Source Select Bit: 1 */
#define SELA2_H             (0x0004u)   /* ACLK Source Select Bit: 2 */

#define SELM_0              (0x0000u)   /* MCLK Source Select 0 */
#define SELM_1              (0x0001u)   /* MCLK Source Select 1 */
#define SELM_2              (0x0002u)   /* MCLK Source Select 2 */
#define SELM_3              (0x0003u)   /* MCLK Source Select 3 */
#define SELM_4              (0x0004u)   /* MCLK Source Select 4 */
#define SELM_5              (0x0005u)   /* MCLK Source Select 5 */
#define SELM_6              (0x0006u)   /* MCLK Source Select 6 */
#define SELM_7              (0x0007u)   /* MCLK Source Select 7 */
#define SELM__XT1CLK        (0x0000u)   /* MCLK Source Select XT1CLK */
#define SELM__VLOCLK        (0x0001u)   /* MCLK Source Select VLOCLK */
#define SELM__REFOCLK       (0x0002u)   /* MCLK Source Select REFOCLK */
#define SELM__DCOCLK        (0x0003u)   /* MCLK Source Select DCOCLK */
#define SELM__DCOCLKDIV     (0x0004u)   /* MCLK Source Select DCOCLKDIV */
#define SELM__XT2CLK        (0x0005u)   /* MCLK Source Select XT2CLK */

#define SELS_0              (0x0000u)   /* SMCLK Source Select 0 */
#define SELS_1              (0x0010u)   /* SMCLK Source Select 1 */
#define SELS_2              (0x0020u)   /* SMCLK Source Select 2 */
#define SELS_3              (0x0030u)   /* SMCLK Source Select 3 */
#define SELS_4              (0x0040u)   /* SMCLK Source Select 4 */
#define SELS_5              (0x0050u)   /* SMCLK Source Select 5 */
#define SELS_6              (0x0060u)   /* SMCLK Source Select 6 */
#define SELS_7              (0x0070u)   /* SMCLK Source Select 7 */
#define SELS__XT1CLK        (0x0000u)   /* SMCLK Source Select XT1CLK */
#define SELS__VLOCLK        (0x0010u)   /* SMCLK Source Select VLOCLK */
#define SELS__REFOCLK       (0x0020u)   /* SMCLK Source Select REFOCLK */
#define SELS__DCOCLK        (0x0030u)   /* SMCLK Source Select DCOCLK */
#define SELS__DCOCLKDIV     (0x0040u)   /* SMCLK Source Select DCOCLKDIV */
#define SELS__XT2CLK        (0x0050u)   /* SMCLK Source Select XT2CLK */

#define SELA_0              (0x0000u)   /* ACLK Source Select 0 */
#define SELA_1              (0x0100u)   /* ACLK Source Select 1 */
#define SELA_2              (0x0200u)   /* ACLK Source Select 2 */
#define SELA_3              (0x0300u)   /* ACLK Source Select 3 */
#define SELA_4              (0x0400u)   /* ACLK Source Select 4 */
#define SELA_5              (0x0500u)   /* ACLK Source Select 5 */
#define SELA_6              (0x0600u)   /* ACLK Source Select 6 */
#define SELA_7              (0x0700u)   /* ACLK Source Select 7 */
#define SELA__XT1CLK        (0x0000u)   /* ACLK Source Select XT1CLK */
#define SELA__VLOCLK        (0x0100u)   /* ACLK Source Select VLOCLK */
#define SELA__REFOCLK       (0x0200u)   /* ACLK Source Select REFOCLK */
#define SELA__DCOCLK        (0x0300u)   /* ACLK Source Select DCOCLK */
#define SELA__DCOCLKDIV     (0x0400u)   /* ACLK Source Select DCOCLKDIV */
#define SELA__XT2CLK        (0x0500u)   /* ACLK Source Select XT2CLK */
/* UCSCTL5 Control Bits */
#define DIVM0_L             (0x0001u)   /* MCLK Divider Bit: 0 */
#define DIVM1_L             (0x0002u)   /* MCLK Divider Bit: 1 */
#define DIVM2_L             (0x0004u)   /* MCLK Divider Bit: 2 */
#define DIVS0_L             (0x0010u)   /* SMCLK Divider Bit: 0 */
#define DIVS1_L             (0x0020u)   /* SMCLK Divider Bit: 1 */
#define DIVS2_L             (0x0040u)   /* SMCLK Divider Bit: 2 */
#define DIVA0_H             (0x0001u)   /* ACLK Divider Bit: 0 */
#define DIVA1_H             (0x0002u)   /* ACLK Divider Bit: 1 */
#define DIVA2_H             (0x0004u)   /* ACLK Divider Bit: 2 */
#define DIVPA0_H            (0x0010u)   /* ACLK from Pin Divider Bit: 0 */
#define DIVPA1_H            (0x0020u)   /* ACLK from Pin Divider Bit: 1 */
#define DIVPA2_H            (0x0040u)   /* ACLK from Pin Divider Bit: 2 */

#define DIVM_0              (0x0000u)    /* MCLK Source Divider 0 */
#define DIVM_1              (0x0001u)    /* MCLK Source Divider 1 */
#define DIVM_2              (0x0002u)    /* MCLK Source Divider 2 */
#define DIVM_3              (0x0003u)    /* MCLK Source Divider 3 */
#define DIVM_4              (0x0004u)    /* MCLK Source Divider 4 */
#define DIVM_5              (0x0005u)    /* MCLK Source Divider 5 */
#define DIVM_6              (0x0006u)    /* MCLK Source Divider 6 */
#define DIVM_7              (0x0007u)    /* MCLK Source Divider 7 */
#define DIVM__1             (0x0000u)    /* MCLK Source Divider f(MCLK)/1 */
#define DIVM__2             (0x0001u)    /* MCLK Source Divider f(MCLK)/2 */
#define DIVM__4             (0x0002u)    /* MCLK Source Divider f(MCLK)/4 */
#define DIVM__8             (0x0003u)    /* MCLK Source Divider f(MCLK)/8 */
#define DIVM__16            (0x0004u)    /* MCLK Source Divider f(MCLK)/16 */
#define DIVM__32            (0x0005u)    /* MCLK Source Divider f(MCLK)/32 */

#define DIVS_0              (0x0000u)    /* SMCLK Source Divider 0 */
#define DIVS_1              (0x0010u)    /* SMCLK Source Divider 1 */
#define DIVS_2              (0x0020u)    /* SMCLK Source Divider 2 */
#define DIVS_3              (0x0030u)    /* SMCLK Source Divider 3 */
#define DIVS_4              (0x0040u)    /* SMCLK Source Divider 4 */
#define DIVS_5              (0x0050u)    /* SMCLK Source Divider 5 */
#define DIVS_6              (0x0060u)    /* SMCLK Source Divider 6 */
#define DIVS_7              (0x0070u)    /* SMCLK Source Divider 7 */
#define DIVS__1             (0x0000u)    /* SMCLK Source Divider f(SMCLK)/1 */
#define DIVS__2             (0x0010u)    /* SMCLK Source Divider f(SMCLK)/2 */
#define DIVS__4             (0x0020u)    /* SMCLK Source Divider f(SMCLK)/4 */
#define DIVS__8             (0x0030u)    /* SMCLK Source Divider f(SMCLK)/8 */
#define DIVS__16            (0x0040u)    /* SMCLK Source Divider f(SMCLK)/16 */
#define DIVS__32            (0x0050u)    /* SMCLK Source Divider f(SMCLK)/32 */

#define DIVA_0              (0x0000u)    /* ACLK Source Divider 0 */
#define DIVA_1              (0x0100u)    /* ACLK Source Divider 1 */
#define DIVA_2              (0x0200u)    /* ACLK Source Divider 2 */
#define DIVA_3              (0x0300u)    /* ACLK Source Divider 3 */
#define DIVA_4              (0x0400u)    /* ACLK Source Divider 4 */
#define DIVA_5              (0x0500u)    /* ACLK Source Divider 5 */
#define DIVA_6              (0x0600u)    /* ACLK Source Divider 6 */
#define DIVA_7              (0x0700u)    /* ACLK Source Divider 7 */
#define DIVA__1             (0x0000u)    /* ACLK Source Divider f(ACLK)/1 */
#define DIVA__2             (0x0100u)    /* ACLK Source Divider f(ACLK)/2 */
#define DIVA__4             (0x0200u)    /* ACLK Source Divider f(ACLK)/4 */
#define DIVA__8             (0x0300u)    /* ACLK Source Divider f(ACLK)/8 */
#define DIVA__16            (0x0400u)    /* ACLK Source Divider f(ACLK)/16 */
#define DIVA__32            (0x0500u)    /* ACLK Source Divider f(ACLK)/32 */

#define DIVPA_0             (0x0000u)    /* ACLK from Pin Source Divider 0 */
#define DIVPA_1             (0x1000u)    /* ACLK from Pin Source Divider 1 */
#define DIVPA_2             (0x2000u)    /* ACLK from Pin Source Divider 2 */
#define DIVPA_3             (0x3000u)    /* ACLK from Pin Source Divider 3 */
#define DIVPA_4             (0x4000u)    /* ACLK from Pin Source Divider 4 */
#define DIVPA_5             (0x5000u)    /* ACLK from Pin Source Divider 5 */
#define DIVPA_6             (0x6000u)    /* ACLK from Pin Source Divider 6 */
#define DIVPA_7             (0x7000u)    /* ACLK from Pin Source Divider 7 */
#define DIVPA__1            (0x0000u)    /* ACLK from Pin Source Divider f(ACLK)/1 */
#define DIVPA__2            (0x1000u)    /* ACLK from Pin Source Divider f(ACLK)/2 */
#define DIVPA__4            (0x2000u)    /* ACLK from Pin Source Divider f(ACLK)/4 */
#define DIVPA__8            (0x3000u)    /* ACLK from Pin Source Divider f(ACLK)/8 */
#define DIVPA__16           (0x4000u)    /* ACLK from Pin Source Divider f(ACLK)/16 */
#define DIVPA__32           (0x5000u)    /* ACLK from Pin Source Divider f(ACLK)/32 */
/* UCSCTL6 Control Bits */
#define XT1OFF_L            (0x0001u)    /* High Frequency Oscillator 1 (XT1) disable */
#define SMCLKOFF_L          (0x0002u)    /* SMCLK Off */
#define XCAP0_L             (0x0004u)   /* XIN/XOUT Cap Bit: 0 */
#define XCAP1_L             (0x0008u)   /* XIN/XOUT Cap Bit: 1 */
#define XT1BYPASS_L         (0x0010u)    /* XT1 bypass mode : 0: internal 1:sourced from external pin */
#define XTS_L               (0x0020u)   /* 1: Selects high-freq. oscillator */
#define XT1DRIVE0_L         (0x0040u)    /* XT1 Drive Level mode Bit 0 */
#define XT1DRIVE1_L         (0x0080u)    /* XT1 Drive Level mode Bit 1 */
/* UCSCTL6 Control Bits */
#define XT2OFF_H            (0x0001u)    /* High Frequency Oscillator 2 (XT2) disable */
#define XT2BYPASS_H         (0x0010u)    /* XT2 bypass mode : 0: internal 1:sourced from external pin */
#define XT2DRIVE0_H         (0x0040u)    /* XT2 Drive Level mode Bit 0 */
#define XT2DRIVE1_H         (0x0080u)    /* XT2 Drive Level mode Bit 1 */

#define XCAP_0              (0x0000u)    /* XIN/XOUT Cap 0 */
#define XCAP_1              (0x0004u)    /* XIN/XOUT Cap 1 */
#define XCAP_2              (0x0008u)    /* XIN/XOUT Cap 2 */
#define XCAP_3              (0x000Cu)    /* XIN/XOUT Cap 3 */
#define XT1DRIVE_0          (0x0000u)    /* XT1 Drive Level mode: 0 */
#define XT1DRIVE_1          (0x0040u)    /* XT1 Drive Level mode: 1 */
#define XT1DRIVE_2          (0x0080u)    /* XT1 Drive Level mode: 2 */
#define XT1DRIVE_3          (0x00C0u)    /* XT1 Drive Level mode: 3 */
#define XT2DRIVE_0          (0x0000u)    /* XT2 Drive Level mode: 0 */
#define XT2DRIVE_1          (0x4000u)    /* XT2 Drive Level mode: 1 */
#define XT2DRIVE_2          (0x8000u)    /* XT2 Drive Level mode: 2 */
#define XT2DRIVE_3          (0xC000u)    /* XT2 Drive Level mode: 3 */
/* UCSCTL7 Control Bits */
#define DCOFFG_L            (0x0001u)    /* DCO Fault Flag */
#define XT1LFOFFG_L         (0x0002u)    /* XT1 Low Frequency Oscillator Fault Flag */
#define XT2OFFG_L           (0x0008u)    /* High Frequency Oscillator 2 Fault Flag */
/* UCSCTL8 Control Bits */
#define ACLKREQEN_L         (0x0001u)    /* ACLK Clock Request Enable */
#define MCLKREQEN_L         (0x0002u)    /* MCLK Clock Request Enable */
#define SMCLKREQEN_L        (0x0004u)    /* SMCLK Clock Request Enable */
#define MODOSCREQEN_L       (0x0008u)    /* MODOSC Clock Request Enable */

/*-------------------------------------------------------------------------
 *   USCI_A0  UART Mode
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short UCA0CTLW0;   /* USCI A0 Control Word Register 0  */

  struct
  {
    unsigned short UCSWRST         : 1; /* USCI Software Reset  */
    unsigned short UCTXBRK         : 1; /* Send next Data as Break  */
    unsigned short UCTXADDR        : 1; /* Send next Data as Address  */
    unsigned short UCDORM          : 1; /* Dormant (Sleep) Mode  */
    unsigned short UCBRKIE         : 1; /* Break interrupt enable  */
    unsigned short UCRXEIE         : 1; /* RX Error interrupt enable  */
    unsigned short UCSSEL0         : 1; /* USCI 0 Clock Source Select 0  */
    unsigned short UCSSEL1         : 1; /* USCI 0 Clock Source Select 1  */
    unsigned short UCSYNC          : 1; /* Sync-Mode  0:UART-Mode / 1:SPI-Mode  */
    unsigned short UCMODE0         : 1; /* Async. Mode: USCI Mode 0  */
    unsigned short UCMODE1         : 1; /* Async. Mode: USCI Mode 1  */
    unsigned short UCSPB           : 1; /* Async. Mode: Stop Bits  0:one / 1: two  */
    unsigned short UC7BIT          : 1; /* Async. Mode: Data Bits  0:8-bits / 1:7-bits  */
    unsigned short UCMSB           : 1; /* Async. Mode: MSB first  0:LSB / 1:MSB  */
    unsigned short UCPAR           : 1; /* Async. Mode: Parity     0:odd / 1:even  */
    unsigned short UCPEN           : 1; /* Async. Mode: Parity enable  */
  } UCA0CTLW0_bit;

  struct
  {
    unsigned char UCA0CTLW0_L;
    unsigned char UCA0CTLW0_H;
  };
  struct
  {
    unsigned char UCA0CTL1;   /* USCI A0 Control Register 1  */
    unsigned char UCA0CTL0;   /* USCI A0 Control Register 0  */
  };
  unsigned short UCA0CTLW0__SPI;   /*  */
  struct
  {
    unsigned short UCSWRST         : 1; /* USCI Software Reset  */
    unsigned short UCSTEM          : 1; /* USCI STE Mode  */
    unsigned short                : 4;
    unsigned short UCSSEL0         : 1; /* USCI 0 Clock Source Select 0  */
    unsigned short UCSSEL1         : 1; /* USCI 0 Clock Source Select 1  */
    unsigned short UCSYNC          : 1; /* Sync-Mode  0:UART-Mode / 1:SPI-Mode  */
    unsigned short UCMODE0         : 1; /* Async. Mode: USCI Mode 0  */
    unsigned short UCMODE1         : 1; /* Async. Mode: USCI Mode 1  */
    unsigned short UCMST           : 1; /* Sync. Mode: Master Select  */
    unsigned short UC7BIT          : 1; /* Async. Mode: Data Bits  0:8-bits / 1:7-bits  */
    unsigned short UCMSB           : 1; /* Async. Mode: MSB first  0:LSB / 1:MSB  */
    unsigned short UCCKPL          : 1; /* Sync. Mode: Clock Polarity  */
    unsigned short UCCKPH          : 1; /* Sync. Mode: Clock Phase  */
  } UCA0CTLW0__SPI_bit;

  struct
  {
    unsigned char UCA0CTL1__SPI;   /*  */
    unsigned char UCA0CTL0__SPI;   /*  */
  };
} @ 0x05C0;

enum {
  UCSWRST         = 0x0001,
  UCTXBRK         = 0x0002,
  UCTXADDR        = 0x0004,
  UCDORM          = 0x0008,
  UCBRKIE         = 0x0010,
  UCRXEIE         = 0x0020,
  UCSSEL0         = 0x0040,
  UCSSEL1         = 0x0080,
  UCSYNC          = 0x0100,
  UCMODE0         = 0x0200,
  UCMODE1         = 0x0400,
  UCSPB           = 0x0800,
  UC7BIT          = 0x1000,
  UCMSB           = 0x2000,
  UCPAR           = 0x4000,
  UCPEN           = 0x8000
};

__no_init volatile union
{
  unsigned short UCA0CTLW1;   /* USCI A0 Control Word Register 1  */

  struct
  {
    unsigned short UCGLIT0         : 1; /* USCI Deglitch Time Bit 0  */
    unsigned short UCGLIT1         : 1; /* USCI Deglitch Time Bit 1  */
  } UCA0CTLW1_bit;

  struct
  {
    unsigned char UCA0CTLW1_L;
    unsigned char UCA0CTLW1_H;
  };
} @ 0x05C2;

enum {
  UCGLIT0         = 0x0001,
  UCGLIT1         = 0x0002
};

__no_init volatile union
{
  unsigned short UCA0BRW;   /* USCI A0 Baud Word Rate 0  */
  struct
  {
    unsigned char UCA0BRW_L;
    unsigned char UCA0BRW_H;
  };
  struct
  {
    unsigned char UCA0BR0;   /* USCI A0 Baud Rate 0  */
    unsigned char UCA0BR1;   /* USCI A0 Baud Rate 1  */
  };
  unsigned short UCA0BRW__SPI;   /*  */
  struct
  {
    unsigned char UCA0BR0__SPI;   /*  */
    unsigned char UCA0BR1__SPI;   /*  */
  };
} @ 0x05C6;

__no_init volatile union
{
  unsigned short UCA0MCTLW;   /* USCI A0 Modulation Control  */

  struct
  {
    unsigned short UCOS16          : 1; /* USCI 16-times Oversampling enable  */
    unsigned short                : 3;
    unsigned short UCBRF0          : 1; /* USCI First Stage Modulation Select 0  */
    unsigned short UCBRF1          : 1; /* USCI First Stage Modulation Select 1  */
    unsigned short UCBRF2          : 1; /* USCI First Stage Modulation Select 2  */
    unsigned short UCBRF3          : 1; /* USCI First Stage Modulation Select 3  */
    unsigned short UCBRS0          : 1; /* USCI Second Stage Modulation Select 0  */
    unsigned short UCBRS1          : 1; /* USCI Second Stage Modulation Select 1  */
    unsigned short UCBRS2          : 1; /* USCI Second Stage Modulation Select 2  */
    unsigned short UCBRS3          : 1; /* USCI Second Stage Modulation Select 3  */
    unsigned short UCBRS4          : 1; /* USCI Second Stage Modulation Select 4  */
    unsigned short UCBRS5          : 1; /* USCI Second Stage Modulation Select 5  */
    unsigned short UCBRS6          : 1; /* USCI Second Stage Modulation Select 6  */
    unsigned short UCBRS7          : 1; /* USCI Second Stage Modulation Select 7  */
  } UCA0MCTLW_bit;

  struct
  {
    unsigned char UCA0MCTLW_L;
    unsigned char UCA0MCTLW_H;
  };
} @ 0x05C8;

enum {
  UCOS16          = 0x0001,
  UCBRF0          = 0x0010,
  UCBRF1          = 0x0020,
  UCBRF2          = 0x0040,
  UCBRF3          = 0x0080,
  UCBRS0          = 0x0100,
  UCBRS1          = 0x0200,
  UCBRS2          = 0x0400,
  UCBRS3          = 0x0800,
  UCBRS4          = 0x1000,
  UCBRS5          = 0x2000,
  UCBRS6          = 0x4000,
  UCBRS7          = 0x8000
};

__no_init volatile union
{
  unsigned char UCA0STATW;   /* USCI A0 Status Register  */

  struct
  {
    unsigned char UCBUSY          : 1; /* USCI Busy Flag  */
    unsigned char UCADDR          : 1; /* USCI Address received Flag  */
    unsigned char UCRXERR         : 1; /* USCI RX Error Flag  */
    unsigned char UCBRK           : 1; /* USCI Break received  */
    unsigned char UCPE            : 1; /* USCI Parity Error Flag  */
    unsigned char UCOE            : 1; /* USCI Overrun Error Flag  */
    unsigned char UCFE            : 1; /* USCI Frame Error Flag  */
    unsigned char UCLISTEN        : 1; /* USCI Listen mode  */
  } UCA0STATW_bit;

  unsigned char UCA0STATW__SPI;   /*  */
  struct
  {
    unsigned char UCBUSY          : 1; /* USCI Busy Flag  */
    unsigned char                : 4;
    unsigned char UCOE            : 1; /* USCI Overrun Error Flag  */
    unsigned char UCFE            : 1; /* USCI Frame Error Flag  */
    unsigned char UCLISTEN        : 1; /* USCI Listen mode  */
  } UCA0STATW__SPI_bit;

} @ 0x05CA;

enum {
  UCBUSY          = 0x0001,
  UCADDR          = 0x0002,
  UCRXERR         = 0x0004,
  UCBRK           = 0x0008,
  UCPE            = 0x0010,
  UCOE            = 0x0020,
  UCFE            = 0x0040,
  UCLISTEN        = 0x0080
};

__no_init volatile union
{
  unsigned __READ short UCA0RXBUF;   /* USCI A0 Receive Buffer  */
  struct
  {
    unsigned __READ char UCA0RXBUF_L;
    unsigned __READ char UCA0RXBUF_H;
  };
  unsigned short UCA0RXBUF__SPI;   /*  */
} @ 0x05CC;

__no_init volatile union
{
  unsigned short UCA0TXBUF;   /* USCI A0 Transmit Buffer  */
  struct
  {
    unsigned char UCA0TXBUF_L;
    unsigned char UCA0TXBUF_H;
  };
  unsigned short UCA0TXBUF__SPI;   /*  */
} @ 0x05CE;


__no_init volatile union
{
  unsigned char UCA0ABCTL;   /* USCI A0 LIN Control  */

  struct
  {
    unsigned char UCABDEN         : 1; /* Auto Baud Rate detect enable  */
    unsigned char                : 1;
    unsigned char UCBTOE          : 1; /* Break Timeout error  */
    unsigned char UCSTOE          : 1; /* Sync-Field Timeout error  */
    unsigned char UCDELIM0        : 1; /* Break Sync Delimiter 0  */
    unsigned char UCDELIM1        : 1; /* Break Sync Delimiter 1  */
  }UCA0ABCTL_bit;
} @ 0x05D0;


enum {
  UCABDEN         = 0x0001,
  UCBTOE          = 0x0004,
  UCSTOE          = 0x0008,
  UCDELIM0        = 0x0010,
  UCDELIM1        = 0x0020
};

__no_init volatile union
{
  unsigned short UCA0IRCTL;   /* USCI A0 IrDA Transmit Control  */

  struct
  {
    unsigned short UCIREN          : 1; /* IRDA Encoder/Decoder enable  */
    unsigned short UCIRTXCLK       : 1; /* IRDA Transmit Pulse Clock Select  */
    unsigned short UCIRTXPL0       : 1; /* IRDA Transmit Pulse Length 0  */
    unsigned short UCIRTXPL1       : 1; /* IRDA Transmit Pulse Length 1  */
    unsigned short UCIRTXPL2       : 1; /* IRDA Transmit Pulse Length 2  */
    unsigned short UCIRTXPL3       : 1; /* IRDA Transmit Pulse Length 3  */
    unsigned short UCIRTXPL4       : 1; /* IRDA Transmit Pulse Length 4  */
    unsigned short UCIRTXPL5       : 1; /* IRDA Transmit Pulse Length 5  */
    unsigned short UCIRRXFE        : 1; /* IRDA Receive Filter enable  */
    unsigned short UCIRRXPL        : 1; /* IRDA Receive Input Polarity  */
    unsigned short UCIRRXFL0       : 1; /* IRDA Receive Filter Length 0  */
    unsigned short UCIRRXFL1       : 1; /* IRDA Receive Filter Length 1  */
    unsigned short UCIRRXFL2       : 1; /* IRDA Receive Filter Length 2  */
    unsigned short UCIRRXFL3       : 1; /* IRDA Receive Filter Length 3  */
    unsigned short UCIRRXFL4       : 1; /* IRDA Receive Filter Length 4  */
    unsigned short UCIRRXFL5       : 1; /* IRDA Receive Filter Length 5  */
  } UCA0IRCTL_bit;

  struct
  {
    unsigned char UCA0IRCTL_L;
    unsigned char UCA0IRCTL_H;
  };
  struct
  {
    unsigned char UCA0IRTCTL;   /* USCI A0 IrDA Transmit Control  */
    unsigned char UCA0IRRCTL;   /* USCI A0 IrDA Receive Control  */
  };
} @ 0x05D2;

enum {
  UCIREN          = 0x0001,
  UCIRTXCLK       = 0x0002,
  UCIRTXPL0       = 0x0004,
  UCIRTXPL1       = 0x0008,
  UCIRTXPL2       = 0x0010,
  UCIRTXPL3       = 0x0020,
  UCIRTXPL4       = 0x0040,
  UCIRTXPL5       = 0x0080,
  UCIRRXFE        = 0x0100,
  UCIRRXPL        = 0x0200,
  UCIRRXFL0       = 0x0400,
  UCIRRXFL1       = 0x0800,
  UCIRRXFL2       = 0x1000,
  UCIRRXFL3       = 0x2000,
  UCIRRXFL4       = 0x4000,
  UCIRRXFL5       = 0x8000
};

__no_init volatile union
{
  unsigned short UCA0IE;   /* USCI A0 Interrupt Enable Register  */
  struct
  {
    unsigned char UCA0IE_L;
    unsigned char UCA0IE_H;
  };
  unsigned short UCA0IE__UART;   /*  */
  struct
  {
    unsigned short UCRXIE          : 1; /* UART Receive Interrupt Enable  */
    unsigned short UCTXIE          : 1; /* UART Transmit Interrupt Enable  */
    unsigned short UCSTTIE         : 1; /* UART Start Bit Interrupt Enalble  */
    unsigned short UCTXCPTIE       : 1; /* UART Transmit Complete Interrupt Enable  */
  } UCA0IE__UART_bit;

  struct
  {
    unsigned char UCA0IE__SPI;   /*  */
  };
  struct
  {
    struct
    {
      unsigned char UCRXIE          : 1; /* UART Receive Interrupt Enable  */
      unsigned char UCTXIE          : 1; /* UART Transmit Interrupt Enable  */
    } UCA0IE__SPI_bit;

  }; 
} @ 0x05DA;

__no_init volatile union
{
  unsigned short UCA0IFG;   /* USCI A0 Interrupt Flags Register  */
  struct
  {
    unsigned char UCA0IFG_L;
    unsigned char UCA0IFG_H;
  };
  unsigned short UCA0IFG__UART;   /*  */
  struct
  {
    unsigned short UCRXIFG         : 1; /* UART Receive Interrupt Flag  */
    unsigned short UCTXIFG         : 1; /* UART Transmit Interrupt Flag  */
    unsigned short UCSTTIFG        : 1; /* UART Start Bit Interrupt Flag  */
    unsigned short UCTXCPTIFG      : 1; /* UART Transmit Complete Interrupt Flag  */
  } UCA0IFG__UART_bit;

  struct
  {
    unsigned char UCA0IFG__SPI;   /*  */
  };
  struct
  {
    struct
    {
      unsigned char UCRXIFG         : 1; /* UART Receive Interrupt Flag  */
      unsigned char UCTXIFG         : 1; /* UART Transmit Interrupt Flag  */
    } UCA0IFG__SPI_bit;

  }; 
} @ 0x05DC;

enum {
  UCRXIE          = 0x0001,
  UCTXIE          = 0x0002,
  UCSTTIE         = 0x0004,
  UCTXCPTIE       = 0x0008
};

enum {
  UCRXIFG         = 0x0001,
  UCTXIFG         = 0x0002,
  UCSTTIFG        = 0x0004,
  UCTXCPTIFG      = 0x0008
};

__no_init volatile union
{
  unsigned short UCA0IV;   /* USCI A0 Interrupt Vector Register  */
  unsigned short UCA0IV__SPI;   /*  */
} @ 0x05DE;

#define __MSP430_HAS_EUSCI_A0__      /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_EUSCI_A0__ 0x05C0
#define EUSCI_A0_BASE __MSP430_BASEADDRESS_EUSCI_A0__

/*-------------------------------------------------------------------------
 *   USCI_A0  SPI Mode
 *-------------------------------------------------------------------------*/


enum {
/*  UCSWRST         = 0x0001, */
  UCSTEM          = 0x0002,
/*  UCSSEL0         = 0x0040, */
/*  UCSSEL1         = 0x0080, */
/*  UCSYNC          = 0x0100, */
/*  UCMODE0         = 0x0200, */
/*  UCMODE1         = 0x0400, */
  UCMST           = 0x0800,
/*  UC7BIT          = 0x1000, */
/*  UCMSB           = 0x2000, */
  UCCKPL          = 0x4000,
  UCCKPH          = 0x8000
};

/*
enum {
  UCBUSY          = 0x0001,
  UCOE            = 0x0020,
  UCFE            = 0x0040,
  UCLISTEN        = 0x0080,
};

*/
/*
enum {
  UCRXIE          = 0x0001,
  UCTXIE          = 0x0002,
};

*/
/*
enum {
  UCRXIFG         = 0x0001,
  UCTXIFG         = 0x0002,
};

*/
/*-------------------------------------------------------------------------
 *   USCI_B0  SPI Mode
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short UCB0CTLW0__SPI;   /*  */

  struct
  {
    unsigned short UCSWRST         : 1; /* USCI Software Reset  */
    unsigned short UCSTEM          : 1; /* USCI STE Mode  */
    unsigned short                : 4;
    unsigned short UCSSEL0         : 1; /* USCI 0 Clock Source Select 0  */
    unsigned short UCSSEL1         : 1; /* USCI 0 Clock Source Select 1  */
    unsigned short UCSYNC          : 1; /* Sync-Mode  0:UART-Mode / 1:SPI-Mode  */
    unsigned short UCMODE0         : 1; /* Async. Mode: USCI Mode 0  */
    unsigned short UCMODE1         : 1; /* Async. Mode: USCI Mode 1  */
    unsigned short UCMST           : 1; /* Sync. Mode: Master Select  */
    unsigned short UC7BIT          : 1; /* Async. Mode: Data Bits  0:8-bits / 1:7-bits  */
    unsigned short UCMSB           : 1; /* Async. Mode: MSB first  0:LSB / 1:MSB  */
    unsigned short UCCKPL          : 1; /* Sync. Mode: Clock Polarity  */
    unsigned short UCCKPH          : 1; /* Sync. Mode: Clock Phase  */
  } UCB0CTLW0__SPI_bit;

  struct
  {
    unsigned char UCB0CTL1__SPI;   /*  */
    unsigned char UCB0CTL0__SPI;   /*  */
  };
  unsigned short UCB0CTLW0;   /* USCI B0 Control Word Register 0  */
  struct
  {
    unsigned short UCSWRST         : 1; /* USCI Software Reset  */
    unsigned short UCTXSTT         : 1; /* Transmit START  */
    unsigned short UCTXSTP         : 1; /* Transmit STOP  */
    unsigned short UCTXNACK        : 1; /* Transmit NACK  */
    unsigned short UCTR            : 1; /* Transmit/Receive Select/Flag  */
    unsigned short UCTXACK         : 1; /* Transmit ACK  */
    unsigned short UCSSEL0         : 1; /* USCI 0 Clock Source Select 0  */
    unsigned short UCSSEL1         : 1; /* USCI 0 Clock Source Select 1  */
    unsigned short                : 1;
    unsigned short UCMODE0         : 1; /* Async. Mode: USCI Mode 0  */
    unsigned short UCMODE1         : 1; /* Async. Mode: USCI Mode 1  */
    unsigned short UCMST           : 1; /* Sync. Mode: Master Select  */
    unsigned short                : 1;
    unsigned short UCMM            : 1; /* Multi-Master Environment  */
    unsigned short UCSLA10         : 1; /* 10-bit Slave Address Mode  */
    unsigned short UCA10           : 1; /* 10-bit Address Mode  */
  } UCB0CTLW0_bit;

  struct
  {
    unsigned char UCB0CTL1;   /* USCI B0 Control Register 1  */
    unsigned char UCB0CTL0;   /* USCI B0 Control Register 0  */
  };
} @ 0x0640;

/*
enum {
  UCSWRST         = 0x0001,
  UCSTEM          = 0x0002,
  UCSSEL0         = 0x0040,
  UCSSEL1         = 0x0080,
  UCSYNC          = 0x0100,
  UCMODE0         = 0x0200,
  UCMODE1         = 0x0400,
  UCMST           = 0x0800,
  UC7BIT          = 0x1000,
  UCMSB           = 0x2000,
  UCCKPL          = 0x4000,
  UCCKPH          = 0x8000,
};

*/
__no_init volatile union
{
  unsigned short UCB0BRW__SPI;   /*  */
  struct
  {
    unsigned char UCB0BR0__SPI;   /*  */
    unsigned char UCB0BR1__SPI;   /*  */
  };
  unsigned short UCB0BRW;   /* USCI B0 Baud Word Rate 0  */
  struct
  {
    unsigned char UCB0BR0;   /* USCI B0 Baud Rate 0  */
    unsigned char UCB0BR1;   /* USCI B0 Baud Rate 1  */
  };
} @ 0x0646;

__no_init volatile union
{
  unsigned short UCB0STATW__SPI;   /*  */

  struct
  {
    unsigned short UCBUSY          : 1; /* USCI Busy Flag  */
    unsigned short                : 4;
    unsigned short UCOE            : 1; /* USCI Overrun Error Flag  */
    unsigned short UCFE            : 1; /* USCI Frame Error Flag  */
    unsigned short UCLISTEN        : 1; /* USCI Listen mode  */
  } UCB0STATW__SPI_bit;

  unsigned short UCB0STATW;   /* USCI B0 Status Word Register  */
  unsigned short UCB0STATW__I2C;   /*  */
  struct
  {
    unsigned short                : 4;
    unsigned short UCBBUSY         : 1; /* Bus Busy Flag  */
    unsigned short UCGC            : 1; /* General Call address received Flag  */
    unsigned short UCSCLLOW        : 1; /* SCL low  */
    unsigned short                : 1;
    unsigned short UCBCNT0         : 1; /* USCI Byte Counter Bit 0  */
    unsigned short UCBCNT1         : 1; /* USCI Byte Counter Bit 1  */
    unsigned short UCBCNT2         : 1; /* USCI Byte Counter Bit 2  */
    unsigned short UCBCNT3         : 1; /* USCI Byte Counter Bit 3  */
    unsigned short UCBCNT4         : 1; /* USCI Byte Counter Bit 4  */
    unsigned short UCBCNT5         : 1; /* USCI Byte Counter Bit 5  */
    unsigned short UCBCNT6         : 1; /* USCI Byte Counter Bit 6  */
    unsigned short UCBCNT7         : 1; /* USCI Byte Counter Bit 7  */
  } UCB0STATW__I2C_bit;

  struct
  {
    unsigned char UCB0STAT__I2C;   /*  */
    unsigned char UCB0BCNT__I2C;   /*  */
  };
  struct
  {
    struct
    {
      unsigned char                : 4;
      unsigned char UCBBUSY         : 1; /* Bus Busy Flag  */
      unsigned char UCGC            : 1; /* General Call address received Flag  */
      unsigned char UCSCLLOW        : 1; /* SCL low  */
    } UCB0STAT__I2C_bit;

    struct
    {
      unsigned char UCBCNT0         : 1; /* USCI Byte Counter Bit 0  */
      unsigned char UCBCNT1         : 1; /* USCI Byte Counter Bit 1  */
      unsigned char UCBCNT2         : 1; /* USCI Byte Counter Bit 2  */
      unsigned char UCBCNT3         : 1; /* USCI Byte Counter Bit 3  */
      unsigned char UCBCNT4         : 1; /* USCI Byte Counter Bit 4  */
      unsigned char UCBCNT5         : 1; /* USCI Byte Counter Bit 5  */
      unsigned char UCBCNT6         : 1; /* USCI Byte Counter Bit 6  */
      unsigned char UCBCNT7         : 1; /* USCI Byte Counter Bit 7  */
    } UCB0BCNT__I2C_bit;
  }; 
} @ 0x0648;

/*
enum {
  UCBUSY          = 0x0001,
  UCOE            = 0x0020,
  UCFE            = 0x0040,
  UCLISTEN        = 0x0080,
};

*/
__no_init volatile union
{
  unsigned short UCB0RXBUF__SPI;   /*  */
  unsigned __READ short UCB0RXBUF;   /* USCI B0 Receive Buffer  */
} @ 0x064C;

__no_init volatile union
{
  unsigned short UCB0TXBUF__SPI;   /*  */
  unsigned short UCB0TXBUF;   /* USCI B0 Transmit Buffer  */
} @ 0x064E;

__no_init volatile union
{
  unsigned short UCB0IE__SPI;   /*  */

  struct
  {
    unsigned short UCRXIE          : 1; /* UART Receive Interrupt Enable  */
    unsigned short UCTXIE          : 1; /* UART Transmit Interrupt Enable  */
  } UCB0IE__SPI_bit;

  unsigned short UCB0IE;   /* USCI B0 Interrupt Enable Register  */
  unsigned short UCB0IE__I2C;   /*  */
  struct
  {
    unsigned short UCRXIE0         : 1; /* I2C Receive Interrupt Enable 0  */
    unsigned short UCTXIE0         : 1; /* I2C Transmit Interrupt Enable 0  */
    unsigned short UCSTTIE         : 1; /* UART Start Bit Interrupt Enalble  */
    unsigned short UCSTPIE         : 1; /* I2C STOP Condition interrupt enable  */
    unsigned short UCALIE          : 1; /* I2C Arbitration Lost interrupt enable  */
    unsigned short UCNACKIE        : 1; /* I2C NACK Condition interrupt enable  */
    unsigned short UCBCNTIE        : 1; /* I2C Automatic stop assertion interrupt enable  */
    unsigned short UCCLTOIE        : 1; /* I2C Clock Low Timeout interrupt enable  */
    unsigned short UCRXIE1         : 1; /* I2C Receive Interrupt Enable 1  */
    unsigned short UCTXIE1         : 1; /* I2C Transmit Interrupt Enable 1  */
    unsigned short UCRXIE2         : 1; /* I2C Receive Interrupt Enable 2  */
    unsigned short UCTXIE2         : 1; /* I2C Transmit Interrupt Enable 2  */
    unsigned short UCRXIE3         : 1; /* I2C Receive Interrupt Enable 3  */
    unsigned short UCTXIE3         : 1; /* I2C Transmit Interrupt Enable 3  */
    unsigned short UCBIT9IE        : 1; /* I2C Bit 9 Position Interrupt Enable 3  */
  } UCB0IE__I2C_bit;

} @ 0x066A;

/*
enum {
  UCRXIE          = 0x0001,
  UCTXIE          = 0x0002,
};

*/
__no_init volatile union
{
  unsigned short UCB0IFG__SPI;   /*  */

  struct
  {
    unsigned short UCRXIFG         : 1; /* UART Receive Interrupt Flag  */
    unsigned short UCTXIFG         : 1; /* UART Transmit Interrupt Flag  */
  } UCB0IFG__SPI_bit;

  unsigned short UCB0IFG;   /* USCI B0 Interrupt Flags Register  */
  unsigned short UCB0IFG__I2C;   /*  */
  struct
  {
    unsigned short UCRXIFG0        : 1; /* I2C Receive Interrupt Flag 0  */
    unsigned short UCTXIFG0        : 1; /* I2C Transmit Interrupt Flag 0  */
    unsigned short UCSTTIFG        : 1; /* UART Start Bit Interrupt Flag  */
    unsigned short UCSTPIFG        : 1; /* I2C STOP Condition interrupt Flag  */
    unsigned short UCALIFG         : 1; /* I2C Arbitration Lost interrupt Flag  */
    unsigned short UCNACKIFG       : 1; /* I2C NACK Condition interrupt Flag  */
    unsigned short UCBCNTIFG       : 1; /* I2C Byte counter interrupt flag  */
    unsigned short UCCLTOIFG       : 1; /* I2C Clock low Timeout interrupt Flag  */
    unsigned short UCRXIFG1        : 1; /* I2C Receive Interrupt Flag 1  */
    unsigned short UCTXIFG1        : 1; /* I2C Transmit Interrupt Flag 1  */
    unsigned short UCRXIFG2        : 1; /* I2C Receive Interrupt Flag 2  */
    unsigned short UCTXIFG2        : 1; /* I2C Transmit Interrupt Flag 2  */
    unsigned short UCRXIFG3        : 1; /* I2C Receive Interrupt Flag 3  */
    unsigned short UCTXIFG3        : 1; /* I2C Transmit Interrupt Flag 3  */
    unsigned short UCBIT9IFG       : 1; /* I2C Bit 9 Possition Interrupt Flag 3  */
  } UCB0IFG__I2C_bit;

} @ 0x066C;

/*
enum {
  UCRXIFG         = 0x0001,
  UCTXIFG         = 0x0002,
};

*/
__no_init volatile union
{
  unsigned short UCB0IV__SPI;   /*  */
  unsigned short UCB0IV;   /* USCI B0 Interrupt Vector Register  */
} @ 0x066E;

/*-------------------------------------------------------------------------
 *   USCI_B0  I2C Mode
 *-------------------------------------------------------------------------*/


enum {
/*  UCSWRST         = 0x0001, */
  UCTXSTT         = 0x0002,
  UCTXSTP         = 0x0004,
  UCTXNACK        = 0x0008,
  UCTR            = 0x0010,
  UCTXACK         = 0x0020,
/*  UCSSEL0         = 0x0040, */
/*  UCSSEL1         = 0x0080, */
/*  UCMODE0         = 0x0200, */
/*  UCMODE1         = 0x0400, */
/*  UCMST           = 0x0800, */
  UCMM            = 0x2000,
  UCSLA10         = 0x4000,
  UCA10           = 0x8000
};

__no_init volatile union
{
  unsigned short UCB0CTLW1;   /* USCI B0 Control Word Register 1  */

  struct
  {
    unsigned short UCGLIT0         : 1; /* USCI Deglitch Time Bit 0  */
    unsigned short UCGLIT1         : 1; /* USCI Deglitch Time Bit 1  */
    unsigned short UCASTP0         : 1; /* USCI Automatic Stop condition generation Bit: 0  */
    unsigned short UCASTP1         : 1; /* USCI Automatic Stop condition generation Bit: 1  */
    unsigned short UCSWACK         : 1; /* USCI Software controlled ACK  */
    unsigned short UCSTPNACK       : 1; /* USCI Acknowledge Stop last byte  */
    unsigned short UCCLTO0         : 1; /* USCI Clock low timeout Bit: 0  */
    unsigned short UCCLTO1         : 1; /* USCI Clock low timeout Bit: 1  */
    unsigned short UCETXINT        : 1; /* USCI Early UCTXIFG0  */
  } UCB0CTLW1_bit;

  struct
  {
    unsigned char UCB0CTLW1_L;
    unsigned char UCB0CTLW1_H;
  };
} @ 0x0642;

enum {
/*  UCGLIT0         = 0x0001, */
/*  UCGLIT1         = 0x0002, */
  UCASTP0         = 0x0004,
  UCASTP1         = 0x0008,
  UCSWACK         = 0x0010,
  UCSTPNACK       = 0x0020,
  UCCLTO0         = 0x0040,
  UCCLTO1         = 0x0080,
  UCETXINT        = 0x0100
};

enum {
  UCBBUSY         = 0x0010,
  UCGC            = 0x0020,
  UCSCLLOW        = 0x0040,
  UCBCNT0         = 0x0100,
  UCBCNT1         = 0x0200,
  UCBCNT2         = 0x0400,
  UCBCNT3         = 0x0800,
  UCBCNT4         = 0x1000,
  UCBCNT5         = 0x2000,
  UCBCNT6         = 0x4000,
  UCBCNT7         = 0x8000
};

/*
enum {
  UCBBUSY         = 0x0010,
  UCGC            = 0x0020,
  UCSCLLOW        = 0x0040,
};

*/
/*
enum {
  UCBCNT0         = 0x0001,
  UCBCNT1         = 0x0002,
  UCBCNT2         = 0x0004,
  UCBCNT3         = 0x0008,
  UCBCNT4         = 0x0010,
  UCBCNT5         = 0x0020,
  UCBCNT6         = 0x0040,
  UCBCNT7         = 0x0080,
};

*/
__no_init volatile union
{
  unsigned short UCB0TBCNT;   /* USCI B0 Byte Counter Threshold Register  */
  struct
  {
    unsigned char UCB0TBCNT_L;
    unsigned char UCB0TBCNT_H;
  };
} @ 0x064A;

__no_init volatile union
{
  unsigned short UCB0I2COA0;   /* USCI B0 I2C Own Address 0  */

  struct
  {
    unsigned short UCOA0           : 1; /* I2C Own Address Bit 0  */
    unsigned short UCOA1           : 1; /* I2C Own Address Bit 1  */
    unsigned short UCOA2           : 1; /* I2C Own Address Bit 2  */
    unsigned short UCOA3           : 1; /* I2C Own Address Bit 3  */
    unsigned short UCOA4           : 1; /* I2C Own Address Bit 4  */
    unsigned short UCOA5           : 1; /* I2C Own Address Bit 5  */
    unsigned short UCOA6           : 1; /* I2C Own Address Bit 6  */
    unsigned short UCOA7           : 1; /* I2C Own Address Bit 7  */
    unsigned short UCOA8           : 1; /* I2C Own Address Bit 8  */
    unsigned short UCOA9           : 1; /* I2C Own Address Bit 9  */
    unsigned short UCOAEN          : 1; /* I2C Own Address enable  */
    unsigned short                : 4;
    unsigned short UCGCEN          : 1; /* I2C General Call enable  */
  } UCB0I2COA0_bit;

  struct
  {
    unsigned char UCB0I2COA0_L;
    unsigned char UCB0I2COA0_H;
  };
} @ 0x0654;

enum {
  UCOA0           = 0x0001,
  UCOA1           = 0x0002,
  UCOA2           = 0x0004,
  UCOA3           = 0x0008,
  UCOA4           = 0x0010,
  UCOA5           = 0x0020,
  UCOA6           = 0x0040,
  UCOA7           = 0x0080,
  UCOA8           = 0x0100,
  UCOA9           = 0x0200,
  UCOAEN          = 0x0400,
  UCGCEN          = 0x8000
};

__no_init volatile union
{
  unsigned short UCB0I2COA1;   /* USCI B0 I2C Own Address 1  */

  struct
  {
    unsigned short UCOA0           : 1; /* I2C Own Address Bit 0  */
    unsigned short UCOA1           : 1; /* I2C Own Address Bit 1  */
    unsigned short UCOA2           : 1; /* I2C Own Address Bit 2  */
    unsigned short UCOA3           : 1; /* I2C Own Address Bit 3  */
    unsigned short UCOA4           : 1; /* I2C Own Address Bit 4  */
    unsigned short UCOA5           : 1; /* I2C Own Address Bit 5  */
    unsigned short UCOA6           : 1; /* I2C Own Address Bit 6  */
    unsigned short UCOA7           : 1; /* I2C Own Address Bit 7  */
    unsigned short UCOA8           : 1; /* I2C Own Address Bit 8  */
    unsigned short UCOA9           : 1; /* I2C Own Address Bit 9  */
    unsigned short UCOAEN          : 1; /* I2C Own Address enable  */
  } UCB0I2COA1_bit;

  struct
  {
    unsigned char UCB0I2COA1_L;
    unsigned char UCB0I2COA1_H;
  };
} @ 0x0656;

/*
enum {
  UCOA0           = 0x0001,
  UCOA1           = 0x0002,
  UCOA2           = 0x0004,
  UCOA3           = 0x0008,
  UCOA4           = 0x0010,
  UCOA5           = 0x0020,
  UCOA6           = 0x0040,
  UCOA7           = 0x0080,
  UCOA8           = 0x0100,
  UCOA9           = 0x0200,
  UCOAEN          = 0x0400,
};

*/
__no_init volatile union
{
  unsigned short UCB0I2COA2;   /* USCI B0 I2C Own Address 2  */

  struct
  {
    unsigned short UCOA0           : 1; /* I2C Own Address Bit 0  */
    unsigned short UCOA1           : 1; /* I2C Own Address Bit 1  */
    unsigned short UCOA2           : 1; /* I2C Own Address Bit 2  */
    unsigned short UCOA3           : 1; /* I2C Own Address Bit 3  */
    unsigned short UCOA4           : 1; /* I2C Own Address Bit 4  */
    unsigned short UCOA5           : 1; /* I2C Own Address Bit 5  */
    unsigned short UCOA6           : 1; /* I2C Own Address Bit 6  */
    unsigned short UCOA7           : 1; /* I2C Own Address Bit 7  */
    unsigned short UCOA8           : 1; /* I2C Own Address Bit 8  */
    unsigned short UCOA9           : 1; /* I2C Own Address Bit 9  */
    unsigned short UCOAEN          : 1; /* I2C Own Address enable  */
  } UCB0I2COA2_bit;

  struct
  {
    unsigned char UCB0I2COA2_L;
    unsigned char UCB0I2COA2_H;
  };
} @ 0x0658;

/*
enum {
  UCOA0           = 0x0001,
  UCOA1           = 0x0002,
  UCOA2           = 0x0004,
  UCOA3           = 0x0008,
  UCOA4           = 0x0010,
  UCOA5           = 0x0020,
  UCOA6           = 0x0040,
  UCOA7           = 0x0080,
  UCOA8           = 0x0100,
  UCOA9           = 0x0200,
  UCOAEN          = 0x0400,
};

*/
__no_init volatile union
{
  unsigned short UCB0I2COA3;   /* USCI B0 I2C Own Address 3  */

  struct
  {
    unsigned short UCOA0           : 1; /* I2C Own Address Bit 0  */
    unsigned short UCOA1           : 1; /* I2C Own Address Bit 1  */
    unsigned short UCOA2           : 1; /* I2C Own Address Bit 2  */
    unsigned short UCOA3           : 1; /* I2C Own Address Bit 3  */
    unsigned short UCOA4           : 1; /* I2C Own Address Bit 4  */
    unsigned short UCOA5           : 1; /* I2C Own Address Bit 5  */
    unsigned short UCOA6           : 1; /* I2C Own Address Bit 6  */
    unsigned short UCOA7           : 1; /* I2C Own Address Bit 7  */
    unsigned short UCOA8           : 1; /* I2C Own Address Bit 8  */
    unsigned short UCOA9           : 1; /* I2C Own Address Bit 9  */
    unsigned short UCOAEN          : 1; /* I2C Own Address enable  */
  } UCB0I2COA3_bit;

  struct
  {
    unsigned char UCB0I2COA3_L;
    unsigned char UCB0I2COA3_H;
  };
} @ 0x065A;

/*
enum {
  UCOA0           = 0x0001,
  UCOA1           = 0x0002,
  UCOA2           = 0x0004,
  UCOA3           = 0x0008,
  UCOA4           = 0x0010,
  UCOA5           = 0x0020,
  UCOA6           = 0x0040,
  UCOA7           = 0x0080,
  UCOA8           = 0x0100,
  UCOA9           = 0x0200,
  UCOAEN          = 0x0400,
};

*/
__no_init volatile union
{
  unsigned short UCB0ADDRX;   /* USCI B0 Received Address Register  */

  struct
  {
    unsigned short UCADDRX0        : 1; /* I2C Receive Address Bit 0  */
    unsigned short UCADDRX1        : 1; /* I2C Receive Address Bit 1  */
    unsigned short UCADDRX2        : 1; /* I2C Receive Address Bit 2  */
    unsigned short UCADDRX3        : 1; /* I2C Receive Address Bit 3  */
    unsigned short UCADDRX4        : 1; /* I2C Receive Address Bit 4  */
    unsigned short UCADDRX5        : 1; /* I2C Receive Address Bit 5  */
    unsigned short UCADDRX6        : 1; /* I2C Receive Address Bit 6  */
    unsigned short UCADDRX7        : 1; /* I2C Receive Address Bit 7  */
    unsigned short UCADDRX8        : 1; /* I2C Receive Address Bit 8  */
    unsigned short UCADDRX9        : 1; /* I2C Receive Address Bit 9  */
  } UCB0ADDRX_bit;

  struct
  {
    unsigned char UCB0ADDRX_L;
    unsigned char UCB0ADDRX_H;
  };
} @ 0x065C;

enum {
  UCADDRX0        = 0x0001,
  UCADDRX1        = 0x0002,
  UCADDRX2        = 0x0004,
  UCADDRX3        = 0x0008,
  UCADDRX4        = 0x0010,
  UCADDRX5        = 0x0020,
  UCADDRX6        = 0x0040,
  UCADDRX7        = 0x0080,
  UCADDRX8        = 0x0100,
  UCADDRX9        = 0x0200
};

__no_init volatile union
{
  unsigned short UCB0ADDMASK;   /* USCI B0 Address Mask Register  */

  struct
  {
    unsigned short UCADDMASK0      : 1; /* I2C Address Mask Bit 0  */
    unsigned short UCADDMASK1      : 1; /* I2C Address Mask Bit 1  */
    unsigned short UCADDMASK2      : 1; /* I2C Address Mask Bit 2  */
    unsigned short UCADDMASK3      : 1; /* I2C Address Mask Bit 3  */
    unsigned short UCADDMASK4      : 1; /* I2C Address Mask Bit 4  */
    unsigned short UCADDMASK5      : 1; /* I2C Address Mask Bit 5  */
    unsigned short UCADDMASK6      : 1; /* I2C Address Mask Bit 6  */
    unsigned short UCADDMASK7      : 1; /* I2C Address Mask Bit 7  */
    unsigned short UCADDMASK8      : 1; /* I2C Address Mask Bit 8  */
    unsigned short UCADDMASK9      : 1; /* I2C Address Mask Bit 9  */
  } UCB0ADDMASK_bit;

  struct
  {
    unsigned char UCB0ADDMASK_L;
    unsigned char UCB0ADDMASK_H;
  };
} @ 0x065E;

enum {
  UCADDMASK0      = 0x0001,
  UCADDMASK1      = 0x0002,
  UCADDMASK2      = 0x0004,
  UCADDMASK3      = 0x0008,
  UCADDMASK4      = 0x0010,
  UCADDMASK5      = 0x0020,
  UCADDMASK6      = 0x0040,
  UCADDMASK7      = 0x0080,
  UCADDMASK8      = 0x0100,
  UCADDMASK9      = 0x0200
};

__no_init volatile union
{
  unsigned short UCB0I2CSA;   /* USCI B0 I2C Slave Address  */

  struct
  {
    unsigned short UCSA0           : 1; /* I2C Slave Address Bit 0  */
    unsigned short UCSA1           : 1; /* I2C Slave Address Bit 1  */
    unsigned short UCSA2           : 1; /* I2C Slave Address Bit 2  */
    unsigned short UCSA3           : 1; /* I2C Slave Address Bit 3  */
    unsigned short UCSA4           : 1; /* I2C Slave Address Bit 4  */
    unsigned short UCSA5           : 1; /* I2C Slave Address Bit 5  */
    unsigned short UCSA6           : 1; /* I2C Slave Address Bit 6  */
    unsigned short UCSA7           : 1; /* I2C Slave Address Bit 7  */
    unsigned short UCSA8           : 1; /* I2C Slave Address Bit 8  */
    unsigned short UCSA9           : 1; /* I2C Slave Address Bit 9  */
  } UCB0I2CSA_bit;

  struct
  {
    unsigned char UCB0I2CSA_L;
    unsigned char UCB0I2CSA_H;
  };
} @ 0x0660;

enum {
  UCSA0           = 0x0001,
  UCSA1           = 0x0002,
  UCSA2           = 0x0004,
  UCSA3           = 0x0008,
  UCSA4           = 0x0010,
  UCSA5           = 0x0020,
  UCSA6           = 0x0040,
  UCSA7           = 0x0080,
  UCSA8           = 0x0100,
  UCSA9           = 0x0200
};

enum {
  UCRXIE0         = 0x0001,
  UCTXIE0         = 0x0002,
/*  UCSTTIE         = 0x0004, */
  UCSTPIE         = 0x0008,
  UCALIE          = 0x0010,
  UCNACKIE        = 0x0020,
  UCBCNTIE        = 0x0040,
  UCCLTOIE        = 0x0080,
  UCRXIE1         = 0x0100,
  UCTXIE1         = 0x0200,
  UCRXIE2         = 0x0400,
  UCTXIE2         = 0x0800,
  UCRXIE3         = 0x1000,
  UCTXIE3         = 0x2000,
  UCBIT9IE        = 0x4000
};

enum {
  UCRXIFG0        = 0x0001,
  UCTXIFG0        = 0x0002,
/*  UCSTTIFG        = 0x0004, */
  UCSTPIFG        = 0x0008,
  UCALIFG         = 0x0010,
  UCNACKIFG       = 0x0020,
  UCBCNTIFG       = 0x0040,
  UCCLTOIFG       = 0x0080,
  UCRXIFG1        = 0x0100,
  UCTXIFG1        = 0x0200,
  UCRXIFG2        = 0x0400,
  UCTXIFG2        = 0x0800,
  UCRXIFG3        = 0x1000,
  UCTXIFG3        = 0x2000,
  UCBIT9IFG       = 0x4000
};

#define __MSP430_HAS_EUSCI_B0__       /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_EUSCI_B0__ 0x0640
#define EUSCI_B0_BASE __MSP430_BASEADDRESS_EUSCI_B0__
#define UCB0STAT            UCB0STATW_L /* USCI B0 Status Register */
#define UCB0BCNT            UCB0STATW_H /* USCI B0 Byte Counter Register */
#define UCSSEL1_L           (0x0080u)    /* USCI 0 Clock Source Select 1 */
#define UCSSEL0_L           (0x0040u)    /* USCI 0 Clock Source Select 0 */
#define UCRXEIE_L           (0x0020u)    /* RX Error interrupt enable */
#define UCBRKIE_L           (0x0010u)    /* Break interrupt enable */
#define UCDORM_L            (0x0008u)    /* Dormant (Sleep) Mode */
#define UCTXADDR_L          (0x0004u)    /* Send next Data as Address */
#define UCTXBRK_L           (0x0002u)    /* Send next Data as Break */
#define UCSWRST_L           (0x0001u)    /* USCI Software Reset */
#define UCPEN_H             (0x0080u)    /* Async. Mode: Parity enable */
#define UCPAR_H             (0x0040u)    /* Async. Mode: Parity     0:odd / 1:even */
#define UCMSB_H             (0x0020u)    /* Async. Mode: MSB first  0:LSB / 1:MSB */
#define UC7BIT_H            (0x0010u)    /* Async. Mode: Data Bits  0:8-bits / 1:7-bits */
#define UCSPB_H             (0x0008u)    /* Async. Mode: Stop Bits  0:one / 1: two */
#define UCMODE1_H           (0x0004u)    /* Async. Mode: USCI Mode 1 */
#define UCMODE0_H           (0x0002u)    /* Async. Mode: USCI Mode 0 */
#define UCSYNC_H            (0x0001u)    /* Sync-Mode  0:UART-Mode / 1:SPI-Mode */
#define UCTXACK_L           (0x0020u)    /* Transmit ACK */
#define UCTR_L              (0x0010u)    /* Transmit/Receive Select/Flag */
#define UCTXNACK_L          (0x0008u)    /* Transmit NACK */
#define UCTXSTP_L           (0x0004u)    /* Transmit STOP */
#define UCTXSTT_L           (0x0002u)    /* Transmit START */
#define UCA10_H             (0x0080u)    /* 10-bit Address Mode */
#define UCSLA10_H           (0x0040u)    /* 10-bit Slave Address Mode */
#define UCMM_H              (0x0020u)    /* Multi-Master Environment */

#define UCMODE_0            (0x0000u)    /* Sync. Mode: USCI Mode: 0 */
#define UCMODE_1            (0x0200u)    /* Sync. Mode: USCI Mode: 1 */
#define UCMODE_2            (0x0400u)    /* Sync. Mode: USCI Mode: 2 */
#define UCMODE_3            (0x0600u)    /* Sync. Mode: USCI Mode: 3 */

#define UCSSEL_0            (0x0000u)    /* USCI 0 Clock Source: 0 */
#define UCSSEL_1            (0x0040u)    /* USCI 0 Clock Source: 1 */
#define UCSSEL_2            (0x0080u)    /* USCI 0 Clock Source: 2 */
#define UCSSEL_3            (0x00C0u)    /* USCI 0 Clock Source: 3 */
#define UCSSEL__UCLK        (0x0000u)    /* USCI 0 Clock Source: UCLK */
#define UCSSEL__ACLK        (0x0040u)    /* USCI 0 Clock Source: ACLK */
#define UCSSEL__SMCLK       (0x0080u)    /* USCI 0 Clock Source: SMCLK */
#define UCGLIT1_L           (0x0002u)    /* USCI Deglitch Time Bit 1 */
#define UCGLIT0_L           (0x0001u)    /* USCI Deglitch Time Bit 0 */
#define UCCLTO1_L           (0x0080u)    /* USCI Clock low timeout Bit: 1 */
#define UCCLTO0_L           (0x0040u)    /* USCI Clock low timeout Bit: 0 */
#define UCSTPNACK_L         (0x0020u)    /* USCI Acknowledge Stop last byte */
#define UCSWACK_L           (0x0010u)    /* USCI Software controlled ACK */
#define UCASTP1_L           (0x0008u)    /* USCI Automatic Stop condition generation Bit: 1 */
#define UCASTP0_L           (0x0004u)    /* USCI Automatic Stop condition generation Bit: 0 */
#define UCETXINT_H          (0x0001u)    /* USCI Early UCTXIFG0 */

#define UCGLIT_0            (0x0000u)    /* USCI Deglitch time: 0 */
#define UCGLIT_1            (0x0001u)    /* USCI Deglitch time: 1 */
#define UCGLIT_2            (0x0002u)    /* USCI Deglitch time: 2 */
#define UCGLIT_3            (0x0003u)    /* USCI Deglitch time: 3 */

#define UCASTP_0            (0x0000u)    /* USCI Automatic Stop condition generation: 0 */
#define UCASTP_1            (0x0004u)    /* USCI Automatic Stop condition generation: 1 */
#define UCASTP_2            (0x0008u)    /* USCI Automatic Stop condition generation: 2 */
#define UCASTP_3            (0x000Cu)    /* USCI Automatic Stop condition generation: 3 */

#define UCCLTO_0            (0x0000u)    /* USCI Clock low timeout: 0 */
#define UCCLTO_1            (0x0040u)    /* USCI Clock low timeout: 1 */
#define UCCLTO_2            (0x0080u)    /* USCI Clock low timeout: 2 */
#define UCCLTO_3            (0x00C0u)    /* USCI Clock low timeout: 3 */
/* UCAxMCTLW Control Bits */
#define UCBRF3_L            (0x0080u)    /* USCI First Stage Modulation Select 3 */
#define UCBRF2_L            (0x0040u)    /* USCI First Stage Modulation Select 2 */
#define UCBRF1_L            (0x0020u)    /* USCI First Stage Modulation Select 1 */
#define UCBRF0_L            (0x0010u)    /* USCI First Stage Modulation Select 0 */
#define UCOS16_L            (0x0001u)    /* USCI 16-times Oversampling enable */
/* UCAxMCTLW Control Bits */
#define UCBRS7_H            (0x0080u)    /* USCI Second Stage Modulation Select 7 */
#define UCBRS6_H            (0x0040u)    /* USCI Second Stage Modulation Select 6 */
#define UCBRS5_H            (0x0020u)    /* USCI Second Stage Modulation Select 5 */
#define UCBRS4_H            (0x0010u)    /* USCI Second Stage Modulation Select 4 */
#define UCBRS3_H            (0x0008u)    /* USCI Second Stage Modulation Select 3 */
#define UCBRS2_H            (0x0004u)    /* USCI Second Stage Modulation Select 2 */
#define UCBRS1_H            (0x0002u)    /* USCI Second Stage Modulation Select 1 */
#define UCBRS0_H            (0x0001u)    /* USCI Second Stage Modulation Select 0 */

#define UCBRF_0             (0x00)    /* USCI First Stage Modulation: 0 */
#define UCBRF_1             (0x10)    /* USCI First Stage Modulation: 1 */
#define UCBRF_2             (0x20)    /* USCI First Stage Modulation: 2 */
#define UCBRF_3             (0x30)    /* USCI First Stage Modulation: 3 */
#define UCBRF_4             (0x40)    /* USCI First Stage Modulation: 4 */
#define UCBRF_5             (0x50)    /* USCI First Stage Modulation: 5 */
#define UCBRF_6             (0x60)    /* USCI First Stage Modulation: 6 */
#define UCBRF_7             (0x70)    /* USCI First Stage Modulation: 7 */
#define UCBRF_8             (0x80)    /* USCI First Stage Modulation: 8 */
#define UCBRF_9             (0x90)    /* USCI First Stage Modulation: 9 */
#define UCBRF_10            (0xA0)    /* USCI First Stage Modulation: A */
#define UCBRF_11            (0xB0)    /* USCI First Stage Modulation: B */
#define UCBRF_12            (0xC0)    /* USCI First Stage Modulation: C */
#define UCBRF_13            (0xD0)    /* USCI First Stage Modulation: D */
#define UCBRF_14            (0xE0)    /* USCI First Stage Modulation: E */
#define UCBRF_15            (0xF0)    /* USCI First Stage Modulation: F */
#define UCIDLE              (0x0002u)  /* USCI Idle line detected Flag */
/* UCBxTBCNT I2C Control Bits */
#define UCTBCNT7            (0x0080u)  /* USCI Byte Counter Bit 7 */
#define UCTBCNT6            (0x0040u)  /* USCI Byte Counter Bit 6 */
#define UCTBCNT5            (0x0020u)  /* USCI Byte Counter Bit 5 */
#define UCTBCNT4            (0x0010u)  /* USCI Byte Counter Bit 4 */
#define UCTBCNT3            (0x0008u)  /* USCI Byte Counter Bit 3 */
#define UCTBCNT2            (0x0004u)  /* USCI Byte Counter Bit 2 */
#define UCTBCNT1            (0x0002u)  /* USCI Byte Counter Bit 1 */
#define UCTBCNT0            (0x0001u)  /* USCI Byte Counter Bit 0 */
/* UCAxIRCTL Control Bits */
#define UCIRTXPL5_L         (0x0080u)  /* IRDA Transmit Pulse Length 5 */
#define UCIRTXPL4_L         (0x0040u)  /* IRDA Transmit Pulse Length 4 */
#define UCIRTXPL3_L         (0x0020u)  /* IRDA Transmit Pulse Length 3 */
#define UCIRTXPL2_L         (0x0010u)  /* IRDA Transmit Pulse Length 2 */
#define UCIRTXPL1_L         (0x0008u)  /* IRDA Transmit Pulse Length 1 */
#define UCIRTXPL0_L         (0x0004u)  /* IRDA Transmit Pulse Length 0 */
#define UCIRTXCLK_L         (0x0002u)  /* IRDA Transmit Pulse Clock Select */
#define UCIREN_L            (0x0001u)  /* IRDA Encoder/Decoder enable */
/* UCAxIRCTL Control Bits */
#define UCIRRXFL5_H         (0x0080u)  /* IRDA Receive Filter Length 5 */
#define UCIRRXFL4_H         (0x0040u)  /* IRDA Receive Filter Length 4 */
#define UCIRRXFL3_H         (0x0020u)  /* IRDA Receive Filter Length 3 */
#define UCIRRXFL2_H         (0x0010u)  /* IRDA Receive Filter Length 2 */
#define UCIRRXFL1_H         (0x0008u)  /* IRDA Receive Filter Length 1 */
#define UCIRRXFL0_H         (0x0004u)  /* IRDA Receive Filter Length 0 */
#define UCIRRXPL_H          (0x0002u)  /* IRDA Receive Input Polarity */
#define UCIRRXFE_H          (0x0001u)  /* IRDA Receive Filter enable */
/* UCBxI2COA0 Control Bits */
#define UCOA7_L             (0x0080u)  /* I2C Own Address Bit 7 */
#define UCOA6_L             (0x0040u)  /* I2C Own Address Bit 6 */
#define UCOA5_L             (0x0020u)  /* I2C Own Address Bit 5 */
#define UCOA4_L             (0x0010u)  /* I2C Own Address Bit 4 */
#define UCOA3_L             (0x0008u)  /* I2C Own Address Bit 3 */
#define UCOA2_L             (0x0004u)  /* I2C Own Address Bit 2 */
#define UCOA1_L             (0x0002u)  /* I2C Own Address Bit 1 */
#define UCOA0_L             (0x0001u)  /* I2C Own Address Bit 0 */
/* UCBxI2COA0 Control Bits */
#define UCGCEN_H            (0x0080u)  /* I2C General Call enable */
#define UCOAEN_H            (0x0004u)  /* I2C Own Address enable */
#define UCOA9_H             (0x0002u)  /* I2C Own Address Bit 9 */
#define UCOA8_H             (0x0001u)  /* I2C Own Address Bit 8 */
/* UCBxADDRX Control Bits */
#define UCADDRX7_L          (0x0080u)  /* I2C Receive Address Bit 7 */
#define UCADDRX6_L          (0x0040u)  /* I2C Receive Address Bit 6 */
#define UCADDRX5_L          (0x0020u)  /* I2C Receive Address Bit 5 */
#define UCADDRX4_L          (0x0010u)  /* I2C Receive Address Bit 4 */
#define UCADDRX3_L          (0x0008u)  /* I2C Receive Address Bit 3 */
#define UCADDRX2_L          (0x0004u)  /* I2C Receive Address Bit 2 */
#define UCADDRX1_L          (0x0002u)  /* I2C Receive Address Bit 1 */
#define UCADDRX0_L          (0x0001u)  /* I2C Receive Address Bit 0 */
/* UCBxADDRX Control Bits */
#define UCADDRX9_H          (0x0002u)  /* I2C Receive Address Bit 9 */
#define UCADDRX8_H          (0x0001u)  /* I2C Receive Address Bit 8 */
/* UCBxADDMASK Control Bits */
#define UCADDMASK7_L        (0x0080u)  /* I2C Address Mask Bit 7 */
#define UCADDMASK6_L        (0x0040u)  /* I2C Address Mask Bit 6 */
#define UCADDMASK5_L        (0x0020u)  /* I2C Address Mask Bit 5 */
#define UCADDMASK4_L        (0x0010u)  /* I2C Address Mask Bit 4 */
#define UCADDMASK3_L        (0x0008u)  /* I2C Address Mask Bit 3 */
#define UCADDMASK2_L        (0x0004u)  /* I2C Address Mask Bit 2 */
#define UCADDMASK1_L        (0x0002u)  /* I2C Address Mask Bit 1 */
#define UCADDMASK0_L        (0x0001u)  /* I2C Address Mask Bit 0 */
/* UCBxADDMASK Control Bits */
#define UCADDMASK9_H        (0x0002u)  /* I2C Address Mask Bit 9 */
#define UCADDMASK8_H        (0x0001u)  /* I2C Address Mask Bit 8 */
/* UCBxI2CSA Control Bits */
#define UCSA7_L             (0x0080u)  /* I2C Slave Address Bit 7 */
#define UCSA6_L             (0x0040u)  /* I2C Slave Address Bit 6 */
#define UCSA5_L             (0x0020u)  /* I2C Slave Address Bit 5 */
#define UCSA4_L             (0x0010u)  /* I2C Slave Address Bit 4 */
#define UCSA3_L             (0x0008u)  /* I2C Slave Address Bit 3 */
#define UCSA2_L             (0x0004u)  /* I2C Slave Address Bit 2 */
#define UCSA1_L             (0x0002u)  /* I2C Slave Address Bit 1 */
#define UCSA0_L             (0x0001u)  /* I2C Slave Address Bit 0 */
/* UCBxI2CSA Control Bits */
#define UCSA9_H             (0x0002u)  /* I2C Slave Address Bit 9 */
#define UCSA8_H             (0x0001u)  /* I2C Slave Address Bit 8 */
/* USCI Interrupt Vector UART Definitions */
#define USCI_NONE            (0x0000u)   /* No Interrupt pending */
#define USCI_UART_UCRXIFG    (0x0002u)   /* Interrupt Vector: UCRXIFG */
#define USCI_UART_UCTXIFG    (0x0004u)   /* Interrupt Vector: UCTXIFG */
#define USCI_UART_UCSTTIFG   (0x0006u)   /* Interrupt Vector: UCSTTIFG */
#define USCI_UART_UCTXCPTIFG (0x0008u)   /* Interrupt Vector: UCTXCPTIFG */
/* USCI Interrupt Vector SPI Definitions */
#define USCI_SPI_UCRXIFG    (0x0002u)    /* Interrupt Vector: UCRXIFG */
#define USCI_SPI_UCTXIFG    (0x0004u)    /* Interrupt Vector: UCTXIFG */
/* USCI Interrupt Vector I2C Definitions */
#define USCI_I2C_UCALIFG    (0x0002u)    /* Interrupt Vector: I2C Mode: UCALIFG */
#define USCI_I2C_UCNACKIFG  (0x0004u)    /* Interrupt Vector: I2C Mode: UCNACKIFG */
#define USCI_I2C_UCSTTIFG   (0x0006u)    /* Interrupt Vector: I2C Mode: UCSTTIFG*/
#define USCI_I2C_UCSTPIFG   (0x0008u)    /* Interrupt Vector: I2C Mode: UCSTPIFG*/
#define USCI_I2C_UCRXIFG3   (0x000Au)    /* Interrupt Vector: I2C Mode: UCRXIFG3 */
#define USCI_I2C_UCTXIFG3   (0x000Cu)    /* Interrupt Vector: I2C Mode: UCTXIFG3 */
#define USCI_I2C_UCRXIFG2   (0x000Eu)    /* Interrupt Vector: I2C Mode: UCRXIFG2 */
#define USCI_I2C_UCTXIFG2   (0x0010u)    /* Interrupt Vector: I2C Mode: UCTXIFG2 */
#define USCI_I2C_UCRXIFG1   (0x0012u)    /* Interrupt Vector: I2C Mode: UCRXIFG1 */
#define USCI_I2C_UCTXIFG1   (0x0014u)    /* Interrupt Vector: I2C Mode: UCTXIFG1 */
#define USCI_I2C_UCRXIFG0   (0x0016u)    /* Interrupt Vector: I2C Mode: UCRXIFG0 */
#define USCI_I2C_UCTXIFG0   (0x0018u)    /* Interrupt Vector: I2C Mode: UCTXIFG0 */
#define USCI_I2C_UCBCNTIFG  (0x001Au)    /* Interrupt Vector: I2C Mode: UCBCNTIFG */
#define USCI_I2C_UCCLTOIFG  (0x001Cu)    /* Interrupt Vector: I2C Mode: UCCLTOIFG */
#define USCI_I2C_UCBIT9IFG  (0x001Eu)    /* Interrupt Vector: I2C Mode: UCBIT9IFG */

/*-------------------------------------------------------------------------
 *   USCI_A1  UART Mode
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short UCA1CTLW0;   /* USCI A1 Control Word Register 0  */

  struct
  {
    unsigned short UCSWRST         : 1; /* USCI Software Reset  */
    unsigned short UCTXBRK         : 1; /* Send next Data as Break  */
    unsigned short UCTXADDR        : 1; /* Send next Data as Address  */
    unsigned short UCDORM          : 1; /* Dormant (Sleep) Mode  */
    unsigned short UCBRKIE         : 1; /* Break interrupt enable  */
    unsigned short UCRXEIE         : 1; /* RX Error interrupt enable  */
    unsigned short UCSSEL0         : 1; /* USCI 0 Clock Source Select 0  */
    unsigned short UCSSEL1         : 1; /* USCI 0 Clock Source Select 1  */
    unsigned short UCSYNC          : 1; /* Sync-Mode  0:UART-Mode / 1:SPI-Mode  */
    unsigned short UCMODE0         : 1; /* Async. Mode: USCI Mode 0  */
    unsigned short UCMODE1         : 1; /* Async. Mode: USCI Mode 1  */
    unsigned short UCSPB           : 1; /* Async. Mode: Stop Bits  0:one / 1: two  */
    unsigned short UC7BIT          : 1; /* Async. Mode: Data Bits  0:8-bits / 1:7-bits  */
    unsigned short UCMSB           : 1; /* Async. Mode: MSB first  0:LSB / 1:MSB  */
    unsigned short UCPAR           : 1; /* Async. Mode: Parity     0:odd / 1:even  */
    unsigned short UCPEN           : 1; /* Async. Mode: Parity enable  */
  } UCA1CTLW0_bit;

  struct
  {
    unsigned char UCA1CTLW0_L;
    unsigned char UCA1CTLW0_H;
  };
  struct
  {
    unsigned char UCA1CTL1;   /* USCI A1 Control Register 1  */
    unsigned char UCA1CTL0;   /* USCI A1 Control Register 0  */
  };
  unsigned short UCA1CTLW0__SPI;   /*  */
  struct
  {
    unsigned short UCSWRST         : 1; /* USCI Software Reset  */
    unsigned short UCSTEM          : 1; /* USCI STE Mode  */
    unsigned short                : 4;
    unsigned short UCSSEL0         : 1; /* USCI 0 Clock Source Select 0  */
    unsigned short UCSSEL1         : 1; /* USCI 0 Clock Source Select 1  */
    unsigned short UCSYNC          : 1; /* Sync-Mode  0:UART-Mode / 1:SPI-Mode  */
    unsigned short UCMODE0         : 1; /* Async. Mode: USCI Mode 0  */
    unsigned short UCMODE1         : 1; /* Async. Mode: USCI Mode 1  */
    unsigned short UCMST           : 1; /* Sync. Mode: Master Select  */
    unsigned short UC7BIT          : 1; /* Async. Mode: Data Bits  0:8-bits / 1:7-bits  */
    unsigned short UCMSB           : 1; /* Async. Mode: MSB first  0:LSB / 1:MSB  */
    unsigned short UCCKPL          : 1; /* Sync. Mode: Clock Polarity  */
    unsigned short UCCKPH          : 1; /* Sync. Mode: Clock Phase  */
  } UCA1CTLW0__SPI_bit;

  struct
  {
    unsigned char UCA1CTL1__SPI;   /*  */
    unsigned char UCA1CTL0__SPI;   /*  */
  };
} @ 0x05E0;

/*
enum {
  UCSWRST         = 0x0001,
  UCTXBRK         = 0x0002,
  UCTXADDR        = 0x0004,
  UCDORM          = 0x0008,
  UCBRKIE         = 0x0010,
  UCRXEIE         = 0x0020,
  UCSSEL0         = 0x0040,
  UCSSEL1         = 0x0080,
  UCSYNC          = 0x0100,
  UCMODE0         = 0x0200,
  UCMODE1         = 0x0400,
  UCSPB           = 0x0800,
  UC7BIT          = 0x1000,
  UCMSB           = 0x2000,
  UCPAR           = 0x4000,
  UCPEN           = 0x8000,
};

*/
__no_init volatile union
{
  unsigned short UCA1CTLW1;   /* USCI A1 Control Word Register 1  */

  struct
  {
    unsigned short UCGLIT0         : 1; /* USCI Deglitch Time Bit 0  */
    unsigned short UCGLIT1         : 1; /* USCI Deglitch Time Bit 1  */
  } UCA1CTLW1_bit;

  struct
  {
    unsigned char UCA1CTLW1_L;
    unsigned char UCA1CTLW1_H;
  };
} @ 0x05E2;

/*
enum {
  UCGLIT0         = 0x0001,
  UCGLIT1         = 0x0002,
};

*/
__no_init volatile union
{
  unsigned short UCA1BRW;   /* USCI A1 Baud Word Rate 0  */
  struct
  {
    unsigned char UCA1BRW_L;
    unsigned char UCA1BRW_H;
  };
  struct
  {
    unsigned char UCA1BR0;   /* USCI A1 Baud Rate 0  */
    unsigned char UCA1BR1;   /* USCI A1 Baud Rate 1  */
  };
  unsigned short UCA1BRW__SPI;   /*  */
  struct
  {
    unsigned char UCA1BR0__SPI;   /*  */
    unsigned char UCA1BR1__SPI;   /*  */
  };
} @ 0x05E6;

__no_init volatile union
{
  unsigned short UCA1MCTLW;   /* USCI A1 Modulation Control  */

  struct
  {
    unsigned short UCOS16          : 1; /* USCI 16-times Oversampling enable  */
    unsigned short                : 3;
    unsigned short UCBRF0          : 1; /* USCI First Stage Modulation Select 0  */
    unsigned short UCBRF1          : 1; /* USCI First Stage Modulation Select 1  */
    unsigned short UCBRF2          : 1; /* USCI First Stage Modulation Select 2  */
    unsigned short UCBRF3          : 1; /* USCI First Stage Modulation Select 3  */
    unsigned short UCBRS0          : 1; /* USCI Second Stage Modulation Select 0  */
    unsigned short UCBRS1          : 1; /* USCI Second Stage Modulation Select 1  */
    unsigned short UCBRS2          : 1; /* USCI Second Stage Modulation Select 2  */
    unsigned short UCBRS3          : 1; /* USCI Second Stage Modulation Select 3  */
    unsigned short UCBRS4          : 1; /* USCI Second Stage Modulation Select 4  */
    unsigned short UCBRS5          : 1; /* USCI Second Stage Modulation Select 5  */
    unsigned short UCBRS6          : 1; /* USCI Second Stage Modulation Select 6  */
    unsigned short UCBRS7          : 1; /* USCI Second Stage Modulation Select 7  */
  } UCA1MCTLW_bit;

  struct
  {
    unsigned char UCA1MCTLW_L;
    unsigned char UCA1MCTLW_H;
  };
} @ 0x05E8;

/*
enum {
  UCOS16          = 0x0001,
  UCBRF0          = 0x0010,
  UCBRF1          = 0x0020,
  UCBRF2          = 0x0040,
  UCBRF3          = 0x0080,
  UCBRS0          = 0x0100,
  UCBRS1          = 0x0200,
  UCBRS2          = 0x0400,
  UCBRS3          = 0x0800,
  UCBRS4          = 0x1000,
  UCBRS5          = 0x2000,
  UCBRS6          = 0x4000,
  UCBRS7          = 0x8000,
};

*/
__no_init volatile union
{
  unsigned char UCA1STATW;   /* USCI A1 Status Register  */

  struct
  {
    unsigned char UCBUSY          : 1; /* USCI Busy Flag  */
    unsigned char UCADDR          : 1; /* USCI Address received Flag  */
    unsigned char UCRXERR         : 1; /* USCI RX Error Flag  */
    unsigned char UCBRK           : 1; /* USCI Break received  */
    unsigned char UCPE            : 1; /* USCI Parity Error Flag  */
    unsigned char UCOE            : 1; /* USCI Overrun Error Flag  */
    unsigned char UCFE            : 1; /* USCI Frame Error Flag  */
    unsigned char UCLISTEN        : 1; /* USCI Listen mode  */
  } UCA1STATW_bit;

  unsigned char UCA1STATW__SPI;   /*  */
  struct
  {
    unsigned char UCBUSY          : 1; /* USCI Busy Flag  */
    unsigned char                : 4;
    unsigned char UCOE            : 1; /* USCI Overrun Error Flag  */
    unsigned char UCFE            : 1; /* USCI Frame Error Flag  */
    unsigned char UCLISTEN        : 1; /* USCI Listen mode  */
  } UCA1STATW__SPI_bit;

} @ 0x05EA;

/*
enum {
  UCBUSY          = 0x0001,
  UCADDR          = 0x0002,
  UCRXERR         = 0x0004,
  UCBRK           = 0x0008,
  UCPE            = 0x0010,
  UCOE            = 0x0020,
  UCFE            = 0x0040,
  UCLISTEN        = 0x0080,
};

*/
__no_init volatile union
{
  unsigned __READ short UCA1RXBUF;   /* USCI A1 Receive Buffer  */
  struct
  {
    unsigned __READ char UCA1RXBUF_L;
    unsigned __READ char UCA1RXBUF_H;
  };
  unsigned short UCA1RXBUF__SPI;   /*  */
} @ 0x05EC;

__no_init volatile union
{
  unsigned short UCA1TXBUF;   /* USCI A1 Transmit Buffer  */
  struct
  {
    unsigned char UCA1TXBUF_L;
    unsigned char UCA1TXBUF_H;
  };
  unsigned short UCA1TXBUF__SPI;   /*  */
} @ 0x05EE;


__no_init volatile union
{
  unsigned char UCA1ABCTL;   /* USCI A1 LIN Control  */

  struct
  {
    unsigned char UCABDEN         : 1; /* Auto Baud Rate detect enable  */
    unsigned char                : 1;
    unsigned char UCBTOE          : 1; /* Break Timeout error  */
    unsigned char UCSTOE          : 1; /* Sync-Field Timeout error  */
    unsigned char UCDELIM0        : 1; /* Break Sync Delimiter 0  */
    unsigned char UCDELIM1        : 1; /* Break Sync Delimiter 1  */
  }UCA1ABCTL_bit;
} @ 0x05F0;


/*
enum {
  UCABDEN         = 0x0001,
  UCBTOE          = 0x0004,
  UCSTOE          = 0x0008,
  UCDELIM0        = 0x0010,
  UCDELIM1        = 0x0020,
};

*/
__no_init volatile union
{
  unsigned short UCA1IRCTL;   /* USCI A1 IrDA Transmit Control  */

  struct
  {
    unsigned short UCIREN          : 1; /* IRDA Encoder/Decoder enable  */
    unsigned short UCIRTXCLK       : 1; /* IRDA Transmit Pulse Clock Select  */
    unsigned short UCIRTXPL0       : 1; /* IRDA Transmit Pulse Length 0  */
    unsigned short UCIRTXPL1       : 1; /* IRDA Transmit Pulse Length 1  */
    unsigned short UCIRTXPL2       : 1; /* IRDA Transmit Pulse Length 2  */
    unsigned short UCIRTXPL3       : 1; /* IRDA Transmit Pulse Length 3  */
    unsigned short UCIRTXPL4       : 1; /* IRDA Transmit Pulse Length 4  */
    unsigned short UCIRTXPL5       : 1; /* IRDA Transmit Pulse Length 5  */
    unsigned short UCIRRXFE        : 1; /* IRDA Receive Filter enable  */
    unsigned short UCIRRXPL        : 1; /* IRDA Receive Input Polarity  */
    unsigned short UCIRRXFL0       : 1; /* IRDA Receive Filter Length 0  */
    unsigned short UCIRRXFL1       : 1; /* IRDA Receive Filter Length 1  */
    unsigned short UCIRRXFL2       : 1; /* IRDA Receive Filter Length 2  */
    unsigned short UCIRRXFL3       : 1; /* IRDA Receive Filter Length 3  */
    unsigned short UCIRRXFL4       : 1; /* IRDA Receive Filter Length 4  */
    unsigned short UCIRRXFL5       : 1; /* IRDA Receive Filter Length 5  */
  } UCA1IRCTL_bit;

  struct
  {
    unsigned char UCA1IRCTL_L;
    unsigned char UCA1IRCTL_H;
  };
  struct
  {
    unsigned char UCA1IRTCTL;   /* USCI A1 IrDA Transmit Control  */
    unsigned char UCA1IRRCTL;   /* USCI A1 IrDA Receive Control  */
  };
} @ 0x05F2;

/*
enum {
  UCIREN          = 0x0001,
  UCIRTXCLK       = 0x0002,
  UCIRTXPL0       = 0x0004,
  UCIRTXPL1       = 0x0008,
  UCIRTXPL2       = 0x0010,
  UCIRTXPL3       = 0x0020,
  UCIRTXPL4       = 0x0040,
  UCIRTXPL5       = 0x0080,
  UCIRRXFE        = 0x0100,
  UCIRRXPL        = 0x0200,
  UCIRRXFL0       = 0x0400,
  UCIRRXFL1       = 0x0800,
  UCIRRXFL2       = 0x1000,
  UCIRRXFL3       = 0x2000,
  UCIRRXFL4       = 0x4000,
  UCIRRXFL5       = 0x8000,
};

*/
__no_init volatile union
{
  unsigned short UCA1IE;   /* USCI A1 Interrupt Enable Register  */
  struct
  {
    unsigned char UCA1IE_L;
    unsigned char UCA1IE_H;
  };
  unsigned short UCA1IE__UART;   /*  */
  struct
  {
    unsigned short UCRXIE          : 1; /* UART Receive Interrupt Enable  */
    unsigned short UCTXIE          : 1; /* UART Transmit Interrupt Enable  */
    unsigned short UCSTTIE         : 1; /* UART Start Bit Interrupt Enalble  */
    unsigned short UCTXCPTIE       : 1; /* UART Transmit Complete Interrupt Enable  */
  } UCA1IE__UART_bit;

  struct
  {
    unsigned char UCA1IE__SPI;   /*  */
  };
  struct
  {
    struct
    {
      unsigned char UCRXIE          : 1; /* UART Receive Interrupt Enable  */
      unsigned char UCTXIE          : 1; /* UART Transmit Interrupt Enable  */
    } UCA1IE__SPI_bit;

  }; 
} @ 0x05FA;

__no_init volatile union
{
  unsigned short UCA1IFG;   /* USCI A1 Interrupt Flags Register  */
  struct
  {
    unsigned char UCA1IFG_L;
    unsigned char UCA1IFG_H;
  };
  unsigned short UCA1IFG__UART;   /*  */
  struct
  {
    unsigned short UCRXIFG         : 1; /* UART Receive Interrupt Flag  */
    unsigned short UCTXIFG         : 1; /* UART Transmit Interrupt Flag  */
    unsigned short UCSTTIFG        : 1; /* UART Start Bit Interrupt Flag  */
    unsigned short UCTXCPTIFG      : 1; /* UART Transmit Complete Interrupt Flag  */
  } UCA1IFG__UART_bit;

  struct
  {
    unsigned char UCA1IFG__SPI;   /*  */
  };
  struct
  {
    struct
    {
      unsigned char UCRXIFG         : 1; /* UART Receive Interrupt Flag  */
      unsigned char UCTXIFG         : 1; /* UART Transmit Interrupt Flag  */
    } UCA1IFG__SPI_bit;

  }; 
} @ 0x05FC;

/*
enum {
  UCRXIE          = 0x0001,
  UCTXIE          = 0x0002,
  UCSTTIE         = 0x0004,
  UCTXCPTIE       = 0x0008,
};

*/
/*
enum {
  UCRXIFG         = 0x0001,
  UCTXIFG         = 0x0002,
  UCSTTIFG        = 0x0004,
  UCTXCPTIFG      = 0x0008,
};

*/
__no_init volatile union
{
  unsigned short UCA1IV;   /* USCI A1 Interrupt Vector Register  */
  unsigned short UCA1IV__SPI;   /*  */
} @ 0x05FE;

#define __MSP430_HAS_EUSCI_A1__      /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_EUSCI_A1__ 0x05E0
#define EUSCI_A1_BASE __MSP430_BASEADDRESS_EUSCI_A1__

/*-------------------------------------------------------------------------
 *   USCI_A1  SPI Mode
 *-------------------------------------------------------------------------*/


/*
enum {
  UCSWRST         = 0x0001,
  UCSTEM          = 0x0002,
  UCSSEL0         = 0x0040,
  UCSSEL1         = 0x0080,
  UCSYNC          = 0x0100,
  UCMODE0         = 0x0200,
  UCMODE1         = 0x0400,
  UCMST           = 0x0800,
  UC7BIT          = 0x1000,
  UCMSB           = 0x2000,
  UCCKPL          = 0x4000,
  UCCKPH          = 0x8000,
};

*/
/*
enum {
  UCBUSY          = 0x0001,
  UCOE            = 0x0020,
  UCFE            = 0x0040,
  UCLISTEN        = 0x0080,
};

*/
/*
enum {
  UCRXIE          = 0x0001,
  UCTXIE          = 0x0002,
};

*/
/*
enum {
  UCRXIFG         = 0x0001,
  UCTXIFG         = 0x0002,
};

*/
/*-------------------------------------------------------------------------
 *   USCI_A2  UART Mode
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short UCA2CTLW0;   /* USCI A2 Control Word Register 0  */

  struct
  {
    unsigned short UCSWRST         : 1; /* USCI Software Reset  */
    unsigned short UCTXBRK         : 1; /* Send next Data as Break  */
    unsigned short UCTXADDR        : 1; /* Send next Data as Address  */
    unsigned short UCDORM          : 1; /* Dormant (Sleep) Mode  */
    unsigned short UCBRKIE         : 1; /* Break interrupt enable  */
    unsigned short UCRXEIE         : 1; /* RX Error interrupt enable  */
    unsigned short UCSSEL0         : 1; /* USCI 0 Clock Source Select 0  */
    unsigned short UCSSEL1         : 1; /* USCI 0 Clock Source Select 1  */
    unsigned short UCSYNC          : 1; /* Sync-Mode  0:UART-Mode / 1:SPI-Mode  */
    unsigned short UCMODE0         : 1; /* Async. Mode: USCI Mode 0  */
    unsigned short UCMODE1         : 1; /* Async. Mode: USCI Mode 1  */
    unsigned short UCSPB           : 1; /* Async. Mode: Stop Bits  0:one / 1: two  */
    unsigned short UC7BIT          : 1; /* Async. Mode: Data Bits  0:8-bits / 1:7-bits  */
    unsigned short UCMSB           : 1; /* Async. Mode: MSB first  0:LSB / 1:MSB  */
    unsigned short UCPAR           : 1; /* Async. Mode: Parity     0:odd / 1:even  */
    unsigned short UCPEN           : 1; /* Async. Mode: Parity enable  */
  } UCA2CTLW0_bit;

  struct
  {
    unsigned char UCA2CTLW0_L;
    unsigned char UCA2CTLW0_H;
  };
  struct
  {
    unsigned char UCA2CTL1;   /* USCI A2 Control Register 1  */
    unsigned char UCA2CTL0;   /* USCI A2 Control Register 0  */
  };
  unsigned short UCA2CTLW0__SPI;   /*  */
  struct
  {
    unsigned short UCSWRST         : 1; /* USCI Software Reset  */
    unsigned short UCSTEM          : 1; /* USCI STE Mode  */
    unsigned short                : 4;
    unsigned short UCSSEL0         : 1; /* USCI 0 Clock Source Select 0  */
    unsigned short UCSSEL1         : 1; /* USCI 0 Clock Source Select 1  */
    unsigned short UCSYNC          : 1; /* Sync-Mode  0:UART-Mode / 1:SPI-Mode  */
    unsigned short UCMODE0         : 1; /* Async. Mode: USCI Mode 0  */
    unsigned short UCMODE1         : 1; /* Async. Mode: USCI Mode 1  */
    unsigned short UCMST           : 1; /* Sync. Mode: Master Select  */
    unsigned short UC7BIT          : 1; /* Async. Mode: Data Bits  0:8-bits / 1:7-bits  */
    unsigned short UCMSB           : 1; /* Async. Mode: MSB first  0:LSB / 1:MSB  */
    unsigned short UCCKPL          : 1; /* Sync. Mode: Clock Polarity  */
    unsigned short UCCKPH          : 1; /* Sync. Mode: Clock Phase  */
  } UCA2CTLW0__SPI_bit;

  struct
  {
    unsigned char UCA2CTL1__SPI;   /*  */
    unsigned char UCA2CTL0__SPI;   /*  */
  };
} @ 0x0600;

/*
enum {
  UCSWRST         = 0x0001,
  UCTXBRK         = 0x0002,
  UCTXADDR        = 0x0004,
  UCDORM          = 0x0008,
  UCBRKIE         = 0x0010,
  UCRXEIE         = 0x0020,
  UCSSEL0         = 0x0040,
  UCSSEL1         = 0x0080,
  UCSYNC          = 0x0100,
  UCMODE0         = 0x0200,
  UCMODE1         = 0x0400,
  UCSPB           = 0x0800,
  UC7BIT          = 0x1000,
  UCMSB           = 0x2000,
  UCPAR           = 0x4000,
  UCPEN           = 0x8000,
};

*/
__no_init volatile union
{
  unsigned short UCA2CTLW1;   /* USCI A2 Control Word Register 1  */

  struct
  {
    unsigned short UCGLIT0         : 1; /* USCI Deglitch Time Bit 0  */
    unsigned short UCGLIT1         : 1; /* USCI Deglitch Time Bit 1  */
  } UCA2CTLW1_bit;

  struct
  {
    unsigned char UCA2CTLW1_L;
    unsigned char UCA2CTLW1_H;
  };
} @ 0x0602;

/*
enum {
  UCGLIT0         = 0x0001,
  UCGLIT1         = 0x0002,
};

*/
__no_init volatile union
{
  unsigned short UCA2BRW;   /* USCI A2 Baud Word Rate 0  */
  struct
  {
    unsigned char UCA2BRW_L;
    unsigned char UCA2BRW_H;
  };
  struct
  {
    unsigned char UCA2BR0;   /* USCI A2 Baud Rate 0  */
    unsigned char UCA2BR1;   /* USCI A2 Baud Rate 1  */
  };
  unsigned short UCA2BRW__SPI;   /*  */
  struct
  {
    unsigned char UCA2BR0__SPI;   /*  */
    unsigned char UCA2BR1__SPI;   /*  */
  };
} @ 0x0606;

__no_init volatile union
{
  unsigned short UCA2MCTLW;   /* USCI A2 Modulation Control  */

  struct
  {
    unsigned short UCOS16          : 1; /* USCI 16-times Oversampling enable  */
    unsigned short                : 3;
    unsigned short UCBRF0          : 1; /* USCI First Stage Modulation Select 0  */
    unsigned short UCBRF1          : 1; /* USCI First Stage Modulation Select 1  */
    unsigned short UCBRF2          : 1; /* USCI First Stage Modulation Select 2  */
    unsigned short UCBRF3          : 1; /* USCI First Stage Modulation Select 3  */
    unsigned short UCBRS0          : 1; /* USCI Second Stage Modulation Select 0  */
    unsigned short UCBRS1          : 1; /* USCI Second Stage Modulation Select 1  */
    unsigned short UCBRS2          : 1; /* USCI Second Stage Modulation Select 2  */
    unsigned short UCBRS3          : 1; /* USCI Second Stage Modulation Select 3  */
    unsigned short UCBRS4          : 1; /* USCI Second Stage Modulation Select 4  */
    unsigned short UCBRS5          : 1; /* USCI Second Stage Modulation Select 5  */
    unsigned short UCBRS6          : 1; /* USCI Second Stage Modulation Select 6  */
    unsigned short UCBRS7          : 1; /* USCI Second Stage Modulation Select 7  */
  } UCA2MCTLW_bit;

  struct
  {
    unsigned char UCA2MCTLW_L;
    unsigned char UCA2MCTLW_H;
  };
} @ 0x0608;

/*
enum {
  UCOS16          = 0x0001,
  UCBRF0          = 0x0010,
  UCBRF1          = 0x0020,
  UCBRF2          = 0x0040,
  UCBRF3          = 0x0080,
  UCBRS0          = 0x0100,
  UCBRS1          = 0x0200,
  UCBRS2          = 0x0400,
  UCBRS3          = 0x0800,
  UCBRS4          = 0x1000,
  UCBRS5          = 0x2000,
  UCBRS6          = 0x4000,
  UCBRS7          = 0x8000,
};

*/
__no_init volatile union
{
  unsigned char UCA2STATW;   /* USCI A2 Status Register  */

  struct
  {
    unsigned char UCBUSY          : 1; /* USCI Busy Flag  */
    unsigned char UCADDR          : 1; /* USCI Address received Flag  */
    unsigned char UCRXERR         : 1; /* USCI RX Error Flag  */
    unsigned char UCBRK           : 1; /* USCI Break received  */
    unsigned char UCPE            : 1; /* USCI Parity Error Flag  */
    unsigned char UCOE            : 1; /* USCI Overrun Error Flag  */
    unsigned char UCFE            : 1; /* USCI Frame Error Flag  */
    unsigned char UCLISTEN        : 1; /* USCI Listen mode  */
  } UCA2STATW_bit;

  unsigned char UCA2STATW__SPI;   /*  */
  struct
  {
    unsigned char UCBUSY          : 1; /* USCI Busy Flag  */
    unsigned char                : 4;
    unsigned char UCOE            : 1; /* USCI Overrun Error Flag  */
    unsigned char UCFE            : 1; /* USCI Frame Error Flag  */
    unsigned char UCLISTEN        : 1; /* USCI Listen mode  */
  } UCA2STATW__SPI_bit;

} @ 0x060A;

/*
enum {
  UCBUSY          = 0x0001,
  UCADDR          = 0x0002,
  UCRXERR         = 0x0004,
  UCBRK           = 0x0008,
  UCPE            = 0x0010,
  UCOE            = 0x0020,
  UCFE            = 0x0040,
  UCLISTEN        = 0x0080,
};

*/
__no_init volatile union
{
  unsigned __READ short UCA2RXBUF;   /* USCI A2 Receive Buffer  */
  struct
  {
    unsigned __READ char UCA2RXBUF_L;
    unsigned __READ char UCA2RXBUF_H;
  };
  unsigned short UCA2RXBUF__SPI;   /*  */
} @ 0x060C;

__no_init volatile union
{
  unsigned short UCA2TXBUF;   /* USCI A2 Transmit Buffer  */
  struct
  {
    unsigned char UCA2TXBUF_L;
    unsigned char UCA2TXBUF_H;
  };
  unsigned short UCA2TXBUF__SPI;   /*  */
} @ 0x060E;


__no_init volatile union
{
  unsigned char UCA2ABCTL;   /* USCI A2 LIN Control  */

  struct
  {
    unsigned char UCABDEN         : 1; /* Auto Baud Rate detect enable  */
    unsigned char                : 1;
    unsigned char UCBTOE          : 1; /* Break Timeout error  */
    unsigned char UCSTOE          : 1; /* Sync-Field Timeout error  */
    unsigned char UCDELIM0        : 1; /* Break Sync Delimiter 0  */
    unsigned char UCDELIM1        : 1; /* Break Sync Delimiter 1  */
  }UCA2ABCTL_bit;
} @ 0x0610;


/*
enum {
  UCABDEN         = 0x0001,
  UCBTOE          = 0x0004,
  UCSTOE          = 0x0008,
  UCDELIM0        = 0x0010,
  UCDELIM1        = 0x0020,
};

*/
__no_init volatile union
{
  unsigned short UCA2IRCTL;   /* USCI A2 IrDA Transmit Control  */

  struct
  {
    unsigned short UCIREN          : 1; /* IRDA Encoder/Decoder enable  */
    unsigned short UCIRTXCLK       : 1; /* IRDA Transmit Pulse Clock Select  */
    unsigned short UCIRTXPL0       : 1; /* IRDA Transmit Pulse Length 0  */
    unsigned short UCIRTXPL1       : 1; /* IRDA Transmit Pulse Length 1  */
    unsigned short UCIRTXPL2       : 1; /* IRDA Transmit Pulse Length 2  */
    unsigned short UCIRTXPL3       : 1; /* IRDA Transmit Pulse Length 3  */
    unsigned short UCIRTXPL4       : 1; /* IRDA Transmit Pulse Length 4  */
    unsigned short UCIRTXPL5       : 1; /* IRDA Transmit Pulse Length 5  */
    unsigned short UCIRRXFE        : 1; /* IRDA Receive Filter enable  */
    unsigned short UCIRRXPL        : 1; /* IRDA Receive Input Polarity  */
    unsigned short UCIRRXFL0       : 1; /* IRDA Receive Filter Length 0  */
    unsigned short UCIRRXFL1       : 1; /* IRDA Receive Filter Length 1  */
    unsigned short UCIRRXFL2       : 1; /* IRDA Receive Filter Length 2  */
    unsigned short UCIRRXFL3       : 1; /* IRDA Receive Filter Length 3  */
    unsigned short UCIRRXFL4       : 1; /* IRDA Receive Filter Length 4  */
    unsigned short UCIRRXFL5       : 1; /* IRDA Receive Filter Length 5  */
  } UCA2IRCTL_bit;

  struct
  {
    unsigned char UCA2IRCTL_L;
    unsigned char UCA2IRCTL_H;
  };
  struct
  {
    unsigned char UCA2IRTCTL;   /* USCI A2 IrDA Transmit Control  */
    unsigned char UCA2IRRCTL;   /* USCI A2 IrDA Receive Control  */
  };
} @ 0x0612;

/*
enum {
  UCIREN          = 0x0001,
  UCIRTXCLK       = 0x0002,
  UCIRTXPL0       = 0x0004,
  UCIRTXPL1       = 0x0008,
  UCIRTXPL2       = 0x0010,
  UCIRTXPL3       = 0x0020,
  UCIRTXPL4       = 0x0040,
  UCIRTXPL5       = 0x0080,
  UCIRRXFE        = 0x0100,
  UCIRRXPL        = 0x0200,
  UCIRRXFL0       = 0x0400,
  UCIRRXFL1       = 0x0800,
  UCIRRXFL2       = 0x1000,
  UCIRRXFL3       = 0x2000,
  UCIRRXFL4       = 0x4000,
  UCIRRXFL5       = 0x8000,
};

*/
__no_init volatile union
{
  unsigned short UCA2IE;   /* USCI A2 Interrupt Enable Register  */
  struct
  {
    unsigned char UCA2IE_L;
    unsigned char UCA2IE_H;
  };
  unsigned short UCA2IE__UART;   /*  */
  struct
  {
    unsigned short UCRXIE          : 1; /* UART Receive Interrupt Enable  */
    unsigned short UCTXIE          : 1; /* UART Transmit Interrupt Enable  */
    unsigned short UCSTTIE         : 1; /* UART Start Bit Interrupt Enalble  */
    unsigned short UCTXCPTIE       : 1; /* UART Transmit Complete Interrupt Enable  */
  } UCA2IE__UART_bit;

  struct
  {
    unsigned char UCA2IE__SPI;   /*  */
  };
  struct
  {
    struct
    {
      unsigned char UCRXIE          : 1; /* UART Receive Interrupt Enable  */
      unsigned char UCTXIE          : 1; /* UART Transmit Interrupt Enable  */
    } UCA2IE__SPI_bit;

  }; 
} @ 0x061A;

__no_init volatile union
{
  unsigned short UCA2IFG;   /* USCI A2 Interrupt Flags Register  */
  struct
  {
    unsigned char UCA2IFG_L;
    unsigned char UCA2IFG_H;
  };
  unsigned short UCA2IFG__UART;   /*  */
  struct
  {
    unsigned short UCRXIFG         : 1; /* UART Receive Interrupt Flag  */
    unsigned short UCTXIFG         : 1; /* UART Transmit Interrupt Flag  */
    unsigned short UCSTTIFG        : 1; /* UART Start Bit Interrupt Flag  */
    unsigned short UCTXCPTIFG      : 1; /* UART Transmit Complete Interrupt Flag  */
  } UCA2IFG__UART_bit;

  struct
  {
    unsigned char UCA2IFG__SPI;   /*  */
  };
  struct
  {
    struct
    {
      unsigned char UCRXIFG         : 1; /* UART Receive Interrupt Flag  */
      unsigned char UCTXIFG         : 1; /* UART Transmit Interrupt Flag  */
    } UCA2IFG__SPI_bit;

  }; 
} @ 0x061C;

/*
enum {
  UCRXIE          = 0x0001,
  UCTXIE          = 0x0002,
  UCSTTIE         = 0x0004,
  UCTXCPTIE       = 0x0008,
};

*/
/*
enum {
  UCRXIFG         = 0x0001,
  UCTXIFG         = 0x0002,
  UCSTTIFG        = 0x0004,
  UCTXCPTIFG      = 0x0008,
};

*/
__no_init volatile union
{
  unsigned short UCA2IV;   /* USCI A2 Interrupt Vector Register  */
  unsigned short UCA2IV__SPI;   /*  */
} @ 0x061E;

#define __MSP430_HAS_EUSCI_A2__      /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_EUSCI_A2__ 0x0600
#define EUSCI_A2_BASE __MSP430_BASEADDRESS_EUSCI_A2__

/*-------------------------------------------------------------------------
 *   USCI_A2  SPI Mode
 *-------------------------------------------------------------------------*/


/*
enum {
  UCSWRST         = 0x0001,
  UCSTEM          = 0x0002,
  UCSSEL0         = 0x0040,
  UCSSEL1         = 0x0080,
  UCSYNC          = 0x0100,
  UCMODE0         = 0x0200,
  UCMODE1         = 0x0400,
  UCMST           = 0x0800,
  UC7BIT          = 0x1000,
  UCMSB           = 0x2000,
  UCCKPL          = 0x4000,
  UCCKPH          = 0x8000,
};

*/
/*
enum {
  UCBUSY          = 0x0001,
  UCOE            = 0x0020,
  UCFE            = 0x0040,
  UCLISTEN        = 0x0080,
};

*/
/*
enum {
  UCRXIE          = 0x0001,
  UCTXIE          = 0x0002,
};

*/
/*
enum {
  UCRXIFG         = 0x0001,
  UCTXIFG         = 0x0002,
};

*/
/*-------------------------------------------------------------------------
 *   Watchdog Timer
 *-------------------------------------------------------------------------*/


__no_init volatile union
{
  unsigned short WDTCTL;   /* Watchdog Timer Control  */

  struct
  {
    unsigned short WDTIS0          : 1; /* WDT - Timer Interval Select 0  */
    unsigned short WDTIS1          : 1; /* WDT - Timer Interval Select 1  */
    unsigned short WDTIS2          : 1; /* WDT - Timer Interval Select 2  */
    unsigned short WDTCNTCL        : 1; /* WDT - Timer Clear  */
    unsigned short WDTTMSEL        : 1; /* WDT - Timer Mode Select  */
    unsigned short WDTSSEL0        : 1; /* WDT - Timer Clock Source Select 0  */
    unsigned short WDTSSEL1        : 1; /* WDT - Timer Clock Source Select 1  */
    unsigned short WDTHOLD         : 1; /* WDT - Timer hold  */
  } WDTCTL_bit;

  struct
  {
    unsigned char WDTCTL_L;
    unsigned char WDTCTL_H;
  };
} @ 0x015C;

enum {
  WDTIS0          = 0x0001,
  WDTIS1          = 0x0002,
  WDTIS2          = 0x0004,
  WDTCNTCL        = 0x0008,
  WDTTMSEL        = 0x0010,
  WDTSSEL0        = 0x0020,
  WDTSSEL1        = 0x0040,
  WDTHOLD         = 0x0080
};



#define __MSP430_HAS_WDT_A__          /* Definition to show that Module is available */
#define __MSP430_BASEADDRESS_WDT_A__ 0x0150
#define WDT_A_BASE __MSP430_BASEADDRESS_WDT_A__
/* WDTCTL Control Bits */
#define WDTIS0_L            (0x0001u)  /* WDT - Timer Interval Select 0 */
#define WDTIS1_L            (0x0002u)  /* WDT - Timer Interval Select 1 */
#define WDTIS2_L            (0x0004u)  /* WDT - Timer Interval Select 2 */
#define WDTCNTCL_L          (0x0008u)  /* WDT - Timer Clear */
#define WDTTMSEL_L          (0x0010u)  /* WDT - Timer Mode Select */
#define WDTSSEL0_L          (0x0020u)  /* WDT - Timer Clock Source Select 0 */
#define WDTSSEL1_L          (0x0040u)  /* WDT - Timer Clock Source Select 1 */
#define WDTHOLD_L           (0x0080u)  /* WDT - Timer hold */

#define WDTPW               (0x5A00u)

#define WDTIS_0           (0*0x0001u)  /* WDT - Timer Interval Select: /2G */
#define WDTIS_1           (1*0x0001u)  /* WDT - Timer Interval Select: /128M */
#define WDTIS_2           (2*0x0001u)  /* WDT - Timer Interval Select: /8192k */
#define WDTIS_3           (3*0x0001u)  /* WDT - Timer Interval Select: /512k */
#define WDTIS_4           (4*0x0001u)  /* WDT - Timer Interval Select: /32k */
#define WDTIS_5           (5*0x0001u)  /* WDT - Timer Interval Select: /8192 */
#define WDTIS_6           (6*0x0001u)  /* WDT - Timer Interval Select: /512 */
#define WDTIS_7           (7*0x0001u)  /* WDT - Timer Interval Select: /64 */
#define WDTIS__2G         (0*0x0001u)  /* WDT - Timer Interval Select: /2G */
#define WDTIS__128M       (1*0x0001u)  /* WDT - Timer Interval Select: /128M */
#define WDTIS__8192K      (2*0x0001u)  /* WDT - Timer Interval Select: /8192k */
#define WDTIS__512K       (3*0x0001u)  /* WDT - Timer Interval Select: /512k */
#define WDTIS__32K        (4*0x0001u)  /* WDT - Timer Interval Select: /32k */
#define WDTIS__8192       (5*0x0001u)  /* WDT - Timer Interval Select: /8192 */
#define WDTIS__512        (6*0x0001u)  /* WDT - Timer Interval Select: /512 */
#define WDTIS__64         (7*0x0001u)  /* WDT - Timer Interval Select: /64 */

#define WDTSSEL_0         (0*0x0020u)  /* WDT - Timer Clock Source Select: SMCLK */
#define WDTSSEL_1         (1*0x0020u)  /* WDT - Timer Clock Source Select: ACLK */
#define WDTSSEL_2         (2*0x0020u)  /* WDT - Timer Clock Source Select: VLO_CLK */
#define WDTSSEL_3         (3*0x0020u)  /* WDT - Timer Clock Source Select: reserved */
#define WDTSSEL__SMCLK    (0*0x0020u)  /* WDT - Timer Clock Source Select: SMCLK */
#define WDTSSEL__ACLK     (1*0x0020u)  /* WDT - Timer Clock Source Select: ACLK */
#define WDTSSEL__VLO      (2*0x0020u)  /* WDT - Timer Clock Source Select: VLO_CLK */
/* WDT is clocked by fSMCLK (assumed 1MHz) */
#define WDT_MDLY_32         (WDTPW+WDTTMSEL+WDTCNTCL+WDTIS2)                         /* 32ms interval (default) */
#define WDT_MDLY_8          (WDTPW+WDTTMSEL+WDTCNTCL+WDTIS2+WDTIS0)                  /* 8ms     " */
#define WDT_MDLY_0_5        (WDTPW+WDTTMSEL+WDTCNTCL+WDTIS2+WDTIS1)                  /* 0.5ms   " */
#define WDT_MDLY_0_064      (WDTPW+WDTTMSEL+WDTCNTCL+WDTIS2+WDTIS1+WDTIS0)           /* 0.064ms " */
/* WDT is clocked by fACLK (assumed 32KHz) */
#define WDT_ADLY_1000       (WDTPW+WDTTMSEL+WDTCNTCL+WDTIS2+WDTSSEL0)                /* 1000ms  " */
#define WDT_ADLY_250        (WDTPW+WDTTMSEL+WDTCNTCL+WDTIS2+WDTSSEL0+WDTIS0)         /* 250ms   " */
#define WDT_ADLY_16         (WDTPW+WDTTMSEL+WDTCNTCL+WDTIS2+WDTSSEL0+WDTIS1)         /* 16ms    " */
#define WDT_ADLY_1_9        (WDTPW+WDTTMSEL+WDTCNTCL+WDTIS2+WDTSSEL0+WDTIS1+WDTIS0)  /* 1.9ms   " */
/* WDT is clocked by fSMCLK (assumed 1MHz) */
#define WDT_MRST_32         (WDTPW+WDTCNTCL+WDTIS2)                                  /* 32ms interval (default) */
#define WDT_MRST_8          (WDTPW+WDTCNTCL+WDTIS2+WDTIS0)                           /* 8ms     " */
#define WDT_MRST_0_5        (WDTPW+WDTCNTCL+WDTIS2+WDTIS1)                           /* 0.5ms   " */
#define WDT_MRST_0_064      (WDTPW+WDTCNTCL+WDTIS2+WDTIS1+WDTIS0)                    /* 0.064ms " */
/* WDT is clocked by fACLK (assumed 32KHz) */
#define WDT_ARST_1000       (WDTPW+WDTCNTCL+WDTSSEL0+WDTIS2)                         /* 1000ms  " */
#define WDT_ARST_250        (WDTPW+WDTCNTCL+WDTSSEL0+WDTIS2+WDTIS0)                  /* 250ms   " */
#define WDT_ARST_16         (WDTPW+WDTCNTCL+WDTSSEL0+WDTIS2+WDTIS1)                  /* 16ms    " */
#define WDT_ARST_1_9        (WDTPW+WDTCNTCL+WDTSSEL0+WDTIS2+WDTIS1+WDTIS0)           /* 1.9ms   " */




#pragma language=restore
#endif  /* __IAR_SYSTEMS_ICC__  */


/************************************************************
* Timer A interrupt vector value
************************************************************/

/* Compability definitions */

#define TAIV_CCIFG1         TAIV_TACCR1       /* Capture/compare 1 */
#define TAIV_CCIFG2         TAIV_TACCR2       /* Capture/compare 2 */
#define TAIV_CCIFG3         TAIV_6            /* Capture/compare 3 */
#define TAIV_CCIFG4         TAIV_8            /* Capture/compare 4 */

/************************************************************
* Interrupt Vectors (offset from 0xFF80)
************************************************************/

#define RTC_VECTOR          (40 * 2u) /* 0xFFD0 RTC */
#define LCD_C_VECTOR        (41 * 2u) /* 0xFFD2 LCD C */
#define TIMER3_A1_VECTOR    (42 * 2u) /* 0xFFD4 Timer3_A2 CC1, TA */
#define TIMER3_A0_VECTOR    (43 * 2u) /* 0xFFD8 Timer3_A2 CC0 */
#define PORT2_VECTOR        (44 * 2u) /* 0xFFDA Port 2 */
#define TIMER2_A1_VECTOR    (45 * 2u) /* 0xFFDC Timer2_A2 CC1, TA */
#define TIMER2_A0_VECTOR    (46 * 2u) /* 0xFFDE Timer2_A2 CC0 */
#define PORT1_VECTOR        (47 * 2u) /* 0xFFDE Port 1 */
#define TIMER1_A1_VECTOR    (48 * 2u) /* 0xFFE0 Timer1_A2 CC1, TA1 */
#define TIMER1_A0_VECTOR    (49 * 2u) /* 0xFFE2 Timer1_A2 CC0 */
#define DMA_VECTOR          (50 * 2u) /* 0xFFE4 DMA */
#define AUX_VECTOR          (51 * 2u) /* 0xFFE6 AUX Supply */
#define USCI_A2_VECTOR      (52 * 2u) /* 0xFFE8 USCI A2 Receive/Transmit */
#define USCI_A1_VECTOR      (53 * 2u) /* 0xFFEA USCI A1 Receive/Transmit */
#define TIMER0_A1_VECTOR    (54 * 2u) /* 0xFFEC Timer0_A2 CC1-CC2, TA */
#define TIMER0_A0_VECTOR    (55 * 2u) /* 0xFFEE Timer0_A2 CC0 */
#define SD24B_VECTOR        (56 * 2u) /* 0xFFF0 SD24B ADC */
#define ADC10_VECTOR        (57 * 2u) /* 0xFFF2 ADC */
#define USCI_B0_VECTOR      (58 * 2u) /* 0xFFF4 USCI B0 Receive/Transmit */
#define USCI_A0_VECTOR      (59 * 2u) /* 0xFFF6 USCI A0 Receive/Transmit */
#define WDT_VECTOR          (60 * 2u) /* 0xFFF8 Watchdog Timer */
#define UNMI_VECTOR         (61 * 2u) /* 0xFFFA User Non-maskable */
#define SYSNMI_VECTOR       (62 * 2u) /* 0xFFFC System Non-maskable */
#define RESET_VECTOR        (63 * 2u) /* 0xFFFE Reset [Highest Priority] */


#endif /* __IO430xxxx */
