#include "include.h"

#include <stdlib.h>
#include <stdio.h>

char A0_RxBuf[30];
UINT8 RxA0_write_counter = 0;
UINT8 RxA0_read_counter = 0;
UINT16 Device_num;
UINT64 UI_BSN;
UINT16 UI_Span_range;
UINT64 DebugA;
UINT8 tabpage;
char ID_buf[2];
UINT8 ID;
char *token;
const char s[2] = ",";
char *pos;
char UI_value[20];
UINT16 UI_fw_version;
UINT32 UI_cal_data;
UINT64 UI_bsn;
UINT64 UI_gas_name;
INT32 UI_zero;
float UI_span;
float UI_a_value;
INT32 UI_b_value;

void chk_ui_cmd(void)
{
  if(A0_RxBuf[0] == '@')
  {
    if(strncmp(&A0_RxBuf[1], "R,", 2) == 0){
      command_read();
    }
    else if (strncmp(&A0_RxBuf[1], "W,", 2) == 0){
      command_write();
    }
    else if (strncmp(&A0_RxBuf[1], "RO,", 3) == 0){
      command_read_one();
    }
    else
    {
      RxBuf_CMD_Clear();
    }
  }
  else
  {
    RxBuf_CMD_Clear();
  }
}



void RxBuf_CMD_Clear(void){
  RxA0_write_counter = 0;
  memset(A0_RxBuf, 0x00, 30);
}



void command_read(void)
{
  if(strncmp(&A0_RxBuf[3], "ALL\r\n", 5) == 0)
  {
     measure_all_rht();
     measure_gases_data();
     ui_print("\r");
     data_to_UCA(WE_DIMENSIONS);
     ui_print(":");
     data_to_UCA(AE_DIMENSIONS);
     ui_print(":");
     data_to_UCA(CONCENTRATIONS_DIMENSIONS);
     ui_print(":");
     SHT_to_UCA();
     ui_print("\r");  
     RxBuf_CMD_Clear();
  }
  else if(strncmp(&A0_RxBuf[3], "INIT\r\n", 6) == 0)
  {
     ui_print("\r");
     data_to_UCA(GAS_NAME_DIMENSIONS);
     ui_print(":");
     BSN_to_UCA(BSN_DIMENSIONS);
     ui_print(":");
     data_to_UCA(FW_DIMENSIONS);
     ui_print(":");
     data_to_UCA(CAL_DATA_DIMENSIONS);
     ui_print(":");
     data_to_UCA(ZERO_DIMENSIONS);
     ui_print(":");
     data_to_UCA(SPAN_DIMENSIONS);
     ui_print(":");
     data_to_UCA(A_DIMENSIONS);
     ui_print(":"); 
     data_to_UCA(B_DIMENSIONS);
     ui_print("\r");  
     RxBuf_CMD_Clear();
  }
  else if(strncmp(&A0_RxBuf[3], "PPB\r\n", 5) == 0)
  {
     ui_print("\r");
     data_to_UCA(CONCENTRATIONS_DIMENSIONS);
     ui_print("\r");  
     RxBuf_CMD_Clear();
  }
  else if(strncmp(&A0_RxBuf[3], "BSN\r\n", 5) == 0)
  {
     ui_print("\r");
     BSN_to_UCA(BSN_DIMENSIONS);
     ui_print("\r");  
     RxBuf_CMD_Clear();
  }
  else if(strncmp(&A0_RxBuf[3], "FW\r\n", 4) == 0)
  {
     ui_print("\r");
     data_to_UCA(FW_DIMENSIONS);
     ui_print("\r");  
     RxBuf_CMD_Clear();
  }
  else if(strncmp(&A0_RxBuf[3], "CAL\r\n", 5) == 0)
  {
     ui_print("\r");
     data_to_UCA(CAL_DATA_DIMENSIONS);
     ui_print("\r");  
     RxBuf_CMD_Clear();
  }
  else if(strncmp(&A0_RxBuf[3], "GAS\r\n", 5) == 0)
  {
     ui_print("\r");
     data_to_UCA(GAS_NAME_DIMENSIONS);
     ui_print("\r");  
     RxBuf_CMD_Clear();
  }
  else if(strncmp(&A0_RxBuf[3], "ZERO\r\n", 6) == 0)
  {
     ui_print("\r");
     data_to_UCA(ZERO_DIMENSIONS);
     ui_print("\r");  
     RxBuf_CMD_Clear();
  }
  else if(strncmp(&A0_RxBuf[3], "SPAN\r\n", 6) == 0)
  {
     ui_print("\r");
     data_to_UCA(SPAN_DIMENSIONS);
     ui_print("\r");  
     RxBuf_CMD_Clear();
  }
  else if(strncmp(&A0_RxBuf[3], "A\r\n", 3) == 0)
  {
     ui_print("\r");
     data_to_UCA(A_DIMENSIONS);
     ui_print("\r");  
     RxBuf_CMD_Clear();
  }
  else if(strncmp(&A0_RxBuf[3], "B\r\n", 3) == 0)
  {
     ui_print("\r");
     data_to_UCA(B_DIMENSIONS);
     ui_print("\r");  
     RxBuf_CMD_Clear();
  }
  else
  {
     RxBuf_CMD_Clear();
  }
}


void command_write(void)
{
  if(strncmp(&A0_RxBuf[3], "BSN,", 4) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[7], 2);
    ID = atoi(ID_buf);
    get_write_value(UI_value);
    UI_bsn = atoll(UI_value); 
    //Write BSN
    if(record_bsn(ID, UI_bsn)){
      //true
      ui_print_ack();
    }
    else{
      //false
    }
    return;
  }
  else if(strncmp(&A0_RxBuf[3], "CAL,", 4) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[7], 2);
    ID = atoi(ID_buf);
    get_write_value(UI_value);
    UI_cal_data = atol(UI_value); 
    //Write BSN
    if(record_cal_date(ID, UI_cal_data)){
      //true
      ui_print_ack();
    }
    else{
      //false
    }
    return;
  }
  else if(strncmp(&A0_RxBuf[3], "ZERO,", 5) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[8], 2);
    ID = atoi(ID_buf);
    get_write_value(UI_value);
    UI_zero = atol(UI_value); 
    //Write BSN
    if(record_zero(ID, UI_zero)){
      //true
      ui_print_ack();
    }
    else{
      //false
    }
    return;
  }
  else if(strncmp(&A0_RxBuf[3], "SPAN,", 5) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[8], 2);
    ID = atoi(ID_buf);
    get_write_value(UI_value);
    UI_span = atof(UI_value); 
    //Write BSN
    if(record_span(ID, UI_span)){
      //true
      ui_print_ack();
    }
    else{
      //false
    }
    return;
  }
  else if(strncmp(&A0_RxBuf[3], "A,", 2) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[5], 2);
    ID = atoi(ID_buf);
    get_write_value(UI_value);
    UI_a_value = atof(UI_value); 
    //Write BSN
    if(record_a(ID, UI_a_value)){
      //true
      ui_print_ack();
    }
    else{
      //false
    }
    return;
  }
  else if(strncmp(&A0_RxBuf[3], "B,", 2) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[5], 2);
    ID = atoi(ID_buf);
    get_write_value(UI_value);
     UI_b_value = atol(UI_value); 
    //Write BSN
    if(record_b(ID, UI_b_value)){
      //true
      ui_print_ack();
    }
    else{
      //false
    }
    return;
  }
  else{
    return;
  }
}



void command_read_one(void)
{
  if(strncmp(&A0_RxBuf[4], "BSN,", 4) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[8], 2);
    ID = atoi(ID_buf);
    ui_print("\r");
    one_BSN_to_UCA(BSN_DIMENSIONS, ID);
    ui_print("\r");  
    RxBuf_CMD_Clear();
  }
  if(strncmp(&A0_RxBuf[4], "CAL,", 4) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[8], 2);
    ID = atoi(ID_buf);
    ui_print("\r");
    one_data_to_UCA(CAL_DATA_DIMENSIONS, ID);
    ui_print("\r");  
    RxBuf_CMD_Clear();
  }
  if(strncmp(&A0_RxBuf[4], "ZERO,", 5) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[9], 2);
    ID = atoi(ID_buf);
    ui_print("\r");
    one_data_to_UCA(ZERO_DIMENSIONS, ID);
    ui_print("\r");  
    RxBuf_CMD_Clear();
  }
  if(strncmp(&A0_RxBuf[4], "SPAN,", 5) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[9], 2);
    ID = atoi(ID_buf);
    ui_print("\r");
    one_data_to_UCA(SPAN_DIMENSIONS, ID);
    ui_print("\r");  
    RxBuf_CMD_Clear();  
  }
  if(strncmp(&A0_RxBuf[4], "A,", 2) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[6], 2);
    ID = atoi(ID_buf);
    ui_print("\r");
    one_data_to_UCA(A_DIMENSIONS, ID);
    ui_print("\r");  
    RxBuf_CMD_Clear();  
  }
  if(strncmp(&A0_RxBuf[4], "B,", 2) == 0)
  {
    strncpy(ID_buf, &A0_RxBuf[6], 2);
    ID = atoi(ID_buf);
    ui_print("\r");
    one_data_to_UCA(B_DIMENSIONS, ID);
    ui_print("\r");  
    RxBuf_CMD_Clear();  
  }
  else
  {
     RxBuf_CMD_Clear();
  }
}

void get_write_value(char result[20]){
  token = strtok(A0_RxBuf, s);
  for(int i = 0; i<3; i++){
    token = strtok(NULL, s);
  }
  pos = strchr(token, '\r');
  if (pos != NULL) {
    int len = pos - token;
    strncpy(result, token, len);
    result[len] = '\0'; 
  }
}


/*
void command_Write_BSN(void)
{
  if(A0_RxBuf[0] == 'W' && A0_RxBuf[1] == 'B' && A0_RxBuf[2] == 'S' && A0_RxBuf[3] == 'N' || A0_RxBuf[19] == '\r' || A0_RxBuf[20] == '\r')
  {
    Device_num = 0;
    if(A0_RxBuf[19] >=0x30 && A0_RxBuf[19]<=0x39)
    {
      Device_num += ((int)A0_RxBuf[18]-48)*10;
      Device_num += (int)A0_RxBuf[19]-48;
    }
    else
    {
      Device_num += (int)A0_RxBuf[18]-48;
    }
    
    UI_BSN += ((int)A0_RxBuf[4]-48)*(1000000000000);//把字串轉成數字
    UI_BSN += ((int)A0_RxBuf[5]-48)*(100000000000);
    UI_BSN += ((int)A0_RxBuf[6]-48)*(10000000000);
    DebugA = ((int)A0_RxBuf[7]-48);
    DebugA = DebugA*1000000000;
    UI_BSN += DebugA;
    UI_BSN += ((int)A0_RxBuf[8]-48)*(100000000);
    UI_BSN += ((int)A0_RxBuf[9]-48)*(10000000);
    UI_BSN += ((int)A0_RxBuf[10]-48)*(1000000);
    UI_BSN += ((int)A0_RxBuf[11]-48)*(100000);
    DebugA = ((int)A0_RxBuf[12]-48);
    DebugA = DebugA*10000;
    UI_BSN += DebugA;
    UI_BSN += ((int)A0_RxBuf[13]-48)*(1000);
    UI_BSN += ((int)A0_RxBuf[14]-48)*(100);
    UI_BSN += ((int)A0_RxBuf[15]-48)*(10);
    UI_BSN += ((int)A0_RxBuf[16]-48)*(1);
//    Device_Select_BSN(Device_num);
    RxBuf_CMD_Clear();
    UI_BSN = 0;
  }
}

void command_Wrire_Zero(void)
{
  if(A0_RxBuf[0] == 'W' && A0_RxBuf[1] == 'Z' && A0_RxBuf[2] == 'e' && A0_RxBuf[3] == 'r' && A0_RxBuf[4] == 'o' && A0_RxBuf[5] == '\r')
  {
//    Correction_Zero();
    RxBuf_CMD_Clear();
  }
}

void command_Wrire_Span(void)
{
  if(A0_RxBuf[0] == 'W' && A0_RxBuf[1] == 'S' && A0_RxBuf[2] == 'p' && A0_RxBuf[3] == 'a' && A0_RxBuf[4] == 'n' || A0_RxBuf[8] == '\r' || A0_RxBuf[9] == '\r')
  {
    if(A0_RxBuf[8] >=0x30 && A0_RxBuf[8]<=0x39)//如果A0_RxBuf[8]
    {
      UI_Span_range += ((int)A0_RxBuf[5]-48)*1000;
      UI_Span_range += ((int)A0_RxBuf[6]-48)*100;
      UI_Span_range += ((int)A0_RxBuf[7]-48)*10;
      UI_Span_range += ((int)A0_RxBuf[8]-48)*1;
    }
    else
    {
      UI_Span_range += ((int)A0_RxBuf[5]-48)*100;
      UI_Span_range += ((int)A0_RxBuf[6]-48)*10;
      UI_Span_range += ((int)A0_RxBuf[7]-48)*1;
    }
    Span_range = UI_Span_range;
//    Correction_Span();
    RxBuf_CMD_Clear();
  }
}*/

#pragma vector=USCI_A1_VECTOR
__interrupt void USCI_A1_ISR(void)   //USCI_A0 RX interrupt service routine
{
  switch(__even_in_range(UCA1IV,4))
  {
  case USCI_NONE:break;                       // Vector 0 - no interrupt
  case USCI_UART_UCRXIFG:                     // Vector 2 - RXIFG
    TA2CTL = TASSEL_1 + MC_0 + TACLR;         // ACLK, stop, clear TAR
    A0_RxBuf[RxA0_write_counter]= UCA1RXBUF;
    RxA0_write_counter++;
    break;
  case USCI_UART_UCTXIFG: break;      // TXIFG
  case USCI_UART_UCSTTIFG: break;     // TTIFG
  case USCI_UART_UCTXCPTIFG: break;   // TXCPTIFG
  default: break;
  }
}
