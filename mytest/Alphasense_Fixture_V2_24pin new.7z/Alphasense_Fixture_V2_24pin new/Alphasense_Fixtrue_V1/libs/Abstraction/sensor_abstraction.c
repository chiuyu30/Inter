#include "include.h"
#include <stdio.h>
#include <stdlib.h>

#define CONV_BUF_MAX     20
#define ERROR_NO_NONE    0x01
#define GAS_PORT         24

#define DIMENSIONS       12

#define WE_DIMENSIONS              0
#define AE_DIMENSIONS              1
#define ADC_DIMENSIONS             2
#define FW_DIMENSIONS              3
#define GAS_NAME_DIMENSIONS        4
#define BSN_DIMENSIONS             5
#define ZERO_DIMENSIONS            6
#define SPAN_DIMENSIONS            7
#define A_DIMENSIONS               8
#define B_DIMENSIONS               9
#define CAL_DATA_DIMENSIONS        10
#define CONCENTRATIONS_DIMENSIONS  11


char conv_buf[CONV_BUF_MAX];

INT64 datalink[GAS_PORT][DIMENSIONS]; //24 port , 0:WE, 1:AE, 2:ADC, 3:FW version, 4:Gas name, 5:BSN, 6:ZERO, 7:Span, 8:A, 9:B, 10:

UINT16 fw_version;
UINT32 cal_data;
UINT64 bsn;
UINT64 gas_name;
INT32 zero;
float span;
float a_value;
INT32 b_value;
UINT16 concentrations;

UINT32 we;
UINT32 ae;


UINT8 i,j,k;
UINT8 port_count;
UINT8 Sensor_Name = 0; //1:DD-CO  2:NO2  3:O3  4:NH3  5:H2S 6:AL-CO 7:SO2
UINT16 Span_range;
INT16 SHT3x_RHT[8];


void measure_gases_data(void)
{
#ifdef ENABLE_WATCHDOG
  WDT_A_resetTimer(WDT_A_BASE);
#endif
  //datalink_clear();//清空資料暫存
  for(port_count=0; port_count<24; port_count++){
    delay_micro_second(100);
    if(switch_port(port_count)){//跟感測器說現在要對哪一顆做操作
      //Show err code
      _NOP();
    }
    else{
      //Switch successful
      _NOP();
      sensordata_init();//we ae concentrations(濃度)歸零
      gat_all_gas_data(port_count);
//      chk_ui_cmd();
    }
  }
}

void measure_gases_info(void)
{
#ifdef ENABLE_WATCHDOG
  WDT_A_resetTimer(WDT_A_BASE);
#endif
  for(port_count=0; port_count<24; port_count++){
    delay_micro_second(100);
    if(switch_port(port_count)){
      //Show err code
      _NOP();
    }
    else{
      //Switch successful
      _NOP();
      sensorinfo_init();
      get_all_gas_info(port_count);
    }
  }
}

void gat_all_gas_data(UINT8 port_numbers)
{
#ifdef ENABLE_WATCHDOG
  WDT_A_resetTimer(WDT_A_BASE);
#endif
  //Read WE
  if(aeclmg_getAdc_2(port_address[port_numbers], &we)){//第n個位置的感測器的i2c位置{AL_O3_ADDRESS, AL_NO2_ADDRESS, AL_CO_ADDRESS, AL_SO2_ADDRESS, DD7_NH3_ADDRESS, AL_H2S_ADDRESS, PIDAY5_VOC_ADDRESS}其中一個
    //Show err code
    _NOP();
  }
  else{
    datalink[port_numbers][WE_DIMENSIONS] = we;
#ifdef ENABLE_WATCHDOG
  WDT_A_resetTimer(WDT_A_BASE);
#endif
    //Read AE
    if(aeclmg_getAdc_1(port_address[port_numbers], &ae)){
      //Show err code
      _NOP();
    }
    else{
      datalink[port_numbers][AE_DIMENSIONS] = ae;
#ifdef ENABLE_WATCHDOG
      WDT_A_resetTimer(WDT_A_BASE);
#endif
      //Read concentrations
      if(aeclmg_get_gas_concentrations(port_address[port_numbers], &concentrations)){
        //Show err code
        _NOP();
      }
      else{
        datalink[port_numbers][CONCENTRATIONS_DIMENSIONS] = concentrations;    
      }
    }
  }
}

void get_all_gas_info(UINT8 port_numbers)
{
#ifdef ENABLE_WATCHDOG
  WDT_A_resetTimer(WDT_A_BASE);
#endif
  //Read gas_name
  if(aeclmg_get_gas_name(port_address[port_numbers], &gas_name)){
    //Show err code
    _NOP();
  }
  else{
    datalink[port_numbers][GAS_NAME_DIMENSIONS] = gas_name;
#ifdef ENABLE_WATCHDOG
    WDT_A_resetTimer(WDT_A_BASE);
#endif
    //Read bsn
    if(aeclmg_getSerialId(port_address[port_numbers], &bsn)){
      //Show err code
      _NOP();
    }
    else{
      datalink[port_numbers][BSN_DIMENSIONS] = bsn;
#ifdef ENABLE_WATCHDOG
      WDT_A_resetTimer(WDT_A_BASE);
#endif
      //Read FW
      if(aeclmg_get_fw_version(port_address[port_numbers], &fw_version)){
        //Show err code
        _NOP();
      }
      else{
        datalink[port_numbers][FW_DIMENSIONS] = fw_version;
#ifdef ENABLE_WATCHDOG
        WDT_A_resetTimer(WDT_A_BASE);
#endif
        //Read CAL DATA 
        if(aeclmg_get_cal_date(port_address[port_numbers], &cal_data)){
          //Show err code
          _NOP();
        }
        else{
          datalink[port_numbers][CAL_DATA_DIMENSIONS] = cal_data;
#ifdef ENABLE_WATCHDOG
          WDT_A_resetTimer(WDT_A_BASE);
#endif
          //Read zero 
          if(aeclmg_get_gas_cal_zero(port_address[port_numbers], &zero)){
            //Show err code
            _NOP();
          }
          else{
            datalink[port_numbers][ZERO_DIMENSIONS] = zero;
#ifdef ENABLE_WATCHDOG
            WDT_A_resetTimer(WDT_A_BASE);
#endif
            //Read span 
            if(aeclmg_get_gas_cal_span(port_address[port_numbers], &span)){
              //Show err code
              _NOP();
            }
            else{
              datalink[port_numbers][SPAN_DIMENSIONS] = (INT64)(span*1000);//Check it
#ifdef ENABLE_WATCHDOG
              WDT_A_resetTimer(WDT_A_BASE);
#endif
              //Read a_value 
              if(aeclmg_get_gas_cal_a(port_address[port_numbers], &a_value)){
                //Show err code
                _NOP();
              }
              else{
                datalink[port_numbers][A_DIMENSIONS] = (INT64)(a_value*1000);//Check it
#ifdef ENABLE_WATCHDOG
                WDT_A_resetTimer(WDT_A_BASE);
#endif
                //Read b_value 
                if(aeclmg_get_gas_cal_b(port_address[port_numbers], &b_value)){
                  //Show err code
                  _NOP();
                }
                else{
                  datalink[port_numbers][B_DIMENSIONS] = b_value;
                  
                }
              }
            }
          }
        }
      }
    }
  }
}

void measure_all_rht(void)
{
#ifdef ENABLE_WATCHDOG    
  WDT_A_resetTimer(WDT_A_BASE);
#endif
  for(UINT8 port_sht=0; port_sht<=3; port_sht++){
    if(switch_port_sht(port_sht)){
      //Show err code
      _NOP();
    }
    else{
      //Switch successful
      measure_rht(port_sht);
    }
  }
  //chk_ui_cmd(); //CHECK  
}

void measure_rht(UINT8 sht_count)
{
  INT16 rht_data[2];
  etError   error;

  memset(rht_data,0x00,2);
  
  error = SHT3X_GetTempAndHumi(&temperature, &humidity, REPEATAB_HIGH, MODE_POLLING, 50);   
  if(error != NO_ERROR)
  {
    _NOP();
  }
  else
  {
    rht_data[0] = (INT16) (temperature * 100);
    rht_data[1] = (INT16) (humidity * 100);
  }
  
  switch(sht_count)
  {
  case 0:
    SHT3x_RHT[0] = rht_data[0];
    SHT3x_RHT[1] = rht_data[1];
    break;
  case 1:
    SHT3x_RHT[2] = rht_data[0];
    SHT3x_RHT[3] = rht_data[1];
    break;
  case 2:
    SHT3x_RHT[4] = rht_data[0];
    SHT3x_RHT[5] = rht_data[1];
    break;
  case 3:
    SHT3x_RHT[6] = rht_data[0];
    SHT3x_RHT[7] = rht_data[1];
    break;
  }
}

bool record_bsn(UINT8 id, UINT64 write){
  delay_micro_second(100);
  if(switch_port(id)){
    //Show err code
    _NOP();
  }
  else{
    if(write_and_read_gas_bsn(port_address[id], write, &bsn)){
      //Show err code
      _NOP();
    }
    else{
      datalink[id][BSN_DIMENSIONS] = bsn;
      return true;
    }  
  }
  return false;
}

bool record_cal_date(UINT8 id, UINT32 write){
  if(switch_port(id)){
    //Show err code
    _NOP();
  }
  else{
    if(write_and_read_gas_cal_date(port_address[id], write, &cal_data)){
      //Show err code
      _NOP();
    }
    else{
      _NOP();
      datalink[id][CAL_DATA_DIMENSIONS] = cal_data;
      return true;
    }  
  }
  return false;
}

bool record_zero(UINT8 id, UINT32 write){
  if(switch_port(id)){
    //Show err code
    _NOP();
  }
  else{
    if(write_and_read_gas_cal_zero(port_address[id], write, &zero)){
      //Show err code
      _NOP();
    }
    else{
      _NOP();
      datalink[id][ZERO_DIMENSIONS] = zero;
      return true;
    }  
  }
  return false;
}

bool record_span(UINT8 id, float write){
  if(switch_port(id)){
    //Show err code
    _NOP();
  }
  else{
    if(write_and_read_gas_cal_span(port_address[id], write, &span)){
      //Show err code
      _NOP();
    }
    else{
      _NOP();
      datalink[id][SPAN_DIMENSIONS] = (INT64)(span*1000);
      return true;
    }  
  }
  return false;
}

bool record_a(UINT8 id, float write){
  if(switch_port(id)){
    //Show err code
    _NOP();
  }
  else{
    if(write_and_read_gas_cal_a(port_address[id], write, &a_value)){
      //Show err code
      _NOP();
    }
    else{
      _NOP();
      datalink[id][A_DIMENSIONS] = (INT64)(a_value*1000);
      return true;
    }  
  }
  return false;
}

bool record_b(UINT8 id, INT32 write){
  if(switch_port(id)){
    //Show err code
    _NOP();
  }
  else{
    if(write_and_read_gas_cal_b(port_address[id], write, &b_value)){
      //Show err code
      _NOP();
    }
     else{
        _NOP();
        datalink[id][B_DIMENSIONS] = b_value;
      return true;
    }  
  }
  return false;
}

void datalink_clear(void)
{
  for(i=0;i<24;i++){
    for(j=0;j<11;j++){
      datalink[i][j] = 0;
    }
  }
}

void sensordata_init(void)
{
  we = 0;
  ae = 0;
  concentrations = 0;
}

void sensorinfo_init(void)
{
  fw_version = 0;
  cal_data = 0;
  bsn = 0;
  gas_name = 0;
  zero = 0;
  span = 0;
  a_value = 0;
  b_value = 0;
}

void int_to_str_func(UINT64 conver_int)
{
  memset(conv_buf, 0x00, CONV_BUF_MAX);
  sprintf(conv_buf,"%lld",conver_int);
}

void ui_print(char *character)
{
  while (*character != '\0')
  {
    while (!(UCA1IFG & UCTXIFG));
    UCA1TXBUF = *character++;
  }
}

void ui_print_ack(void)
{
  while (!(UCA1IFG & UCTXIFG));
  UCA1TXBUF = 0x06;
}

void ADC_produce()
{
  if(datalink[i][0] >= datalink[i][1]){
    datalink[i][4] = datalink[i][0] - datalink[i][1];
  }
  
  if(datalink[i][0] < datalink[i][1]){
    datalink[i][4] = datalink[i][0] - datalink[i][1] ;
  }
}

void Correction_Zero()
{
  for(port_count=0;port_count<24;port_count++){
//    switch_port(port_count);
//    Write_Zero(CO_ADDRESS, CMD_W_ZERO, 0);
//    delay_ms(50);
//    Write_Zero(NO2_ADDRESS, CMD_W_ZERO, 0);
//    delay_ms(50);
//    Write_Zero(O3_ADDRESS, CMD_W_ZERO, 0);
//    delay_ms(50);
//    Write_Zero(NH3_ADDRESS, CMD_W_ZERO, 0);
//    delay_ms(50);
//    Write_Zero(H2S_ADDRESS, CMD_W_ZERO, 0);
//    delay_ms(50);
//    Write_Zero(AL_CO_B4_ADDRESS, CMD_W_ZERO, 0);
//    delay_ms(50);
//    Write_Zero(SO2_ADDRESS, CMD_W_ZERO, 0);
//    delay_ms(50);
  }
//  ui_print("\r");
//  ui_print("\ZeroOK:");
//  conv_buf[0] = 'Z';conv_buf[1] = 'e';conv_buf[2] = 'r';conv_buf[3] = 'o';conv_buf[4] = 'O';conv_buf[5] = 'K';
//  ui_print(conv_buf);
//  ui_print("\r\n");
}

void Correction_Span()
{
//  float Span;
//  if(datalink[j][1] == 0)
//  {
//    for(port_count=0;port_count<24;port_count++){
//      Span = ((datalink[port_count][0]-datalink[port_count][6])/Span_range);
//      datalink[port_count][8] = Span;
//      switch_port(port_count);
//      Write_Span(CO_ADDRESS, CMD_W_SPAN, Span);
//      delay_ms(50);
//      Write_Span(NO2_ADDRESS, CMD_W_SPAN, Span);
//      delay_ms(50);
//      Write_Span(O3_ADDRESS, CMD_W_SPAN, Span);
//      delay_ms(50);
//      Write_Span(NH3_ADDRESS, CMD_W_SPAN, Span);
//      delay_ms(50);
//      Write_Span(H2S_ADDRESS, CMD_W_SPAN, Span);
//      delay_ms(50);
//      Write_Span(AL_CO_B4_ADDRESS, CMD_W_SPAN, Span);
//      delay_ms(50);
//      Write_Span(SO2_ADDRESS, CMD_W_SPAN, Span);
//      delay_ms(50);
//    }
//    if (datalink[j][1] != 0)
//    {
//      for(port_count=0;port_count<24;port_count++){
//        Span = ((datalink[port_count][0]-datalink[port_count][6]) - (datalink[port_count][1]-datalink[port_count][7])/Span_range);
//        datalink[port_count][8] = Span;
//        switch_port(port_count);
//        Write_Span(CO_ADDRESS, CMD_W_SPAN, Span);
//        delay_ms(50);
//        Write_Span(NO2_ADDRESS, CMD_W_SPAN, Span);
//        delay_ms(50);
//        Write_Span(O3_ADDRESS, CMD_W_SPAN, Span);
//        delay_ms(50);
//        Write_Span(NH3_ADDRESS, CMD_W_SPAN, Span);
//        delay_ms(50);
//        Write_Span(H2S_ADDRESS, CMD_W_SPAN, Span);
//        delay_ms(50);
//        Write_Span(AL_CO_B4_ADDRESS, CMD_W_SPAN, Span);
//        delay_ms(50);
//        Write_Span(SO2_ADDRESS, CMD_W_SPAN, Span);
//        delay_ms(50);
//      }
//    }
//  }
  //  ui_print("\r");
  //  ui_print("\SpanOK:");
  //  conv_buf[0] = 'S';conv_buf[1] = 'p';conv_buf[2] = 'a';conv_buf[3] = 'n';conv_buf[4] = 'O';conv_buf[5] = 'K';
  //  ui_print(conv_buf);
  //  ui_print("\r\n");
}

void data_to_UCA_count(void)
{
  ui_print(conv_buf);
  ui_print(",");
}


void data_to_UCA(UINT8 data)
{
  for(int i=0;i<24;i++)
  {
    int_to_str_func(datalink[i][data]);
    data_to_UCA_count();  
  }
}

void one_data_to_UCA(UINT8 data, UINT8 ID)
{
  int_to_str_func(datalink[ID][data]);
  data_to_UCA_count();  
}

void BSN_to_UCA(UINT8 data)
{
  for(i=0;i<24;i++)
  {
    int_to_str_func(datalink[i][data]>>16);
    data_to_UCA_count();  
  }
}

void one_BSN_to_UCA(UINT8 data, UINT8 ID)
{
  int_to_str_func(datalink[ID][data]>>16);
  data_to_UCA_count();  
}

void SHT_to_UCA(void)
{
  for(i=0;i<8;i++)
  {
    int_to_str_func(SHT3x_RHT[i] );
    data_to_UCA_count();  
  }
}

/*void ui_parameter_post(void)
{
  data_to_UCA();
  k++;
  if(k >= 10){
    k = 0;
  }
}*/





