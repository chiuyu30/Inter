#ifndef SENSOR_ABSTRACTION
#define SENSOR_ABSTRACTION


#define AL_O3_ADDRESS              0x62
#define AL_NO2_ADDRESS             0x63
#define AL_CO_ADDRESS              0x64
#define AL_SO2_ADDRESS             0x66
#define DD7_NH3_ADDRESS            0x67
#define AL_H2S_ADDRESS             0x68
#define PIDAY5_VOC_ADDRESS         0x74
#define IRMAT_CH4_ADDRESS          0x78

#define WE_DIMENSIONS              0
#define AE_DIMENSIONS              1
#define ADC_DIMENSIONS             2
#define FW_DIMENSIONS              3
#define GAS_NAME_DIMENSIONS        4
#define BSN_DIMENSIONS             5
#define ZERO_DIMENSIONS            6
#define SPAN_DIMENSIONS            7
#define A_DIMENSIONS               8
#define B_DIMENSIONS               9
#define CAL_DATA_DIMENSIONS        10
#define CONCENTRATIONS_DIMENSIONS  11

void measure_gases_data(void);
void measure_gases_info(void);
void measure_rht(UINT8 sht_count);
void measure_all_rht(void);
void gat_all_gas_data(UINT8 port_numbers);
void get_all_gas_info(UINT8 port_numbers);
void datalink_clear(void);

bool record_bsn(UINT8 id, UINT64 write);
bool record_cal_date(UINT8 id, UINT32 write);
bool record_zero(UINT8 id, UINT32 write);
bool record_span(UINT8 id, float write);
bool record_a(UINT8 id, float write);
bool record_b(UINT8 id, INT32 write);

void sensordata_init(void);
void sensorinfo_init(void);
void data_to_UCA(UINT8 data);
void data_to_UCA_count(void);
void one_data_to_UCA(UINT8 data, UINT8 ID);
void BSN_to_UCA(UINT8 data);
void one_BSN_to_UCA(UINT8 data, UINT8 ID);
void SHT_to_UCA(void);
void ui_print(char *character);
void ui_print_ack(void);

void Correction_Zero(void);



extern UINT16 Span_range;



#endif