/*******************************************************************************
*
*   Tasks and timer 
*   
*   IAR EW430 V6.50.1
*   Company: Autotronic Enterprise CO., LTD.
*   Author: Xin.Gan
*   Create Date: 2020/07/27
*
*
*********************************************************************************/
#ifndef TASK_H
#define TASK_H


void task_timer_init(void);
void task_run(void);


#endif