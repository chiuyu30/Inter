#ifndef PERIPHERAL_ABSTRACTION
#define PERIPHERAL_ABSTRACTION

void peripheral_init(void);
void Reset_switch_init(void);

#endif