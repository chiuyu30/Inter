#ifndef UI_COMMAND_H_
#define UI_COMMAND_H_


extern UINT8 tabpage;

void chk_ui_cmd(void);
void command_tabpage(void);
void RxBuf_CMD_Clear(void);
void command_Write_BSN(void);
void command_Wrire_Zero(void);
void command_Wrire_Span(void);
void command_Wrire_Span(void);


#endif
