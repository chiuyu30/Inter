﻿namespace SLM5X_UI
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "上線",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "接收率",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
            "SGP40",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
            "濕度",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new string[] {
            "溫度",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem(new string[] {
            "GPS",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem(new string[] {
            "SD卡",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem(new string[] {
            "PM2.5 (PM2.5 CF)",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem(new string[] {
            "PM10 (PM10 CF)",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem(new string[] {
            "電池充放電資訊",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem11 = new System.Windows.Forms.ListViewItem(new string[] {
            "電池放電資訊",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem12 = new System.Windows.Forms.ListViewItem(new string[] {
            "最大電壓數值",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem13 = new System.Windows.Forms.ListViewItem(new string[] {
            "最小電壓數值",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem14 = new System.Windows.Forms.ListViewItem(new string[] {
            "VOC",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem15 = new System.Windows.Forms.ListViewItem(new string[] {
            "0",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem16 = new System.Windows.Forms.ListViewItem(new string[] {
            "1",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem17 = new System.Windows.Forms.ListViewItem(new string[] {
            "2",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem18 = new System.Windows.Forms.ListViewItem(new string[] {
            "3",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem19 = new System.Windows.Forms.ListViewItem(new string[] {
            "4",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem20 = new System.Windows.Forms.ListViewItem(new string[] {
            "5",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem21 = new System.Windows.Forms.ListViewItem(new string[] {
            "6",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem22 = new System.Windows.Forms.ListViewItem(new string[] {
            "7",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem23 = new System.Windows.Forms.ListViewItem(new string[] {
            "8",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem24 = new System.Windows.Forms.ListViewItem(new string[] {
            "9",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem25 = new System.Windows.Forms.ListViewItem(new string[] {
            "10",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem26 = new System.Windows.Forms.ListViewItem(new string[] {
            "11",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem27 = new System.Windows.Forms.ListViewItem(new string[] {
            "12",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem28 = new System.Windows.Forms.ListViewItem(new string[] {
            "13",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem29 = new System.Windows.Forms.ListViewItem(new string[] {
            "14",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem30 = new System.Windows.Forms.ListViewItem(new string[] {
            "15",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem31 = new System.Windows.Forms.ListViewItem(new string[] {
            "16",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem32 = new System.Windows.Forms.ListViewItem(new string[] {
            "17",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem33 = new System.Windows.Forms.ListViewItem(new string[] {
            "18",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem34 = new System.Windows.Forms.ListViewItem(new string[] {
            "19",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem35 = new System.Windows.Forms.ListViewItem(new string[] {
            "20",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem36 = new System.Windows.Forms.ListViewItem(new string[] {
            "21",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem37 = new System.Windows.Forms.ListViewItem(new string[] {
            "22",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem38 = new System.Windows.Forms.ListViewItem(new string[] {
            "23",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem39 = new System.Windows.Forms.ListViewItem(new string[] {
            "24",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem40 = new System.Windows.Forms.ListViewItem(new string[] {
            "25",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem41 = new System.Windows.Forms.ListViewItem(new string[] {
            "26",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem42 = new System.Windows.Forms.ListViewItem(new string[] {
            "27",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem43 = new System.Windows.Forms.ListViewItem(new string[] {
            "28",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem44 = new System.Windows.Forms.ListViewItem(new string[] {
            "29",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem45 = new System.Windows.Forms.ListViewItem(new string[] {
            "30",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem46 = new System.Windows.Forms.ListViewItem(new string[] {
            "31",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem47 = new System.Windows.Forms.ListViewItem(new string[] {
            "32",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem48 = new System.Windows.Forms.ListViewItem(new string[] {
            "33",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem49 = new System.Windows.Forms.ListViewItem(new string[] {
            "34",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem50 = new System.Windows.Forms.ListViewItem(new string[] {
            "35",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem51 = new System.Windows.Forms.ListViewItem(new string[] {
            "36",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem52 = new System.Windows.Forms.ListViewItem(new string[] {
            "37",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem53 = new System.Windows.Forms.ListViewItem(new string[] {
            "38",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem54 = new System.Windows.Forms.ListViewItem(new string[] {
            "39",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem55 = new System.Windows.Forms.ListViewItem(new string[] {
            "40",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem56 = new System.Windows.Forms.ListViewItem(new string[] {
            "41",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem57 = new System.Windows.Forms.ListViewItem(new string[] {
            "42",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem58 = new System.Windows.Forms.ListViewItem(new string[] {
            "43",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem59 = new System.Windows.Forms.ListViewItem(new string[] {
            "44",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem60 = new System.Windows.Forms.ListViewItem(new string[] {
            "45",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem61 = new System.Windows.Forms.ListViewItem(new string[] {
            "46",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem62 = new System.Windows.Forms.ListViewItem(new string[] {
            "47",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem63 = new System.Windows.Forms.ListViewItem(new string[] {
            "48",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem64 = new System.Windows.Forms.ListViewItem(new string[] {
            "49",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem65 = new System.Windows.Forms.ListViewItem(new string[] {
            "50",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem66 = new System.Windows.Forms.ListViewItem(new string[] {
            "51",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem67 = new System.Windows.Forms.ListViewItem(new string[] {
            "52",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem68 = new System.Windows.Forms.ListViewItem(new string[] {
            "53",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem69 = new System.Windows.Forms.ListViewItem(new string[] {
            "54",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem70 = new System.Windows.Forms.ListViewItem(new string[] {
            "55",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem71 = new System.Windows.Forms.ListViewItem(new string[] {
            "56",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem72 = new System.Windows.Forms.ListViewItem(new string[] {
            "57",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem73 = new System.Windows.Forms.ListViewItem(new string[] {
            "58",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem74 = new System.Windows.Forms.ListViewItem(new string[] {
            "59",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem75 = new System.Windows.Forms.ListViewItem(new string[] {
            "上線",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem76 = new System.Windows.Forms.ListViewItem(new string[] {
            "接收率",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem77 = new System.Windows.Forms.ListViewItem(new string[] {
            "SGP40",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem78 = new System.Windows.Forms.ListViewItem(new string[] {
            "濕度",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem79 = new System.Windows.Forms.ListViewItem(new string[] {
            "溫度",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem80 = new System.Windows.Forms.ListViewItem(new string[] {
            "GPS",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem81 = new System.Windows.Forms.ListViewItem(new string[] {
            "SD卡",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem82 = new System.Windows.Forms.ListViewItem(new string[] {
            "PM2.5 (PM2.5 CF)",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem83 = new System.Windows.Forms.ListViewItem(new string[] {
            "PM10 (PM10 CF)",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem84 = new System.Windows.Forms.ListViewItem(new string[] {
            "電池充放電資訊",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem85 = new System.Windows.Forms.ListViewItem(new string[] {
            "電池放電資訊",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem86 = new System.Windows.Forms.ListViewItem(new string[] {
            "最大電壓數值",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem87 = new System.Windows.Forms.ListViewItem(new string[] {
            "最小電壓數值",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem88 = new System.Windows.Forms.ListViewItem(new string[] {
            "VOC",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem89 = new System.Windows.Forms.ListViewItem(new string[] {
            "0",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem90 = new System.Windows.Forms.ListViewItem(new string[] {
            "1",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem91 = new System.Windows.Forms.ListViewItem(new string[] {
            "2",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem92 = new System.Windows.Forms.ListViewItem(new string[] {
            "3",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem93 = new System.Windows.Forms.ListViewItem(new string[] {
            "4",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem94 = new System.Windows.Forms.ListViewItem(new string[] {
            "5",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem95 = new System.Windows.Forms.ListViewItem(new string[] {
            "6",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem96 = new System.Windows.Forms.ListViewItem(new string[] {
            "7",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem97 = new System.Windows.Forms.ListViewItem(new string[] {
            "8",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem98 = new System.Windows.Forms.ListViewItem(new string[] {
            "9",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem99 = new System.Windows.Forms.ListViewItem(new string[] {
            "10",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem100 = new System.Windows.Forms.ListViewItem(new string[] {
            "11",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem101 = new System.Windows.Forms.ListViewItem(new string[] {
            "12",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem102 = new System.Windows.Forms.ListViewItem(new string[] {
            "13",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem103 = new System.Windows.Forms.ListViewItem(new string[] {
            "14",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem104 = new System.Windows.Forms.ListViewItem(new string[] {
            "15",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem105 = new System.Windows.Forms.ListViewItem(new string[] {
            "16",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem106 = new System.Windows.Forms.ListViewItem(new string[] {
            "17",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem107 = new System.Windows.Forms.ListViewItem(new string[] {
            "18",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem108 = new System.Windows.Forms.ListViewItem(new string[] {
            "19",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem109 = new System.Windows.Forms.ListViewItem(new string[] {
            "20",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem110 = new System.Windows.Forms.ListViewItem(new string[] {
            "21",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem111 = new System.Windows.Forms.ListViewItem(new string[] {
            "22",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem112 = new System.Windows.Forms.ListViewItem(new string[] {
            "23",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem113 = new System.Windows.Forms.ListViewItem(new string[] {
            "24",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem114 = new System.Windows.Forms.ListViewItem(new string[] {
            "25",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem115 = new System.Windows.Forms.ListViewItem(new string[] {
            "26",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem116 = new System.Windows.Forms.ListViewItem(new string[] {
            "27",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem117 = new System.Windows.Forms.ListViewItem(new string[] {
            "28",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem118 = new System.Windows.Forms.ListViewItem(new string[] {
            "29",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem119 = new System.Windows.Forms.ListViewItem(new string[] {
            "30",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem120 = new System.Windows.Forms.ListViewItem(new string[] {
            "31",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem121 = new System.Windows.Forms.ListViewItem(new string[] {
            "32",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem122 = new System.Windows.Forms.ListViewItem(new string[] {
            "33",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem123 = new System.Windows.Forms.ListViewItem(new string[] {
            "34",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem124 = new System.Windows.Forms.ListViewItem(new string[] {
            "35",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem125 = new System.Windows.Forms.ListViewItem(new string[] {
            "36",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem126 = new System.Windows.Forms.ListViewItem(new string[] {
            "37",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem127 = new System.Windows.Forms.ListViewItem(new string[] {
            "38",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem128 = new System.Windows.Forms.ListViewItem(new string[] {
            "39",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem129 = new System.Windows.Forms.ListViewItem(new string[] {
            "40",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem130 = new System.Windows.Forms.ListViewItem(new string[] {
            "41",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem131 = new System.Windows.Forms.ListViewItem(new string[] {
            "42",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem132 = new System.Windows.Forms.ListViewItem(new string[] {
            "43",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem133 = new System.Windows.Forms.ListViewItem(new string[] {
            "44",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem134 = new System.Windows.Forms.ListViewItem(new string[] {
            "45",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem135 = new System.Windows.Forms.ListViewItem(new string[] {
            "46",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem136 = new System.Windows.Forms.ListViewItem(new string[] {
            "47",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem137 = new System.Windows.Forms.ListViewItem(new string[] {
            "48",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem138 = new System.Windows.Forms.ListViewItem(new string[] {
            "49",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem139 = new System.Windows.Forms.ListViewItem(new string[] {
            "50",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem140 = new System.Windows.Forms.ListViewItem(new string[] {
            "51",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem141 = new System.Windows.Forms.ListViewItem(new string[] {
            "52",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem142 = new System.Windows.Forms.ListViewItem(new string[] {
            "53",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem143 = new System.Windows.Forms.ListViewItem(new string[] {
            "54",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem144 = new System.Windows.Forms.ListViewItem(new string[] {
            "55",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem145 = new System.Windows.Forms.ListViewItem(new string[] {
            "56",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem146 = new System.Windows.Forms.ListViewItem(new string[] {
            "57",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem147 = new System.Windows.Forms.ListViewItem(new string[] {
            "58",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem148 = new System.Windows.Forms.ListViewItem(new string[] {
            "59",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem149 = new System.Windows.Forms.ListViewItem(new string[] {
            "上線",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem150 = new System.Windows.Forms.ListViewItem(new string[] {
            "接收率",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem151 = new System.Windows.Forms.ListViewItem(new string[] {
            "SGP40",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem152 = new System.Windows.Forms.ListViewItem(new string[] {
            "濕度",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem153 = new System.Windows.Forms.ListViewItem(new string[] {
            "溫度",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem154 = new System.Windows.Forms.ListViewItem(new string[] {
            "GPS",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem155 = new System.Windows.Forms.ListViewItem(new string[] {
            "SD卡",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem156 = new System.Windows.Forms.ListViewItem(new string[] {
            "PM2.5 (PM2.5 CF)",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem157 = new System.Windows.Forms.ListViewItem(new string[] {
            "PM10 (PM10 CF)",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem158 = new System.Windows.Forms.ListViewItem(new string[] {
            "電池充放電資訊",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem159 = new System.Windows.Forms.ListViewItem(new string[] {
            "電池放電資訊",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem160 = new System.Windows.Forms.ListViewItem(new string[] {
            "最大電壓數值",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem161 = new System.Windows.Forms.ListViewItem(new string[] {
            "最小電壓數值",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem162 = new System.Windows.Forms.ListViewItem(new string[] {
            "VOC",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem163 = new System.Windows.Forms.ListViewItem(new string[] {
            "0",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem164 = new System.Windows.Forms.ListViewItem(new string[] {
            "1",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem165 = new System.Windows.Forms.ListViewItem(new string[] {
            "2",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem166 = new System.Windows.Forms.ListViewItem(new string[] {
            "3",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem167 = new System.Windows.Forms.ListViewItem(new string[] {
            "4",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem168 = new System.Windows.Forms.ListViewItem(new string[] {
            "5",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem169 = new System.Windows.Forms.ListViewItem(new string[] {
            "6",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem170 = new System.Windows.Forms.ListViewItem(new string[] {
            "7",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem171 = new System.Windows.Forms.ListViewItem(new string[] {
            "8",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem172 = new System.Windows.Forms.ListViewItem(new string[] {
            "9",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem173 = new System.Windows.Forms.ListViewItem(new string[] {
            "10",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem174 = new System.Windows.Forms.ListViewItem(new string[] {
            "11",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem175 = new System.Windows.Forms.ListViewItem(new string[] {
            "12",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem176 = new System.Windows.Forms.ListViewItem(new string[] {
            "13",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem177 = new System.Windows.Forms.ListViewItem(new string[] {
            "14",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem178 = new System.Windows.Forms.ListViewItem(new string[] {
            "15",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem179 = new System.Windows.Forms.ListViewItem(new string[] {
            "16",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem180 = new System.Windows.Forms.ListViewItem(new string[] {
            "17",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem181 = new System.Windows.Forms.ListViewItem(new string[] {
            "18",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem182 = new System.Windows.Forms.ListViewItem(new string[] {
            "19",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem183 = new System.Windows.Forms.ListViewItem(new string[] {
            "20",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem184 = new System.Windows.Forms.ListViewItem(new string[] {
            "21",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem185 = new System.Windows.Forms.ListViewItem(new string[] {
            "22",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem186 = new System.Windows.Forms.ListViewItem(new string[] {
            "23",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem187 = new System.Windows.Forms.ListViewItem(new string[] {
            "24",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem188 = new System.Windows.Forms.ListViewItem(new string[] {
            "25",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem189 = new System.Windows.Forms.ListViewItem(new string[] {
            "26",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem190 = new System.Windows.Forms.ListViewItem(new string[] {
            "27",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem191 = new System.Windows.Forms.ListViewItem(new string[] {
            "28",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem192 = new System.Windows.Forms.ListViewItem(new string[] {
            "29",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem193 = new System.Windows.Forms.ListViewItem(new string[] {
            "30",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem194 = new System.Windows.Forms.ListViewItem(new string[] {
            "31",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem195 = new System.Windows.Forms.ListViewItem(new string[] {
            "32",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem196 = new System.Windows.Forms.ListViewItem(new string[] {
            "33",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem197 = new System.Windows.Forms.ListViewItem(new string[] {
            "34",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem198 = new System.Windows.Forms.ListViewItem(new string[] {
            "35",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem199 = new System.Windows.Forms.ListViewItem(new string[] {
            "36",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem200 = new System.Windows.Forms.ListViewItem(new string[] {
            "37",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem201 = new System.Windows.Forms.ListViewItem(new string[] {
            "38",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem202 = new System.Windows.Forms.ListViewItem(new string[] {
            "39",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem203 = new System.Windows.Forms.ListViewItem(new string[] {
            "40",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem204 = new System.Windows.Forms.ListViewItem(new string[] {
            "41",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem205 = new System.Windows.Forms.ListViewItem(new string[] {
            "42",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem206 = new System.Windows.Forms.ListViewItem(new string[] {
            "43",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem207 = new System.Windows.Forms.ListViewItem(new string[] {
            "44",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem208 = new System.Windows.Forms.ListViewItem(new string[] {
            "45",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem209 = new System.Windows.Forms.ListViewItem(new string[] {
            "46",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem210 = new System.Windows.Forms.ListViewItem(new string[] {
            "47",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem211 = new System.Windows.Forms.ListViewItem(new string[] {
            "48",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem212 = new System.Windows.Forms.ListViewItem(new string[] {
            "49",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem213 = new System.Windows.Forms.ListViewItem(new string[] {
            "50",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem214 = new System.Windows.Forms.ListViewItem(new string[] {
            "51",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem215 = new System.Windows.Forms.ListViewItem(new string[] {
            "52",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem216 = new System.Windows.Forms.ListViewItem(new string[] {
            "53",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem217 = new System.Windows.Forms.ListViewItem(new string[] {
            "54",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem218 = new System.Windows.Forms.ListViewItem(new string[] {
            "55",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem219 = new System.Windows.Forms.ListViewItem(new string[] {
            "56",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem220 = new System.Windows.Forms.ListViewItem(new string[] {
            "57",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem221 = new System.Windows.Forms.ListViewItem(new string[] {
            "58",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem222 = new System.Windows.Forms.ListViewItem(new string[] {
            "59",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem223 = new System.Windows.Forms.ListViewItem(new string[] {
            "上線",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem224 = new System.Windows.Forms.ListViewItem(new string[] {
            "接收率",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem225 = new System.Windows.Forms.ListViewItem(new string[] {
            "SGP40",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem226 = new System.Windows.Forms.ListViewItem(new string[] {
            "濕度",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem227 = new System.Windows.Forms.ListViewItem(new string[] {
            "溫度",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem228 = new System.Windows.Forms.ListViewItem(new string[] {
            "GPS",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem229 = new System.Windows.Forms.ListViewItem(new string[] {
            "SD卡",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem230 = new System.Windows.Forms.ListViewItem(new string[] {
            "PM2.5 (PM2.5 CF)",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem231 = new System.Windows.Forms.ListViewItem(new string[] {
            "PM10 (PM10 CF)",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem232 = new System.Windows.Forms.ListViewItem(new string[] {
            "電池充放電資訊",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem233 = new System.Windows.Forms.ListViewItem(new string[] {
            "電池放電資訊",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem234 = new System.Windows.Forms.ListViewItem(new string[] {
            "最大電壓數值",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem235 = new System.Windows.Forms.ListViewItem(new string[] {
            "最小電壓數值",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem236 = new System.Windows.Forms.ListViewItem(new string[] {
            "VOC",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem237 = new System.Windows.Forms.ListViewItem(new string[] {
            "0",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem238 = new System.Windows.Forms.ListViewItem(new string[] {
            "1",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem239 = new System.Windows.Forms.ListViewItem(new string[] {
            "2",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem240 = new System.Windows.Forms.ListViewItem(new string[] {
            "3",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem241 = new System.Windows.Forms.ListViewItem(new string[] {
            "4",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem242 = new System.Windows.Forms.ListViewItem(new string[] {
            "5",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem243 = new System.Windows.Forms.ListViewItem(new string[] {
            "6",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem244 = new System.Windows.Forms.ListViewItem(new string[] {
            "7",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem245 = new System.Windows.Forms.ListViewItem(new string[] {
            "8",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem246 = new System.Windows.Forms.ListViewItem(new string[] {
            "9",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem247 = new System.Windows.Forms.ListViewItem(new string[] {
            "10",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem248 = new System.Windows.Forms.ListViewItem(new string[] {
            "11",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem249 = new System.Windows.Forms.ListViewItem(new string[] {
            "12",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem250 = new System.Windows.Forms.ListViewItem(new string[] {
            "13",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem251 = new System.Windows.Forms.ListViewItem(new string[] {
            "14",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem252 = new System.Windows.Forms.ListViewItem(new string[] {
            "15",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem253 = new System.Windows.Forms.ListViewItem(new string[] {
            "16",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem254 = new System.Windows.Forms.ListViewItem(new string[] {
            "17",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem255 = new System.Windows.Forms.ListViewItem(new string[] {
            "18",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem256 = new System.Windows.Forms.ListViewItem(new string[] {
            "19",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem257 = new System.Windows.Forms.ListViewItem(new string[] {
            "20",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem258 = new System.Windows.Forms.ListViewItem(new string[] {
            "21",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem259 = new System.Windows.Forms.ListViewItem(new string[] {
            "22",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem260 = new System.Windows.Forms.ListViewItem(new string[] {
            "23",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem261 = new System.Windows.Forms.ListViewItem(new string[] {
            "24",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem262 = new System.Windows.Forms.ListViewItem(new string[] {
            "25",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem263 = new System.Windows.Forms.ListViewItem(new string[] {
            "26",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem264 = new System.Windows.Forms.ListViewItem(new string[] {
            "27",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem265 = new System.Windows.Forms.ListViewItem(new string[] {
            "28",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem266 = new System.Windows.Forms.ListViewItem(new string[] {
            "29",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem267 = new System.Windows.Forms.ListViewItem(new string[] {
            "30",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem268 = new System.Windows.Forms.ListViewItem(new string[] {
            "31",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem269 = new System.Windows.Forms.ListViewItem(new string[] {
            "32",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem270 = new System.Windows.Forms.ListViewItem(new string[] {
            "33",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem271 = new System.Windows.Forms.ListViewItem(new string[] {
            "34",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem272 = new System.Windows.Forms.ListViewItem(new string[] {
            "35",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem273 = new System.Windows.Forms.ListViewItem(new string[] {
            "36",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem274 = new System.Windows.Forms.ListViewItem(new string[] {
            "37",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem275 = new System.Windows.Forms.ListViewItem(new string[] {
            "38",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem276 = new System.Windows.Forms.ListViewItem(new string[] {
            "39",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem277 = new System.Windows.Forms.ListViewItem(new string[] {
            "40",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem278 = new System.Windows.Forms.ListViewItem(new string[] {
            "41",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem279 = new System.Windows.Forms.ListViewItem(new string[] {
            "42",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem280 = new System.Windows.Forms.ListViewItem(new string[] {
            "43",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem281 = new System.Windows.Forms.ListViewItem(new string[] {
            "44",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem282 = new System.Windows.Forms.ListViewItem(new string[] {
            "45",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem283 = new System.Windows.Forms.ListViewItem(new string[] {
            "46",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem284 = new System.Windows.Forms.ListViewItem(new string[] {
            "47",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem285 = new System.Windows.Forms.ListViewItem(new string[] {
            "48",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem286 = new System.Windows.Forms.ListViewItem(new string[] {
            "49",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem287 = new System.Windows.Forms.ListViewItem(new string[] {
            "50",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem288 = new System.Windows.Forms.ListViewItem(new string[] {
            "51",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem289 = new System.Windows.Forms.ListViewItem(new string[] {
            "52",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem290 = new System.Windows.Forms.ListViewItem(new string[] {
            "53",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem291 = new System.Windows.Forms.ListViewItem(new string[] {
            "54",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem292 = new System.Windows.Forms.ListViewItem(new string[] {
            "55",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem293 = new System.Windows.Forms.ListViewItem(new string[] {
            "56",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem294 = new System.Windows.Forms.ListViewItem(new string[] {
            "57",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem295 = new System.Windows.Forms.ListViewItem(new string[] {
            "58",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem296 = new System.Windows.Forms.ListViewItem(new string[] {
            "59",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem297 = new System.Windows.Forms.ListViewItem(new string[] {
            "上線",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem298 = new System.Windows.Forms.ListViewItem(new string[] {
            "接收率",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem299 = new System.Windows.Forms.ListViewItem(new string[] {
            "SGP40",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem300 = new System.Windows.Forms.ListViewItem(new string[] {
            "濕度",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem301 = new System.Windows.Forms.ListViewItem(new string[] {
            "溫度",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem302 = new System.Windows.Forms.ListViewItem(new string[] {
            "GPS",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem303 = new System.Windows.Forms.ListViewItem(new string[] {
            "SD卡",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem304 = new System.Windows.Forms.ListViewItem(new string[] {
            "PM2.5 (PM2.5 CF)",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem305 = new System.Windows.Forms.ListViewItem(new string[] {
            "PM10 (PM10 CF)",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem306 = new System.Windows.Forms.ListViewItem(new string[] {
            "電池充放電資訊",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem307 = new System.Windows.Forms.ListViewItem(new string[] {
            "電池放電資訊",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem308 = new System.Windows.Forms.ListViewItem(new string[] {
            "最大電壓數值",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem309 = new System.Windows.Forms.ListViewItem(new string[] {
            "最小電壓數值",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem310 = new System.Windows.Forms.ListViewItem(new string[] {
            "VOC",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem311 = new System.Windows.Forms.ListViewItem(new string[] {
            "0",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem312 = new System.Windows.Forms.ListViewItem(new string[] {
            "1",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem313 = new System.Windows.Forms.ListViewItem(new string[] {
            "2",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem314 = new System.Windows.Forms.ListViewItem(new string[] {
            "3",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem315 = new System.Windows.Forms.ListViewItem(new string[] {
            "4",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem316 = new System.Windows.Forms.ListViewItem(new string[] {
            "5",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem317 = new System.Windows.Forms.ListViewItem(new string[] {
            "6",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem318 = new System.Windows.Forms.ListViewItem(new string[] {
            "7",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem319 = new System.Windows.Forms.ListViewItem(new string[] {
            "8",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem320 = new System.Windows.Forms.ListViewItem(new string[] {
            "9",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem321 = new System.Windows.Forms.ListViewItem(new string[] {
            "10",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem322 = new System.Windows.Forms.ListViewItem(new string[] {
            "11",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem323 = new System.Windows.Forms.ListViewItem(new string[] {
            "12",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem324 = new System.Windows.Forms.ListViewItem(new string[] {
            "13",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem325 = new System.Windows.Forms.ListViewItem(new string[] {
            "14",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem326 = new System.Windows.Forms.ListViewItem(new string[] {
            "15",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem327 = new System.Windows.Forms.ListViewItem(new string[] {
            "16",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem328 = new System.Windows.Forms.ListViewItem(new string[] {
            "17",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem329 = new System.Windows.Forms.ListViewItem(new string[] {
            "18",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem330 = new System.Windows.Forms.ListViewItem(new string[] {
            "19",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem331 = new System.Windows.Forms.ListViewItem(new string[] {
            "20",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem332 = new System.Windows.Forms.ListViewItem(new string[] {
            "21",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem333 = new System.Windows.Forms.ListViewItem(new string[] {
            "22",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem334 = new System.Windows.Forms.ListViewItem(new string[] {
            "23",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem335 = new System.Windows.Forms.ListViewItem(new string[] {
            "24",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem336 = new System.Windows.Forms.ListViewItem(new string[] {
            "25",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem337 = new System.Windows.Forms.ListViewItem(new string[] {
            "26",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem338 = new System.Windows.Forms.ListViewItem(new string[] {
            "27",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem339 = new System.Windows.Forms.ListViewItem(new string[] {
            "28",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem340 = new System.Windows.Forms.ListViewItem(new string[] {
            "29",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem341 = new System.Windows.Forms.ListViewItem(new string[] {
            "30",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem342 = new System.Windows.Forms.ListViewItem(new string[] {
            "31",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem343 = new System.Windows.Forms.ListViewItem(new string[] {
            "32",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem344 = new System.Windows.Forms.ListViewItem(new string[] {
            "33",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem345 = new System.Windows.Forms.ListViewItem(new string[] {
            "34",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem346 = new System.Windows.Forms.ListViewItem(new string[] {
            "35",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem347 = new System.Windows.Forms.ListViewItem(new string[] {
            "36",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem348 = new System.Windows.Forms.ListViewItem(new string[] {
            "37",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem349 = new System.Windows.Forms.ListViewItem(new string[] {
            "38",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem350 = new System.Windows.Forms.ListViewItem(new string[] {
            "39",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem351 = new System.Windows.Forms.ListViewItem(new string[] {
            "40",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem352 = new System.Windows.Forms.ListViewItem(new string[] {
            "41",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem353 = new System.Windows.Forms.ListViewItem(new string[] {
            "42",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem354 = new System.Windows.Forms.ListViewItem(new string[] {
            "43",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem355 = new System.Windows.Forms.ListViewItem(new string[] {
            "44",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem356 = new System.Windows.Forms.ListViewItem(new string[] {
            "45",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem357 = new System.Windows.Forms.ListViewItem(new string[] {
            "46",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem358 = new System.Windows.Forms.ListViewItem(new string[] {
            "47",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem359 = new System.Windows.Forms.ListViewItem(new string[] {
            "48",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem360 = new System.Windows.Forms.ListViewItem(new string[] {
            "49",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem361 = new System.Windows.Forms.ListViewItem(new string[] {
            "50",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem362 = new System.Windows.Forms.ListViewItem(new string[] {
            "51",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem363 = new System.Windows.Forms.ListViewItem(new string[] {
            "52",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem364 = new System.Windows.Forms.ListViewItem(new string[] {
            "53",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem365 = new System.Windows.Forms.ListViewItem(new string[] {
            "54",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem366 = new System.Windows.Forms.ListViewItem(new string[] {
            "55",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem367 = new System.Windows.Forms.ListViewItem(new string[] {
            "56",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem368 = new System.Windows.Forms.ListViewItem(new string[] {
            "57",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem369 = new System.Windows.Forms.ListViewItem(new string[] {
            "58",
            "--"}, -1);
            System.Windows.Forms.ListViewItem listViewItem370 = new System.Windows.Forms.ListViewItem(new string[] {
            "59",
            "--"}, -1);
            this.label34 = new System.Windows.Forms.Label();
            this.Port1_box = new System.Windows.Forms.ComboBox();
            this.btn_Connect = new System.Windows.Forms.Button();
            this.label_State1 = new System.Windows.Forms.Label();
            this.btn_cap = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.error_check_list5 = new System.Windows.Forms.ListView();
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView5 = new System.Windows.Forms.ListView();
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Port5_box = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.error_check_list4 = new System.Windows.Forms.ListView();
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView4 = new System.Windows.Forms.ListView();
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Port4_box = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.error_check_list3 = new System.Windows.Forms.ListView();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView3 = new System.Windows.Forms.ListView();
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Port3_box = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.error_check_list2 = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Port2_box = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.error_check_list1 = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label_pass_time = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label34.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(10, 14);
            this.label34.Margin = new System.Windows.Forms.Padding(10, 10, 0, 0);
            this.label34.Name = "label34";
            this.label34.Padding = new System.Windows.Forms.Padding(26, 4, 25, 5);
            this.label34.Size = new System.Drawing.Size(101, 31);
            this.label34.TabIndex = 269;
            this.label34.Text = "Port";
            // 
            // Port1_box
            // 
            this.Port1_box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Port1_box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Port1_box.Font = new System.Drawing.Font("Consolas", 15F);
            this.Port1_box.FormattingEnabled = true;
            this.Port1_box.Location = new System.Drawing.Point(111, 14);
            this.Port1_box.Margin = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.Port1_box.Name = "Port1_box";
            this.Port1_box.Size = new System.Drawing.Size(122, 31);
            this.Port1_box.TabIndex = 268;
            this.Port1_box.DropDown += new System.EventHandler(this.Port1_box_DropDown);
            // 
            // btn_Connect
            // 
            this.btn_Connect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_Connect.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_Connect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Connect.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_Connect.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Connect.Location = new System.Drawing.Point(21, 33);
            this.btn_Connect.Margin = new System.Windows.Forms.Padding(0);
            this.btn_Connect.Name = "btn_Connect";
            this.btn_Connect.Size = new System.Drawing.Size(132, 31);
            this.btn_Connect.TabIndex = 270;
            this.btn_Connect.Text = "Connect";
            this.btn_Connect.UseVisualStyleBackColor = false;
            this.btn_Connect.Click += new System.EventHandler(this.btn_Connect_Click);
            // 
            // label_State1
            // 
            this.label_State1.AutoSize = true;
            this.label_State1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_State1.Location = new System.Drawing.Point(173, 38);
            this.label_State1.Margin = new System.Windows.Forms.Padding(20, 0, 3, 0);
            this.label_State1.Name = "label_State1";
            this.label_State1.Size = new System.Drawing.Size(240, 22);
            this.label_State1.TabIndex = 272;
            this.label_State1.Text = "Choose port to connect.";
            // 
            // btn_cap
            // 
            this.btn_cap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_cap.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_cap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cap.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_cap.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_cap.Location = new System.Drawing.Point(617, 33);
            this.btn_cap.Margin = new System.Windows.Forms.Padding(0);
            this.btn_cap.Name = "btn_cap";
            this.btn_cap.Size = new System.Drawing.Size(167, 31);
            this.btn_cap.TabIndex = 273;
            this.btn_cap.Text = "Capture";
            this.btn_cap.UseVisualStyleBackColor = false;
            this.btn_cap.Click += new System.EventHandler(this.btn_cap_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.groupBox5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.groupBox1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(21, 92);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1360, 575);
            this.tableLayoutPanel1.TabIndex = 274;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.panel5);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox5.Location = new System.Drawing.Point(1091, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(266, 569);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "ID_5";
            // 
            // panel5
            // 
            this.panel5.AutoScroll = true;
            this.panel5.Controls.Add(this.error_check_list5);
            this.panel5.Controls.Add(this.listView5);
            this.panel5.Controls.Add(this.Port5_box);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 24);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(260, 542);
            this.panel5.TabIndex = 1;
            // 
            // error_check_list5
            // 
            this.error_check_list5.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader17,
            this.columnHeader18});
            this.error_check_list5.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error_check_list5.HideSelection = false;
            this.error_check_list5.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5,
            listViewItem6,
            listViewItem7,
            listViewItem8,
            listViewItem9,
            listViewItem10,
            listViewItem11,
            listViewItem12,
            listViewItem13,
            listViewItem14});
            this.error_check_list5.Location = new System.Drawing.Point(10, 55);
            this.error_check_list5.Margin = new System.Windows.Forms.Padding(10);
            this.error_check_list5.Name = "error_check_list5";
            this.error_check_list5.Size = new System.Drawing.Size(223, 197);
            this.error_check_list5.TabIndex = 271;
            this.error_check_list5.UseCompatibleStateImageBehavior = false;
            this.error_check_list5.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "檢查項目";
            this.columnHeader17.Width = 137;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = " ";
            this.columnHeader18.Width = 61;
            // 
            // listView5
            // 
            this.listView5.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader19,
            this.columnHeader20});
            this.listView5.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView5.HideSelection = false;
            this.listView5.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem15,
            listViewItem16,
            listViewItem17,
            listViewItem18,
            listViewItem19,
            listViewItem20,
            listViewItem21,
            listViewItem22,
            listViewItem23,
            listViewItem24,
            listViewItem25,
            listViewItem26,
            listViewItem27,
            listViewItem28,
            listViewItem29,
            listViewItem30,
            listViewItem31,
            listViewItem32,
            listViewItem33,
            listViewItem34,
            listViewItem35,
            listViewItem36,
            listViewItem37,
            listViewItem38,
            listViewItem39,
            listViewItem40,
            listViewItem41,
            listViewItem42,
            listViewItem43,
            listViewItem44,
            listViewItem45,
            listViewItem46,
            listViewItem47,
            listViewItem48,
            listViewItem49,
            listViewItem50,
            listViewItem51,
            listViewItem52,
            listViewItem53,
            listViewItem54,
            listViewItem55,
            listViewItem56,
            listViewItem57,
            listViewItem58,
            listViewItem59,
            listViewItem60,
            listViewItem61,
            listViewItem62,
            listViewItem63,
            listViewItem64,
            listViewItem65,
            listViewItem66,
            listViewItem67,
            listViewItem68,
            listViewItem69,
            listViewItem70,
            listViewItem71,
            listViewItem72,
            listViewItem73,
            listViewItem74});
            this.listView5.Location = new System.Drawing.Point(10, 262);
            this.listView5.Margin = new System.Windows.Forms.Padding(10, 0, 10, 10);
            this.listView5.Name = "listView5";
            this.listView5.Size = new System.Drawing.Size(223, 535);
            this.listView5.TabIndex = 270;
            this.listView5.UseCompatibleStateImageBehavior = false;
            this.listView5.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "Addr";
            this.columnHeader19.Width = 71;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "Value";
            this.columnHeader20.Width = 130;
            // 
            // Port5_box
            // 
            this.Port5_box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Port5_box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Port5_box.Font = new System.Drawing.Font("Consolas", 15F);
            this.Port5_box.FormattingEnabled = true;
            this.Port5_box.Location = new System.Drawing.Point(111, 14);
            this.Port5_box.Margin = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.Port5_box.Name = "Port5_box";
            this.Port5_box.Size = new System.Drawing.Size(122, 31);
            this.Port5_box.TabIndex = 268;
            this.Port5_box.DropDown += new System.EventHandler(this.Port5_box_DropDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label4.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(10, 14);
            this.label4.Margin = new System.Windows.Forms.Padding(10, 10, 0, 0);
            this.label4.Name = "label4";
            this.label4.Padding = new System.Windows.Forms.Padding(26, 4, 25, 5);
            this.label4.Size = new System.Drawing.Size(101, 31);
            this.label4.TabIndex = 269;
            this.label4.Text = "Port";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.panel4);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(819, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(266, 569);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "ID_4";
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.Controls.Add(this.error_check_list4);
            this.panel4.Controls.Add(this.listView4);
            this.panel4.Controls.Add(this.Port4_box);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 24);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(260, 542);
            this.panel4.TabIndex = 1;
            // 
            // error_check_list4
            // 
            this.error_check_list4.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader13,
            this.columnHeader14});
            this.error_check_list4.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error_check_list4.HideSelection = false;
            this.error_check_list4.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem75,
            listViewItem76,
            listViewItem77,
            listViewItem78,
            listViewItem79,
            listViewItem80,
            listViewItem81,
            listViewItem82,
            listViewItem83,
            listViewItem84,
            listViewItem85,
            listViewItem86,
            listViewItem87,
            listViewItem88});
            this.error_check_list4.Location = new System.Drawing.Point(10, 55);
            this.error_check_list4.Margin = new System.Windows.Forms.Padding(10);
            this.error_check_list4.Name = "error_check_list4";
            this.error_check_list4.Size = new System.Drawing.Size(223, 197);
            this.error_check_list4.TabIndex = 271;
            this.error_check_list4.UseCompatibleStateImageBehavior = false;
            this.error_check_list4.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "檢查項目";
            this.columnHeader13.Width = 137;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = " ";
            this.columnHeader14.Width = 61;
            // 
            // listView4
            // 
            this.listView4.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader15,
            this.columnHeader16});
            this.listView4.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView4.HideSelection = false;
            this.listView4.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem89,
            listViewItem90,
            listViewItem91,
            listViewItem92,
            listViewItem93,
            listViewItem94,
            listViewItem95,
            listViewItem96,
            listViewItem97,
            listViewItem98,
            listViewItem99,
            listViewItem100,
            listViewItem101,
            listViewItem102,
            listViewItem103,
            listViewItem104,
            listViewItem105,
            listViewItem106,
            listViewItem107,
            listViewItem108,
            listViewItem109,
            listViewItem110,
            listViewItem111,
            listViewItem112,
            listViewItem113,
            listViewItem114,
            listViewItem115,
            listViewItem116,
            listViewItem117,
            listViewItem118,
            listViewItem119,
            listViewItem120,
            listViewItem121,
            listViewItem122,
            listViewItem123,
            listViewItem124,
            listViewItem125,
            listViewItem126,
            listViewItem127,
            listViewItem128,
            listViewItem129,
            listViewItem130,
            listViewItem131,
            listViewItem132,
            listViewItem133,
            listViewItem134,
            listViewItem135,
            listViewItem136,
            listViewItem137,
            listViewItem138,
            listViewItem139,
            listViewItem140,
            listViewItem141,
            listViewItem142,
            listViewItem143,
            listViewItem144,
            listViewItem145,
            listViewItem146,
            listViewItem147,
            listViewItem148});
            this.listView4.Location = new System.Drawing.Point(10, 262);
            this.listView4.Margin = new System.Windows.Forms.Padding(10, 0, 10, 10);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(223, 535);
            this.listView4.TabIndex = 270;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Addr";
            this.columnHeader15.Width = 71;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Value";
            this.columnHeader16.Width = 130;
            // 
            // Port4_box
            // 
            this.Port4_box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Port4_box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Port4_box.Font = new System.Drawing.Font("Consolas", 15F);
            this.Port4_box.FormattingEnabled = true;
            this.Port4_box.Location = new System.Drawing.Point(111, 14);
            this.Port4_box.Margin = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.Port4_box.Name = "Port4_box";
            this.Port4_box.Size = new System.Drawing.Size(122, 31);
            this.Port4_box.TabIndex = 268;
            this.Port4_box.DropDown += new System.EventHandler(this.Port4_box_DropDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label3.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(10, 14);
            this.label3.Margin = new System.Windows.Forms.Padding(10, 10, 0, 0);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(26, 4, 25, 5);
            this.label3.Size = new System.Drawing.Size(101, 31);
            this.label3.TabIndex = 269;
            this.label3.Text = "Port";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.panel3);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(547, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(266, 569);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ID_3";
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.Controls.Add(this.error_check_list3);
            this.panel3.Controls.Add(this.listView3);
            this.panel3.Controls.Add(this.Port3_box);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 24);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(260, 542);
            this.panel3.TabIndex = 1;
            // 
            // error_check_list3
            // 
            this.error_check_list3.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10});
            this.error_check_list3.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error_check_list3.HideSelection = false;
            this.error_check_list3.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem149,
            listViewItem150,
            listViewItem151,
            listViewItem152,
            listViewItem153,
            listViewItem154,
            listViewItem155,
            listViewItem156,
            listViewItem157,
            listViewItem158,
            listViewItem159,
            listViewItem160,
            listViewItem161,
            listViewItem162});
            this.error_check_list3.Location = new System.Drawing.Point(10, 55);
            this.error_check_list3.Margin = new System.Windows.Forms.Padding(10);
            this.error_check_list3.Name = "error_check_list3";
            this.error_check_list3.Size = new System.Drawing.Size(223, 197);
            this.error_check_list3.TabIndex = 271;
            this.error_check_list3.UseCompatibleStateImageBehavior = false;
            this.error_check_list3.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "檢查項目";
            this.columnHeader9.Width = 137;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = " ";
            this.columnHeader10.Width = 61;
            // 
            // listView3
            // 
            this.listView3.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader11,
            this.columnHeader12});
            this.listView3.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView3.HideSelection = false;
            this.listView3.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem163,
            listViewItem164,
            listViewItem165,
            listViewItem166,
            listViewItem167,
            listViewItem168,
            listViewItem169,
            listViewItem170,
            listViewItem171,
            listViewItem172,
            listViewItem173,
            listViewItem174,
            listViewItem175,
            listViewItem176,
            listViewItem177,
            listViewItem178,
            listViewItem179,
            listViewItem180,
            listViewItem181,
            listViewItem182,
            listViewItem183,
            listViewItem184,
            listViewItem185,
            listViewItem186,
            listViewItem187,
            listViewItem188,
            listViewItem189,
            listViewItem190,
            listViewItem191,
            listViewItem192,
            listViewItem193,
            listViewItem194,
            listViewItem195,
            listViewItem196,
            listViewItem197,
            listViewItem198,
            listViewItem199,
            listViewItem200,
            listViewItem201,
            listViewItem202,
            listViewItem203,
            listViewItem204,
            listViewItem205,
            listViewItem206,
            listViewItem207,
            listViewItem208,
            listViewItem209,
            listViewItem210,
            listViewItem211,
            listViewItem212,
            listViewItem213,
            listViewItem214,
            listViewItem215,
            listViewItem216,
            listViewItem217,
            listViewItem218,
            listViewItem219,
            listViewItem220,
            listViewItem221,
            listViewItem222});
            this.listView3.Location = new System.Drawing.Point(10, 262);
            this.listView3.Margin = new System.Windows.Forms.Padding(10, 0, 10, 10);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(223, 535);
            this.listView3.TabIndex = 270;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Addr";
            this.columnHeader11.Width = 71;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Value";
            this.columnHeader12.Width = 130;
            // 
            // Port3_box
            // 
            this.Port3_box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Port3_box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Port3_box.Font = new System.Drawing.Font("Consolas", 15F);
            this.Port3_box.FormattingEnabled = true;
            this.Port3_box.Location = new System.Drawing.Point(111, 14);
            this.Port3_box.Margin = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.Port3_box.Name = "Port3_box";
            this.Port3_box.Size = new System.Drawing.Size(122, 31);
            this.Port3_box.TabIndex = 268;
            this.Port3_box.DropDown += new System.EventHandler(this.Port3_box_DropDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label2.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 14);
            this.label2.Margin = new System.Windows.Forms.Padding(10, 10, 0, 0);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(26, 4, 25, 5);
            this.label2.Size = new System.Drawing.Size(101, 31);
            this.label2.TabIndex = 269;
            this.label2.Text = "Port";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel2);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(275, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(266, 569);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ID_2";
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.error_check_list2);
            this.panel2.Controls.Add(this.listView2);
            this.panel2.Controls.Add(this.Port2_box);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 24);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(260, 542);
            this.panel2.TabIndex = 1;
            // 
            // error_check_list2
            // 
            this.error_check_list2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6});
            this.error_check_list2.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error_check_list2.HideSelection = false;
            this.error_check_list2.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem223,
            listViewItem224,
            listViewItem225,
            listViewItem226,
            listViewItem227,
            listViewItem228,
            listViewItem229,
            listViewItem230,
            listViewItem231,
            listViewItem232,
            listViewItem233,
            listViewItem234,
            listViewItem235,
            listViewItem236});
            this.error_check_list2.Location = new System.Drawing.Point(10, 55);
            this.error_check_list2.Margin = new System.Windows.Forms.Padding(10);
            this.error_check_list2.Name = "error_check_list2";
            this.error_check_list2.Size = new System.Drawing.Size(223, 197);
            this.error_check_list2.TabIndex = 271;
            this.error_check_list2.UseCompatibleStateImageBehavior = false;
            this.error_check_list2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "檢查項目";
            this.columnHeader5.Width = 137;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = " ";
            this.columnHeader6.Width = 61;
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader7,
            this.columnHeader8});
            this.listView2.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView2.HideSelection = false;
            this.listView2.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem237,
            listViewItem238,
            listViewItem239,
            listViewItem240,
            listViewItem241,
            listViewItem242,
            listViewItem243,
            listViewItem244,
            listViewItem245,
            listViewItem246,
            listViewItem247,
            listViewItem248,
            listViewItem249,
            listViewItem250,
            listViewItem251,
            listViewItem252,
            listViewItem253,
            listViewItem254,
            listViewItem255,
            listViewItem256,
            listViewItem257,
            listViewItem258,
            listViewItem259,
            listViewItem260,
            listViewItem261,
            listViewItem262,
            listViewItem263,
            listViewItem264,
            listViewItem265,
            listViewItem266,
            listViewItem267,
            listViewItem268,
            listViewItem269,
            listViewItem270,
            listViewItem271,
            listViewItem272,
            listViewItem273,
            listViewItem274,
            listViewItem275,
            listViewItem276,
            listViewItem277,
            listViewItem278,
            listViewItem279,
            listViewItem280,
            listViewItem281,
            listViewItem282,
            listViewItem283,
            listViewItem284,
            listViewItem285,
            listViewItem286,
            listViewItem287,
            listViewItem288,
            listViewItem289,
            listViewItem290,
            listViewItem291,
            listViewItem292,
            listViewItem293,
            listViewItem294,
            listViewItem295,
            listViewItem296});
            this.listView2.Location = new System.Drawing.Point(10, 262);
            this.listView2.Margin = new System.Windows.Forms.Padding(10, 0, 10, 10);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(223, 535);
            this.listView2.TabIndex = 270;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Addr";
            this.columnHeader7.Width = 71;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Value";
            this.columnHeader8.Width = 130;
            // 
            // Port2_box
            // 
            this.Port2_box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Port2_box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Port2_box.Font = new System.Drawing.Font("Consolas", 15F);
            this.Port2_box.FormattingEnabled = true;
            this.Port2_box.Location = new System.Drawing.Point(111, 14);
            this.Port2_box.Margin = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.Port2_box.Name = "Port2_box";
            this.Port2_box.Size = new System.Drawing.Size(122, 31);
            this.Port2_box.TabIndex = 268;
            this.Port2_box.DropDown += new System.EventHandler(this.Port2_box_DropDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(10, 10, 0, 0);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(26, 4, 25, 5);
            this.label1.Size = new System.Drawing.Size(101, 31);
            this.label1.TabIndex = 269;
            this.label1.Text = "Port";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(266, 569);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ID_1";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.error_check_list1);
            this.panel1.Controls.Add(this.listView1);
            this.panel1.Controls.Add(this.Port1_box);
            this.panel1.Controls.Add(this.label34);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 24);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(260, 542);
            this.panel1.TabIndex = 0;
            // 
            // error_check_list1
            // 
            this.error_check_list1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.error_check_list1.Font = new System.Drawing.Font("Consolas", 12.75F);
            this.error_check_list1.HideSelection = false;
            this.error_check_list1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem297,
            listViewItem298,
            listViewItem299,
            listViewItem300,
            listViewItem301,
            listViewItem302,
            listViewItem303,
            listViewItem304,
            listViewItem305,
            listViewItem306,
            listViewItem307,
            listViewItem308,
            listViewItem309,
            listViewItem310});
            this.error_check_list1.Location = new System.Drawing.Point(10, 55);
            this.error_check_list1.Margin = new System.Windows.Forms.Padding(10);
            this.error_check_list1.Name = "error_check_list1";
            this.error_check_list1.Size = new System.Drawing.Size(223, 197);
            this.error_check_list1.TabIndex = 271;
            this.error_check_list1.UseCompatibleStateImageBehavior = false;
            this.error_check_list1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "檢查項目";
            this.columnHeader3.Width = 137;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = " ";
            this.columnHeader4.Width = 61;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView1.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.HideSelection = false;
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem311,
            listViewItem312,
            listViewItem313,
            listViewItem314,
            listViewItem315,
            listViewItem316,
            listViewItem317,
            listViewItem318,
            listViewItem319,
            listViewItem320,
            listViewItem321,
            listViewItem322,
            listViewItem323,
            listViewItem324,
            listViewItem325,
            listViewItem326,
            listViewItem327,
            listViewItem328,
            listViewItem329,
            listViewItem330,
            listViewItem331,
            listViewItem332,
            listViewItem333,
            listViewItem334,
            listViewItem335,
            listViewItem336,
            listViewItem337,
            listViewItem338,
            listViewItem339,
            listViewItem340,
            listViewItem341,
            listViewItem342,
            listViewItem343,
            listViewItem344,
            listViewItem345,
            listViewItem346,
            listViewItem347,
            listViewItem348,
            listViewItem349,
            listViewItem350,
            listViewItem351,
            listViewItem352,
            listViewItem353,
            listViewItem354,
            listViewItem355,
            listViewItem356,
            listViewItem357,
            listViewItem358,
            listViewItem359,
            listViewItem360,
            listViewItem361,
            listViewItem362,
            listViewItem363,
            listViewItem364,
            listViewItem365,
            listViewItem366,
            listViewItem367,
            listViewItem368,
            listViewItem369,
            listViewItem370});
            this.listView1.Location = new System.Drawing.Point(10, 262);
            this.listView1.Margin = new System.Windows.Forms.Padding(10, 0, 10, 10);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(223, 535);
            this.listView1.TabIndex = 270;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Addr";
            this.columnHeader1.Width = 71;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Value";
            this.columnHeader2.Width = 130;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label_pass_time
            // 
            this.label_pass_time.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_pass_time.AutoSize = true;
            this.label_pass_time.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_pass_time.Location = new System.Drawing.Point(799, 37);
            this.label_pass_time.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_pass_time.Name = "label_pass_time";
            this.label_pass_time.Size = new System.Drawing.Size(130, 22);
            this.label_pass_time.TabIndex = 275;
            this.label_pass_time.Text = "00 : 00 : 00";
            this.label_pass_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1398, 686);
            this.Controls.Add(this.label_pass_time);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.btn_cap);
            this.Controls.Add(this.label_State1);
            this.Controls.Add(this.btn_Connect);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox Port1_box;
        private System.Windows.Forms.Button btn_Connect;
        private System.Windows.Forms.Label label_State1;
        private System.Windows.Forms.Button btn_cap;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label_pass_time;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ListView error_check_list1;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ListView error_check_list5;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ListView listView5;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.ComboBox Port5_box;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ListView error_check_list4;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ComboBox Port4_box;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ListView error_check_list3;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ComboBox Port3_box;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListView error_check_list2;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ComboBox Port2_box;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer2;
    }
}

