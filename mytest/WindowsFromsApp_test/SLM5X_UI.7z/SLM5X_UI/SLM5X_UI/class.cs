﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SLM5X_UI.Properties
{
    public class modbus
    {
        
    }
}
