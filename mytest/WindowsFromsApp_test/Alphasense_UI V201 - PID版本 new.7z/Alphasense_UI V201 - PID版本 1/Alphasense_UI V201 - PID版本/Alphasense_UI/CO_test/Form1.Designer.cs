﻿namespace CO_test
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox_USBLink = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.Sabio_Port_box = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Sabio_Baud_box = new System.Windows.Forms.ComboBox();
            this.btn_Sabio_Connect = new System.Windows.Forms.Button();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel9 = new System.Windows.Forms.FlowLayoutPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.Update_LED = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.flowLayoutPanel13 = new System.Windows.Forms.FlowLayoutPanel();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.flowLayoutPanel14 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.label_Status8 = new System.Windows.Forms.Label();
            this.label_Status6 = new System.Windows.Forms.Label();
            this.label_Status4 = new System.Windows.Forms.Label();
            this.label_Status7 = new System.Windows.Forms.Label();
            this.label_Status5 = new System.Windows.Forms.Label();
            this.label_Status3 = new System.Windows.Forms.Label();
            this.label_Status1 = new System.Windows.Forms.Label();
            this.label_Status2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.label86 = new System.Windows.Forms.Label();
            this.flowLayoutPanel12 = new System.Windows.Forms.FlowLayoutPanel();
            this.label21 = new System.Windows.Forms.Label();
            this.flowLayoutPanel7 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.label22 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.flowLayoutPanel16 = new System.Windows.Forms.FlowLayoutPanel();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.flowLayoutPanel17 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.label_Measure4 = new System.Windows.Forms.Label();
            this.label_Measure2 = new System.Windows.Forms.Label();
            this.label_Measure3 = new System.Windows.Forms.Label();
            this.label_Measure1 = new System.Windows.Forms.Label();
            this.label_Measure5 = new System.Windows.Forms.Label();
            this.label_Measure6 = new System.Windows.Forms.Label();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.label25 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.flowLayoutPanel11 = new System.Windows.Forms.FlowLayoutPanel();
            this.btn_CheckNow = new System.Windows.Forms.Button();
            this.btn_Purge = new System.Windows.Forms.Button();
            this.btn_PurgeLock = new System.Windows.Forms.Button();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel10 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.label24 = new System.Windows.Forms.Label();
            this.Addr_Box = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.Sequence_Box = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.Point_Box = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.Sabio_Time_Box = new System.Windows.Forms.TextBox();
            this.btn_MS = new System.Windows.Forms.Button();
            this.btn_Zero_MS = new System.Windows.Forms.Button();
            this.btn_Span_MS = new System.Windows.Forms.Button();
            this.flowLayoutPanel8 = new System.Windows.Forms.FlowLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.Sabio_UpdateRate_Box = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.FileName_Box = new System.Windows.Forms.TextBox();
            this.btn_Sabio_cap = new System.Windows.Forms.Button();
            this.label_Sabio_time = new System.Windows.Forms.Label();
            this.flowLayoutPanel19 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.label33 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_CmdStart = new System.Windows.Forms.Button();
            this.btn_CmdStop = new System.Windows.Forms.Button();
            this.btn_ClnList = new System.Windows.Forms.Button();
            this.label_Sabio_State = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.Sabio_Info_Box = new System.Windows.Forms.RichTextBox();
            this.brn_InfoCln = new System.Windows.Forms.Button();
            this.groupBox_I2C = new System.Windows.Forms.GroupBox();
            this.btn_test = new System.Windows.Forms.Button();
            this.test_box = new System.Windows.Forms.TextBox();
            this.AlphFix_Info_box = new System.Windows.Forms.RichTextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.btn_AlphFix_Connect = new System.Windows.Forms.Button();
            this.AlphFix_Port_box = new System.Windows.Forms.ComboBox();
            this.btn_AlphFix_stopORstart = new System.Windows.Forms.Button();
            this.label_AlphFix_State = new System.Windows.Forms.Label();
            this.groupBox_IDBOX = new System.Windows.Forms.GroupBox();
            this.btn_InitALL = new System.Windows.Forms.Button();
            this.btn_AlphFix_read = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_AutoSpan = new System.Windows.Forms.Button();
            this.btn_CalZero = new System.Windows.Forms.Button();
            this.SpanValue_box = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_AlphFix_write = new System.Windows.Forms.Button();
            this.ID_box = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.Value_box = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Item_box = new System.Windows.Forms.ComboBox();
            this.group_SHT0 = new System.Windows.Forms.GroupBox();
            this.label_AH0 = new System.Windows.Forms.Label();
            this.label_RH0 = new System.Windows.Forms.Label();
            this.label_Temp0 = new System.Windows.Forms.Label();
            this.group_SHT1 = new System.Windows.Forms.GroupBox();
            this.label_AH1 = new System.Windows.Forms.Label();
            this.label_RH1 = new System.Windows.Forms.Label();
            this.label_Temp1 = new System.Windows.Forms.Label();
            this.group_Response = new System.Windows.Forms.GroupBox();
            this.label_Response = new System.Windows.Forms.Label();
            this.group_SHT2 = new System.Windows.Forms.GroupBox();
            this.label_AH2 = new System.Windows.Forms.Label();
            this.label_RH2 = new System.Windows.Forms.Label();
            this.label_Temp2 = new System.Windows.Forms.Label();
            this.group_SHT3 = new System.Windows.Forms.GroupBox();
            this.label_AH3 = new System.Windows.Forms.Label();
            this.label_RH3 = new System.Windows.Forms.Label();
            this.label_Temp3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.AlphFix_UpdateRate_Box = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.AlphFix_FileName_box = new System.Windows.Forms.TextBox();
            this.label_AlphFix_time = new System.Windows.Forms.Label();
            this.btn_AlphFix_cap = new System.Windows.Forms.Button();
            this.btn_AlphFix_Log = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.tabSelect = new System.Windows.Forms.TabControl();
            this.tabPage_PCBA_WEAE = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.group_PCBA23 = new System.Windows.Forms.GroupBox();
            this.label_WE23 = new System.Windows.Forms.Label();
            this.label_AE23 = new System.Windows.Forms.Label();
            this.group_PCBA22 = new System.Windows.Forms.GroupBox();
            this.label_WE22 = new System.Windows.Forms.Label();
            this.label_AE22 = new System.Windows.Forms.Label();
            this.group_PCBA21 = new System.Windows.Forms.GroupBox();
            this.label_WE21 = new System.Windows.Forms.Label();
            this.label_AE21 = new System.Windows.Forms.Label();
            this.group_PCBA20 = new System.Windows.Forms.GroupBox();
            this.label_WE20 = new System.Windows.Forms.Label();
            this.label_AE20 = new System.Windows.Forms.Label();
            this.group_PCBA19 = new System.Windows.Forms.GroupBox();
            this.label_WE19 = new System.Windows.Forms.Label();
            this.label_AE19 = new System.Windows.Forms.Label();
            this.group_PCBA18 = new System.Windows.Forms.GroupBox();
            this.label_WE18 = new System.Windows.Forms.Label();
            this.label_AE18 = new System.Windows.Forms.Label();
            this.group_PCBA17 = new System.Windows.Forms.GroupBox();
            this.label_WE17 = new System.Windows.Forms.Label();
            this.label_AE17 = new System.Windows.Forms.Label();
            this.group_PCBA16 = new System.Windows.Forms.GroupBox();
            this.label_WE16 = new System.Windows.Forms.Label();
            this.label_AE16 = new System.Windows.Forms.Label();
            this.group_PCBA15 = new System.Windows.Forms.GroupBox();
            this.label_WE15 = new System.Windows.Forms.Label();
            this.label_AE15 = new System.Windows.Forms.Label();
            this.group_PCBA14 = new System.Windows.Forms.GroupBox();
            this.label_WE14 = new System.Windows.Forms.Label();
            this.label_AE14 = new System.Windows.Forms.Label();
            this.group_PCBA13 = new System.Windows.Forms.GroupBox();
            this.label_WE13 = new System.Windows.Forms.Label();
            this.label_AE13 = new System.Windows.Forms.Label();
            this.group_PCBA12 = new System.Windows.Forms.GroupBox();
            this.label_WE12 = new System.Windows.Forms.Label();
            this.label_AE12 = new System.Windows.Forms.Label();
            this.group_PCBA11 = new System.Windows.Forms.GroupBox();
            this.label_WE11 = new System.Windows.Forms.Label();
            this.label_AE11 = new System.Windows.Forms.Label();
            this.group_PCBA10 = new System.Windows.Forms.GroupBox();
            this.label_WE10 = new System.Windows.Forms.Label();
            this.label_AE10 = new System.Windows.Forms.Label();
            this.group_PCBA9 = new System.Windows.Forms.GroupBox();
            this.label_WE9 = new System.Windows.Forms.Label();
            this.label_AE9 = new System.Windows.Forms.Label();
            this.group_PCBA8 = new System.Windows.Forms.GroupBox();
            this.label_WE8 = new System.Windows.Forms.Label();
            this.label_AE8 = new System.Windows.Forms.Label();
            this.group_PCBA7 = new System.Windows.Forms.GroupBox();
            this.label_WE7 = new System.Windows.Forms.Label();
            this.label_AE7 = new System.Windows.Forms.Label();
            this.group_PCBA6 = new System.Windows.Forms.GroupBox();
            this.label_WE6 = new System.Windows.Forms.Label();
            this.label_AE6 = new System.Windows.Forms.Label();
            this.group_PCBA5 = new System.Windows.Forms.GroupBox();
            this.label_WE5 = new System.Windows.Forms.Label();
            this.label_AE5 = new System.Windows.Forms.Label();
            this.group_PCBA4 = new System.Windows.Forms.GroupBox();
            this.label_WE4 = new System.Windows.Forms.Label();
            this.label_AE4 = new System.Windows.Forms.Label();
            this.group_PCBA3 = new System.Windows.Forms.GroupBox();
            this.label_WE3 = new System.Windows.Forms.Label();
            this.label_AE3 = new System.Windows.Forms.Label();
            this.group_PCBA2 = new System.Windows.Forms.GroupBox();
            this.label_WE2 = new System.Windows.Forms.Label();
            this.label_AE2 = new System.Windows.Forms.Label();
            this.group_PCBA1 = new System.Windows.Forms.GroupBox();
            this.label_WE1 = new System.Windows.Forms.Label();
            this.label_AE1 = new System.Windows.Forms.Label();
            this.group_PCBA0 = new System.Windows.Forms.GroupBox();
            this.label_WE0 = new System.Windows.Forms.Label();
            this.label_AE0 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label_PCBA_WEAE_Humidity1 = new System.Windows.Forms.Label();
            this.label_PCBA_WEAE_Temp1 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label_PCBA_WEAE_Humidity2 = new System.Windows.Forms.Label();
            this.label_PCBA_WEAE_Temp2 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label_PCBA_WEAE_Humidity3 = new System.Windows.Forms.Label();
            this.label_PCBA_WEAE_Temp3 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label_PCBA_WEAE_Humidity4 = new System.Windows.Forms.Label();
            this.label_PCBA_WEAE_Temp4 = new System.Windows.Forms.Label();
            this.tabPage_ADC = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.group_ADC23 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value23 = new System.Windows.Forms.Label();
            this.label_ADC23 = new System.Windows.Forms.Label();
            this.group_ADC22 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value22 = new System.Windows.Forms.Label();
            this.label_ADC22 = new System.Windows.Forms.Label();
            this.group_ADC21 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value21 = new System.Windows.Forms.Label();
            this.label_ADC21 = new System.Windows.Forms.Label();
            this.group_ADC20 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value20 = new System.Windows.Forms.Label();
            this.label_ADC20 = new System.Windows.Forms.Label();
            this.group_ADC19 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value19 = new System.Windows.Forms.Label();
            this.label_ADC19 = new System.Windows.Forms.Label();
            this.group_ADC18 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value18 = new System.Windows.Forms.Label();
            this.label_ADC18 = new System.Windows.Forms.Label();
            this.group_ADC17 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value17 = new System.Windows.Forms.Label();
            this.label_ADC17 = new System.Windows.Forms.Label();
            this.group_ADC16 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value16 = new System.Windows.Forms.Label();
            this.label_ADC16 = new System.Windows.Forms.Label();
            this.group_ADC15 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value15 = new System.Windows.Forms.Label();
            this.label_ADC15 = new System.Windows.Forms.Label();
            this.group_ADC14 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value14 = new System.Windows.Forms.Label();
            this.label_ADC14 = new System.Windows.Forms.Label();
            this.group_ADC13 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value13 = new System.Windows.Forms.Label();
            this.label_ADC13 = new System.Windows.Forms.Label();
            this.group_ADC12 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value12 = new System.Windows.Forms.Label();
            this.label_ADC12 = new System.Windows.Forms.Label();
            this.group_ADC11 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value11 = new System.Windows.Forms.Label();
            this.label_ADC11 = new System.Windows.Forms.Label();
            this.group_ADC10 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value10 = new System.Windows.Forms.Label();
            this.label_ADC10 = new System.Windows.Forms.Label();
            this.group_ADC9 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value9 = new System.Windows.Forms.Label();
            this.label_ADC9 = new System.Windows.Forms.Label();
            this.group_ADC8 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value8 = new System.Windows.Forms.Label();
            this.label_ADC8 = new System.Windows.Forms.Label();
            this.group_ADC7 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value7 = new System.Windows.Forms.Label();
            this.label_ADC7 = new System.Windows.Forms.Label();
            this.group_ADC6 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value6 = new System.Windows.Forms.Label();
            this.label_ADC6 = new System.Windows.Forms.Label();
            this.group_ADC5 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value5 = new System.Windows.Forms.Label();
            this.label_ADC5 = new System.Windows.Forms.Label();
            this.group_ADC4 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value4 = new System.Windows.Forms.Label();
            this.label_ADC4 = new System.Windows.Forms.Label();
            this.group_ADC3 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value3 = new System.Windows.Forms.Label();
            this.label_ADC3 = new System.Windows.Forms.Label();
            this.group_ADC2 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value2 = new System.Windows.Forms.Label();
            this.label_ADC2 = new System.Windows.Forms.Label();
            this.group_ADC1 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value1 = new System.Windows.Forms.Label();
            this.label_ADC1 = new System.Windows.Forms.Label();
            this.group_ADC0 = new System.Windows.Forms.GroupBox();
            this.label_ADC_Value0 = new System.Windows.Forms.Label();
            this.label_ADC0 = new System.Windows.Forms.Label();
            this.tabPage_Zero = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.group_zero18 = new System.Windows.Forms.GroupBox();
            this.label_Zero18 = new System.Windows.Forms.Label();
            this.group_zero23 = new System.Windows.Forms.GroupBox();
            this.label_Zero23 = new System.Windows.Forms.Label();
            this.group_zero22 = new System.Windows.Forms.GroupBox();
            this.label_Zero22 = new System.Windows.Forms.Label();
            this.group_zero21 = new System.Windows.Forms.GroupBox();
            this.label_Zero21 = new System.Windows.Forms.Label();
            this.group_zero20 = new System.Windows.Forms.GroupBox();
            this.label_Zero20 = new System.Windows.Forms.Label();
            this.group_zero19 = new System.Windows.Forms.GroupBox();
            this.label_Zero19 = new System.Windows.Forms.Label();
            this.group_zero17 = new System.Windows.Forms.GroupBox();
            this.label_Zero17 = new System.Windows.Forms.Label();
            this.group_zero16 = new System.Windows.Forms.GroupBox();
            this.label_Zero16 = new System.Windows.Forms.Label();
            this.group_zero15 = new System.Windows.Forms.GroupBox();
            this.label_Zero15 = new System.Windows.Forms.Label();
            this.group_zero14 = new System.Windows.Forms.GroupBox();
            this.label_Zero14 = new System.Windows.Forms.Label();
            this.group_zero13 = new System.Windows.Forms.GroupBox();
            this.label_Zero13 = new System.Windows.Forms.Label();
            this.group_zero12 = new System.Windows.Forms.GroupBox();
            this.label_Zero12 = new System.Windows.Forms.Label();
            this.group_zero11 = new System.Windows.Forms.GroupBox();
            this.label_Zero11 = new System.Windows.Forms.Label();
            this.group_zero10 = new System.Windows.Forms.GroupBox();
            this.label_Zero10 = new System.Windows.Forms.Label();
            this.group_zero9 = new System.Windows.Forms.GroupBox();
            this.label_Zero9 = new System.Windows.Forms.Label();
            this.group_zero8 = new System.Windows.Forms.GroupBox();
            this.label_Zero8 = new System.Windows.Forms.Label();
            this.group_zero7 = new System.Windows.Forms.GroupBox();
            this.label_Zero7 = new System.Windows.Forms.Label();
            this.group_zero6 = new System.Windows.Forms.GroupBox();
            this.label_Zero6 = new System.Windows.Forms.Label();
            this.group_zero5 = new System.Windows.Forms.GroupBox();
            this.label_Zero5 = new System.Windows.Forms.Label();
            this.group_zero4 = new System.Windows.Forms.GroupBox();
            this.label_Zero4 = new System.Windows.Forms.Label();
            this.group_zero3 = new System.Windows.Forms.GroupBox();
            this.label_Zero3 = new System.Windows.Forms.Label();
            this.group_zero2 = new System.Windows.Forms.GroupBox();
            this.label_Zero2 = new System.Windows.Forms.Label();
            this.group_zero1 = new System.Windows.Forms.GroupBox();
            this.label_Zero1 = new System.Windows.Forms.Label();
            this.group_zero0 = new System.Windows.Forms.GroupBox();
            this.label_Zero0 = new System.Windows.Forms.Label();
            this.tabPage_Span = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.group_Span23 = new System.Windows.Forms.GroupBox();
            this.label_Span23 = new System.Windows.Forms.Label();
            this.group_Span22 = new System.Windows.Forms.GroupBox();
            this.label_Span22 = new System.Windows.Forms.Label();
            this.group_Span0 = new System.Windows.Forms.GroupBox();
            this.label_Span0 = new System.Windows.Forms.Label();
            this.group_Span14 = new System.Windows.Forms.GroupBox();
            this.label_Span14 = new System.Windows.Forms.Label();
            this.group_Span15 = new System.Windows.Forms.GroupBox();
            this.label_Span15 = new System.Windows.Forms.Label();
            this.group_Span20 = new System.Windows.Forms.GroupBox();
            this.label_Span20 = new System.Windows.Forms.Label();
            this.group_Span19 = new System.Windows.Forms.GroupBox();
            this.label_Span19 = new System.Windows.Forms.Label();
            this.group_Span18 = new System.Windows.Forms.GroupBox();
            this.label_Span18 = new System.Windows.Forms.Label();
            this.group_Span17 = new System.Windows.Forms.GroupBox();
            this.label_Span17 = new System.Windows.Forms.Label();
            this.group_Span16 = new System.Windows.Forms.GroupBox();
            this.label_Span16 = new System.Windows.Forms.Label();
            this.group_Span1 = new System.Windows.Forms.GroupBox();
            this.label_Span1 = new System.Windows.Forms.Label();
            this.group_Span7 = new System.Windows.Forms.GroupBox();
            this.label_Span7 = new System.Windows.Forms.Label();
            this.group_Span2 = new System.Windows.Forms.GroupBox();
            this.label_Span2 = new System.Windows.Forms.Label();
            this.group_Span8 = new System.Windows.Forms.GroupBox();
            this.label_Span8 = new System.Windows.Forms.Label();
            this.group_Span3 = new System.Windows.Forms.GroupBox();
            this.label_Span3 = new System.Windows.Forms.Label();
            this.group_Span9 = new System.Windows.Forms.GroupBox();
            this.label_Span9 = new System.Windows.Forms.Label();
            this.group_Span10 = new System.Windows.Forms.GroupBox();
            this.label_Span10 = new System.Windows.Forms.Label();
            this.group_Span11 = new System.Windows.Forms.GroupBox();
            this.label_Span11 = new System.Windows.Forms.Label();
            this.group_Span12 = new System.Windows.Forms.GroupBox();
            this.label_Span12 = new System.Windows.Forms.Label();
            this.group_Span13 = new System.Windows.Forms.GroupBox();
            this.label_Span13 = new System.Windows.Forms.Label();
            this.group_Span4 = new System.Windows.Forms.GroupBox();
            this.label_Span4 = new System.Windows.Forms.Label();
            this.group_Span5 = new System.Windows.Forms.GroupBox();
            this.label_Span5 = new System.Windows.Forms.Label();
            this.group_Span6 = new System.Windows.Forms.GroupBox();
            this.label_Span6 = new System.Windows.Forms.Label();
            this.group_Span21 = new System.Windows.Forms.GroupBox();
            this.label_Span21 = new System.Windows.Forms.Label();
            this.a = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.group_A23 = new System.Windows.Forms.GroupBox();
            this.label_A23 = new System.Windows.Forms.Label();
            this.group_A22 = new System.Windows.Forms.GroupBox();
            this.label_A22 = new System.Windows.Forms.Label();
            this.group_A0 = new System.Windows.Forms.GroupBox();
            this.label_A0 = new System.Windows.Forms.Label();
            this.group_A14 = new System.Windows.Forms.GroupBox();
            this.label_A14 = new System.Windows.Forms.Label();
            this.group_A15 = new System.Windows.Forms.GroupBox();
            this.label_A15 = new System.Windows.Forms.Label();
            this.group_A20 = new System.Windows.Forms.GroupBox();
            this.label_A20 = new System.Windows.Forms.Label();
            this.group_A19 = new System.Windows.Forms.GroupBox();
            this.label_A19 = new System.Windows.Forms.Label();
            this.group_A18 = new System.Windows.Forms.GroupBox();
            this.label_A18 = new System.Windows.Forms.Label();
            this.group_A17 = new System.Windows.Forms.GroupBox();
            this.label_A17 = new System.Windows.Forms.Label();
            this.group_A16 = new System.Windows.Forms.GroupBox();
            this.label_A16 = new System.Windows.Forms.Label();
            this.group_A1 = new System.Windows.Forms.GroupBox();
            this.label_A1 = new System.Windows.Forms.Label();
            this.group_A7 = new System.Windows.Forms.GroupBox();
            this.label_A7 = new System.Windows.Forms.Label();
            this.group_A2 = new System.Windows.Forms.GroupBox();
            this.label_A2 = new System.Windows.Forms.Label();
            this.group_A8 = new System.Windows.Forms.GroupBox();
            this.label_A8 = new System.Windows.Forms.Label();
            this.group_A3 = new System.Windows.Forms.GroupBox();
            this.label_A3 = new System.Windows.Forms.Label();
            this.group_A9 = new System.Windows.Forms.GroupBox();
            this.label_A9 = new System.Windows.Forms.Label();
            this.group_A10 = new System.Windows.Forms.GroupBox();
            this.label_A10 = new System.Windows.Forms.Label();
            this.group_A11 = new System.Windows.Forms.GroupBox();
            this.label_A11 = new System.Windows.Forms.Label();
            this.group_A12 = new System.Windows.Forms.GroupBox();
            this.label_A12 = new System.Windows.Forms.Label();
            this.group_A13 = new System.Windows.Forms.GroupBox();
            this.label_A13 = new System.Windows.Forms.Label();
            this.group_A4 = new System.Windows.Forms.GroupBox();
            this.label_A4 = new System.Windows.Forms.Label();
            this.group_A5 = new System.Windows.Forms.GroupBox();
            this.label_A5 = new System.Windows.Forms.Label();
            this.group_A6 = new System.Windows.Forms.GroupBox();
            this.label_A6 = new System.Windows.Forms.Label();
            this.group_A21 = new System.Windows.Forms.GroupBox();
            this.label_A21 = new System.Windows.Forms.Label();
            this.b = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.group_B23 = new System.Windows.Forms.GroupBox();
            this.label_B23 = new System.Windows.Forms.Label();
            this.group_B22 = new System.Windows.Forms.GroupBox();
            this.label_B22 = new System.Windows.Forms.Label();
            this.group_B0 = new System.Windows.Forms.GroupBox();
            this.label_B0 = new System.Windows.Forms.Label();
            this.group_B14 = new System.Windows.Forms.GroupBox();
            this.label_B14 = new System.Windows.Forms.Label();
            this.group_B15 = new System.Windows.Forms.GroupBox();
            this.label_B15 = new System.Windows.Forms.Label();
            this.group_B20 = new System.Windows.Forms.GroupBox();
            this.label_B20 = new System.Windows.Forms.Label();
            this.group_B19 = new System.Windows.Forms.GroupBox();
            this.label_B19 = new System.Windows.Forms.Label();
            this.group_B18 = new System.Windows.Forms.GroupBox();
            this.label_B18 = new System.Windows.Forms.Label();
            this.group_B17 = new System.Windows.Forms.GroupBox();
            this.label_B17 = new System.Windows.Forms.Label();
            this.group_B16 = new System.Windows.Forms.GroupBox();
            this.label_B16 = new System.Windows.Forms.Label();
            this.group_B1 = new System.Windows.Forms.GroupBox();
            this.label_B1 = new System.Windows.Forms.Label();
            this.group_B7 = new System.Windows.Forms.GroupBox();
            this.label_B7 = new System.Windows.Forms.Label();
            this.group_B2 = new System.Windows.Forms.GroupBox();
            this.label_B2 = new System.Windows.Forms.Label();
            this.group_B8 = new System.Windows.Forms.GroupBox();
            this.label_B8 = new System.Windows.Forms.Label();
            this.group_B3 = new System.Windows.Forms.GroupBox();
            this.label_B3 = new System.Windows.Forms.Label();
            this.group_B9 = new System.Windows.Forms.GroupBox();
            this.label_B9 = new System.Windows.Forms.Label();
            this.group_B10 = new System.Windows.Forms.GroupBox();
            this.label_B10 = new System.Windows.Forms.Label();
            this.group_B11 = new System.Windows.Forms.GroupBox();
            this.label_B11 = new System.Windows.Forms.Label();
            this.group_B12 = new System.Windows.Forms.GroupBox();
            this.label_B12 = new System.Windows.Forms.Label();
            this.group_B13 = new System.Windows.Forms.GroupBox();
            this.label_B13 = new System.Windows.Forms.Label();
            this.group_B4 = new System.Windows.Forms.GroupBox();
            this.label_B4 = new System.Windows.Forms.Label();
            this.group_B5 = new System.Windows.Forms.GroupBox();
            this.label_B5 = new System.Windows.Forms.Label();
            this.group_B6 = new System.Windows.Forms.GroupBox();
            this.label_B6 = new System.Windows.Forms.Label();
            this.group_B21 = new System.Windows.Forms.GroupBox();
            this.label_B21 = new System.Windows.Forms.Label();
            this.tabPage_GasName = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox_Sensor_Name0 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name0 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name23 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name23 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name22 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name22 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name21 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name21 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name1 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name1 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name14 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name14 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name15 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name15 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name20 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name20 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name19 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name19 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name18 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name18 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name17 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name17 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name16 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name16 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name2 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name2 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name7 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name7 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name3 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name3 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name8 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name8 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name4 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name4 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name9 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name9 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name10 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name10 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name11 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name11 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name12 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name12 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name13 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name13 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name5 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name5 = new System.Windows.Forms.Label();
            this.groupBox_Sensor_Name6 = new System.Windows.Forms.GroupBox();
            this.label_Sensor_Name6 = new System.Windows.Forms.Label();
            this.tabPage_BSN = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.group_BSN0 = new System.Windows.Forms.GroupBox();
            this.label_BSN0 = new System.Windows.Forms.Label();
            this.group_BSN23 = new System.Windows.Forms.GroupBox();
            this.label_BSN23 = new System.Windows.Forms.Label();
            this.group_BSN1 = new System.Windows.Forms.GroupBox();
            this.label_BSN1 = new System.Windows.Forms.Label();
            this.group_BSN22 = new System.Windows.Forms.GroupBox();
            this.label_BSN22 = new System.Windows.Forms.Label();
            this.group_BSN17 = new System.Windows.Forms.GroupBox();
            this.label_BSN17 = new System.Windows.Forms.Label();
            this.group_BSN21 = new System.Windows.Forms.GroupBox();
            this.label_BSN21 = new System.Windows.Forms.Label();
            this.group_BSN2 = new System.Windows.Forms.GroupBox();
            this.label_BSN2 = new System.Windows.Forms.Label();
            this.group_BSN20 = new System.Windows.Forms.GroupBox();
            this.label_BSN20 = new System.Windows.Forms.Label();
            this.group_BSN11 = new System.Windows.Forms.GroupBox();
            this.label_BSN11 = new System.Windows.Forms.Label();
            this.group_BSN19 = new System.Windows.Forms.GroupBox();
            this.label_BSN19 = new System.Windows.Forms.Label();
            this.group_BSN16 = new System.Windows.Forms.GroupBox();
            this.label_BSN16 = new System.Windows.Forms.Label();
            this.group_BSN18 = new System.Windows.Forms.GroupBox();
            this.label_BSN18 = new System.Windows.Forms.Label();
            this.group_BSN3 = new System.Windows.Forms.GroupBox();
            this.label_BSN3 = new System.Windows.Forms.Label();
            this.group_BSN5 = new System.Windows.Forms.GroupBox();
            this.label_BSN5 = new System.Windows.Forms.Label();
            this.group_BSN15 = new System.Windows.Forms.GroupBox();
            this.label_BSN15 = new System.Windows.Forms.Label();
            this.group_BSN4 = new System.Windows.Forms.GroupBox();
            this.label_BSN4 = new System.Windows.Forms.Label();
            this.group_BSN10 = new System.Windows.Forms.GroupBox();
            this.label_BSN10 = new System.Windows.Forms.Label();
            this.group_BSN14 = new System.Windows.Forms.GroupBox();
            this.label_BSN14 = new System.Windows.Forms.Label();
            this.group_BSN6 = new System.Windows.Forms.GroupBox();
            this.label_BSN6 = new System.Windows.Forms.Label();
            this.group_BSN7 = new System.Windows.Forms.GroupBox();
            this.label_BSN7 = new System.Windows.Forms.Label();
            this.group_BSN8 = new System.Windows.Forms.GroupBox();
            this.label_BSN8 = new System.Windows.Forms.Label();
            this.group_BSN13 = new System.Windows.Forms.GroupBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label_BSN13 = new System.Windows.Forms.Label();
            this.group_BSN9 = new System.Windows.Forms.GroupBox();
            this.label_BSN9 = new System.Windows.Forms.Label();
            this.group_BSN12 = new System.Windows.Forms.GroupBox();
            this.label_BSN12 = new System.Windows.Forms.Label();
            this.tabPage_FWV = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.group_FW0 = new System.Windows.Forms.GroupBox();
            this.label_FW_0 = new System.Windows.Forms.Label();
            this.group_FW23 = new System.Windows.Forms.GroupBox();
            this.label_FW_23 = new System.Windows.Forms.Label();
            this.group_FW22 = new System.Windows.Forms.GroupBox();
            this.label_FW_22 = new System.Windows.Forms.Label();
            this.group_FW21 = new System.Windows.Forms.GroupBox();
            this.label_FW_21 = new System.Windows.Forms.Label();
            this.group_FW1 = new System.Windows.Forms.GroupBox();
            this.label_FW_1 = new System.Windows.Forms.Label();
            this.group_FW14 = new System.Windows.Forms.GroupBox();
            this.label_FW_14 = new System.Windows.Forms.Label();
            this.group_FW15 = new System.Windows.Forms.GroupBox();
            this.label_FW_15 = new System.Windows.Forms.Label();
            this.group_FW20 = new System.Windows.Forms.GroupBox();
            this.label_FW_20 = new System.Windows.Forms.Label();
            this.group_FW19 = new System.Windows.Forms.GroupBox();
            this.label_FW_19 = new System.Windows.Forms.Label();
            this.group_FW18 = new System.Windows.Forms.GroupBox();
            this.label_FW_18 = new System.Windows.Forms.Label();
            this.group_FW17 = new System.Windows.Forms.GroupBox();
            this.label_FW_17 = new System.Windows.Forms.Label();
            this.group_FW16 = new System.Windows.Forms.GroupBox();
            this.label_FW_16 = new System.Windows.Forms.Label();
            this.group_FW2 = new System.Windows.Forms.GroupBox();
            this.label_FW_2 = new System.Windows.Forms.Label();
            this.group_FW7 = new System.Windows.Forms.GroupBox();
            this.label_FW_7 = new System.Windows.Forms.Label();
            this.group_FW3 = new System.Windows.Forms.GroupBox();
            this.label_FW_3 = new System.Windows.Forms.Label();
            this.group_FW8 = new System.Windows.Forms.GroupBox();
            this.label_FW_8 = new System.Windows.Forms.Label();
            this.group_FW4 = new System.Windows.Forms.GroupBox();
            this.label_FW_4 = new System.Windows.Forms.Label();
            this.group_FW9 = new System.Windows.Forms.GroupBox();
            this.label_FW_9 = new System.Windows.Forms.Label();
            this.group_FW10 = new System.Windows.Forms.GroupBox();
            this.label_FW_10 = new System.Windows.Forms.Label();
            this.group_FW11 = new System.Windows.Forms.GroupBox();
            this.label_FW_11 = new System.Windows.Forms.Label();
            this.group_FW12 = new System.Windows.Forms.GroupBox();
            this.label_FW_12 = new System.Windows.Forms.Label();
            this.group_FW13 = new System.Windows.Forms.GroupBox();
            this.label_FW_13 = new System.Windows.Forms.Label();
            this.group_FW5 = new System.Windows.Forms.GroupBox();
            this.label_FW_5 = new System.Windows.Forms.Label();
            this.group_FW6 = new System.Windows.Forms.GroupBox();
            this.label_FW_6 = new System.Windows.Forms.Label();
            this.Cal_Date = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.group_CalDate23 = new System.Windows.Forms.GroupBox();
            this.label_CalDate23 = new System.Windows.Forms.Label();
            this.group_CalDate22 = new System.Windows.Forms.GroupBox();
            this.label_CalDate22 = new System.Windows.Forms.Label();
            this.group_CalDate14 = new System.Windows.Forms.GroupBox();
            this.label_CalDate14 = new System.Windows.Forms.Label();
            this.group_CalDate15 = new System.Windows.Forms.GroupBox();
            this.label_CalDate15 = new System.Windows.Forms.Label();
            this.group_CalDate20 = new System.Windows.Forms.GroupBox();
            this.label_CalDate20 = new System.Windows.Forms.Label();
            this.group_CalDate19 = new System.Windows.Forms.GroupBox();
            this.label_CalDate19 = new System.Windows.Forms.Label();
            this.group_CalDate18 = new System.Windows.Forms.GroupBox();
            this.label_CalDate18 = new System.Windows.Forms.Label();
            this.group_CalDate17 = new System.Windows.Forms.GroupBox();
            this.label_CalDate17 = new System.Windows.Forms.Label();
            this.group_CalDate16 = new System.Windows.Forms.GroupBox();
            this.label_CalDate16 = new System.Windows.Forms.Label();
            this.group_CalDate1 = new System.Windows.Forms.GroupBox();
            this.label_CalDate1 = new System.Windows.Forms.Label();
            this.group_CalDate7 = new System.Windows.Forms.GroupBox();
            this.label_CalDate7 = new System.Windows.Forms.Label();
            this.group_CalDate2 = new System.Windows.Forms.GroupBox();
            this.label_CalDate2 = new System.Windows.Forms.Label();
            this.group_CalDate8 = new System.Windows.Forms.GroupBox();
            this.label_CalDate8 = new System.Windows.Forms.Label();
            this.group_CalDate3 = new System.Windows.Forms.GroupBox();
            this.label_CalDate3 = new System.Windows.Forms.Label();
            this.group_CalDate9 = new System.Windows.Forms.GroupBox();
            this.label_CalDate9 = new System.Windows.Forms.Label();
            this.group_CalDate10 = new System.Windows.Forms.GroupBox();
            this.label_CalDate10 = new System.Windows.Forms.Label();
            this.group_CalDate11 = new System.Windows.Forms.GroupBox();
            this.label_CalDate11 = new System.Windows.Forms.Label();
            this.group_CalDate12 = new System.Windows.Forms.GroupBox();
            this.label_CalDate12 = new System.Windows.Forms.Label();
            this.group_CalDate13 = new System.Windows.Forms.GroupBox();
            this.label_CalDate13 = new System.Windows.Forms.Label();
            this.group_CalDate4 = new System.Windows.Forms.GroupBox();
            this.label_CalDate4 = new System.Windows.Forms.Label();
            this.group_CalDate5 = new System.Windows.Forms.GroupBox();
            this.label_CalDate5 = new System.Windows.Forms.Label();
            this.group_CalDate6 = new System.Windows.Forms.GroupBox();
            this.label_CalDate6 = new System.Windows.Forms.Label();
            this.group_CalDate21 = new System.Windows.Forms.GroupBox();
            this.label_CalDate21 = new System.Windows.Forms.Label();
            this.group_CalDate0 = new System.Windows.Forms.GroupBox();
            this.label_CalDate0 = new System.Windows.Forms.Label();
            this.timer_command = new System.Windows.Forms.Timer(this.components);
            this.timer_getStatus = new System.Windows.Forms.Timer(this.components);
            this.timer_getValue = new System.Windows.Forms.Timer(this.components);
            this.label_Serial0 = new System.Windows.Forms.Label();
            this.label_Serial_Value0 = new System.Windows.Forms.Label();
            this.label_SN_Temp4 = new System.Windows.Forms.Label();
            this.label_SN_Humidity4 = new System.Windows.Forms.Label();
            this.label_Serial6 = new System.Windows.Forms.Label();
            this.label_Serial_Value6 = new System.Windows.Forms.Label();
            this.label_Serial13 = new System.Windows.Forms.Label();
            this.label_Serial_Value13 = new System.Windows.Forms.Label();
            this.label_Serial20 = new System.Windows.Forms.Label();
            this.label_Serial_Value20 = new System.Windows.Forms.Label();
            this.label_Serial27 = new System.Windows.Forms.Label();
            this.label_Serial_Value27 = new System.Windows.Forms.Label();
            this.label_Serial34 = new System.Windows.Forms.Label();
            this.label_Serial_Value34 = new System.Windows.Forms.Label();
            this.label_Serial5 = new System.Windows.Forms.Label();
            this.label_Serial_Value5 = new System.Windows.Forms.Label();
            this.label_Serial12 = new System.Windows.Forms.Label();
            this.label_Serial_Value12 = new System.Windows.Forms.Label();
            this.label_Serial19 = new System.Windows.Forms.Label();
            this.label_Serial_Value19 = new System.Windows.Forms.Label();
            this.label_Serial26 = new System.Windows.Forms.Label();
            this.label_Serial_Value26 = new System.Windows.Forms.Label();
            this.label_Serial33 = new System.Windows.Forms.Label();
            this.label_Serial_Value33 = new System.Windows.Forms.Label();
            this.label_Serial4 = new System.Windows.Forms.Label();
            this.label_Serial_Value4 = new System.Windows.Forms.Label();
            this.label_Serial11 = new System.Windows.Forms.Label();
            this.label_Serial_Value11 = new System.Windows.Forms.Label();
            this.label_Serial18 = new System.Windows.Forms.Label();
            this.label_Serial_Value18 = new System.Windows.Forms.Label();
            this.label_Serial25 = new System.Windows.Forms.Label();
            this.label_Serial_Value25 = new System.Windows.Forms.Label();
            this.label_Serial32 = new System.Windows.Forms.Label();
            this.label_Serial_Value32 = new System.Windows.Forms.Label();
            this.label_Serial3 = new System.Windows.Forms.Label();
            this.label_Serial_Value3 = new System.Windows.Forms.Label();
            this.label_Serial10 = new System.Windows.Forms.Label();
            this.label_Serial_Value10 = new System.Windows.Forms.Label();
            this.label_Serial17 = new System.Windows.Forms.Label();
            this.label_Serial_Value17 = new System.Windows.Forms.Label();
            this.label_Serial24 = new System.Windows.Forms.Label();
            this.label_Serial_Value24 = new System.Windows.Forms.Label();
            this.label_Serial31 = new System.Windows.Forms.Label();
            this.label_Serial_Value31 = new System.Windows.Forms.Label();
            this.label_Serial2 = new System.Windows.Forms.Label();
            this.label_Serial_Value2 = new System.Windows.Forms.Label();
            this.label_Serial9 = new System.Windows.Forms.Label();
            this.label_Serial_Value9 = new System.Windows.Forms.Label();
            this.label_Serial16 = new System.Windows.Forms.Label();
            this.label_Serial_Value16 = new System.Windows.Forms.Label();
            this.label_Serial23 = new System.Windows.Forms.Label();
            this.label_Serial_Value23 = new System.Windows.Forms.Label();
            this.label_Serial30 = new System.Windows.Forms.Label();
            this.label_Serial_Value30 = new System.Windows.Forms.Label();
            this.label_Serial1 = new System.Windows.Forms.Label();
            this.label_Serial_Value1 = new System.Windows.Forms.Label();
            this.label_Serial8 = new System.Windows.Forms.Label();
            this.label_Serial_Value8 = new System.Windows.Forms.Label();
            this.label_Serial15 = new System.Windows.Forms.Label();
            this.label_Serial_Value15 = new System.Windows.Forms.Label();
            this.label_Serial22 = new System.Windows.Forms.Label();
            this.label_Serial_Value22 = new System.Windows.Forms.Label();
            this.label_Serial29 = new System.Windows.Forms.Label();
            this.label_Serial_Value29 = new System.Windows.Forms.Label();
            this.label_Serial7 = new System.Windows.Forms.Label();
            this.label_Serial_Value7 = new System.Windows.Forms.Label();
            this.label_Serial14 = new System.Windows.Forms.Label();
            this.label_Serial_Value14 = new System.Windows.Forms.Label();
            this.label_Serial21 = new System.Windows.Forms.Label();
            this.label_Serial_Value21 = new System.Windows.Forms.Label();
            this.label_Serial28 = new System.Windows.Forms.Label();
            this.label_Serial_Value28 = new System.Windows.Forms.Label();
            this.label_SN_Temp3 = new System.Windows.Forms.Label();
            this.label_SN_Humidity3 = new System.Windows.Forms.Label();
            this.label_SN_Temp2 = new System.Windows.Forms.Label();
            this.label_SN_Humidity2 = new System.Windows.Forms.Label();
            this.label_SN_Temp1 = new System.Windows.Forms.Label();
            this.label_SN_Humidity1 = new System.Windows.Forms.Label();
            this.serialPort2 = new System.IO.Ports.SerialPort(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.flowLayoutPanel18 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel20 = new System.Windows.Forms.FlowLayoutPanel();
            this.timer_alcap = new System.Windows.Forms.Timer(this.components);
            this.groupBox_USBLink.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.flowLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.flowLayoutPanel13.SuspendLayout();
            this.flowLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.flowLayoutPanel12.SuspendLayout();
            this.flowLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.flowLayoutPanel16.SuspendLayout();
            this.flowLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.flowLayoutPanel11.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.flowLayoutPanel10.SuspendLayout();
            this.flowLayoutPanel6.SuspendLayout();
            this.flowLayoutPanel8.SuspendLayout();
            this.flowLayoutPanel19.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.groupBox_I2C.SuspendLayout();
            this.groupBox_IDBOX.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SpanValue_box)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ID_box)).BeginInit();
            this.group_SHT0.SuspendLayout();
            this.group_SHT1.SuspendLayout();
            this.group_Response.SuspendLayout();
            this.group_SHT2.SuspendLayout();
            this.group_SHT3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabSelect.SuspendLayout();
            this.tabPage_PCBA_WEAE.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.group_PCBA23.SuspendLayout();
            this.group_PCBA22.SuspendLayout();
            this.group_PCBA21.SuspendLayout();
            this.group_PCBA20.SuspendLayout();
            this.group_PCBA19.SuspendLayout();
            this.group_PCBA18.SuspendLayout();
            this.group_PCBA17.SuspendLayout();
            this.group_PCBA16.SuspendLayout();
            this.group_PCBA15.SuspendLayout();
            this.group_PCBA14.SuspendLayout();
            this.group_PCBA13.SuspendLayout();
            this.group_PCBA12.SuspendLayout();
            this.group_PCBA11.SuspendLayout();
            this.group_PCBA10.SuspendLayout();
            this.group_PCBA9.SuspendLayout();
            this.group_PCBA8.SuspendLayout();
            this.group_PCBA7.SuspendLayout();
            this.group_PCBA6.SuspendLayout();
            this.group_PCBA5.SuspendLayout();
            this.group_PCBA4.SuspendLayout();
            this.group_PCBA3.SuspendLayout();
            this.group_PCBA2.SuspendLayout();
            this.group_PCBA1.SuspendLayout();
            this.group_PCBA0.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage_ADC.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.group_ADC23.SuspendLayout();
            this.group_ADC22.SuspendLayout();
            this.group_ADC21.SuspendLayout();
            this.group_ADC20.SuspendLayout();
            this.group_ADC19.SuspendLayout();
            this.group_ADC18.SuspendLayout();
            this.group_ADC17.SuspendLayout();
            this.group_ADC16.SuspendLayout();
            this.group_ADC15.SuspendLayout();
            this.group_ADC14.SuspendLayout();
            this.group_ADC13.SuspendLayout();
            this.group_ADC12.SuspendLayout();
            this.group_ADC11.SuspendLayout();
            this.group_ADC10.SuspendLayout();
            this.group_ADC9.SuspendLayout();
            this.group_ADC8.SuspendLayout();
            this.group_ADC7.SuspendLayout();
            this.group_ADC6.SuspendLayout();
            this.group_ADC5.SuspendLayout();
            this.group_ADC4.SuspendLayout();
            this.group_ADC3.SuspendLayout();
            this.group_ADC2.SuspendLayout();
            this.group_ADC1.SuspendLayout();
            this.group_ADC0.SuspendLayout();
            this.tabPage_Zero.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.group_zero18.SuspendLayout();
            this.group_zero23.SuspendLayout();
            this.group_zero22.SuspendLayout();
            this.group_zero21.SuspendLayout();
            this.group_zero20.SuspendLayout();
            this.group_zero19.SuspendLayout();
            this.group_zero17.SuspendLayout();
            this.group_zero16.SuspendLayout();
            this.group_zero15.SuspendLayout();
            this.group_zero14.SuspendLayout();
            this.group_zero13.SuspendLayout();
            this.group_zero12.SuspendLayout();
            this.group_zero11.SuspendLayout();
            this.group_zero10.SuspendLayout();
            this.group_zero9.SuspendLayout();
            this.group_zero8.SuspendLayout();
            this.group_zero7.SuspendLayout();
            this.group_zero6.SuspendLayout();
            this.group_zero5.SuspendLayout();
            this.group_zero4.SuspendLayout();
            this.group_zero3.SuspendLayout();
            this.group_zero2.SuspendLayout();
            this.group_zero1.SuspendLayout();
            this.group_zero0.SuspendLayout();
            this.tabPage_Span.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.group_Span23.SuspendLayout();
            this.group_Span22.SuspendLayout();
            this.group_Span0.SuspendLayout();
            this.group_Span14.SuspendLayout();
            this.group_Span15.SuspendLayout();
            this.group_Span20.SuspendLayout();
            this.group_Span19.SuspendLayout();
            this.group_Span18.SuspendLayout();
            this.group_Span17.SuspendLayout();
            this.group_Span16.SuspendLayout();
            this.group_Span1.SuspendLayout();
            this.group_Span7.SuspendLayout();
            this.group_Span2.SuspendLayout();
            this.group_Span8.SuspendLayout();
            this.group_Span3.SuspendLayout();
            this.group_Span9.SuspendLayout();
            this.group_Span10.SuspendLayout();
            this.group_Span11.SuspendLayout();
            this.group_Span12.SuspendLayout();
            this.group_Span13.SuspendLayout();
            this.group_Span4.SuspendLayout();
            this.group_Span5.SuspendLayout();
            this.group_Span6.SuspendLayout();
            this.group_Span21.SuspendLayout();
            this.a.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.group_A23.SuspendLayout();
            this.group_A22.SuspendLayout();
            this.group_A0.SuspendLayout();
            this.group_A14.SuspendLayout();
            this.group_A15.SuspendLayout();
            this.group_A20.SuspendLayout();
            this.group_A19.SuspendLayout();
            this.group_A18.SuspendLayout();
            this.group_A17.SuspendLayout();
            this.group_A16.SuspendLayout();
            this.group_A1.SuspendLayout();
            this.group_A7.SuspendLayout();
            this.group_A2.SuspendLayout();
            this.group_A8.SuspendLayout();
            this.group_A3.SuspendLayout();
            this.group_A9.SuspendLayout();
            this.group_A10.SuspendLayout();
            this.group_A11.SuspendLayout();
            this.group_A12.SuspendLayout();
            this.group_A13.SuspendLayout();
            this.group_A4.SuspendLayout();
            this.group_A5.SuspendLayout();
            this.group_A6.SuspendLayout();
            this.group_A21.SuspendLayout();
            this.b.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.group_B23.SuspendLayout();
            this.group_B22.SuspendLayout();
            this.group_B0.SuspendLayout();
            this.group_B14.SuspendLayout();
            this.group_B15.SuspendLayout();
            this.group_B20.SuspendLayout();
            this.group_B19.SuspendLayout();
            this.group_B18.SuspendLayout();
            this.group_B17.SuspendLayout();
            this.group_B16.SuspendLayout();
            this.group_B1.SuspendLayout();
            this.group_B7.SuspendLayout();
            this.group_B2.SuspendLayout();
            this.group_B8.SuspendLayout();
            this.group_B3.SuspendLayout();
            this.group_B9.SuspendLayout();
            this.group_B10.SuspendLayout();
            this.group_B11.SuspendLayout();
            this.group_B12.SuspendLayout();
            this.group_B13.SuspendLayout();
            this.group_B4.SuspendLayout();
            this.group_B5.SuspendLayout();
            this.group_B6.SuspendLayout();
            this.group_B21.SuspendLayout();
            this.tabPage_GasName.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.groupBox_Sensor_Name0.SuspendLayout();
            this.groupBox_Sensor_Name23.SuspendLayout();
            this.groupBox_Sensor_Name22.SuspendLayout();
            this.groupBox_Sensor_Name21.SuspendLayout();
            this.groupBox_Sensor_Name1.SuspendLayout();
            this.groupBox_Sensor_Name14.SuspendLayout();
            this.groupBox_Sensor_Name15.SuspendLayout();
            this.groupBox_Sensor_Name20.SuspendLayout();
            this.groupBox_Sensor_Name19.SuspendLayout();
            this.groupBox_Sensor_Name18.SuspendLayout();
            this.groupBox_Sensor_Name17.SuspendLayout();
            this.groupBox_Sensor_Name16.SuspendLayout();
            this.groupBox_Sensor_Name2.SuspendLayout();
            this.groupBox_Sensor_Name7.SuspendLayout();
            this.groupBox_Sensor_Name3.SuspendLayout();
            this.groupBox_Sensor_Name8.SuspendLayout();
            this.groupBox_Sensor_Name4.SuspendLayout();
            this.groupBox_Sensor_Name9.SuspendLayout();
            this.groupBox_Sensor_Name10.SuspendLayout();
            this.groupBox_Sensor_Name11.SuspendLayout();
            this.groupBox_Sensor_Name12.SuspendLayout();
            this.groupBox_Sensor_Name13.SuspendLayout();
            this.groupBox_Sensor_Name5.SuspendLayout();
            this.groupBox_Sensor_Name6.SuspendLayout();
            this.tabPage_BSN.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.group_BSN0.SuspendLayout();
            this.group_BSN23.SuspendLayout();
            this.group_BSN1.SuspendLayout();
            this.group_BSN22.SuspendLayout();
            this.group_BSN17.SuspendLayout();
            this.group_BSN21.SuspendLayout();
            this.group_BSN2.SuspendLayout();
            this.group_BSN20.SuspendLayout();
            this.group_BSN11.SuspendLayout();
            this.group_BSN19.SuspendLayout();
            this.group_BSN16.SuspendLayout();
            this.group_BSN18.SuspendLayout();
            this.group_BSN3.SuspendLayout();
            this.group_BSN5.SuspendLayout();
            this.group_BSN15.SuspendLayout();
            this.group_BSN4.SuspendLayout();
            this.group_BSN10.SuspendLayout();
            this.group_BSN14.SuspendLayout();
            this.group_BSN6.SuspendLayout();
            this.group_BSN7.SuspendLayout();
            this.group_BSN8.SuspendLayout();
            this.group_BSN13.SuspendLayout();
            this.group_BSN9.SuspendLayout();
            this.group_BSN12.SuspendLayout();
            this.tabPage_FWV.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.group_FW0.SuspendLayout();
            this.group_FW23.SuspendLayout();
            this.group_FW22.SuspendLayout();
            this.group_FW21.SuspendLayout();
            this.group_FW1.SuspendLayout();
            this.group_FW14.SuspendLayout();
            this.group_FW15.SuspendLayout();
            this.group_FW20.SuspendLayout();
            this.group_FW19.SuspendLayout();
            this.group_FW18.SuspendLayout();
            this.group_FW17.SuspendLayout();
            this.group_FW16.SuspendLayout();
            this.group_FW2.SuspendLayout();
            this.group_FW7.SuspendLayout();
            this.group_FW3.SuspendLayout();
            this.group_FW8.SuspendLayout();
            this.group_FW4.SuspendLayout();
            this.group_FW9.SuspendLayout();
            this.group_FW10.SuspendLayout();
            this.group_FW11.SuspendLayout();
            this.group_FW12.SuspendLayout();
            this.group_FW13.SuspendLayout();
            this.group_FW5.SuspendLayout();
            this.group_FW6.SuspendLayout();
            this.Cal_Date.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.group_CalDate23.SuspendLayout();
            this.group_CalDate22.SuspendLayout();
            this.group_CalDate14.SuspendLayout();
            this.group_CalDate15.SuspendLayout();
            this.group_CalDate20.SuspendLayout();
            this.group_CalDate19.SuspendLayout();
            this.group_CalDate18.SuspendLayout();
            this.group_CalDate17.SuspendLayout();
            this.group_CalDate16.SuspendLayout();
            this.group_CalDate1.SuspendLayout();
            this.group_CalDate7.SuspendLayout();
            this.group_CalDate2.SuspendLayout();
            this.group_CalDate8.SuspendLayout();
            this.group_CalDate3.SuspendLayout();
            this.group_CalDate9.SuspendLayout();
            this.group_CalDate10.SuspendLayout();
            this.group_CalDate11.SuspendLayout();
            this.group_CalDate12.SuspendLayout();
            this.group_CalDate13.SuspendLayout();
            this.group_CalDate4.SuspendLayout();
            this.group_CalDate5.SuspendLayout();
            this.group_CalDate6.SuspendLayout();
            this.group_CalDate21.SuspendLayout();
            this.group_CalDate0.SuspendLayout();
            this.flowLayoutPanel18.SuspendLayout();
            this.flowLayoutPanel20.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_USBLink
            // 
            this.groupBox_USBLink.Controls.Add(this.tableLayoutPanel8);
            this.groupBox_USBLink.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold);
            this.groupBox_USBLink.Location = new System.Drawing.Point(3, 739);
            this.groupBox_USBLink.Margin = new System.Windows.Forms.Padding(3, 20, 3, 20);
            this.groupBox_USBLink.Name = "groupBox_USBLink";
            this.groupBox_USBLink.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox_USBLink.Size = new System.Drawing.Size(1419, 514);
            this.groupBox_USBLink.TabIndex = 1;
            this.groupBox_USBLink.TabStop = false;
            this.groupBox_USBLink.Text = "Sabio4010";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 670F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 743F));
            this.tableLayoutPanel8.Controls.Add(this.flowLayoutPanel1, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.flowLayoutPanel3, 1, 1);
            this.tableLayoutPanel8.Controls.Add(this.flowLayoutPanel5, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.label_Sabio_State, 1, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(3, 31);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(1413, 481);
            this.tableLayoutPanel8.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.label11);
            this.flowLayoutPanel1.Controls.Add(this.Sabio_Port_box);
            this.flowLayoutPanel1.Controls.Add(this.label12);
            this.flowLayoutPanel1.Controls.Add(this.Sabio_Baud_box);
            this.flowLayoutPanel1.Controls.Add(this.btn_Sabio_Connect);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(10, 10);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(650, 31);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label11.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(0, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Padding = new System.Windows.Forms.Padding(26, 4, 25, 5);
            this.label11.Size = new System.Drawing.Size(101, 31);
            this.label11.TabIndex = 11;
            this.label11.Text = "Port";
            // 
            // Sabio_Port_box
            // 
            this.Sabio_Port_box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Sabio_Port_box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sabio_Port_box.Font = new System.Drawing.Font("Consolas", 15F);
            this.Sabio_Port_box.FormattingEnabled = true;
            this.Sabio_Port_box.Location = new System.Drawing.Point(101, 0);
            this.Sabio_Port_box.Margin = new System.Windows.Forms.Padding(0, 0, 20, 0);
            this.Sabio_Port_box.Name = "Sabio_Port_box";
            this.Sabio_Port_box.Size = new System.Drawing.Size(102, 31);
            this.Sabio_Port_box.TabIndex = 0;
            this.Sabio_Port_box.DropDown += new System.EventHandler(this.Sabio_Port_box_DropDown);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label12.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(223, 0);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Padding = new System.Windows.Forms.Padding(26, 4, 25, 5);
            this.label12.Size = new System.Drawing.Size(101, 31);
            this.label12.TabIndex = 13;
            this.label12.Text = "Baud";
            // 
            // Sabio_Baud_box
            // 
            this.Sabio_Baud_box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Sabio_Baud_box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sabio_Baud_box.Font = new System.Drawing.Font("Consolas", 15F);
            this.Sabio_Baud_box.FormattingEnabled = true;
            this.Sabio_Baud_box.Items.AddRange(new object[] {
            "4800",
            "9600",
            "14400"});
            this.Sabio_Baud_box.Location = new System.Drawing.Point(324, 0);
            this.Sabio_Baud_box.Margin = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.Sabio_Baud_box.Name = "Sabio_Baud_box";
            this.Sabio_Baud_box.Size = new System.Drawing.Size(102, 31);
            this.Sabio_Baud_box.TabIndex = 1;
            // 
            // btn_Sabio_Connect
            // 
            this.btn_Sabio_Connect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_Sabio_Connect.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_Sabio_Connect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Sabio_Connect.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sabio_Connect.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Sabio_Connect.Location = new System.Drawing.Point(451, 0);
            this.btn_Sabio_Connect.Margin = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btn_Sabio_Connect.Name = "btn_Sabio_Connect";
            this.btn_Sabio_Connect.Size = new System.Drawing.Size(132, 31);
            this.btn_Sabio_Connect.TabIndex = 2;
            this.btn_Sabio_Connect.Text = "Connect";
            this.btn_Sabio_Connect.UseVisualStyleBackColor = false;
            this.btn_Sabio_Connect.Click += new System.EventHandler(this.btn_Sabio_Connect_Click);
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Controls.Add(this.flowLayoutPanel9);
            this.flowLayoutPanel3.Controls.Add(this.flowLayoutPanel12);
            this.flowLayoutPanel3.Controls.Add(this.flowLayoutPanel11);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(680, 71);
            this.flowLayoutPanel3.Margin = new System.Windows.Forms.Padding(10, 20, 10, 10);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(723, 400);
            this.flowLayoutPanel3.TabIndex = 11;
            // 
            // flowLayoutPanel9
            // 
            this.flowLayoutPanel9.Controls.Add(this.label14);
            this.flowLayoutPanel9.Controls.Add(this.Update_LED);
            this.flowLayoutPanel9.Controls.Add(this.tableLayoutPanel9);
            this.flowLayoutPanel9.Controls.Add(this.flowLayoutPanel13);
            this.flowLayoutPanel9.Controls.Add(this.flowLayoutPanel14);
            this.flowLayoutPanel9.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel9.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel9.Name = "flowLayoutPanel9";
            this.flowLayoutPanel9.Size = new System.Drawing.Size(722, 129);
            this.flowLayoutPanel9.TabIndex = 29;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(0, 0);
            this.label14.Margin = new System.Windows.Forms.Padding(0, 0, 540, 0);
            this.label14.Name = "label14";
            this.label14.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label14.Size = new System.Drawing.Size(100, 31);
            this.label14.TabIndex = 27;
            this.label14.Text = "Status :";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Update_LED
            // 
            this.Update_LED.AutoSize = true;
            this.Update_LED.BackColor = System.Drawing.Color.Transparent;
            this.Update_LED.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Update_LED.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Update_LED.Location = new System.Drawing.Point(640, 0);
            this.Update_LED.Margin = new System.Windows.Forms.Padding(0);
            this.Update_LED.Name = "Update_LED";
            this.Update_LED.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.Update_LED.Size = new System.Drawing.Size(33, 30);
            this.Update_LED.TabIndex = 22;
            this.Update_LED.Text = "●";
            this.Update_LED.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.tableLayoutPanel9.ColumnCount = 6;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tableLayoutPanel9.Controls.Add(this.label15, 1, 0);
            this.tableLayoutPanel9.Controls.Add(this.label16, 2, 0);
            this.tableLayoutPanel9.Controls.Add(this.label17, 3, 0);
            this.tableLayoutPanel9.Controls.Add(this.label83, 4, 0);
            this.tableLayoutPanel9.Location = new System.Drawing.Point(0, 31);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(722, 31);
            this.tableLayoutPanel9.TabIndex = 28;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label15.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(160, 0);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label15.Size = new System.Drawing.Size(80, 31);
            this.label15.TabIndex = 26;
            this.label15.Text = "Source";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label16.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(284, 0);
            this.label16.Margin = new System.Windows.Forms.Padding(0);
            this.label16.Name = "label16";
            this.label16.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label16.Size = new System.Drawing.Size(50, 31);
            this.label16.TabIndex = 25;
            this.label16.Text = "1st";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label17.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(408, 0);
            this.label17.Margin = new System.Windows.Forms.Padding(0);
            this.label17.Name = "label17";
            this.label17.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label17.Size = new System.Drawing.Size(50, 31);
            this.label17.TabIndex = 27;
            this.label17.Text = "2nd";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label83.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(532, 0);
            this.label83.Margin = new System.Windows.Forms.Padding(0);
            this.label83.Name = "label83";
            this.label83.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label83.Size = new System.Drawing.Size(50, 31);
            this.label83.TabIndex = 28;
            this.label83.Text = "3rd";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flowLayoutPanel13
            // 
            this.flowLayoutPanel13.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.flowLayoutPanel13.Controls.Add(this.label84);
            this.flowLayoutPanel13.Controls.Add(this.label85);
            this.flowLayoutPanel13.Location = new System.Drawing.Point(0, 62);
            this.flowLayoutPanel13.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel13.Name = "flowLayoutPanel13";
            this.flowLayoutPanel13.Size = new System.Drawing.Size(160, 67);
            this.flowLayoutPanel13.TabIndex = 26;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label84.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label84.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(0, 0);
            this.label84.Margin = new System.Windows.Forms.Padding(0);
            this.label84.Name = "label84";
            this.label84.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label84.Size = new System.Drawing.Size(70, 31);
            this.label84.TabIndex = 23;
            this.label84.Text = "Gases";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label85.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label85.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(0, 31);
            this.label85.Margin = new System.Windows.Forms.Padding(0);
            this.label85.Name = "label85";
            this.label85.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label85.Size = new System.Drawing.Size(150, 31);
            this.label85.TabIndex = 25;
            this.label85.Text = "Diluted Gases";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flowLayoutPanel14
            // 
            this.flowLayoutPanel14.Controls.Add(this.tableLayoutPanel10);
            this.flowLayoutPanel14.Controls.Add(this.tableLayoutPanel16);
            this.flowLayoutPanel14.Location = new System.Drawing.Point(160, 62);
            this.flowLayoutPanel14.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel14.Name = "flowLayoutPanel14";
            this.flowLayoutPanel14.Size = new System.Drawing.Size(562, 67);
            this.flowLayoutPanel14.TabIndex = 26;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.BackColor = System.Drawing.Color.LightGray;
            this.tableLayoutPanel10.ColumnCount = 4;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel10.Controls.Add(this.label_Status8, 3, 1);
            this.tableLayoutPanel10.Controls.Add(this.label_Status6, 2, 1);
            this.tableLayoutPanel10.Controls.Add(this.label_Status4, 1, 1);
            this.tableLayoutPanel10.Controls.Add(this.label_Status7, 3, 0);
            this.tableLayoutPanel10.Controls.Add(this.label_Status5, 2, 0);
            this.tableLayoutPanel10.Controls.Add(this.label_Status3, 1, 0);
            this.tableLayoutPanel10.Controls.Add(this.label_Status1, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.label_Status2, 0, 1);
            this.tableLayoutPanel10.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel10.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(497, 67);
            this.tableLayoutPanel10.TabIndex = 0;
            // 
            // label_Status8
            // 
            this.label_Status8.AutoSize = true;
            this.label_Status8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Status8.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Status8.Location = new System.Drawing.Point(372, 33);
            this.label_Status8.Margin = new System.Windows.Forms.Padding(0);
            this.label_Status8.Name = "label_Status8";
            this.label_Status8.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Status8.Size = new System.Drawing.Size(40, 31);
            this.label_Status8.TabIndex = 31;
            this.label_Status8.Text = "--";
            this.label_Status8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Status6
            // 
            this.label_Status6.AutoSize = true;
            this.label_Status6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Status6.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Status6.Location = new System.Drawing.Point(248, 33);
            this.label_Status6.Margin = new System.Windows.Forms.Padding(0);
            this.label_Status6.Name = "label_Status6";
            this.label_Status6.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Status6.Size = new System.Drawing.Size(40, 31);
            this.label_Status6.TabIndex = 30;
            this.label_Status6.Text = "--";
            this.label_Status6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Status4
            // 
            this.label_Status4.AutoSize = true;
            this.label_Status4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Status4.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Status4.Location = new System.Drawing.Point(124, 33);
            this.label_Status4.Margin = new System.Windows.Forms.Padding(0);
            this.label_Status4.Name = "label_Status4";
            this.label_Status4.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Status4.Size = new System.Drawing.Size(40, 31);
            this.label_Status4.TabIndex = 29;
            this.label_Status4.Text = "--";
            this.label_Status4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Status7
            // 
            this.label_Status7.AutoSize = true;
            this.label_Status7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Status7.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Status7.Location = new System.Drawing.Point(372, 0);
            this.label_Status7.Margin = new System.Windows.Forms.Padding(0);
            this.label_Status7.Name = "label_Status7";
            this.label_Status7.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Status7.Size = new System.Drawing.Size(40, 31);
            this.label_Status7.TabIndex = 28;
            this.label_Status7.Text = "--";
            this.label_Status7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Status5
            // 
            this.label_Status5.AutoSize = true;
            this.label_Status5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Status5.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Status5.Location = new System.Drawing.Point(248, 0);
            this.label_Status5.Margin = new System.Windows.Forms.Padding(0);
            this.label_Status5.Name = "label_Status5";
            this.label_Status5.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Status5.Size = new System.Drawing.Size(40, 31);
            this.label_Status5.TabIndex = 27;
            this.label_Status5.Text = "--";
            this.label_Status5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Status3
            // 
            this.label_Status3.AutoSize = true;
            this.label_Status3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Status3.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Status3.Location = new System.Drawing.Point(124, 0);
            this.label_Status3.Margin = new System.Windows.Forms.Padding(0);
            this.label_Status3.Name = "label_Status3";
            this.label_Status3.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Status3.Size = new System.Drawing.Size(40, 31);
            this.label_Status3.TabIndex = 26;
            this.label_Status3.Text = "--";
            this.label_Status3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Status1
            // 
            this.label_Status1.AutoSize = true;
            this.label_Status1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Status1.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Status1.Location = new System.Drawing.Point(0, 0);
            this.label_Status1.Margin = new System.Windows.Forms.Padding(0);
            this.label_Status1.Name = "label_Status1";
            this.label_Status1.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Status1.Size = new System.Drawing.Size(40, 31);
            this.label_Status1.TabIndex = 24;
            this.label_Status1.Text = "--";
            this.label_Status1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Status2
            // 
            this.label_Status2.AutoSize = true;
            this.label_Status2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Status2.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Status2.Location = new System.Drawing.Point(0, 33);
            this.label_Status2.Margin = new System.Windows.Forms.Padding(0);
            this.label_Status2.Name = "label_Status2";
            this.label_Status2.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Status2.Size = new System.Drawing.Size(40, 31);
            this.label_Status2.TabIndex = 25;
            this.label_Status2.Text = "--";
            this.label_Status2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.BackColor = System.Drawing.Color.LightGray;
            this.tableLayoutPanel16.ColumnCount = 1;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Controls.Add(this.label86, 0, 1);
            this.tableLayoutPanel16.Location = new System.Drawing.Point(497, 0);
            this.tableLayoutPanel16.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(65, 67);
            this.tableLayoutPanel16.TabIndex = 1;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label86.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(0, 33);
            this.label86.Margin = new System.Windows.Forms.Padding(0);
            this.label86.Name = "label86";
            this.label86.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label86.Size = new System.Drawing.Size(50, 31);
            this.label86.TabIndex = 25;
            this.label86.Text = "PPB";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flowLayoutPanel12
            // 
            this.flowLayoutPanel12.Controls.Add(this.label21);
            this.flowLayoutPanel12.Controls.Add(this.flowLayoutPanel7);
            this.flowLayoutPanel12.Controls.Add(this.flowLayoutPanel16);
            this.flowLayoutPanel12.Controls.Add(this.flowLayoutPanel17);
            this.flowLayoutPanel12.Location = new System.Drawing.Point(0, 129);
            this.flowLayoutPanel12.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel12.Name = "flowLayoutPanel12";
            this.flowLayoutPanel12.Size = new System.Drawing.Size(723, 155);
            this.flowLayoutPanel12.TabIndex = 30;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(0, 0);
            this.label21.Margin = new System.Windows.Forms.Padding(0, 0, 400, 0);
            this.label21.Name = "label21";
            this.label21.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label21.Size = new System.Drawing.Size(110, 31);
            this.label21.TabIndex = 27;
            this.label21.Text = "Measure :";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flowLayoutPanel7
            // 
            this.flowLayoutPanel7.Controls.Add(this.tableLayoutPanel11);
            this.flowLayoutPanel7.Location = new System.Drawing.Point(0, 31);
            this.flowLayoutPanel7.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel7.Name = "flowLayoutPanel7";
            this.flowLayoutPanel7.Size = new System.Drawing.Size(723, 31);
            this.flowLayoutPanel7.TabIndex = 28;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.tableLayoutPanel11.ColumnCount = 4;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 160F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tableLayoutPanel11.Controls.Add(this.label22, 1, 0);
            this.tableLayoutPanel11.Controls.Add(this.label18, 2, 0);
            this.tableLayoutPanel11.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel11.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(722, 31);
            this.tableLayoutPanel11.TabIndex = 0;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label22.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(160, 0);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label22.Size = new System.Drawing.Size(90, 31);
            this.label22.TabIndex = 26;
            this.label22.Text = "Control";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(408, 0);
            this.label18.Margin = new System.Windows.Forms.Padding(0);
            this.label18.Name = "label18";
            this.label18.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label18.Size = new System.Drawing.Size(90, 31);
            this.label18.TabIndex = 25;
            this.label18.Text = "Monitor";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flowLayoutPanel16
            // 
            this.flowLayoutPanel16.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.flowLayoutPanel16.Controls.Add(this.label19);
            this.flowLayoutPanel16.Controls.Add(this.label20);
            this.flowLayoutPanel16.Controls.Add(this.label23);
            this.flowLayoutPanel16.Location = new System.Drawing.Point(0, 62);
            this.flowLayoutPanel16.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel16.Name = "flowLayoutPanel16";
            this.flowLayoutPanel16.Size = new System.Drawing.Size(160, 93);
            this.flowLayoutPanel16.TabIndex = 26;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label19.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(0, 0);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label19.Size = new System.Drawing.Size(130, 31);
            this.label19.TabIndex = 25;
            this.label19.Text = "Diluted MFC";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label20.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(0, 31);
            this.label20.Margin = new System.Windows.Forms.Padding(0);
            this.label20.Name = "label20";
            this.label20.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label20.Size = new System.Drawing.Size(130, 31);
            this.label20.TabIndex = 23;
            this.label20.Text = "Source  MFC";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label23.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(0, 62);
            this.label23.Margin = new System.Windows.Forms.Padding(0);
            this.label23.Name = "label23";
            this.label23.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label23.Size = new System.Drawing.Size(140, 31);
            this.label23.TabIndex = 30;
            this.label23.Text = "Total   Flow";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flowLayoutPanel17
            // 
            this.flowLayoutPanel17.Controls.Add(this.tableLayoutPanel12);
            this.flowLayoutPanel17.Controls.Add(this.tableLayoutPanel13);
            this.flowLayoutPanel17.Location = new System.Drawing.Point(160, 62);
            this.flowLayoutPanel17.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel17.Name = "flowLayoutPanel17";
            this.flowLayoutPanel17.Size = new System.Drawing.Size(563, 93);
            this.flowLayoutPanel17.TabIndex = 26;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.BackColor = System.Drawing.Color.LightGray;
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.label_Measure4, 0, 1);
            this.tableLayoutPanel12.Controls.Add(this.label_Measure2, 1, 0);
            this.tableLayoutPanel12.Controls.Add(this.label_Measure3, 0, 1);
            this.tableLayoutPanel12.Controls.Add(this.label_Measure1, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.label_Measure5, 0, 2);
            this.tableLayoutPanel12.Controls.Add(this.label_Measure6, 1, 2);
            this.tableLayoutPanel12.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel12.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 3;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(497, 93);
            this.tableLayoutPanel12.TabIndex = 0;
            // 
            // label_Measure4
            // 
            this.label_Measure4.AutoSize = true;
            this.label_Measure4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Measure4.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Measure4.Location = new System.Drawing.Point(248, 31);
            this.label_Measure4.Margin = new System.Windows.Forms.Padding(0);
            this.label_Measure4.Name = "label_Measure4";
            this.label_Measure4.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Measure4.Size = new System.Drawing.Size(40, 31);
            this.label_Measure4.TabIndex = 26;
            this.label_Measure4.Text = "--";
            this.label_Measure4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Measure2
            // 
            this.label_Measure2.AutoSize = true;
            this.label_Measure2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Measure2.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Measure2.Location = new System.Drawing.Point(248, 0);
            this.label_Measure2.Margin = new System.Windows.Forms.Padding(0);
            this.label_Measure2.Name = "label_Measure2";
            this.label_Measure2.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Measure2.Size = new System.Drawing.Size(40, 31);
            this.label_Measure2.TabIndex = 29;
            this.label_Measure2.Text = "--";
            this.label_Measure2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Measure3
            // 
            this.label_Measure3.AutoSize = true;
            this.label_Measure3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Measure3.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Measure3.Location = new System.Drawing.Point(0, 31);
            this.label_Measure3.Margin = new System.Windows.Forms.Padding(0);
            this.label_Measure3.Name = "label_Measure3";
            this.label_Measure3.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Measure3.Size = new System.Drawing.Size(40, 31);
            this.label_Measure3.TabIndex = 25;
            this.label_Measure3.Text = "--";
            this.label_Measure3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Measure1
            // 
            this.label_Measure1.AutoSize = true;
            this.label_Measure1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Measure1.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Measure1.Location = new System.Drawing.Point(0, 0);
            this.label_Measure1.Margin = new System.Windows.Forms.Padding(0);
            this.label_Measure1.Name = "label_Measure1";
            this.label_Measure1.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Measure1.Size = new System.Drawing.Size(40, 31);
            this.label_Measure1.TabIndex = 24;
            this.label_Measure1.Text = "--";
            this.label_Measure1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Measure5
            // 
            this.label_Measure5.AutoSize = true;
            this.label_Measure5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Measure5.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Measure5.Location = new System.Drawing.Point(0, 62);
            this.label_Measure5.Margin = new System.Windows.Forms.Padding(0);
            this.label_Measure5.Name = "label_Measure5";
            this.label_Measure5.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Measure5.Size = new System.Drawing.Size(40, 31);
            this.label_Measure5.TabIndex = 31;
            this.label_Measure5.Text = "--";
            this.label_Measure5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_Measure6
            // 
            this.label_Measure6.AutoSize = true;
            this.label_Measure6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_Measure6.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Measure6.Location = new System.Drawing.Point(248, 62);
            this.label_Measure6.Margin = new System.Windows.Forms.Padding(0);
            this.label_Measure6.Name = "label_Measure6";
            this.label_Measure6.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label_Measure6.Size = new System.Drawing.Size(40, 31);
            this.label_Measure6.TabIndex = 30;
            this.label_Measure6.Text = "--";
            this.label_Measure6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.BackColor = System.Drawing.Color.LightGray;
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.label25, 0, 1);
            this.tableLayoutPanel13.Controls.Add(this.label28, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.label29, 0, 2);
            this.tableLayoutPanel13.Location = new System.Drawing.Point(497, 0);
            this.tableLayoutPanel13.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 3;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(65, 93);
            this.tableLayoutPanel13.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label25.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(0, 31);
            this.label25.Margin = new System.Windows.Forms.Padding(0);
            this.label25.Name = "label25";
            this.label25.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label25.Size = new System.Drawing.Size(60, 31);
            this.label25.TabIndex = 25;
            this.label25.Text = "SCCM";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label28.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(0, 0);
            this.label28.Margin = new System.Windows.Forms.Padding(0);
            this.label28.Name = "label28";
            this.label28.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label28.Size = new System.Drawing.Size(60, 31);
            this.label28.TabIndex = 29;
            this.label28.Text = "SLPM";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label29.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(0, 62);
            this.label29.Margin = new System.Windows.Forms.Padding(0);
            this.label29.Name = "label29";
            this.label29.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label29.Size = new System.Drawing.Size(60, 31);
            this.label29.TabIndex = 30;
            this.label29.Text = "SLPM";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flowLayoutPanel11
            // 
            this.flowLayoutPanel11.Controls.Add(this.btn_CheckNow);
            this.flowLayoutPanel11.Controls.Add(this.btn_Purge);
            this.flowLayoutPanel11.Controls.Add(this.btn_PurgeLock);
            this.flowLayoutPanel11.Location = new System.Drawing.Point(0, 316);
            this.flowLayoutPanel11.Margin = new System.Windows.Forms.Padding(0, 32, 0, 0);
            this.flowLayoutPanel11.Name = "flowLayoutPanel11";
            this.flowLayoutPanel11.Size = new System.Drawing.Size(723, 40);
            this.flowLayoutPanel11.TabIndex = 27;
            // 
            // btn_CheckNow
            // 
            this.btn_CheckNow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_CheckNow.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_CheckNow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CheckNow.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CheckNow.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_CheckNow.Location = new System.Drawing.Point(0, 0);
            this.btn_CheckNow.Margin = new System.Windows.Forms.Padding(0);
            this.btn_CheckNow.Name = "btn_CheckNow";
            this.btn_CheckNow.Size = new System.Drawing.Size(160, 40);
            this.btn_CheckNow.TabIndex = 0;
            this.btn_CheckNow.Text = "Check now";
            this.btn_CheckNow.UseVisualStyleBackColor = false;
            this.btn_CheckNow.Click += new System.EventHandler(this.btn_CheckNow_Click);
            // 
            // btn_Purge
            // 
            this.btn_Purge.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_Purge.Enabled = false;
            this.btn_Purge.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Purge.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold);
            this.btn_Purge.Location = new System.Drawing.Point(544, 0);
            this.btn_Purge.Margin = new System.Windows.Forms.Padding(384, 0, 0, 0);
            this.btn_Purge.Name = "btn_Purge";
            this.btn_Purge.Size = new System.Drawing.Size(113, 40);
            this.btn_Purge.TabIndex = 2;
            this.btn_Purge.Text = "Purge";
            this.btn_Purge.UseVisualStyleBackColor = false;
            this.btn_Purge.Click += new System.EventHandler(this.btn_Purge_Click);
            // 
            // btn_PurgeLock
            // 
            this.btn_PurgeLock.BackColor = System.Drawing.Color.LightGray;
            this.btn_PurgeLock.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_PurgeLock.BackgroundImage")));
            this.btn_PurgeLock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_PurgeLock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_PurgeLock.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold);
            this.btn_PurgeLock.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_PurgeLock.Location = new System.Drawing.Point(657, 0);
            this.btn_PurgeLock.Margin = new System.Windows.Forms.Padding(0);
            this.btn_PurgeLock.Name = "btn_PurgeLock";
            this.btn_PurgeLock.Size = new System.Drawing.Size(66, 40);
            this.btn_PurgeLock.TabIndex = 1;
            this.btn_PurgeLock.UseVisualStyleBackColor = false;
            this.btn_PurgeLock.Click += new System.EventHandler(this.btn_PurgeLock_Click);
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.Controls.Add(this.flowLayoutPanel10);
            this.flowLayoutPanel5.Controls.Add(this.flowLayoutPanel19);
            this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(10, 71);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(10, 20, 10, 10);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(650, 400);
            this.flowLayoutPanel5.TabIndex = 1;
            // 
            // flowLayoutPanel10
            // 
            this.flowLayoutPanel10.Controls.Add(this.flowLayoutPanel6);
            this.flowLayoutPanel10.Controls.Add(this.flowLayoutPanel8);
            this.flowLayoutPanel10.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel10.Margin = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.flowLayoutPanel10.Name = "flowLayoutPanel10";
            this.flowLayoutPanel10.Size = new System.Drawing.Size(203, 400);
            this.flowLayoutPanel10.TabIndex = 3;
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Controls.Add(this.label24);
            this.flowLayoutPanel6.Controls.Add(this.Addr_Box);
            this.flowLayoutPanel6.Controls.Add(this.label26);
            this.flowLayoutPanel6.Controls.Add(this.Sequence_Box);
            this.flowLayoutPanel6.Controls.Add(this.label27);
            this.flowLayoutPanel6.Controls.Add(this.Point_Box);
            this.flowLayoutPanel6.Controls.Add(this.label30);
            this.flowLayoutPanel6.Controls.Add(this.Sabio_Time_Box);
            this.flowLayoutPanel6.Controls.Add(this.btn_MS);
            this.flowLayoutPanel6.Controls.Add(this.btn_Zero_MS);
            this.flowLayoutPanel6.Controls.Add(this.btn_Span_MS);
            this.flowLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(202, 206);
            this.flowLayoutPanel6.TabIndex = 1;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label24.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(0, 0);
            this.label24.Margin = new System.Windows.Forms.Padding(0);
            this.label24.Name = "label24";
            this.label24.Padding = new System.Windows.Forms.Padding(5, 4, 16, 5);
            this.label24.Size = new System.Drawing.Size(101, 31);
            this.label24.TabIndex = 10;
            this.label24.Text = "Address";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Addr_Box
            // 
            this.Addr_Box.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Addr_Box.Font = new System.Drawing.Font("Consolas", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addr_Box.Location = new System.Drawing.Point(101, 0);
            this.Addr_Box.Margin = new System.Windows.Forms.Padding(0);
            this.Addr_Box.Name = "Addr_Box";
            this.Addr_Box.ReadOnly = true;
            this.Addr_Box.Size = new System.Drawing.Size(101, 31);
            this.Addr_Box.TabIndex = 0;
            this.Addr_Box.Text = "001";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label26.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(0, 31);
            this.label26.Margin = new System.Windows.Forms.Padding(0);
            this.label26.Name = "label26";
            this.label26.Padding = new System.Windows.Forms.Padding(5, 4, 6, 5);
            this.label26.Size = new System.Drawing.Size(101, 31);
            this.label26.TabIndex = 11;
            this.label26.Text = "Sequence";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Sequence_Box
            // 
            this.Sequence_Box.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Sequence_Box.Font = new System.Drawing.Font("Consolas", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sequence_Box.Location = new System.Drawing.Point(101, 31);
            this.Sequence_Box.Margin = new System.Windows.Forms.Padding(0);
            this.Sequence_Box.Name = "Sequence_Box";
            this.Sequence_Box.Size = new System.Drawing.Size(101, 31);
            this.Sequence_Box.TabIndex = 1;
            this.Sequence_Box.Text = "C4H8";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label27.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(0, 62);
            this.label27.Margin = new System.Windows.Forms.Padding(0);
            this.label27.Name = "label27";
            this.label27.Padding = new System.Windows.Forms.Padding(5, 4, 36, 5);
            this.label27.Size = new System.Drawing.Size(101, 31);
            this.label27.TabIndex = 16;
            this.label27.Text = "Point";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Point_Box
            // 
            this.Point_Box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Point_Box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Point_Box.Font = new System.Drawing.Font("Consolas", 15F);
            this.Point_Box.FormattingEnabled = true;
            this.Point_Box.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.Point_Box.Location = new System.Drawing.Point(101, 62);
            this.Point_Box.Margin = new System.Windows.Forms.Padding(0);
            this.Point_Box.Name = "Point_Box";
            this.Point_Box.Size = new System.Drawing.Size(101, 31);
            this.Point_Box.TabIndex = 2;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label30.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(0, 93);
            this.label30.Margin = new System.Windows.Forms.Padding(0);
            this.label30.Name = "label30";
            this.label30.Padding = new System.Windows.Forms.Padding(5, 4, 16, 5);
            this.label30.Size = new System.Drawing.Size(101, 31);
            this.label30.TabIndex = 12;
            this.label30.Text = "Time(m)";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Sabio_Time_Box
            // 
            this.Sabio_Time_Box.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Sabio_Time_Box.Font = new System.Drawing.Font("Consolas", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sabio_Time_Box.Location = new System.Drawing.Point(101, 93);
            this.Sabio_Time_Box.Margin = new System.Windows.Forms.Padding(0);
            this.Sabio_Time_Box.Name = "Sabio_Time_Box";
            this.Sabio_Time_Box.Size = new System.Drawing.Size(101, 31);
            this.Sabio_Time_Box.TabIndex = 3;
            this.Sabio_Time_Box.Text = "5";
            // 
            // btn_MS
            // 
            this.btn_MS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_MS.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_MS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_MS.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MS.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_MS.Location = new System.Drawing.Point(0, 124);
            this.btn_MS.Margin = new System.Windows.Forms.Padding(0);
            this.btn_MS.Name = "btn_MS";
            this.btn_MS.Size = new System.Drawing.Size(203, 40);
            this.btn_MS.TabIndex = 4;
            this.btn_MS.Text = "MS";
            this.btn_MS.UseVisualStyleBackColor = false;
            this.btn_MS.Click += new System.EventHandler(this.btn_MS_Click);
            // 
            // btn_Zero_MS
            // 
            this.btn_Zero_MS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_Zero_MS.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_Zero_MS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Zero_MS.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Zero_MS.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Zero_MS.Location = new System.Drawing.Point(0, 164);
            this.btn_Zero_MS.Margin = new System.Windows.Forms.Padding(0);
            this.btn_Zero_MS.Name = "btn_Zero_MS";
            this.btn_Zero_MS.Size = new System.Drawing.Size(101, 40);
            this.btn_Zero_MS.TabIndex = 17;
            this.btn_Zero_MS.Text = "Zero MS";
            this.btn_Zero_MS.UseVisualStyleBackColor = false;
            this.btn_Zero_MS.Click += new System.EventHandler(this.btn_Zero_MS_Click);
            // 
            // btn_Span_MS
            // 
            this.btn_Span_MS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_Span_MS.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_Span_MS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Span_MS.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Span_MS.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Span_MS.Location = new System.Drawing.Point(101, 164);
            this.btn_Span_MS.Margin = new System.Windows.Forms.Padding(0);
            this.btn_Span_MS.Name = "btn_Span_MS";
            this.btn_Span_MS.Size = new System.Drawing.Size(101, 40);
            this.btn_Span_MS.TabIndex = 18;
            this.btn_Span_MS.Text = "Span MS";
            this.btn_Span_MS.UseVisualStyleBackColor = false;
            this.btn_Span_MS.Click += new System.EventHandler(this.btn_Span_MS_Click);
            // 
            // flowLayoutPanel8
            // 
            this.flowLayoutPanel8.Controls.Add(this.label10);
            this.flowLayoutPanel8.Controls.Add(this.Sabio_UpdateRate_Box);
            this.flowLayoutPanel8.Controls.Add(this.label31);
            this.flowLayoutPanel8.Controls.Add(this.FileName_Box);
            this.flowLayoutPanel8.Controls.Add(this.btn_Sabio_cap);
            this.flowLayoutPanel8.Controls.Add(this.label_Sabio_time);
            this.flowLayoutPanel8.Location = new System.Drawing.Point(0, 206);
            this.flowLayoutPanel8.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel8.Name = "flowLayoutPanel8";
            this.flowLayoutPanel8.Size = new System.Drawing.Size(203, 193);
            this.flowLayoutPanel8.TabIndex = 26;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label10.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(0, 18);
            this.label10.Margin = new System.Windows.Forms.Padding(0, 18, 0, 0);
            this.label10.Name = "label10";
            this.label10.Padding = new System.Windows.Forms.Padding(5, 4, 0, 5);
            this.label10.Size = new System.Drawing.Size(95, 31);
            this.label10.TabIndex = 31;
            this.label10.Text = "Time(s):";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Sabio_UpdateRate_Box
            // 
            this.Sabio_UpdateRate_Box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Sabio_UpdateRate_Box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sabio_UpdateRate_Box.Font = new System.Drawing.Font("Consolas", 15F);
            this.Sabio_UpdateRate_Box.FormattingEnabled = true;
            this.Sabio_UpdateRate_Box.Items.AddRange(new object[] {
            "5",
            "10",
            "20",
            "30",
            "60"});
            this.Sabio_UpdateRate_Box.Location = new System.Drawing.Point(95, 18);
            this.Sabio_UpdateRate_Box.Margin = new System.Windows.Forms.Padding(0, 18, 0, 0);
            this.Sabio_UpdateRate_Box.Name = "Sabio_UpdateRate_Box";
            this.Sabio_UpdateRate_Box.Size = new System.Drawing.Size(107, 31);
            this.Sabio_UpdateRate_Box.TabIndex = 0;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label31.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(0, 49);
            this.label31.Margin = new System.Windows.Forms.Padding(0);
            this.label31.Name = "label31";
            this.label31.Padding = new System.Windows.Forms.Padding(5, 4, 87, 5);
            this.label31.Size = new System.Drawing.Size(202, 31);
            this.label31.TabIndex = 27;
            this.label31.Text = "File name:";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FileName_Box
            // 
            this.FileName_Box.Font = new System.Drawing.Font("Consolas", 15F);
            this.FileName_Box.Location = new System.Drawing.Point(0, 80);
            this.FileName_Box.Margin = new System.Windows.Forms.Padding(0);
            this.FileName_Box.Name = "FileName_Box";
            this.FileName_Box.Size = new System.Drawing.Size(203, 31);
            this.FileName_Box.TabIndex = 1;
            // 
            // btn_Sabio_cap
            // 
            this.btn_Sabio_cap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_Sabio_cap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Sabio_cap.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold);
            this.btn_Sabio_cap.Location = new System.Drawing.Point(0, 111);
            this.btn_Sabio_cap.Margin = new System.Windows.Forms.Padding(0);
            this.btn_Sabio_cap.Name = "btn_Sabio_cap";
            this.btn_Sabio_cap.Size = new System.Drawing.Size(202, 40);
            this.btn_Sabio_cap.TabIndex = 2;
            this.btn_Sabio_cap.Text = "Capture";
            this.btn_Sabio_cap.UseVisualStyleBackColor = false;
            this.btn_Sabio_cap.Click += new System.EventHandler(this.btn_Sabio_cap_Click);
            // 
            // label_Sabio_time
            // 
            this.label_Sabio_time.AutoSize = true;
            this.label_Sabio_time.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sabio_time.Location = new System.Drawing.Point(36, 161);
            this.label_Sabio_time.Margin = new System.Windows.Forms.Padding(36, 10, 2, 0);
            this.label_Sabio_time.Name = "label_Sabio_time";
            this.label_Sabio_time.Size = new System.Drawing.Size(130, 22);
            this.label_Sabio_time.TabIndex = 168;
            this.label_Sabio_time.Text = "00 : 00 : 00";
            this.label_Sabio_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // flowLayoutPanel19
            // 
            this.flowLayoutPanel19.Controls.Add(this.tableLayoutPanel14);
            this.flowLayoutPanel19.Controls.Add(this.listView1);
            this.flowLayoutPanel19.Controls.Add(this.btn_CmdStart);
            this.flowLayoutPanel19.Controls.Add(this.btn_CmdStop);
            this.flowLayoutPanel19.Controls.Add(this.btn_ClnList);
            this.flowLayoutPanel19.Location = new System.Drawing.Point(223, 0);
            this.flowLayoutPanel19.Margin = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.flowLayoutPanel19.Name = "flowLayoutPanel19";
            this.flowLayoutPanel19.Size = new System.Drawing.Size(427, 400);
            this.flowLayoutPanel19.TabIndex = 4;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 278F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 83F));
            this.tableLayoutPanel14.Controls.Add(this.label33, 0, 0);
            this.tableLayoutPanel14.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel14.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 1;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(361, 32);
            this.tableLayoutPanel14.TabIndex = 0;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label33.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(0, 0);
            this.label33.Margin = new System.Windows.Forms.Padding(0);
            this.label33.Name = "label33";
            this.label33.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label33.Size = new System.Drawing.Size(150, 31);
            this.label33.TabIndex = 25;
            this.label33.Text = "Command List:";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView1.Font = new System.Drawing.Font("Consolas", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(0, 32);
            this.listView1.Margin = new System.Windows.Forms.Padding(0);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(427, 325);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.ColumnWidthChanging += new System.Windows.Forms.ColumnWidthChangingEventHandler(this.listView1_ColumnWidthChanging);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Command";
            this.columnHeader1.Width = 213;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Rest time(m)";
            this.columnHeader2.Width = 130;
            // 
            // btn_CmdStart
            // 
            this.btn_CmdStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_CmdStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CmdStart.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold);
            this.btn_CmdStart.Location = new System.Drawing.Point(0, 357);
            this.btn_CmdStart.Margin = new System.Windows.Forms.Padding(0);
            this.btn_CmdStart.Name = "btn_CmdStart";
            this.btn_CmdStart.Size = new System.Drawing.Size(142, 40);
            this.btn_CmdStart.TabIndex = 0;
            this.btn_CmdStart.Text = "Start";
            this.btn_CmdStart.UseVisualStyleBackColor = false;
            this.btn_CmdStart.Click += new System.EventHandler(this.btn_CmdStart_Click);
            // 
            // btn_CmdStop
            // 
            this.btn_CmdStop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_CmdStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CmdStop.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold);
            this.btn_CmdStop.Location = new System.Drawing.Point(142, 357);
            this.btn_CmdStop.Margin = new System.Windows.Forms.Padding(0);
            this.btn_CmdStop.Name = "btn_CmdStop";
            this.btn_CmdStop.Size = new System.Drawing.Size(142, 40);
            this.btn_CmdStop.TabIndex = 1;
            this.btn_CmdStop.Text = "Stop";
            this.btn_CmdStop.UseVisualStyleBackColor = false;
            this.btn_CmdStop.Click += new System.EventHandler(this.btn_CmdStop_Click);
            // 
            // btn_ClnList
            // 
            this.btn_ClnList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_ClnList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ClnList.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold);
            this.btn_ClnList.Location = new System.Drawing.Point(284, 357);
            this.btn_ClnList.Margin = new System.Windows.Forms.Padding(0);
            this.btn_ClnList.Name = "btn_ClnList";
            this.btn_ClnList.Size = new System.Drawing.Size(143, 40);
            this.btn_ClnList.TabIndex = 2;
            this.btn_ClnList.Text = "Clean list";
            this.btn_ClnList.UseVisualStyleBackColor = false;
            this.btn_ClnList.Click += new System.EventHandler(this.btn_ClnList_Click);
            // 
            // label_Sabio_State
            // 
            this.label_Sabio_State.AutoSize = true;
            this.label_Sabio_State.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold);
            this.label_Sabio_State.Location = new System.Drawing.Point(680, 10);
            this.label_Sabio_State.Margin = new System.Windows.Forms.Padding(10);
            this.label_Sabio_State.Name = "label_Sabio_State";
            this.label_Sabio_State.Padding = new System.Windows.Forms.Padding(2, 6, 25, 6);
            this.label_Sabio_State.Size = new System.Drawing.Size(267, 31);
            this.label_Sabio_State.TabIndex = 3;
            this.label_Sabio_State.Text = "Choose port to connect.";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(0, 0);
            this.label32.Margin = new System.Windows.Forms.Padding(0);
            this.label32.Name = "label32";
            this.label32.Padding = new System.Windows.Forms.Padding(5, 4, 5, 5);
            this.label32.Size = new System.Drawing.Size(70, 31);
            this.label32.TabIndex = 23;
            this.label32.Text = "Info:";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Sabio_Info_Box
            // 
            this.Sabio_Info_Box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Sabio_Info_Box.Font = new System.Drawing.Font("Consolas", 10F);
            this.Sabio_Info_Box.Location = new System.Drawing.Point(10, 31);
            this.Sabio_Info_Box.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.Sabio_Info_Box.Name = "Sabio_Info_Box";
            this.Sabio_Info_Box.Size = new System.Drawing.Size(288, 124);
            this.Sabio_Info_Box.TabIndex = 8;
            this.Sabio_Info_Box.Text = "";
            this.Sabio_Info_Box.TextChanged += new System.EventHandler(this.Info_Box_TextChanged);
            // 
            // brn_InfoCln
            // 
            this.brn_InfoCln.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold);
            this.brn_InfoCln.Location = new System.Drawing.Point(0, 155);
            this.brn_InfoCln.Margin = new System.Windows.Forms.Padding(0);
            this.brn_InfoCln.Name = "brn_InfoCln";
            this.brn_InfoCln.Size = new System.Drawing.Size(75, 34);
            this.brn_InfoCln.TabIndex = 25;
            this.brn_InfoCln.Text = "clean";
            this.brn_InfoCln.UseVisualStyleBackColor = true;
            this.brn_InfoCln.Click += new System.EventHandler(this.brn_InfoCln_Click);
            // 
            // groupBox_I2C
            // 
            this.groupBox_I2C.Controls.Add(this.btn_test);
            this.groupBox_I2C.Controls.Add(this.test_box);
            this.groupBox_I2C.Controls.Add(this.AlphFix_Info_box);
            this.groupBox_I2C.Controls.Add(this.label34);
            this.groupBox_I2C.Controls.Add(this.btn_AlphFix_Connect);
            this.groupBox_I2C.Controls.Add(this.AlphFix_Port_box);
            this.groupBox_I2C.Controls.Add(this.btn_AlphFix_stopORstart);
            this.groupBox_I2C.Controls.Add(this.label_AlphFix_State);
            this.groupBox_I2C.Controls.Add(this.groupBox_IDBOX);
            this.groupBox_I2C.Controls.Add(this.group_SHT0);
            this.groupBox_I2C.Controls.Add(this.group_SHT1);
            this.groupBox_I2C.Controls.Add(this.group_Response);
            this.groupBox_I2C.Controls.Add(this.group_SHT2);
            this.groupBox_I2C.Controls.Add(this.group_SHT3);
            this.groupBox_I2C.Controls.Add(this.label2);
            this.groupBox_I2C.Controls.Add(this.groupBox3);
            this.groupBox_I2C.Controls.Add(this.tabSelect);
            this.groupBox_I2C.Font = new System.Drawing.Font("Consolas", 18F, System.Drawing.FontStyle.Bold);
            this.groupBox_I2C.Location = new System.Drawing.Point(3, 2);
            this.groupBox_I2C.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox_I2C.Name = "groupBox_I2C";
            this.groupBox_I2C.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox_I2C.Size = new System.Drawing.Size(1419, 715);
            this.groupBox_I2C.TabIndex = 0;
            this.groupBox_I2C.TabStop = false;
            this.groupBox_I2C.Text = "GAS V3";
            // 
            // btn_test
            // 
            this.btn_test.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_test.Location = new System.Drawing.Point(587, 620);
            this.btn_test.Name = "btn_test";
            this.btn_test.Size = new System.Drawing.Size(94, 28);
            this.btn_test.TabIndex = 270;
            this.btn_test.Text = "test";
            this.btn_test.UseVisualStyleBackColor = true;
            this.btn_test.Click += new System.EventHandler(this.btn_test_Click);
            // 
            // test_box
            // 
            this.test_box.Font = new System.Drawing.Font("Consolas", 13F);
            this.test_box.Location = new System.Drawing.Point(586, 587);
            this.test_box.Margin = new System.Windows.Forms.Padding(0);
            this.test_box.MaxLength = 50;
            this.test_box.Name = "test_box";
            this.test_box.Size = new System.Drawing.Size(201, 28);
            this.test_box.TabIndex = 269;
            // 
            // AlphFix_Info_box
            // 
            this.AlphFix_Info_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.AlphFix_Info_box.Font = new System.Drawing.Font("Consolas", 10F);
            this.AlphFix_Info_box.Location = new System.Drawing.Point(1064, 15);
            this.AlphFix_Info_box.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.AlphFix_Info_box.Name = "AlphFix_Info_box";
            this.AlphFix_Info_box.Size = new System.Drawing.Size(341, 69);
            this.AlphFix_Info_box.TabIndex = 268;
            this.AlphFix_Info_box.Text = "";
            this.AlphFix_Info_box.TextChanged += new System.EventHandler(this.AlphFix_Info_Box_TextChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label34.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(13, 40);
            this.label34.Margin = new System.Windows.Forms.Padding(0);
            this.label34.Name = "label34";
            this.label34.Padding = new System.Windows.Forms.Padding(26, 4, 25, 5);
            this.label34.Size = new System.Drawing.Size(101, 31);
            this.label34.TabIndex = 267;
            this.label34.Text = "Port";
            // 
            // btn_AlphFix_Connect
            // 
            this.btn_AlphFix_Connect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_AlphFix_Connect.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_AlphFix_Connect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AlphFix_Connect.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_AlphFix_Connect.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AlphFix_Connect.Location = new System.Drawing.Point(236, 40);
            this.btn_AlphFix_Connect.Margin = new System.Windows.Forms.Padding(0);
            this.btn_AlphFix_Connect.Name = "btn_AlphFix_Connect";
            this.btn_AlphFix_Connect.Size = new System.Drawing.Size(132, 31);
            this.btn_AlphFix_Connect.TabIndex = 1;
            this.btn_AlphFix_Connect.Text = "Connect";
            this.btn_AlphFix_Connect.UseVisualStyleBackColor = false;
            this.btn_AlphFix_Connect.Click += new System.EventHandler(this.btn_AlphFix_Connect_Click);
            // 
            // AlphFix_Port_box
            // 
            this.AlphFix_Port_box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AlphFix_Port_box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AlphFix_Port_box.Font = new System.Drawing.Font("Consolas", 15F);
            this.AlphFix_Port_box.FormattingEnabled = true;
            this.AlphFix_Port_box.Location = new System.Drawing.Point(112, 40);
            this.AlphFix_Port_box.Name = "AlphFix_Port_box";
            this.AlphFix_Port_box.Size = new System.Drawing.Size(104, 31);
            this.AlphFix_Port_box.TabIndex = 0;
            this.AlphFix_Port_box.DropDown += new System.EventHandler(this.AlphFix_Port_box_DropDown);
            // 
            // btn_AlphFix_stopORstart
            // 
            this.btn_AlphFix_stopORstart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_AlphFix_stopORstart.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_AlphFix_stopORstart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AlphFix_stopORstart.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_AlphFix_stopORstart.Location = new System.Drawing.Point(13, 115);
            this.btn_AlphFix_stopORstart.Margin = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_AlphFix_stopORstart.Name = "btn_AlphFix_stopORstart";
            this.btn_AlphFix_stopORstart.Size = new System.Drawing.Size(203, 40);
            this.btn_AlphFix_stopORstart.TabIndex = 2;
            this.btn_AlphFix_stopORstart.Text = "Start";
            this.btn_AlphFix_stopORstart.UseVisualStyleBackColor = false;
            this.btn_AlphFix_stopORstart.Click += new System.EventHandler(this.btn_AlphFix_stopORstart_Click);
            // 
            // label_AlphFix_State
            // 
            this.label_AlphFix_State.AutoSize = true;
            this.label_AlphFix_State.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AlphFix_State.Location = new System.Drawing.Point(388, 44);
            this.label_AlphFix_State.Margin = new System.Windows.Forms.Padding(20, 0, 3, 0);
            this.label_AlphFix_State.Name = "label_AlphFix_State";
            this.label_AlphFix_State.Size = new System.Drawing.Size(240, 22);
            this.label_AlphFix_State.TabIndex = 263;
            this.label_AlphFix_State.Text = "Choose port to connect.";
            // 
            // groupBox_IDBOX
            // 
            this.groupBox_IDBOX.Controls.Add(this.btn_InitALL);
            this.groupBox_IDBOX.Controls.Add(this.btn_AlphFix_read);
            this.groupBox_IDBOX.Controls.Add(this.label6);
            this.groupBox_IDBOX.Controls.Add(this.btn_AutoSpan);
            this.groupBox_IDBOX.Controls.Add(this.btn_CalZero);
            this.groupBox_IDBOX.Controls.Add(this.SpanValue_box);
            this.groupBox_IDBOX.Controls.Add(this.label9);
            this.groupBox_IDBOX.Controls.Add(this.btn_AlphFix_write);
            this.groupBox_IDBOX.Controls.Add(this.ID_box);
            this.groupBox_IDBOX.Controls.Add(this.label7);
            this.groupBox_IDBOX.Controls.Add(this.Value_box);
            this.groupBox_IDBOX.Controls.Add(this.label3);
            this.groupBox_IDBOX.Controls.Add(this.Item_box);
            this.groupBox_IDBOX.Font = new System.Drawing.Font("Consolas", 14F, System.Drawing.FontStyle.Bold);
            this.groupBox_IDBOX.Location = new System.Drawing.Point(12, 495);
            this.groupBox_IDBOX.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox_IDBOX.Name = "groupBox_IDBOX";
            this.groupBox_IDBOX.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox_IDBOX.Size = new System.Drawing.Size(569, 212);
            this.groupBox_IDBOX.TabIndex = 6;
            this.groupBox_IDBOX.TabStop = false;
            this.groupBox_IDBOX.Text = "Write";
            // 
            // btn_InitALL
            // 
            this.btn_InitALL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_InitALL.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_InitALL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_InitALL.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_InitALL.Location = new System.Drawing.Point(223, 153);
            this.btn_InitALL.Margin = new System.Windows.Forms.Padding(20, 0, 3, 2);
            this.btn_InitALL.Name = "btn_InitALL";
            this.btn_InitALL.Size = new System.Drawing.Size(204, 40);
            this.btn_InitALL.TabIndex = 265;
            this.btn_InitALL.Text = "Inital ALL";
            this.btn_InitALL.UseVisualStyleBackColor = false;
            this.btn_InitALL.Click += new System.EventHandler(this.btn_InitALL_Click);
            // 
            // btn_AlphFix_read
            // 
            this.btn_AlphFix_read.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_AlphFix_read.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_AlphFix_read.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AlphFix_read.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_AlphFix_read.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AlphFix_read.Location = new System.Drawing.Point(12, 156);
            this.btn_AlphFix_read.Margin = new System.Windows.Forms.Padding(0);
            this.btn_AlphFix_read.Name = "btn_AlphFix_read";
            this.btn_AlphFix_read.Size = new System.Drawing.Size(191, 40);
            this.btn_AlphFix_read.TabIndex = 4;
            this.btn_AlphFix_read.Text = "Read";
            this.btn_AlphFix_read.UseVisualStyleBackColor = false;
            this.btn_AlphFix_read.Click += new System.EventHandler(this.btn_AlphFix_read_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(11, 88);
            this.label6.Margin = new System.Windows.Forms.Padding(20, 0, 3, 0);
            this.label6.Name = "label6";
            this.label6.Padding = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.label6.Size = new System.Drawing.Size(80, 28);
            this.label6.TabIndex = 264;
            this.label6.Text = " Value ";
            // 
            // btn_AutoSpan
            // 
            this.btn_AutoSpan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_AutoSpan.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_AutoSpan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AutoSpan.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_AutoSpan.Location = new System.Drawing.Point(223, 60);
            this.btn_AutoSpan.Margin = new System.Windows.Forms.Padding(0);
            this.btn_AutoSpan.Name = "btn_AutoSpan";
            this.btn_AutoSpan.Size = new System.Drawing.Size(204, 40);
            this.btn_AutoSpan.TabIndex = 6;
            this.btn_AutoSpan.Text = "Auto Span";
            this.btn_AutoSpan.UseVisualStyleBackColor = false;
            this.btn_AutoSpan.Click += new System.EventHandler(this.btn_AutoSpan_Click);
            // 
            // btn_CalZero
            // 
            this.btn_CalZero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_CalZero.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_CalZero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CalZero.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_CalZero.Location = new System.Drawing.Point(223, 113);
            this.btn_CalZero.Margin = new System.Windows.Forms.Padding(20, 2, 3, 0);
            this.btn_CalZero.Name = "btn_CalZero";
            this.btn_CalZero.Size = new System.Drawing.Size(204, 40);
            this.btn_CalZero.TabIndex = 7;
            this.btn_CalZero.Text = "Auto Zero";
            this.btn_CalZero.UseVisualStyleBackColor = false;
            this.btn_CalZero.Click += new System.EventHandler(this.btn_CalZero_Click);
            // 
            // SpanValue_box
            // 
            this.SpanValue_box.DecimalPlaces = 1;
            this.SpanValue_box.Font = new System.Drawing.Font("Consolas", 13F);
            this.SpanValue_box.Location = new System.Drawing.Point(313, 32);
            this.SpanValue_box.Margin = new System.Windows.Forms.Padding(0);
            this.SpanValue_box.Maximum = new decimal(new int[] {
            400000,
            0,
            0,
            0});
            this.SpanValue_box.Name = "SpanValue_box";
            this.SpanValue_box.Size = new System.Drawing.Size(114, 28);
            this.SpanValue_box.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(223, 32);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Padding = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.label9.Size = new System.Drawing.Size(90, 28);
            this.label9.TabIndex = 263;
            this.label9.Text = "Span PPB";
            // 
            // btn_AlphFix_write
            // 
            this.btn_AlphFix_write.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_AlphFix_write.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_AlphFix_write.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AlphFix_write.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_AlphFix_write.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AlphFix_write.Location = new System.Drawing.Point(12, 116);
            this.btn_AlphFix_write.Margin = new System.Windows.Forms.Padding(0);
            this.btn_AlphFix_write.Name = "btn_AlphFix_write";
            this.btn_AlphFix_write.Size = new System.Drawing.Size(191, 40);
            this.btn_AlphFix_write.TabIndex = 3;
            this.btn_AlphFix_write.Text = "Write";
            this.btn_AlphFix_write.UseVisualStyleBackColor = false;
            this.btn_AlphFix_write.Click += new System.EventHandler(this.btn_AlphFix_write_Click);
            // 
            // ID_box
            // 
            this.ID_box.Font = new System.Drawing.Font("Consolas", 13F);
            this.ID_box.Location = new System.Drawing.Point(91, 32);
            this.ID_box.Margin = new System.Windows.Forms.Padding(0);
            this.ID_box.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.ID_box.Name = "ID_box";
            this.ID_box.Size = new System.Drawing.Size(112, 28);
            this.ID_box.TabIndex = 0;
            this.ID_box.Value = new decimal(new int[] {
            23,
            0,
            0,
            0});
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(11, 32);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.label7.Size = new System.Drawing.Size(80, 28);
            this.label7.TabIndex = 219;
            this.label7.Text = " ID    ";
            // 
            // Value_box
            // 
            this.Value_box.Font = new System.Drawing.Font("Consolas", 13F);
            this.Value_box.Location = new System.Drawing.Point(91, 88);
            this.Value_box.Margin = new System.Windows.Forms.Padding(0);
            this.Value_box.Name = "Value_box";
            this.Value_box.Size = new System.Drawing.Size(112, 28);
            this.Value_box.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(11, 60);
            this.label3.Margin = new System.Windows.Forms.Padding(20, 0, 3, 0);
            this.label3.Name = "label3";
            this.label3.Padding = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.label3.Size = new System.Drawing.Size(80, 28);
            this.label3.TabIndex = 216;
            this.label3.Text = " Item  ";
            // 
            // Item_box
            // 
            this.Item_box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Item_box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Item_box.Font = new System.Drawing.Font("Consolas", 13F);
            this.Item_box.FormattingEnabled = true;
            this.Item_box.Items.AddRange(new object[] {
            "BSN",
            "CAL DATE",
            "ZERO",
            "SPAN",
            "A",
            "B"});
            this.Item_box.Location = new System.Drawing.Point(91, 60);
            this.Item_box.Name = "Item_box";
            this.Item_box.Size = new System.Drawing.Size(112, 28);
            this.Item_box.TabIndex = 1;
            // 
            // group_SHT0
            // 
            this.group_SHT0.Controls.Add(this.label_AH0);
            this.group_SHT0.Controls.Add(this.label_RH0);
            this.group_SHT0.Controls.Add(this.label_Temp0);
            this.group_SHT0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_SHT0.Location = new System.Drawing.Point(849, 495);
            this.group_SHT0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_SHT0.Name = "group_SHT0";
            this.group_SHT0.Padding = new System.Windows.Forms.Padding(3, 2, 3, 20);
            this.group_SHT0.Size = new System.Drawing.Size(134, 120);
            this.group_SHT0.TabIndex = 259;
            this.group_SHT0.TabStop = false;
            this.group_SHT0.Text = "SHT-30-U8";
            // 
            // label_AH0
            // 
            this.label_AH0.AutoSize = true;
            this.label_AH0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AH0.Location = new System.Drawing.Point(10, 88);
            this.label_AH0.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_AH0.Name = "label_AH0";
            this.label_AH0.Size = new System.Drawing.Size(120, 22);
            this.label_AH0.TabIndex = 258;
            this.label_AH0.Text = "AbsHumidity";
            // 
            // label_RH0
            // 
            this.label_RH0.AutoSize = true;
            this.label_RH0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_RH0.Location = new System.Drawing.Point(10, 60);
            this.label_RH0.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_RH0.Name = "label_RH0";
            this.label_RH0.Size = new System.Drawing.Size(90, 22);
            this.label_RH0.TabIndex = 0;
            this.label_RH0.Text = "Humidity";
            // 
            // label_Temp0
            // 
            this.label_Temp0.AutoSize = true;
            this.label_Temp0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Temp0.Location = new System.Drawing.Point(10, 32);
            this.label_Temp0.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Temp0.Name = "label_Temp0";
            this.label_Temp0.Size = new System.Drawing.Size(50, 22);
            this.label_Temp0.TabIndex = 0;
            this.label_Temp0.Text = "Temp";
            // 
            // group_SHT1
            // 
            this.group_SHT1.Controls.Add(this.label_AH1);
            this.group_SHT1.Controls.Add(this.label_RH1);
            this.group_SHT1.Controls.Add(this.label_Temp1);
            this.group_SHT1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_SHT1.Location = new System.Drawing.Point(989, 495);
            this.group_SHT1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_SHT1.Name = "group_SHT1";
            this.group_SHT1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 10);
            this.group_SHT1.Size = new System.Drawing.Size(134, 120);
            this.group_SHT1.TabIndex = 260;
            this.group_SHT1.TabStop = false;
            this.group_SHT1.Text = "SHT-30-U9";
            // 
            // label_AH1
            // 
            this.label_AH1.AutoSize = true;
            this.label_AH1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AH1.Location = new System.Drawing.Point(10, 88);
            this.label_AH1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_AH1.Name = "label_AH1";
            this.label_AH1.Size = new System.Drawing.Size(120, 22);
            this.label_AH1.TabIndex = 259;
            this.label_AH1.Text = "AbsHumidity";
            // 
            // label_RH1
            // 
            this.label_RH1.AutoSize = true;
            this.label_RH1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_RH1.Location = new System.Drawing.Point(10, 60);
            this.label_RH1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_RH1.Name = "label_RH1";
            this.label_RH1.Size = new System.Drawing.Size(90, 22);
            this.label_RH1.TabIndex = 0;
            this.label_RH1.Text = "Humidity";
            // 
            // label_Temp1
            // 
            this.label_Temp1.AutoSize = true;
            this.label_Temp1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Temp1.Location = new System.Drawing.Point(10, 32);
            this.label_Temp1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Temp1.Name = "label_Temp1";
            this.label_Temp1.Size = new System.Drawing.Size(50, 22);
            this.label_Temp1.TabIndex = 0;
            this.label_Temp1.Text = "Temp";
            // 
            // group_Response
            // 
            this.group_Response.Controls.Add(this.label_Response);
            this.group_Response.Font = new System.Drawing.Font("Consolas", 14F, System.Drawing.FontStyle.Bold);
            this.group_Response.Location = new System.Drawing.Point(586, 495);
            this.group_Response.Margin = new System.Windows.Forms.Padding(2);
            this.group_Response.Name = "group_Response";
            this.group_Response.Padding = new System.Windows.Forms.Padding(2);
            this.group_Response.Size = new System.Drawing.Size(258, 88);
            this.group_Response.TabIndex = 182;
            this.group_Response.TabStop = false;
            this.group_Response.Text = "Status";
            // 
            // label_Response
            // 
            this.label_Response.AutoSize = true;
            this.label_Response.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label_Response.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Response.Location = new System.Drawing.Point(17, 34);
            this.label_Response.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Response.Name = "label_Response";
            this.label_Response.Size = new System.Drawing.Size(50, 22);
            this.label_Response.TabIndex = 329;
            this.label_Response.Text = "----";
            // 
            // group_SHT2
            // 
            this.group_SHT2.Controls.Add(this.label_AH2);
            this.group_SHT2.Controls.Add(this.label_RH2);
            this.group_SHT2.Controls.Add(this.label_Temp2);
            this.group_SHT2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_SHT2.Location = new System.Drawing.Point(1128, 495);
            this.group_SHT2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_SHT2.Name = "group_SHT2";
            this.group_SHT2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 10);
            this.group_SHT2.Size = new System.Drawing.Size(134, 120);
            this.group_SHT2.TabIndex = 261;
            this.group_SHT2.TabStop = false;
            this.group_SHT2.Text = "SHT-30-U10";
            // 
            // label_AH2
            // 
            this.label_AH2.AutoSize = true;
            this.label_AH2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AH2.Location = new System.Drawing.Point(12, 88);
            this.label_AH2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_AH2.Name = "label_AH2";
            this.label_AH2.Size = new System.Drawing.Size(120, 22);
            this.label_AH2.TabIndex = 261;
            this.label_AH2.Text = "AbsHumidity";
            // 
            // label_RH2
            // 
            this.label_RH2.AutoSize = true;
            this.label_RH2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_RH2.Location = new System.Drawing.Point(12, 60);
            this.label_RH2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_RH2.Name = "label_RH2";
            this.label_RH2.Size = new System.Drawing.Size(90, 22);
            this.label_RH2.TabIndex = 0;
            this.label_RH2.Text = "Humidity";
            // 
            // label_Temp2
            // 
            this.label_Temp2.AutoSize = true;
            this.label_Temp2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Temp2.Location = new System.Drawing.Point(12, 32);
            this.label_Temp2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Temp2.Name = "label_Temp2";
            this.label_Temp2.Size = new System.Drawing.Size(50, 22);
            this.label_Temp2.TabIndex = 0;
            this.label_Temp2.Text = "Temp";
            // 
            // group_SHT3
            // 
            this.group_SHT3.Controls.Add(this.label_AH3);
            this.group_SHT3.Controls.Add(this.label_RH3);
            this.group_SHT3.Controls.Add(this.label_Temp3);
            this.group_SHT3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_SHT3.Location = new System.Drawing.Point(1267, 495);
            this.group_SHT3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_SHT3.Name = "group_SHT3";
            this.group_SHT3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 10);
            this.group_SHT3.Size = new System.Drawing.Size(134, 120);
            this.group_SHT3.TabIndex = 258;
            this.group_SHT3.TabStop = false;
            this.group_SHT3.Text = "SHT-30-U11";
            // 
            // label_AH3
            // 
            this.label_AH3.AutoSize = true;
            this.label_AH3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AH3.Location = new System.Drawing.Point(10, 88);
            this.label_AH3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_AH3.Name = "label_AH3";
            this.label_AH3.Size = new System.Drawing.Size(120, 22);
            this.label_AH3.TabIndex = 260;
            this.label_AH3.Text = "AbsHumidity";
            // 
            // label_RH3
            // 
            this.label_RH3.AutoSize = true;
            this.label_RH3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_RH3.Location = new System.Drawing.Point(10, 60);
            this.label_RH3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_RH3.Name = "label_RH3";
            this.label_RH3.Size = new System.Drawing.Size(90, 22);
            this.label_RH3.TabIndex = 3;
            this.label_RH3.Text = "Humidity";
            // 
            // label_Temp3
            // 
            this.label_Temp3.AutoSize = true;
            this.label_Temp3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Temp3.Location = new System.Drawing.Point(10, 32);
            this.label_Temp3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_Temp3.Name = "label_Temp3";
            this.label_Temp3.Size = new System.Drawing.Size(50, 22);
            this.label_Temp3.TabIndex = 4;
            this.label_Temp3.Text = "Temp";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 28);
            this.label2.TabIndex = 4;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.AlphFix_UpdateRate_Box);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.AlphFix_FileName_box);
            this.groupBox3.Controls.Add(this.label_AlphFix_time);
            this.groupBox3.Controls.Add(this.btn_AlphFix_cap);
            this.groupBox3.Controls.Add(this.btn_AlphFix_Log);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Font = new System.Drawing.Font("Consolas", 14F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(14, 168);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(201, 320);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Capture Data";
            // 
            // AlphFix_UpdateRate_Box
            // 
            this.AlphFix_UpdateRate_Box.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AlphFix_UpdateRate_Box.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AlphFix_UpdateRate_Box.Font = new System.Drawing.Font("Consolas", 13F);
            this.AlphFix_UpdateRate_Box.FormattingEnabled = true;
            this.AlphFix_UpdateRate_Box.Items.AddRange(new object[] {
            "5",
            "10",
            "20",
            "30",
            "60"});
            this.AlphFix_UpdateRate_Box.Location = new System.Drawing.Point(103, 125);
            this.AlphFix_UpdateRate_Box.Margin = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.AlphFix_UpdateRate_Box.Name = "AlphFix_UpdateRate_Box";
            this.AlphFix_UpdateRate_Box.Size = new System.Drawing.Size(85, 28);
            this.AlphFix_UpdateRate_Box.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(13, 153);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Padding = new System.Windows.Forms.Padding(0, 3, 25, 3);
            this.label5.Size = new System.Drawing.Size(175, 28);
            this.label5.TabIndex = 215;
            this.label5.Text = "FileName :    ";
            // 
            // AlphFix_FileName_box
            // 
            this.AlphFix_FileName_box.Font = new System.Drawing.Font("Consolas", 13F);
            this.AlphFix_FileName_box.Location = new System.Drawing.Point(13, 179);
            this.AlphFix_FileName_box.Margin = new System.Windows.Forms.Padding(0);
            this.AlphFix_FileName_box.MaxLength = 50;
            this.AlphFix_FileName_box.Name = "AlphFix_FileName_box";
            this.AlphFix_FileName_box.Size = new System.Drawing.Size(175, 28);
            this.AlphFix_FileName_box.TabIndex = 2;
            // 
            // label_AlphFix_time
            // 
            this.label_AlphFix_time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label_AlphFix_time.AutoSize = true;
            this.label_AlphFix_time.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AlphFix_time.Location = new System.Drawing.Point(33, 259);
            this.label_AlphFix_time.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_AlphFix_time.Name = "label_AlphFix_time";
            this.label_AlphFix_time.Size = new System.Drawing.Size(130, 22);
            this.label_AlphFix_time.TabIndex = 167;
            this.label_AlphFix_time.Text = "00 : 00 : 00";
            this.label_AlphFix_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_AlphFix_cap
            // 
            this.btn_AlphFix_cap.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_AlphFix_cap.Enabled = false;
            this.btn_AlphFix_cap.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_AlphFix_cap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AlphFix_cap.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_AlphFix_cap.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_AlphFix_cap.Location = new System.Drawing.Point(13, 207);
            this.btn_AlphFix_cap.Margin = new System.Windows.Forms.Padding(0);
            this.btn_AlphFix_cap.Name = "btn_AlphFix_cap";
            this.btn_AlphFix_cap.Size = new System.Drawing.Size(175, 40);
            this.btn_AlphFix_cap.TabIndex = 3;
            this.btn_AlphFix_cap.Text = "Start Cap";
            this.btn_AlphFix_cap.UseVisualStyleBackColor = false;
            this.btn_AlphFix_cap.Click += new System.EventHandler(this.btn_AlphFix_cap_Click);
            // 
            // btn_AlphFix_Log
            // 
            this.btn_AlphFix_Log.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_AlphFix_Log.Enabled = false;
            this.btn_AlphFix_Log.FlatAppearance.BorderColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_AlphFix_Log.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AlphFix_Log.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.btn_AlphFix_Log.Location = new System.Drawing.Point(13, 55);
            this.btn_AlphFix_Log.Margin = new System.Windows.Forms.Padding(10);
            this.btn_AlphFix_Log.Name = "btn_AlphFix_Log";
            this.btn_AlphFix_Log.Size = new System.Drawing.Size(175, 40);
            this.btn_AlphFix_Log.TabIndex = 0;
            this.btn_AlphFix_Log.Text = "Logging Data";
            this.btn_AlphFix_Log.UseVisualStyleBackColor = false;
            this.btn_AlphFix_Log.Click += new System.EventHandler(this.btn_AlphFix_Log_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(13, 125);
            this.label8.Margin = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.label8.Name = "label8";
            this.label8.Padding = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.label8.Size = new System.Drawing.Size(90, 28);
            this.label8.TabIndex = 165;
            this.label8.Text = "Time(s):";
            // 
            // tabSelect
            // 
            this.tabSelect.Controls.Add(this.tabPage_PCBA_WEAE);
            this.tabSelect.Controls.Add(this.tabPage_ADC);
            this.tabSelect.Controls.Add(this.tabPage_Zero);
            this.tabSelect.Controls.Add(this.tabPage_Span);
            this.tabSelect.Controls.Add(this.a);
            this.tabSelect.Controls.Add(this.b);
            this.tabSelect.Controls.Add(this.tabPage_GasName);
            this.tabSelect.Controls.Add(this.tabPage_BSN);
            this.tabSelect.Controls.Add(this.tabPage_FWV);
            this.tabSelect.Controls.Add(this.Cal_Date);
            this.tabSelect.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.tabSelect.Location = new System.Drawing.Point(233, 86);
            this.tabSelect.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabSelect.Name = "tabSelect";
            this.tabSelect.SelectedIndex = 0;
            this.tabSelect.Size = new System.Drawing.Size(1172, 402);
            this.tabSelect.TabIndex = 5;
            // 
            // tabPage_PCBA_WEAE
            // 
            this.tabPage_PCBA_WEAE.Controls.Add(this.tableLayoutPanel1);
            this.tabPage_PCBA_WEAE.Controls.Add(this.groupBox10);
            this.tabPage_PCBA_WEAE.Controls.Add(this.groupBox11);
            this.tabPage_PCBA_WEAE.Controls.Add(this.groupBox12);
            this.tabPage_PCBA_WEAE.Controls.Add(this.groupBox5);
            this.tabPage_PCBA_WEAE.Location = new System.Drawing.Point(4, 29);
            this.tabPage_PCBA_WEAE.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage_PCBA_WEAE.Name = "tabPage_PCBA_WEAE";
            this.tabPage_PCBA_WEAE.Size = new System.Drawing.Size(1164, 369);
            this.tabPage_PCBA_WEAE.TabIndex = 8;
            this.tabPage_PCBA_WEAE.Text = "　【PCBA_WEAE】\n ";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA23, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA22, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA21, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA20, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA19, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA18, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA17, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA16, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA15, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA14, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA13, 6, 1);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA12, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA11, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA10, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA9, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA8, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA7, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA6, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA5, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA4, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA3, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.group_PCBA0, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1164, 369);
            this.tableLayoutPanel1.TabIndex = 213;
            // 
            // group_PCBA23
            // 
            this.group_PCBA23.Controls.Add(this.label_WE23);
            this.group_PCBA23.Controls.Add(this.label_AE23);
            this.group_PCBA23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA23.Location = new System.Drawing.Point(335, 278);
            this.group_PCBA23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA23.Name = "group_PCBA23";
            this.group_PCBA23.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA23.Size = new System.Drawing.Size(160, 89);
            this.group_PCBA23.TabIndex = 199;
            this.group_PCBA23.TabStop = false;
            this.group_PCBA23.Text = "ID_23";
            // 
            // label_WE23
            // 
            this.label_WE23.AutoSize = true;
            this.label_WE23.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE23.Location = new System.Drawing.Point(10, 30);
            this.label_WE23.Name = "label_WE23";
            this.label_WE23.Size = new System.Drawing.Size(90, 22);
            this.label_WE23.TabIndex = 63;
            this.label_WE23.Text = "WE Value";
            // 
            // label_AE23
            // 
            this.label_AE23.AutoSize = true;
            this.label_AE23.BackColor = System.Drawing.Color.HotPink;
            this.label_AE23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE23.Location = new System.Drawing.Point(10, 52);
            this.label_AE23.Name = "label_AE23";
            this.label_AE23.Size = new System.Drawing.Size(90, 22);
            this.label_AE23.TabIndex = 64;
            this.label_AE23.Text = "AE Value";
            // 
            // group_PCBA22
            // 
            this.group_PCBA22.Controls.Add(this.label_WE22);
            this.group_PCBA22.Controls.Add(this.label_AE22);
            this.group_PCBA22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA22.Location = new System.Drawing.Point(169, 278);
            this.group_PCBA22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA22.Name = "group_PCBA22";
            this.group_PCBA22.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA22.Size = new System.Drawing.Size(160, 89);
            this.group_PCBA22.TabIndex = 204;
            this.group_PCBA22.TabStop = false;
            this.group_PCBA22.Text = "ID_22";
            // 
            // label_WE22
            // 
            this.label_WE22.AutoSize = true;
            this.label_WE22.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE22.Location = new System.Drawing.Point(10, 30);
            this.label_WE22.Name = "label_WE22";
            this.label_WE22.Size = new System.Drawing.Size(90, 22);
            this.label_WE22.TabIndex = 63;
            this.label_WE22.Text = "WE Value";
            // 
            // label_AE22
            // 
            this.label_AE22.AutoSize = true;
            this.label_AE22.BackColor = System.Drawing.Color.HotPink;
            this.label_AE22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE22.Location = new System.Drawing.Point(10, 52);
            this.label_AE22.Name = "label_AE22";
            this.label_AE22.Size = new System.Drawing.Size(90, 22);
            this.label_AE22.TabIndex = 64;
            this.label_AE22.Text = "AE Value";
            // 
            // group_PCBA21
            // 
            this.group_PCBA21.Controls.Add(this.label_WE21);
            this.group_PCBA21.Controls.Add(this.label_AE21);
            this.group_PCBA21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA21.Location = new System.Drawing.Point(3, 278);
            this.group_PCBA21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA21.Name = "group_PCBA21";
            this.group_PCBA21.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA21.Size = new System.Drawing.Size(160, 89);
            this.group_PCBA21.TabIndex = 208;
            this.group_PCBA21.TabStop = false;
            this.group_PCBA21.Text = "ID_21";
            // 
            // label_WE21
            // 
            this.label_WE21.AutoSize = true;
            this.label_WE21.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE21.Location = new System.Drawing.Point(10, 30);
            this.label_WE21.Name = "label_WE21";
            this.label_WE21.Size = new System.Drawing.Size(90, 22);
            this.label_WE21.TabIndex = 63;
            this.label_WE21.Text = "WE Value";
            // 
            // label_AE21
            // 
            this.label_AE21.AutoSize = true;
            this.label_AE21.BackColor = System.Drawing.Color.HotPink;
            this.label_AE21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE21.Location = new System.Drawing.Point(10, 52);
            this.label_AE21.Name = "label_AE21";
            this.label_AE21.Size = new System.Drawing.Size(90, 22);
            this.label_AE21.TabIndex = 64;
            this.label_AE21.Text = "AE Value";
            // 
            // group_PCBA20
            // 
            this.group_PCBA20.Controls.Add(this.label_WE20);
            this.group_PCBA20.Controls.Add(this.label_AE20);
            this.group_PCBA20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA20.Location = new System.Drawing.Point(999, 186);
            this.group_PCBA20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA20.Name = "group_PCBA20";
            this.group_PCBA20.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA20.Size = new System.Drawing.Size(162, 88);
            this.group_PCBA20.TabIndex = 178;
            this.group_PCBA20.TabStop = false;
            this.group_PCBA20.Text = "ID_20";
            // 
            // label_WE20
            // 
            this.label_WE20.AutoSize = true;
            this.label_WE20.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE20.Location = new System.Drawing.Point(10, 30);
            this.label_WE20.Name = "label_WE20";
            this.label_WE20.Size = new System.Drawing.Size(90, 22);
            this.label_WE20.TabIndex = 63;
            this.label_WE20.Text = "WE Value";
            // 
            // label_AE20
            // 
            this.label_AE20.AutoSize = true;
            this.label_AE20.BackColor = System.Drawing.Color.HotPink;
            this.label_AE20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE20.Location = new System.Drawing.Point(10, 52);
            this.label_AE20.Name = "label_AE20";
            this.label_AE20.Size = new System.Drawing.Size(90, 22);
            this.label_AE20.TabIndex = 64;
            this.label_AE20.Text = "AE Value";
            // 
            // group_PCBA19
            // 
            this.group_PCBA19.Controls.Add(this.label_WE19);
            this.group_PCBA19.Controls.Add(this.label_AE19);
            this.group_PCBA19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.group_PCBA19.Location = new System.Drawing.Point(833, 186);
            this.group_PCBA19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA19.Name = "group_PCBA19";
            this.group_PCBA19.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA19.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA19.TabIndex = 183;
            this.group_PCBA19.TabStop = false;
            this.group_PCBA19.Text = "ID_19";
            // 
            // label_WE19
            // 
            this.label_WE19.AutoSize = true;
            this.label_WE19.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE19.Location = new System.Drawing.Point(10, 30);
            this.label_WE19.Name = "label_WE19";
            this.label_WE19.Size = new System.Drawing.Size(90, 22);
            this.label_WE19.TabIndex = 63;
            this.label_WE19.Text = "WE Value";
            // 
            // label_AE19
            // 
            this.label_AE19.AutoSize = true;
            this.label_AE19.BackColor = System.Drawing.Color.HotPink;
            this.label_AE19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE19.Location = new System.Drawing.Point(10, 52);
            this.label_AE19.Name = "label_AE19";
            this.label_AE19.Size = new System.Drawing.Size(90, 22);
            this.label_AE19.TabIndex = 64;
            this.label_AE19.Text = "AE Value";
            // 
            // group_PCBA18
            // 
            this.group_PCBA18.Controls.Add(this.label_WE18);
            this.group_PCBA18.Controls.Add(this.label_AE18);
            this.group_PCBA18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA18.Location = new System.Drawing.Point(667, 186);
            this.group_PCBA18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA18.Name = "group_PCBA18";
            this.group_PCBA18.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA18.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA18.TabIndex = 188;
            this.group_PCBA18.TabStop = false;
            this.group_PCBA18.Text = "ID_18";
            // 
            // label_WE18
            // 
            this.label_WE18.AutoSize = true;
            this.label_WE18.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE18.Location = new System.Drawing.Point(10, 30);
            this.label_WE18.Name = "label_WE18";
            this.label_WE18.Size = new System.Drawing.Size(90, 22);
            this.label_WE18.TabIndex = 63;
            this.label_WE18.Text = "WE Value";
            // 
            // label_AE18
            // 
            this.label_AE18.AutoSize = true;
            this.label_AE18.BackColor = System.Drawing.Color.HotPink;
            this.label_AE18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE18.Location = new System.Drawing.Point(10, 52);
            this.label_AE18.Name = "label_AE18";
            this.label_AE18.Size = new System.Drawing.Size(90, 22);
            this.label_AE18.TabIndex = 64;
            this.label_AE18.Text = "AE Value";
            // 
            // group_PCBA17
            // 
            this.group_PCBA17.Controls.Add(this.label_WE17);
            this.group_PCBA17.Controls.Add(this.label_AE17);
            this.group_PCBA17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA17.Location = new System.Drawing.Point(501, 186);
            this.group_PCBA17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA17.Name = "group_PCBA17";
            this.group_PCBA17.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA17.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA17.TabIndex = 193;
            this.group_PCBA17.TabStop = false;
            this.group_PCBA17.Text = "ID_17";
            // 
            // label_WE17
            // 
            this.label_WE17.AutoSize = true;
            this.label_WE17.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE17.Location = new System.Drawing.Point(10, 30);
            this.label_WE17.Name = "label_WE17";
            this.label_WE17.Size = new System.Drawing.Size(90, 22);
            this.label_WE17.TabIndex = 63;
            this.label_WE17.Text = "WE Value";
            // 
            // label_AE17
            // 
            this.label_AE17.AutoSize = true;
            this.label_AE17.BackColor = System.Drawing.Color.HotPink;
            this.label_AE17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE17.Location = new System.Drawing.Point(10, 52);
            this.label_AE17.Name = "label_AE17";
            this.label_AE17.Size = new System.Drawing.Size(90, 22);
            this.label_AE17.TabIndex = 64;
            this.label_AE17.Text = "AE Value";
            // 
            // group_PCBA16
            // 
            this.group_PCBA16.Controls.Add(this.label_WE16);
            this.group_PCBA16.Controls.Add(this.label_AE16);
            this.group_PCBA16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA16.Location = new System.Drawing.Point(335, 186);
            this.group_PCBA16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA16.Name = "group_PCBA16";
            this.group_PCBA16.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA16.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA16.TabIndex = 198;
            this.group_PCBA16.TabStop = false;
            this.group_PCBA16.Text = "ID_16";
            // 
            // label_WE16
            // 
            this.label_WE16.AutoSize = true;
            this.label_WE16.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE16.Location = new System.Drawing.Point(10, 30);
            this.label_WE16.Name = "label_WE16";
            this.label_WE16.Size = new System.Drawing.Size(90, 22);
            this.label_WE16.TabIndex = 63;
            this.label_WE16.Text = "WE Value";
            // 
            // label_AE16
            // 
            this.label_AE16.AutoSize = true;
            this.label_AE16.BackColor = System.Drawing.Color.HotPink;
            this.label_AE16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE16.Location = new System.Drawing.Point(10, 52);
            this.label_AE16.Name = "label_AE16";
            this.label_AE16.Size = new System.Drawing.Size(90, 22);
            this.label_AE16.TabIndex = 64;
            this.label_AE16.Text = "AE Value";
            // 
            // group_PCBA15
            // 
            this.group_PCBA15.Controls.Add(this.label_WE15);
            this.group_PCBA15.Controls.Add(this.label_AE15);
            this.group_PCBA15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA15.Location = new System.Drawing.Point(169, 186);
            this.group_PCBA15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA15.Name = "group_PCBA15";
            this.group_PCBA15.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA15.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA15.TabIndex = 203;
            this.group_PCBA15.TabStop = false;
            this.group_PCBA15.Text = "ID_15";
            // 
            // label_WE15
            // 
            this.label_WE15.AutoSize = true;
            this.label_WE15.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE15.Location = new System.Drawing.Point(10, 30);
            this.label_WE15.Name = "label_WE15";
            this.label_WE15.Size = new System.Drawing.Size(90, 22);
            this.label_WE15.TabIndex = 63;
            this.label_WE15.Text = "WE Value";
            // 
            // label_AE15
            // 
            this.label_AE15.AutoSize = true;
            this.label_AE15.BackColor = System.Drawing.Color.HotPink;
            this.label_AE15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE15.Location = new System.Drawing.Point(10, 52);
            this.label_AE15.Name = "label_AE15";
            this.label_AE15.Size = new System.Drawing.Size(90, 22);
            this.label_AE15.TabIndex = 64;
            this.label_AE15.Text = "AE Value";
            // 
            // group_PCBA14
            // 
            this.group_PCBA14.Controls.Add(this.label_WE14);
            this.group_PCBA14.Controls.Add(this.label_AE14);
            this.group_PCBA14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA14.Location = new System.Drawing.Point(3, 186);
            this.group_PCBA14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA14.Name = "group_PCBA14";
            this.group_PCBA14.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA14.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA14.TabIndex = 207;
            this.group_PCBA14.TabStop = false;
            this.group_PCBA14.Text = "ID_14";
            // 
            // label_WE14
            // 
            this.label_WE14.AutoSize = true;
            this.label_WE14.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE14.Location = new System.Drawing.Point(10, 30);
            this.label_WE14.Name = "label_WE14";
            this.label_WE14.Size = new System.Drawing.Size(90, 22);
            this.label_WE14.TabIndex = 63;
            this.label_WE14.Text = "WE Value";
            // 
            // label_AE14
            // 
            this.label_AE14.AutoSize = true;
            this.label_AE14.BackColor = System.Drawing.Color.HotPink;
            this.label_AE14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE14.Location = new System.Drawing.Point(10, 52);
            this.label_AE14.Name = "label_AE14";
            this.label_AE14.Size = new System.Drawing.Size(90, 22);
            this.label_AE14.TabIndex = 64;
            this.label_AE14.Text = "AE Value";
            // 
            // group_PCBA13
            // 
            this.group_PCBA13.Controls.Add(this.label_WE13);
            this.group_PCBA13.Controls.Add(this.label_AE13);
            this.group_PCBA13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA13.Location = new System.Drawing.Point(999, 94);
            this.group_PCBA13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA13.Name = "group_PCBA13";
            this.group_PCBA13.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA13.Size = new System.Drawing.Size(162, 88);
            this.group_PCBA13.TabIndex = 177;
            this.group_PCBA13.TabStop = false;
            this.group_PCBA13.Text = "ID_13";
            // 
            // label_WE13
            // 
            this.label_WE13.AutoSize = true;
            this.label_WE13.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE13.Location = new System.Drawing.Point(10, 30);
            this.label_WE13.Name = "label_WE13";
            this.label_WE13.Size = new System.Drawing.Size(90, 22);
            this.label_WE13.TabIndex = 63;
            this.label_WE13.Text = "WE Value";
            // 
            // label_AE13
            // 
            this.label_AE13.AutoSize = true;
            this.label_AE13.BackColor = System.Drawing.Color.HotPink;
            this.label_AE13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE13.Location = new System.Drawing.Point(10, 52);
            this.label_AE13.Name = "label_AE13";
            this.label_AE13.Size = new System.Drawing.Size(90, 22);
            this.label_AE13.TabIndex = 64;
            this.label_AE13.Text = "AE Value";
            // 
            // group_PCBA12
            // 
            this.group_PCBA12.Controls.Add(this.label_WE12);
            this.group_PCBA12.Controls.Add(this.label_AE12);
            this.group_PCBA12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA12.Location = new System.Drawing.Point(833, 94);
            this.group_PCBA12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA12.Name = "group_PCBA12";
            this.group_PCBA12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA12.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA12.TabIndex = 182;
            this.group_PCBA12.TabStop = false;
            this.group_PCBA12.Text = "ID_12";
            // 
            // label_WE12
            // 
            this.label_WE12.AutoSize = true;
            this.label_WE12.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE12.Location = new System.Drawing.Point(10, 30);
            this.label_WE12.Name = "label_WE12";
            this.label_WE12.Size = new System.Drawing.Size(90, 22);
            this.label_WE12.TabIndex = 63;
            this.label_WE12.Text = "WE Value";
            // 
            // label_AE12
            // 
            this.label_AE12.AutoSize = true;
            this.label_AE12.BackColor = System.Drawing.Color.HotPink;
            this.label_AE12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE12.Location = new System.Drawing.Point(10, 52);
            this.label_AE12.Name = "label_AE12";
            this.label_AE12.Size = new System.Drawing.Size(90, 22);
            this.label_AE12.TabIndex = 64;
            this.label_AE12.Text = "AE Value";
            // 
            // group_PCBA11
            // 
            this.group_PCBA11.Controls.Add(this.label_WE11);
            this.group_PCBA11.Controls.Add(this.label_AE11);
            this.group_PCBA11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA11.Location = new System.Drawing.Point(667, 94);
            this.group_PCBA11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA11.Name = "group_PCBA11";
            this.group_PCBA11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA11.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA11.TabIndex = 187;
            this.group_PCBA11.TabStop = false;
            this.group_PCBA11.Text = "ID_11";
            // 
            // label_WE11
            // 
            this.label_WE11.AutoSize = true;
            this.label_WE11.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE11.Location = new System.Drawing.Point(10, 30);
            this.label_WE11.Name = "label_WE11";
            this.label_WE11.Size = new System.Drawing.Size(90, 22);
            this.label_WE11.TabIndex = 63;
            this.label_WE11.Text = "WE Value";
            // 
            // label_AE11
            // 
            this.label_AE11.AutoSize = true;
            this.label_AE11.BackColor = System.Drawing.Color.HotPink;
            this.label_AE11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE11.Location = new System.Drawing.Point(10, 52);
            this.label_AE11.Name = "label_AE11";
            this.label_AE11.Size = new System.Drawing.Size(90, 22);
            this.label_AE11.TabIndex = 64;
            this.label_AE11.Text = "AE Value";
            // 
            // group_PCBA10
            // 
            this.group_PCBA10.Controls.Add(this.label_WE10);
            this.group_PCBA10.Controls.Add(this.label_AE10);
            this.group_PCBA10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA10.Location = new System.Drawing.Point(501, 94);
            this.group_PCBA10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA10.Name = "group_PCBA10";
            this.group_PCBA10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA10.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA10.TabIndex = 192;
            this.group_PCBA10.TabStop = false;
            this.group_PCBA10.Text = "ID_10";
            // 
            // label_WE10
            // 
            this.label_WE10.AutoSize = true;
            this.label_WE10.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE10.Location = new System.Drawing.Point(10, 30);
            this.label_WE10.Name = "label_WE10";
            this.label_WE10.Size = new System.Drawing.Size(90, 22);
            this.label_WE10.TabIndex = 63;
            this.label_WE10.Text = "WE Value";
            // 
            // label_AE10
            // 
            this.label_AE10.AutoSize = true;
            this.label_AE10.BackColor = System.Drawing.Color.HotPink;
            this.label_AE10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE10.Location = new System.Drawing.Point(10, 52);
            this.label_AE10.Name = "label_AE10";
            this.label_AE10.Size = new System.Drawing.Size(90, 22);
            this.label_AE10.TabIndex = 64;
            this.label_AE10.Text = "AE Value";
            // 
            // group_PCBA9
            // 
            this.group_PCBA9.Controls.Add(this.label_WE9);
            this.group_PCBA9.Controls.Add(this.label_AE9);
            this.group_PCBA9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA9.Location = new System.Drawing.Point(335, 94);
            this.group_PCBA9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA9.Name = "group_PCBA9";
            this.group_PCBA9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA9.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA9.TabIndex = 197;
            this.group_PCBA9.TabStop = false;
            this.group_PCBA9.Text = "ID_9";
            // 
            // label_WE9
            // 
            this.label_WE9.AutoSize = true;
            this.label_WE9.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE9.Location = new System.Drawing.Point(10, 22);
            this.label_WE9.Name = "label_WE9";
            this.label_WE9.Size = new System.Drawing.Size(90, 22);
            this.label_WE9.TabIndex = 63;
            this.label_WE9.Text = "WE Value";
            // 
            // label_AE9
            // 
            this.label_AE9.AutoSize = true;
            this.label_AE9.BackColor = System.Drawing.Color.HotPink;
            this.label_AE9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE9.Location = new System.Drawing.Point(10, 44);
            this.label_AE9.Name = "label_AE9";
            this.label_AE9.Size = new System.Drawing.Size(90, 22);
            this.label_AE9.TabIndex = 64;
            this.label_AE9.Text = "AE Value";
            // 
            // group_PCBA8
            // 
            this.group_PCBA8.Controls.Add(this.label_WE8);
            this.group_PCBA8.Controls.Add(this.label_AE8);
            this.group_PCBA8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA8.Location = new System.Drawing.Point(169, 94);
            this.group_PCBA8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA8.Name = "group_PCBA8";
            this.group_PCBA8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA8.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA8.TabIndex = 202;
            this.group_PCBA8.TabStop = false;
            this.group_PCBA8.Text = "ID_8";
            // 
            // label_WE8
            // 
            this.label_WE8.AutoSize = true;
            this.label_WE8.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE8.Location = new System.Drawing.Point(10, 30);
            this.label_WE8.Name = "label_WE8";
            this.label_WE8.Size = new System.Drawing.Size(90, 22);
            this.label_WE8.TabIndex = 63;
            this.label_WE8.Text = "WE Value";
            // 
            // label_AE8
            // 
            this.label_AE8.AutoSize = true;
            this.label_AE8.BackColor = System.Drawing.Color.HotPink;
            this.label_AE8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE8.Location = new System.Drawing.Point(10, 52);
            this.label_AE8.Name = "label_AE8";
            this.label_AE8.Size = new System.Drawing.Size(90, 22);
            this.label_AE8.TabIndex = 64;
            this.label_AE8.Text = "AE Value";
            // 
            // group_PCBA7
            // 
            this.group_PCBA7.Controls.Add(this.label_WE7);
            this.group_PCBA7.Controls.Add(this.label_AE7);
            this.group_PCBA7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA7.Location = new System.Drawing.Point(3, 94);
            this.group_PCBA7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA7.Name = "group_PCBA7";
            this.group_PCBA7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA7.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA7.TabIndex = 206;
            this.group_PCBA7.TabStop = false;
            this.group_PCBA7.Text = "ID_7";
            // 
            // label_WE7
            // 
            this.label_WE7.AutoSize = true;
            this.label_WE7.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE7.Location = new System.Drawing.Point(10, 30);
            this.label_WE7.Name = "label_WE7";
            this.label_WE7.Size = new System.Drawing.Size(90, 22);
            this.label_WE7.TabIndex = 63;
            this.label_WE7.Text = "WE Value";
            // 
            // label_AE7
            // 
            this.label_AE7.AutoSize = true;
            this.label_AE7.BackColor = System.Drawing.Color.HotPink;
            this.label_AE7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE7.Location = new System.Drawing.Point(10, 52);
            this.label_AE7.Name = "label_AE7";
            this.label_AE7.Size = new System.Drawing.Size(90, 22);
            this.label_AE7.TabIndex = 64;
            this.label_AE7.Text = "AE Value";
            // 
            // group_PCBA6
            // 
            this.group_PCBA6.Controls.Add(this.label_WE6);
            this.group_PCBA6.Controls.Add(this.label_AE6);
            this.group_PCBA6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA6.Location = new System.Drawing.Point(999, 2);
            this.group_PCBA6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA6.Name = "group_PCBA6";
            this.group_PCBA6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA6.Size = new System.Drawing.Size(162, 88);
            this.group_PCBA6.TabIndex = 176;
            this.group_PCBA6.TabStop = false;
            this.group_PCBA6.Text = "ID_6";
            // 
            // label_WE6
            // 
            this.label_WE6.AutoSize = true;
            this.label_WE6.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE6.Location = new System.Drawing.Point(10, 30);
            this.label_WE6.Name = "label_WE6";
            this.label_WE6.Size = new System.Drawing.Size(90, 22);
            this.label_WE6.TabIndex = 63;
            this.label_WE6.Text = "WE Value";
            // 
            // label_AE6
            // 
            this.label_AE6.AutoSize = true;
            this.label_AE6.BackColor = System.Drawing.Color.HotPink;
            this.label_AE6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE6.Location = new System.Drawing.Point(10, 52);
            this.label_AE6.Name = "label_AE6";
            this.label_AE6.Size = new System.Drawing.Size(90, 22);
            this.label_AE6.TabIndex = 64;
            this.label_AE6.Text = "AE Value";
            // 
            // group_PCBA5
            // 
            this.group_PCBA5.Controls.Add(this.label_WE5);
            this.group_PCBA5.Controls.Add(this.label_AE5);
            this.group_PCBA5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA5.Location = new System.Drawing.Point(833, 2);
            this.group_PCBA5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA5.Name = "group_PCBA5";
            this.group_PCBA5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA5.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA5.TabIndex = 181;
            this.group_PCBA5.TabStop = false;
            this.group_PCBA5.Text = "ID_5";
            // 
            // label_WE5
            // 
            this.label_WE5.AutoSize = true;
            this.label_WE5.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE5.Location = new System.Drawing.Point(10, 30);
            this.label_WE5.Name = "label_WE5";
            this.label_WE5.Size = new System.Drawing.Size(90, 22);
            this.label_WE5.TabIndex = 63;
            this.label_WE5.Text = "WE Value";
            // 
            // label_AE5
            // 
            this.label_AE5.AutoSize = true;
            this.label_AE5.BackColor = System.Drawing.Color.HotPink;
            this.label_AE5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE5.Location = new System.Drawing.Point(10, 52);
            this.label_AE5.Name = "label_AE5";
            this.label_AE5.Size = new System.Drawing.Size(90, 22);
            this.label_AE5.TabIndex = 64;
            this.label_AE5.Text = "AE Value";
            // 
            // group_PCBA4
            // 
            this.group_PCBA4.Controls.Add(this.label_WE4);
            this.group_PCBA4.Controls.Add(this.label_AE4);
            this.group_PCBA4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA4.Location = new System.Drawing.Point(667, 2);
            this.group_PCBA4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA4.Name = "group_PCBA4";
            this.group_PCBA4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA4.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA4.TabIndex = 186;
            this.group_PCBA4.TabStop = false;
            this.group_PCBA4.Text = "ID_4";
            // 
            // label_WE4
            // 
            this.label_WE4.AutoSize = true;
            this.label_WE4.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE4.Location = new System.Drawing.Point(10, 30);
            this.label_WE4.Name = "label_WE4";
            this.label_WE4.Size = new System.Drawing.Size(90, 22);
            this.label_WE4.TabIndex = 63;
            this.label_WE4.Text = "WE Value";
            // 
            // label_AE4
            // 
            this.label_AE4.AutoSize = true;
            this.label_AE4.BackColor = System.Drawing.Color.HotPink;
            this.label_AE4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE4.Location = new System.Drawing.Point(10, 52);
            this.label_AE4.Name = "label_AE4";
            this.label_AE4.Size = new System.Drawing.Size(90, 22);
            this.label_AE4.TabIndex = 64;
            this.label_AE4.Text = "AE Value";
            // 
            // group_PCBA3
            // 
            this.group_PCBA3.Controls.Add(this.label_WE3);
            this.group_PCBA3.Controls.Add(this.label_AE3);
            this.group_PCBA3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA3.Location = new System.Drawing.Point(501, 2);
            this.group_PCBA3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA3.Name = "group_PCBA3";
            this.group_PCBA3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA3.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA3.TabIndex = 191;
            this.group_PCBA3.TabStop = false;
            this.group_PCBA3.Text = "ID_3";
            // 
            // label_WE3
            // 
            this.label_WE3.AutoSize = true;
            this.label_WE3.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE3.Location = new System.Drawing.Point(10, 30);
            this.label_WE3.Name = "label_WE3";
            this.label_WE3.Size = new System.Drawing.Size(90, 22);
            this.label_WE3.TabIndex = 63;
            this.label_WE3.Text = "WE Value";
            // 
            // label_AE3
            // 
            this.label_AE3.AutoSize = true;
            this.label_AE3.BackColor = System.Drawing.Color.HotPink;
            this.label_AE3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE3.Location = new System.Drawing.Point(10, 52);
            this.label_AE3.Name = "label_AE3";
            this.label_AE3.Size = new System.Drawing.Size(90, 22);
            this.label_AE3.TabIndex = 64;
            this.label_AE3.Text = "AE Value";
            // 
            // group_PCBA2
            // 
            this.group_PCBA2.Controls.Add(this.label_WE2);
            this.group_PCBA2.Controls.Add(this.label_AE2);
            this.group_PCBA2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA2.Location = new System.Drawing.Point(335, 2);
            this.group_PCBA2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA2.Name = "group_PCBA2";
            this.group_PCBA2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA2.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA2.TabIndex = 196;
            this.group_PCBA2.TabStop = false;
            this.group_PCBA2.Text = "ID_2";
            // 
            // label_WE2
            // 
            this.label_WE2.AutoSize = true;
            this.label_WE2.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE2.Location = new System.Drawing.Point(10, 30);
            this.label_WE2.Name = "label_WE2";
            this.label_WE2.Size = new System.Drawing.Size(90, 22);
            this.label_WE2.TabIndex = 63;
            this.label_WE2.Text = "WE Value";
            // 
            // label_AE2
            // 
            this.label_AE2.AutoSize = true;
            this.label_AE2.BackColor = System.Drawing.Color.HotPink;
            this.label_AE2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE2.Location = new System.Drawing.Point(10, 52);
            this.label_AE2.Name = "label_AE2";
            this.label_AE2.Size = new System.Drawing.Size(90, 22);
            this.label_AE2.TabIndex = 64;
            this.label_AE2.Text = "AE Value";
            // 
            // group_PCBA1
            // 
            this.group_PCBA1.Controls.Add(this.label_WE1);
            this.group_PCBA1.Controls.Add(this.label_AE1);
            this.group_PCBA1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA1.Location = new System.Drawing.Point(169, 2);
            this.group_PCBA1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA1.Name = "group_PCBA1";
            this.group_PCBA1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA1.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA1.TabIndex = 201;
            this.group_PCBA1.TabStop = false;
            this.group_PCBA1.Text = "ID_1";
            // 
            // label_WE1
            // 
            this.label_WE1.AutoSize = true;
            this.label_WE1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE1.Location = new System.Drawing.Point(10, 30);
            this.label_WE1.Name = "label_WE1";
            this.label_WE1.Size = new System.Drawing.Size(90, 22);
            this.label_WE1.TabIndex = 63;
            this.label_WE1.Text = "WE Value";
            // 
            // label_AE1
            // 
            this.label_AE1.AutoSize = true;
            this.label_AE1.BackColor = System.Drawing.Color.HotPink;
            this.label_AE1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE1.Location = new System.Drawing.Point(10, 52);
            this.label_AE1.Name = "label_AE1";
            this.label_AE1.Size = new System.Drawing.Size(90, 22);
            this.label_AE1.TabIndex = 64;
            this.label_AE1.Text = "AE Value";
            // 
            // group_PCBA0
            // 
            this.group_PCBA0.BackColor = System.Drawing.SystemColors.Control;
            this.group_PCBA0.Controls.Add(this.label_WE0);
            this.group_PCBA0.Controls.Add(this.label_AE0);
            this.group_PCBA0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_PCBA0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_PCBA0.Location = new System.Drawing.Point(3, 2);
            this.group_PCBA0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA0.Name = "group_PCBA0";
            this.group_PCBA0.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_PCBA0.Size = new System.Drawing.Size(160, 88);
            this.group_PCBA0.TabIndex = 174;
            this.group_PCBA0.TabStop = false;
            this.group_PCBA0.Text = "ID_0";
            // 
            // label_WE0
            // 
            this.label_WE0.AutoSize = true;
            this.label_WE0.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label_WE0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_WE0.Location = new System.Drawing.Point(10, 30);
            this.label_WE0.Name = "label_WE0";
            this.label_WE0.Size = new System.Drawing.Size(90, 22);
            this.label_WE0.TabIndex = 63;
            this.label_WE0.Text = "WE Value";
            this.label_WE0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label_AE0
            // 
            this.label_AE0.AutoSize = true;
            this.label_AE0.BackColor = System.Drawing.Color.HotPink;
            this.label_AE0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_AE0.Location = new System.Drawing.Point(10, 52);
            this.label_AE0.Name = "label_AE0";
            this.label_AE0.Size = new System.Drawing.Size(90, 22);
            this.label_AE0.TabIndex = 64;
            this.label_AE0.Text = "AE Value";
            this.label_AE0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label_PCBA_WEAE_Humidity1);
            this.groupBox10.Controls.Add(this.label_PCBA_WEAE_Temp1);
            this.groupBox10.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox10.Location = new System.Drawing.Point(842, 842);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Size = new System.Drawing.Size(134, 74);
            this.groupBox10.TabIndex = 210;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "SHT-30-U8";
            // 
            // label_PCBA_WEAE_Humidity1
            // 
            this.label_PCBA_WEAE_Humidity1.AutoSize = true;
            this.label_PCBA_WEAE_Humidity1.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_PCBA_WEAE_Humidity1.Location = new System.Drawing.Point(10, 46);
            this.label_PCBA_WEAE_Humidity1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_PCBA_WEAE_Humidity1.Name = "label_PCBA_WEAE_Humidity1";
            this.label_PCBA_WEAE_Humidity1.Size = new System.Drawing.Size(95, 24);
            this.label_PCBA_WEAE_Humidity1.TabIndex = 0;
            this.label_PCBA_WEAE_Humidity1.Text = "Humidity";
            // 
            // label_PCBA_WEAE_Temp1
            // 
            this.label_PCBA_WEAE_Temp1.AutoSize = true;
            this.label_PCBA_WEAE_Temp1.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_PCBA_WEAE_Temp1.Location = new System.Drawing.Point(12, 22);
            this.label_PCBA_WEAE_Temp1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_PCBA_WEAE_Temp1.Name = "label_PCBA_WEAE_Temp1";
            this.label_PCBA_WEAE_Temp1.Size = new System.Drawing.Size(63, 24);
            this.label_PCBA_WEAE_Temp1.TabIndex = 0;
            this.label_PCBA_WEAE_Temp1.Text = "Temp";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label_PCBA_WEAE_Humidity2);
            this.groupBox11.Controls.Add(this.label_PCBA_WEAE_Temp2);
            this.groupBox11.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox11.Location = new System.Drawing.Point(1049, 842);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox11.Size = new System.Drawing.Size(134, 74);
            this.groupBox11.TabIndex = 211;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "SHT-30-U9";
            // 
            // label_PCBA_WEAE_Humidity2
            // 
            this.label_PCBA_WEAE_Humidity2.AutoSize = true;
            this.label_PCBA_WEAE_Humidity2.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_PCBA_WEAE_Humidity2.Location = new System.Drawing.Point(10, 46);
            this.label_PCBA_WEAE_Humidity2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_PCBA_WEAE_Humidity2.Name = "label_PCBA_WEAE_Humidity2";
            this.label_PCBA_WEAE_Humidity2.Size = new System.Drawing.Size(95, 24);
            this.label_PCBA_WEAE_Humidity2.TabIndex = 0;
            this.label_PCBA_WEAE_Humidity2.Text = "Humidity";
            // 
            // label_PCBA_WEAE_Temp2
            // 
            this.label_PCBA_WEAE_Temp2.AutoSize = true;
            this.label_PCBA_WEAE_Temp2.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_PCBA_WEAE_Temp2.Location = new System.Drawing.Point(12, 22);
            this.label_PCBA_WEAE_Temp2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_PCBA_WEAE_Temp2.Name = "label_PCBA_WEAE_Temp2";
            this.label_PCBA_WEAE_Temp2.Size = new System.Drawing.Size(63, 24);
            this.label_PCBA_WEAE_Temp2.TabIndex = 0;
            this.label_PCBA_WEAE_Temp2.Text = "Temp";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label_PCBA_WEAE_Humidity3);
            this.groupBox12.Controls.Add(this.label_PCBA_WEAE_Temp3);
            this.groupBox12.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox12.Location = new System.Drawing.Point(1257, 842);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox12.Size = new System.Drawing.Size(134, 74);
            this.groupBox12.TabIndex = 212;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "SHT-30-U10";
            // 
            // label_PCBA_WEAE_Humidity3
            // 
            this.label_PCBA_WEAE_Humidity3.AutoSize = true;
            this.label_PCBA_WEAE_Humidity3.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_PCBA_WEAE_Humidity3.Location = new System.Drawing.Point(10, 46);
            this.label_PCBA_WEAE_Humidity3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_PCBA_WEAE_Humidity3.Name = "label_PCBA_WEAE_Humidity3";
            this.label_PCBA_WEAE_Humidity3.Size = new System.Drawing.Size(95, 24);
            this.label_PCBA_WEAE_Humidity3.TabIndex = 0;
            this.label_PCBA_WEAE_Humidity3.Text = "Humidity";
            // 
            // label_PCBA_WEAE_Temp3
            // 
            this.label_PCBA_WEAE_Temp3.AutoSize = true;
            this.label_PCBA_WEAE_Temp3.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_PCBA_WEAE_Temp3.Location = new System.Drawing.Point(12, 22);
            this.label_PCBA_WEAE_Temp3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_PCBA_WEAE_Temp3.Name = "label_PCBA_WEAE_Temp3";
            this.label_PCBA_WEAE_Temp3.Size = new System.Drawing.Size(63, 24);
            this.label_PCBA_WEAE_Temp3.TabIndex = 0;
            this.label_PCBA_WEAE_Temp3.Text = "Temp";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label_PCBA_WEAE_Humidity4);
            this.groupBox5.Controls.Add(this.label_PCBA_WEAE_Temp4);
            this.groupBox5.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox5.Location = new System.Drawing.Point(1466, 842);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Size = new System.Drawing.Size(134, 74);
            this.groupBox5.TabIndex = 175;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "SHT-30-U11";
            // 
            // label_PCBA_WEAE_Humidity4
            // 
            this.label_PCBA_WEAE_Humidity4.AutoSize = true;
            this.label_PCBA_WEAE_Humidity4.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_PCBA_WEAE_Humidity4.Location = new System.Drawing.Point(10, 46);
            this.label_PCBA_WEAE_Humidity4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_PCBA_WEAE_Humidity4.Name = "label_PCBA_WEAE_Humidity4";
            this.label_PCBA_WEAE_Humidity4.Size = new System.Drawing.Size(95, 24);
            this.label_PCBA_WEAE_Humidity4.TabIndex = 0;
            this.label_PCBA_WEAE_Humidity4.Text = "Humidity";
            // 
            // label_PCBA_WEAE_Temp4
            // 
            this.label_PCBA_WEAE_Temp4.AutoSize = true;
            this.label_PCBA_WEAE_Temp4.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_PCBA_WEAE_Temp4.Location = new System.Drawing.Point(12, 22);
            this.label_PCBA_WEAE_Temp4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_PCBA_WEAE_Temp4.Name = "label_PCBA_WEAE_Temp4";
            this.label_PCBA_WEAE_Temp4.Size = new System.Drawing.Size(63, 24);
            this.label_PCBA_WEAE_Temp4.TabIndex = 0;
            this.label_PCBA_WEAE_Temp4.Text = "Temp";
            // 
            // tabPage_ADC
            // 
            this.tabPage_ADC.Controls.Add(this.tableLayoutPanel2);
            this.tabPage_ADC.Location = new System.Drawing.Point(4, 29);
            this.tabPage_ADC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage_ADC.Name = "tabPage_ADC";
            this.tabPage_ADC.Size = new System.Drawing.Size(1164, 369);
            this.tabPage_ADC.TabIndex = 9;
            this.tabPage_ADC.Text = "【PPB&ADC】";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel2.ColumnCount = 7;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.Controls.Add(this.group_ADC23, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC22, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC21, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC20, 6, 2);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC19, 5, 2);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC18, 4, 2);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC17, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC16, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC15, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC14, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC13, 6, 1);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC12, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC11, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC10, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC9, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC8, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC7, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC6, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC5, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC4, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC3, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC2, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC1, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.group_ADC0, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1164, 369);
            this.tableLayoutPanel2.TabIndex = 214;
            // 
            // group_ADC23
            // 
            this.group_ADC23.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC23.Controls.Add(this.label_ADC_Value23);
            this.group_ADC23.Controls.Add(this.label_ADC23);
            this.group_ADC23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC23.Location = new System.Drawing.Point(335, 278);
            this.group_ADC23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC23.Name = "group_ADC23";
            this.group_ADC23.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC23.Size = new System.Drawing.Size(160, 89);
            this.group_ADC23.TabIndex = 202;
            this.group_ADC23.TabStop = false;
            this.group_ADC23.Text = "ID_23";
            // 
            // label_ADC_Value23
            // 
            this.label_ADC_Value23.AutoSize = true;
            this.label_ADC_Value23.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value23.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value23.Name = "label_ADC_Value23";
            this.label_ADC_Value23.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value23.TabIndex = 7;
            this.label_ADC_Value23.Text = "ppb Value";
            // 
            // label_ADC23
            // 
            this.label_ADC23.AutoSize = true;
            this.label_ADC23.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC23.Location = new System.Drawing.Point(10, 52);
            this.label_ADC23.Name = "label_ADC23";
            this.label_ADC23.Size = new System.Drawing.Size(100, 22);
            this.label_ADC23.TabIndex = 41;
            this.label_ADC23.Text = "ADC Value";
            // 
            // group_ADC22
            // 
            this.group_ADC22.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC22.Controls.Add(this.label_ADC_Value22);
            this.group_ADC22.Controls.Add(this.label_ADC22);
            this.group_ADC22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC22.Location = new System.Drawing.Point(169, 278);
            this.group_ADC22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC22.Name = "group_ADC22";
            this.group_ADC22.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC22.Size = new System.Drawing.Size(160, 89);
            this.group_ADC22.TabIndex = 207;
            this.group_ADC22.TabStop = false;
            this.group_ADC22.Text = "ID_22";
            // 
            // label_ADC_Value22
            // 
            this.label_ADC_Value22.AutoSize = true;
            this.label_ADC_Value22.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value22.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value22.Name = "label_ADC_Value22";
            this.label_ADC_Value22.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value22.TabIndex = 7;
            this.label_ADC_Value22.Text = "ppb Value";
            // 
            // label_ADC22
            // 
            this.label_ADC22.AutoSize = true;
            this.label_ADC22.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC22.Location = new System.Drawing.Point(10, 52);
            this.label_ADC22.Name = "label_ADC22";
            this.label_ADC22.Size = new System.Drawing.Size(100, 22);
            this.label_ADC22.TabIndex = 41;
            this.label_ADC22.Text = "ADC Value";
            // 
            // group_ADC21
            // 
            this.group_ADC21.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC21.Controls.Add(this.label_ADC_Value21);
            this.group_ADC21.Controls.Add(this.label_ADC21);
            this.group_ADC21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC21.Location = new System.Drawing.Point(3, 278);
            this.group_ADC21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC21.Name = "group_ADC21";
            this.group_ADC21.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC21.Size = new System.Drawing.Size(160, 89);
            this.group_ADC21.TabIndex = 211;
            this.group_ADC21.TabStop = false;
            this.group_ADC21.Text = "ID_21";
            // 
            // label_ADC_Value21
            // 
            this.label_ADC_Value21.AutoSize = true;
            this.label_ADC_Value21.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value21.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value21.Name = "label_ADC_Value21";
            this.label_ADC_Value21.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value21.TabIndex = 7;
            this.label_ADC_Value21.Text = "ppb Value";
            // 
            // label_ADC21
            // 
            this.label_ADC21.AutoSize = true;
            this.label_ADC21.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC21.Location = new System.Drawing.Point(10, 52);
            this.label_ADC21.Name = "label_ADC21";
            this.label_ADC21.Size = new System.Drawing.Size(100, 22);
            this.label_ADC21.TabIndex = 41;
            this.label_ADC21.Text = "ADC Value";
            // 
            // group_ADC20
            // 
            this.group_ADC20.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC20.Controls.Add(this.label_ADC_Value20);
            this.group_ADC20.Controls.Add(this.label_ADC20);
            this.group_ADC20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC20.Location = new System.Drawing.Point(999, 186);
            this.group_ADC20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC20.Name = "group_ADC20";
            this.group_ADC20.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC20.Size = new System.Drawing.Size(162, 88);
            this.group_ADC20.TabIndex = 181;
            this.group_ADC20.TabStop = false;
            this.group_ADC20.Text = "ID_20";
            // 
            // label_ADC_Value20
            // 
            this.label_ADC_Value20.AutoSize = true;
            this.label_ADC_Value20.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value20.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value20.Name = "label_ADC_Value20";
            this.label_ADC_Value20.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value20.TabIndex = 7;
            this.label_ADC_Value20.Text = "ppb Value";
            // 
            // label_ADC20
            // 
            this.label_ADC20.AutoSize = true;
            this.label_ADC20.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC20.Location = new System.Drawing.Point(10, 52);
            this.label_ADC20.Name = "label_ADC20";
            this.label_ADC20.Size = new System.Drawing.Size(100, 22);
            this.label_ADC20.TabIndex = 41;
            this.label_ADC20.Text = "ADC Value";
            // 
            // group_ADC19
            // 
            this.group_ADC19.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC19.Controls.Add(this.label_ADC_Value19);
            this.group_ADC19.Controls.Add(this.label_ADC19);
            this.group_ADC19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC19.Location = new System.Drawing.Point(833, 186);
            this.group_ADC19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC19.Name = "group_ADC19";
            this.group_ADC19.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC19.Size = new System.Drawing.Size(160, 88);
            this.group_ADC19.TabIndex = 186;
            this.group_ADC19.TabStop = false;
            this.group_ADC19.Text = "ID_19";
            // 
            // label_ADC_Value19
            // 
            this.label_ADC_Value19.AutoSize = true;
            this.label_ADC_Value19.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value19.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value19.Name = "label_ADC_Value19";
            this.label_ADC_Value19.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value19.TabIndex = 7;
            this.label_ADC_Value19.Text = "ppb Value";
            // 
            // label_ADC19
            // 
            this.label_ADC19.AutoSize = true;
            this.label_ADC19.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC19.Location = new System.Drawing.Point(10, 52);
            this.label_ADC19.Name = "label_ADC19";
            this.label_ADC19.Size = new System.Drawing.Size(100, 22);
            this.label_ADC19.TabIndex = 41;
            this.label_ADC19.Text = "ADC Value";
            // 
            // group_ADC18
            // 
            this.group_ADC18.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC18.Controls.Add(this.label_ADC_Value18);
            this.group_ADC18.Controls.Add(this.label_ADC18);
            this.group_ADC18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC18.Location = new System.Drawing.Point(667, 186);
            this.group_ADC18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC18.Name = "group_ADC18";
            this.group_ADC18.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC18.Size = new System.Drawing.Size(160, 88);
            this.group_ADC18.TabIndex = 191;
            this.group_ADC18.TabStop = false;
            this.group_ADC18.Text = "ID_18";
            // 
            // label_ADC_Value18
            // 
            this.label_ADC_Value18.AutoSize = true;
            this.label_ADC_Value18.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value18.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value18.Name = "label_ADC_Value18";
            this.label_ADC_Value18.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value18.TabIndex = 7;
            this.label_ADC_Value18.Text = "ppb Value";
            // 
            // label_ADC18
            // 
            this.label_ADC18.AutoSize = true;
            this.label_ADC18.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC18.Location = new System.Drawing.Point(10, 52);
            this.label_ADC18.Name = "label_ADC18";
            this.label_ADC18.Size = new System.Drawing.Size(100, 22);
            this.label_ADC18.TabIndex = 41;
            this.label_ADC18.Text = "ADC Value";
            // 
            // group_ADC17
            // 
            this.group_ADC17.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC17.Controls.Add(this.label_ADC_Value17);
            this.group_ADC17.Controls.Add(this.label_ADC17);
            this.group_ADC17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC17.Location = new System.Drawing.Point(501, 186);
            this.group_ADC17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC17.Name = "group_ADC17";
            this.group_ADC17.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC17.Size = new System.Drawing.Size(160, 88);
            this.group_ADC17.TabIndex = 196;
            this.group_ADC17.TabStop = false;
            this.group_ADC17.Text = "ID_17";
            // 
            // label_ADC_Value17
            // 
            this.label_ADC_Value17.AutoSize = true;
            this.label_ADC_Value17.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value17.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value17.Name = "label_ADC_Value17";
            this.label_ADC_Value17.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value17.TabIndex = 7;
            this.label_ADC_Value17.Text = "ppb Value";
            // 
            // label_ADC17
            // 
            this.label_ADC17.AutoSize = true;
            this.label_ADC17.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC17.Location = new System.Drawing.Point(10, 52);
            this.label_ADC17.Name = "label_ADC17";
            this.label_ADC17.Size = new System.Drawing.Size(100, 22);
            this.label_ADC17.TabIndex = 41;
            this.label_ADC17.Text = "ADC Value";
            // 
            // group_ADC16
            // 
            this.group_ADC16.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC16.Controls.Add(this.label_ADC_Value16);
            this.group_ADC16.Controls.Add(this.label_ADC16);
            this.group_ADC16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC16.Location = new System.Drawing.Point(335, 186);
            this.group_ADC16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC16.Name = "group_ADC16";
            this.group_ADC16.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC16.Size = new System.Drawing.Size(160, 88);
            this.group_ADC16.TabIndex = 201;
            this.group_ADC16.TabStop = false;
            this.group_ADC16.Text = "ID_16";
            // 
            // label_ADC_Value16
            // 
            this.label_ADC_Value16.AutoSize = true;
            this.label_ADC_Value16.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value16.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value16.Name = "label_ADC_Value16";
            this.label_ADC_Value16.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value16.TabIndex = 7;
            this.label_ADC_Value16.Text = "ppb Value";
            // 
            // label_ADC16
            // 
            this.label_ADC16.AutoSize = true;
            this.label_ADC16.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC16.Location = new System.Drawing.Point(10, 52);
            this.label_ADC16.Name = "label_ADC16";
            this.label_ADC16.Size = new System.Drawing.Size(100, 22);
            this.label_ADC16.TabIndex = 41;
            this.label_ADC16.Text = "ADC Value";
            // 
            // group_ADC15
            // 
            this.group_ADC15.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC15.Controls.Add(this.label_ADC_Value15);
            this.group_ADC15.Controls.Add(this.label_ADC15);
            this.group_ADC15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC15.Location = new System.Drawing.Point(169, 186);
            this.group_ADC15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC15.Name = "group_ADC15";
            this.group_ADC15.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC15.Size = new System.Drawing.Size(160, 88);
            this.group_ADC15.TabIndex = 206;
            this.group_ADC15.TabStop = false;
            this.group_ADC15.Text = "ID_15";
            // 
            // label_ADC_Value15
            // 
            this.label_ADC_Value15.AutoSize = true;
            this.label_ADC_Value15.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value15.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value15.Name = "label_ADC_Value15";
            this.label_ADC_Value15.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value15.TabIndex = 7;
            this.label_ADC_Value15.Text = "ppb Value";
            // 
            // label_ADC15
            // 
            this.label_ADC15.AutoSize = true;
            this.label_ADC15.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC15.Location = new System.Drawing.Point(10, 52);
            this.label_ADC15.Name = "label_ADC15";
            this.label_ADC15.Size = new System.Drawing.Size(100, 22);
            this.label_ADC15.TabIndex = 41;
            this.label_ADC15.Text = "ADC Value";
            // 
            // group_ADC14
            // 
            this.group_ADC14.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC14.Controls.Add(this.label_ADC_Value14);
            this.group_ADC14.Controls.Add(this.label_ADC14);
            this.group_ADC14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC14.Location = new System.Drawing.Point(3, 186);
            this.group_ADC14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC14.Name = "group_ADC14";
            this.group_ADC14.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC14.Size = new System.Drawing.Size(160, 88);
            this.group_ADC14.TabIndex = 210;
            this.group_ADC14.TabStop = false;
            this.group_ADC14.Text = "ID_14";
            // 
            // label_ADC_Value14
            // 
            this.label_ADC_Value14.AutoSize = true;
            this.label_ADC_Value14.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value14.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value14.Name = "label_ADC_Value14";
            this.label_ADC_Value14.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value14.TabIndex = 7;
            this.label_ADC_Value14.Text = "ppb Value";
            // 
            // label_ADC14
            // 
            this.label_ADC14.AutoSize = true;
            this.label_ADC14.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC14.Location = new System.Drawing.Point(10, 52);
            this.label_ADC14.Name = "label_ADC14";
            this.label_ADC14.Size = new System.Drawing.Size(100, 22);
            this.label_ADC14.TabIndex = 41;
            this.label_ADC14.Text = "ADC Value";
            // 
            // group_ADC13
            // 
            this.group_ADC13.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC13.Controls.Add(this.label_ADC_Value13);
            this.group_ADC13.Controls.Add(this.label_ADC13);
            this.group_ADC13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC13.Location = new System.Drawing.Point(999, 94);
            this.group_ADC13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC13.Name = "group_ADC13";
            this.group_ADC13.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC13.Size = new System.Drawing.Size(162, 88);
            this.group_ADC13.TabIndex = 180;
            this.group_ADC13.TabStop = false;
            this.group_ADC13.Text = "ID_13";
            // 
            // label_ADC_Value13
            // 
            this.label_ADC_Value13.AutoSize = true;
            this.label_ADC_Value13.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value13.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value13.Name = "label_ADC_Value13";
            this.label_ADC_Value13.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value13.TabIndex = 7;
            this.label_ADC_Value13.Text = "ppb Value";
            // 
            // label_ADC13
            // 
            this.label_ADC13.AutoSize = true;
            this.label_ADC13.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC13.Location = new System.Drawing.Point(10, 52);
            this.label_ADC13.Name = "label_ADC13";
            this.label_ADC13.Size = new System.Drawing.Size(100, 22);
            this.label_ADC13.TabIndex = 41;
            this.label_ADC13.Text = "ADC Value";
            // 
            // group_ADC12
            // 
            this.group_ADC12.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC12.Controls.Add(this.label_ADC_Value12);
            this.group_ADC12.Controls.Add(this.label_ADC12);
            this.group_ADC12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC12.Location = new System.Drawing.Point(833, 94);
            this.group_ADC12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC12.Name = "group_ADC12";
            this.group_ADC12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC12.Size = new System.Drawing.Size(160, 88);
            this.group_ADC12.TabIndex = 185;
            this.group_ADC12.TabStop = false;
            this.group_ADC12.Text = "ID_12";
            // 
            // label_ADC_Value12
            // 
            this.label_ADC_Value12.AutoSize = true;
            this.label_ADC_Value12.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value12.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value12.Name = "label_ADC_Value12";
            this.label_ADC_Value12.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value12.TabIndex = 7;
            this.label_ADC_Value12.Text = "ppb Value";
            // 
            // label_ADC12
            // 
            this.label_ADC12.AutoSize = true;
            this.label_ADC12.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC12.Location = new System.Drawing.Point(10, 52);
            this.label_ADC12.Name = "label_ADC12";
            this.label_ADC12.Size = new System.Drawing.Size(100, 22);
            this.label_ADC12.TabIndex = 41;
            this.label_ADC12.Text = "ADC Value";
            // 
            // group_ADC11
            // 
            this.group_ADC11.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC11.Controls.Add(this.label_ADC_Value11);
            this.group_ADC11.Controls.Add(this.label_ADC11);
            this.group_ADC11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC11.Location = new System.Drawing.Point(667, 94);
            this.group_ADC11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC11.Name = "group_ADC11";
            this.group_ADC11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC11.Size = new System.Drawing.Size(160, 88);
            this.group_ADC11.TabIndex = 190;
            this.group_ADC11.TabStop = false;
            this.group_ADC11.Text = "ID_11";
            // 
            // label_ADC_Value11
            // 
            this.label_ADC_Value11.AutoSize = true;
            this.label_ADC_Value11.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value11.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value11.Name = "label_ADC_Value11";
            this.label_ADC_Value11.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value11.TabIndex = 7;
            this.label_ADC_Value11.Text = "ppb Value";
            // 
            // label_ADC11
            // 
            this.label_ADC11.AutoSize = true;
            this.label_ADC11.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC11.Location = new System.Drawing.Point(10, 52);
            this.label_ADC11.Name = "label_ADC11";
            this.label_ADC11.Size = new System.Drawing.Size(100, 22);
            this.label_ADC11.TabIndex = 41;
            this.label_ADC11.Text = "ADC Value";
            // 
            // group_ADC10
            // 
            this.group_ADC10.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC10.Controls.Add(this.label_ADC_Value10);
            this.group_ADC10.Controls.Add(this.label_ADC10);
            this.group_ADC10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC10.Location = new System.Drawing.Point(501, 94);
            this.group_ADC10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC10.Name = "group_ADC10";
            this.group_ADC10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC10.Size = new System.Drawing.Size(160, 88);
            this.group_ADC10.TabIndex = 195;
            this.group_ADC10.TabStop = false;
            this.group_ADC10.Text = "ID_10";
            // 
            // label_ADC_Value10
            // 
            this.label_ADC_Value10.AutoSize = true;
            this.label_ADC_Value10.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value10.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value10.Name = "label_ADC_Value10";
            this.label_ADC_Value10.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value10.TabIndex = 7;
            this.label_ADC_Value10.Text = "ppb Value";
            // 
            // label_ADC10
            // 
            this.label_ADC10.AutoSize = true;
            this.label_ADC10.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC10.Location = new System.Drawing.Point(10, 52);
            this.label_ADC10.Name = "label_ADC10";
            this.label_ADC10.Size = new System.Drawing.Size(100, 22);
            this.label_ADC10.TabIndex = 41;
            this.label_ADC10.Text = "ADC Value";
            // 
            // group_ADC9
            // 
            this.group_ADC9.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC9.Controls.Add(this.label_ADC_Value9);
            this.group_ADC9.Controls.Add(this.label_ADC9);
            this.group_ADC9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC9.Location = new System.Drawing.Point(335, 94);
            this.group_ADC9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC9.Name = "group_ADC9";
            this.group_ADC9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC9.Size = new System.Drawing.Size(160, 88);
            this.group_ADC9.TabIndex = 200;
            this.group_ADC9.TabStop = false;
            this.group_ADC9.Text = "ID_9";
            // 
            // label_ADC_Value9
            // 
            this.label_ADC_Value9.AutoSize = true;
            this.label_ADC_Value9.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value9.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value9.Name = "label_ADC_Value9";
            this.label_ADC_Value9.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value9.TabIndex = 7;
            this.label_ADC_Value9.Text = "ppb Value";
            // 
            // label_ADC9
            // 
            this.label_ADC9.AutoSize = true;
            this.label_ADC9.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC9.Location = new System.Drawing.Point(10, 52);
            this.label_ADC9.Name = "label_ADC9";
            this.label_ADC9.Size = new System.Drawing.Size(100, 22);
            this.label_ADC9.TabIndex = 41;
            this.label_ADC9.Text = "ADC Value";
            // 
            // group_ADC8
            // 
            this.group_ADC8.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC8.Controls.Add(this.label_ADC_Value8);
            this.group_ADC8.Controls.Add(this.label_ADC8);
            this.group_ADC8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC8.Location = new System.Drawing.Point(169, 94);
            this.group_ADC8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC8.Name = "group_ADC8";
            this.group_ADC8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC8.Size = new System.Drawing.Size(160, 88);
            this.group_ADC8.TabIndex = 205;
            this.group_ADC8.TabStop = false;
            this.group_ADC8.Text = "ID_8";
            // 
            // label_ADC_Value8
            // 
            this.label_ADC_Value8.AutoSize = true;
            this.label_ADC_Value8.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value8.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value8.Name = "label_ADC_Value8";
            this.label_ADC_Value8.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value8.TabIndex = 7;
            this.label_ADC_Value8.Text = "ppb Value";
            // 
            // label_ADC8
            // 
            this.label_ADC8.AutoSize = true;
            this.label_ADC8.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC8.Location = new System.Drawing.Point(10, 52);
            this.label_ADC8.Name = "label_ADC8";
            this.label_ADC8.Size = new System.Drawing.Size(100, 22);
            this.label_ADC8.TabIndex = 41;
            this.label_ADC8.Text = "ADC Value";
            // 
            // group_ADC7
            // 
            this.group_ADC7.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC7.Controls.Add(this.label_ADC_Value7);
            this.group_ADC7.Controls.Add(this.label_ADC7);
            this.group_ADC7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC7.Location = new System.Drawing.Point(3, 94);
            this.group_ADC7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC7.Name = "group_ADC7";
            this.group_ADC7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC7.Size = new System.Drawing.Size(160, 88);
            this.group_ADC7.TabIndex = 209;
            this.group_ADC7.TabStop = false;
            this.group_ADC7.Text = "ID_7";
            // 
            // label_ADC_Value7
            // 
            this.label_ADC_Value7.AutoSize = true;
            this.label_ADC_Value7.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value7.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value7.Name = "label_ADC_Value7";
            this.label_ADC_Value7.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value7.TabIndex = 7;
            this.label_ADC_Value7.Text = "ppb Value";
            // 
            // label_ADC7
            // 
            this.label_ADC7.AutoSize = true;
            this.label_ADC7.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC7.Location = new System.Drawing.Point(10, 52);
            this.label_ADC7.Name = "label_ADC7";
            this.label_ADC7.Size = new System.Drawing.Size(100, 22);
            this.label_ADC7.TabIndex = 41;
            this.label_ADC7.Text = "ADC Value";
            // 
            // group_ADC6
            // 
            this.group_ADC6.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC6.Controls.Add(this.label_ADC_Value6);
            this.group_ADC6.Controls.Add(this.label_ADC6);
            this.group_ADC6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC6.Location = new System.Drawing.Point(999, 2);
            this.group_ADC6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC6.Name = "group_ADC6";
            this.group_ADC6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC6.Size = new System.Drawing.Size(162, 88);
            this.group_ADC6.TabIndex = 179;
            this.group_ADC6.TabStop = false;
            this.group_ADC6.Text = "ID_6";
            // 
            // label_ADC_Value6
            // 
            this.label_ADC_Value6.AutoSize = true;
            this.label_ADC_Value6.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value6.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value6.Name = "label_ADC_Value6";
            this.label_ADC_Value6.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value6.TabIndex = 7;
            this.label_ADC_Value6.Text = "ppb Value";
            // 
            // label_ADC6
            // 
            this.label_ADC6.AutoSize = true;
            this.label_ADC6.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC6.Location = new System.Drawing.Point(10, 52);
            this.label_ADC6.Name = "label_ADC6";
            this.label_ADC6.Size = new System.Drawing.Size(100, 22);
            this.label_ADC6.TabIndex = 41;
            this.label_ADC6.Text = "ADC Value";
            // 
            // group_ADC5
            // 
            this.group_ADC5.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC5.Controls.Add(this.label_ADC_Value5);
            this.group_ADC5.Controls.Add(this.label_ADC5);
            this.group_ADC5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC5.Location = new System.Drawing.Point(833, 2);
            this.group_ADC5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC5.Name = "group_ADC5";
            this.group_ADC5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC5.Size = new System.Drawing.Size(160, 88);
            this.group_ADC5.TabIndex = 184;
            this.group_ADC5.TabStop = false;
            this.group_ADC5.Text = "ID_5";
            // 
            // label_ADC_Value5
            // 
            this.label_ADC_Value5.AutoSize = true;
            this.label_ADC_Value5.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value5.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value5.Name = "label_ADC_Value5";
            this.label_ADC_Value5.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value5.TabIndex = 7;
            this.label_ADC_Value5.Text = "ppb Value";
            // 
            // label_ADC5
            // 
            this.label_ADC5.AutoSize = true;
            this.label_ADC5.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC5.Location = new System.Drawing.Point(10, 52);
            this.label_ADC5.Name = "label_ADC5";
            this.label_ADC5.Size = new System.Drawing.Size(100, 22);
            this.label_ADC5.TabIndex = 41;
            this.label_ADC5.Text = "ADC Value";
            // 
            // group_ADC4
            // 
            this.group_ADC4.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC4.Controls.Add(this.label_ADC_Value4);
            this.group_ADC4.Controls.Add(this.label_ADC4);
            this.group_ADC4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC4.Location = new System.Drawing.Point(667, 2);
            this.group_ADC4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC4.Name = "group_ADC4";
            this.group_ADC4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC4.Size = new System.Drawing.Size(160, 88);
            this.group_ADC4.TabIndex = 189;
            this.group_ADC4.TabStop = false;
            this.group_ADC4.Text = "ID_4";
            // 
            // label_ADC_Value4
            // 
            this.label_ADC_Value4.AutoSize = true;
            this.label_ADC_Value4.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value4.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value4.Name = "label_ADC_Value4";
            this.label_ADC_Value4.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value4.TabIndex = 7;
            this.label_ADC_Value4.Text = "ppb Value";
            // 
            // label_ADC4
            // 
            this.label_ADC4.AutoSize = true;
            this.label_ADC4.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC4.Location = new System.Drawing.Point(10, 52);
            this.label_ADC4.Name = "label_ADC4";
            this.label_ADC4.Size = new System.Drawing.Size(100, 22);
            this.label_ADC4.TabIndex = 41;
            this.label_ADC4.Text = "ADC Value";
            // 
            // group_ADC3
            // 
            this.group_ADC3.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC3.Controls.Add(this.label_ADC_Value3);
            this.group_ADC3.Controls.Add(this.label_ADC3);
            this.group_ADC3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC3.Location = new System.Drawing.Point(501, 2);
            this.group_ADC3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC3.Name = "group_ADC3";
            this.group_ADC3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC3.Size = new System.Drawing.Size(160, 88);
            this.group_ADC3.TabIndex = 194;
            this.group_ADC3.TabStop = false;
            this.group_ADC3.Text = "ID_3";
            // 
            // label_ADC_Value3
            // 
            this.label_ADC_Value3.AutoSize = true;
            this.label_ADC_Value3.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value3.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value3.Name = "label_ADC_Value3";
            this.label_ADC_Value3.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value3.TabIndex = 7;
            this.label_ADC_Value3.Text = "ppb Value";
            // 
            // label_ADC3
            // 
            this.label_ADC3.AutoSize = true;
            this.label_ADC3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC3.Location = new System.Drawing.Point(10, 52);
            this.label_ADC3.Name = "label_ADC3";
            this.label_ADC3.Size = new System.Drawing.Size(100, 22);
            this.label_ADC3.TabIndex = 41;
            this.label_ADC3.Text = "ADC Value";
            // 
            // group_ADC2
            // 
            this.group_ADC2.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC2.Controls.Add(this.label_ADC_Value2);
            this.group_ADC2.Controls.Add(this.label_ADC2);
            this.group_ADC2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC2.Location = new System.Drawing.Point(335, 2);
            this.group_ADC2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC2.Name = "group_ADC2";
            this.group_ADC2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC2.Size = new System.Drawing.Size(160, 88);
            this.group_ADC2.TabIndex = 199;
            this.group_ADC2.TabStop = false;
            this.group_ADC2.Text = "ID_2";
            // 
            // label_ADC_Value2
            // 
            this.label_ADC_Value2.AutoSize = true;
            this.label_ADC_Value2.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value2.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value2.Name = "label_ADC_Value2";
            this.label_ADC_Value2.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value2.TabIndex = 7;
            this.label_ADC_Value2.Text = "ppb Value";
            // 
            // label_ADC2
            // 
            this.label_ADC2.AutoSize = true;
            this.label_ADC2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC2.Location = new System.Drawing.Point(10, 52);
            this.label_ADC2.Name = "label_ADC2";
            this.label_ADC2.Size = new System.Drawing.Size(100, 22);
            this.label_ADC2.TabIndex = 41;
            this.label_ADC2.Text = "ADC Value";
            // 
            // group_ADC1
            // 
            this.group_ADC1.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC1.Controls.Add(this.label_ADC_Value1);
            this.group_ADC1.Controls.Add(this.label_ADC1);
            this.group_ADC1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC1.Location = new System.Drawing.Point(169, 2);
            this.group_ADC1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC1.Name = "group_ADC1";
            this.group_ADC1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC1.Size = new System.Drawing.Size(160, 88);
            this.group_ADC1.TabIndex = 204;
            this.group_ADC1.TabStop = false;
            this.group_ADC1.Text = "ID_1";
            // 
            // label_ADC_Value1
            // 
            this.label_ADC_Value1.AutoSize = true;
            this.label_ADC_Value1.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value1.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value1.Name = "label_ADC_Value1";
            this.label_ADC_Value1.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value1.TabIndex = 7;
            this.label_ADC_Value1.Text = "ppb Value";
            // 
            // label_ADC1
            // 
            this.label_ADC1.AutoSize = true;
            this.label_ADC1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC1.Location = new System.Drawing.Point(10, 52);
            this.label_ADC1.Name = "label_ADC1";
            this.label_ADC1.Size = new System.Drawing.Size(100, 22);
            this.label_ADC1.TabIndex = 41;
            this.label_ADC1.Text = "ADC Value";
            // 
            // group_ADC0
            // 
            this.group_ADC0.BackColor = System.Drawing.Color.Transparent;
            this.group_ADC0.Controls.Add(this.label_ADC_Value0);
            this.group_ADC0.Controls.Add(this.label_ADC0);
            this.group_ADC0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_ADC0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_ADC0.Location = new System.Drawing.Point(3, 2);
            this.group_ADC0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC0.Name = "group_ADC0";
            this.group_ADC0.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_ADC0.Size = new System.Drawing.Size(160, 88);
            this.group_ADC0.TabIndex = 177;
            this.group_ADC0.TabStop = false;
            this.group_ADC0.Text = "ID_0";
            // 
            // label_ADC_Value0
            // 
            this.label_ADC_Value0.AutoSize = true;
            this.label_ADC_Value0.BackColor = System.Drawing.Color.Lime;
            this.label_ADC_Value0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC_Value0.Location = new System.Drawing.Point(10, 30);
            this.label_ADC_Value0.Name = "label_ADC_Value0";
            this.label_ADC_Value0.Size = new System.Drawing.Size(100, 22);
            this.label_ADC_Value0.TabIndex = 7;
            this.label_ADC_Value0.Text = "ppb Value";
            // 
            // label_ADC0
            // 
            this.label_ADC0.AutoSize = true;
            this.label_ADC0.BackColor = System.Drawing.Color.PaleTurquoise;
            this.label_ADC0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_ADC0.Location = new System.Drawing.Point(10, 52);
            this.label_ADC0.Name = "label_ADC0";
            this.label_ADC0.Size = new System.Drawing.Size(100, 22);
            this.label_ADC0.TabIndex = 41;
            this.label_ADC0.Text = "ADC Value";
            // 
            // tabPage_Zero
            // 
            this.tabPage_Zero.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage_Zero.Controls.Add(this.tableLayoutPanel3);
            this.tabPage_Zero.Location = new System.Drawing.Point(4, 29);
            this.tabPage_Zero.Name = "tabPage_Zero";
            this.tabPage_Zero.Size = new System.Drawing.Size(1164, 369);
            this.tabPage_Zero.TabIndex = 12;
            this.tabPage_Zero.Text = "【Zero】";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel3.ColumnCount = 7;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel3.Controls.Add(this.group_zero18, 4, 2);
            this.tableLayoutPanel3.Controls.Add(this.group_zero23, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.group_zero22, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.group_zero21, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.group_zero20, 6, 2);
            this.tableLayoutPanel3.Controls.Add(this.group_zero19, 5, 2);
            this.tableLayoutPanel3.Controls.Add(this.group_zero17, 3, 2);
            this.tableLayoutPanel3.Controls.Add(this.group_zero16, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.group_zero15, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.group_zero14, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.group_zero13, 6, 1);
            this.tableLayoutPanel3.Controls.Add(this.group_zero12, 5, 1);
            this.tableLayoutPanel3.Controls.Add(this.group_zero11, 4, 1);
            this.tableLayoutPanel3.Controls.Add(this.group_zero10, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.group_zero9, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.group_zero8, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.group_zero7, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.group_zero6, 6, 0);
            this.tableLayoutPanel3.Controls.Add(this.group_zero5, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.group_zero4, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.group_zero3, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.group_zero2, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.group_zero1, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.group_zero0, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 4;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1164, 369);
            this.tableLayoutPanel3.TabIndex = 215;
            // 
            // group_zero18
            // 
            this.group_zero18.BackColor = System.Drawing.Color.Transparent;
            this.group_zero18.Controls.Add(this.label_Zero18);
            this.group_zero18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero18.Location = new System.Drawing.Point(667, 186);
            this.group_zero18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero18.Name = "group_zero18";
            this.group_zero18.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero18.Size = new System.Drawing.Size(160, 88);
            this.group_zero18.TabIndex = 221;
            this.group_zero18.TabStop = false;
            this.group_zero18.Text = "ID_18";
            // 
            // label_Zero18
            // 
            this.label_Zero18.AutoSize = true;
            this.label_Zero18.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero18.Location = new System.Drawing.Point(10, 38);
            this.label_Zero18.Name = "label_Zero18";
            this.label_Zero18.Size = new System.Drawing.Size(110, 22);
            this.label_Zero18.TabIndex = 41;
            this.label_Zero18.Text = "Zero Value";
            // 
            // group_zero23
            // 
            this.group_zero23.BackColor = System.Drawing.Color.Transparent;
            this.group_zero23.Controls.Add(this.label_Zero23);
            this.group_zero23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero23.Location = new System.Drawing.Point(335, 278);
            this.group_zero23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero23.Name = "group_zero23";
            this.group_zero23.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero23.Size = new System.Drawing.Size(160, 89);
            this.group_zero23.TabIndex = 228;
            this.group_zero23.TabStop = false;
            this.group_zero23.Text = "ID_23";
            // 
            // label_Zero23
            // 
            this.label_Zero23.AutoSize = true;
            this.label_Zero23.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero23.Location = new System.Drawing.Point(10, 38);
            this.label_Zero23.Name = "label_Zero23";
            this.label_Zero23.Size = new System.Drawing.Size(110, 22);
            this.label_Zero23.TabIndex = 41;
            this.label_Zero23.Text = "Zero Value";
            // 
            // group_zero22
            // 
            this.group_zero22.BackColor = System.Drawing.Color.Transparent;
            this.group_zero22.Controls.Add(this.label_Zero22);
            this.group_zero22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero22.Location = new System.Drawing.Point(169, 278);
            this.group_zero22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero22.Name = "group_zero22";
            this.group_zero22.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero22.Size = new System.Drawing.Size(160, 89);
            this.group_zero22.TabIndex = 232;
            this.group_zero22.TabStop = false;
            this.group_zero22.Text = "ID_22";
            // 
            // label_Zero22
            // 
            this.label_Zero22.AutoSize = true;
            this.label_Zero22.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero22.Location = new System.Drawing.Point(10, 38);
            this.label_Zero22.Name = "label_Zero22";
            this.label_Zero22.Size = new System.Drawing.Size(110, 22);
            this.label_Zero22.TabIndex = 41;
            this.label_Zero22.Text = "Zero Value";
            // 
            // group_zero21
            // 
            this.group_zero21.BackColor = System.Drawing.Color.Transparent;
            this.group_zero21.Controls.Add(this.label_Zero21);
            this.group_zero21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero21.Location = new System.Drawing.Point(3, 278);
            this.group_zero21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero21.Name = "group_zero21";
            this.group_zero21.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero21.Size = new System.Drawing.Size(160, 89);
            this.group_zero21.TabIndex = 235;
            this.group_zero21.TabStop = false;
            this.group_zero21.Text = "ID_21";
            // 
            // label_Zero21
            // 
            this.label_Zero21.AutoSize = true;
            this.label_Zero21.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero21.Location = new System.Drawing.Point(10, 38);
            this.label_Zero21.Name = "label_Zero21";
            this.label_Zero21.Size = new System.Drawing.Size(110, 22);
            this.label_Zero21.TabIndex = 41;
            this.label_Zero21.Text = "Zero Value";
            // 
            // group_zero20
            // 
            this.group_zero20.BackColor = System.Drawing.Color.Transparent;
            this.group_zero20.Controls.Add(this.label_Zero20);
            this.group_zero20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero20.Location = new System.Drawing.Point(999, 186);
            this.group_zero20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero20.Name = "group_zero20";
            this.group_zero20.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero20.Size = new System.Drawing.Size(162, 88);
            this.group_zero20.TabIndex = 215;
            this.group_zero20.TabStop = false;
            this.group_zero20.Text = "ID_20";
            // 
            // label_Zero20
            // 
            this.label_Zero20.AutoSize = true;
            this.label_Zero20.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero20.Location = new System.Drawing.Point(10, 38);
            this.label_Zero20.Name = "label_Zero20";
            this.label_Zero20.Size = new System.Drawing.Size(110, 22);
            this.label_Zero20.TabIndex = 41;
            this.label_Zero20.Text = "Zero Value";
            // 
            // group_zero19
            // 
            this.group_zero19.BackColor = System.Drawing.Color.Transparent;
            this.group_zero19.Controls.Add(this.label_Zero19);
            this.group_zero19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero19.Location = new System.Drawing.Point(833, 186);
            this.group_zero19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero19.Name = "group_zero19";
            this.group_zero19.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero19.Size = new System.Drawing.Size(160, 88);
            this.group_zero19.TabIndex = 218;
            this.group_zero19.TabStop = false;
            this.group_zero19.Text = "ID_19";
            // 
            // label_Zero19
            // 
            this.label_Zero19.AutoSize = true;
            this.label_Zero19.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero19.Location = new System.Drawing.Point(10, 38);
            this.label_Zero19.Name = "label_Zero19";
            this.label_Zero19.Size = new System.Drawing.Size(110, 22);
            this.label_Zero19.TabIndex = 41;
            this.label_Zero19.Text = "Zero Value";
            // 
            // group_zero17
            // 
            this.group_zero17.BackColor = System.Drawing.Color.Transparent;
            this.group_zero17.Controls.Add(this.label_Zero17);
            this.group_zero17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero17.Location = new System.Drawing.Point(501, 186);
            this.group_zero17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero17.Name = "group_zero17";
            this.group_zero17.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero17.Size = new System.Drawing.Size(160, 88);
            this.group_zero17.TabIndex = 224;
            this.group_zero17.TabStop = false;
            this.group_zero17.Text = "ID_17";
            // 
            // label_Zero17
            // 
            this.label_Zero17.AutoSize = true;
            this.label_Zero17.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero17.Location = new System.Drawing.Point(10, 38);
            this.label_Zero17.Name = "label_Zero17";
            this.label_Zero17.Size = new System.Drawing.Size(110, 22);
            this.label_Zero17.TabIndex = 41;
            this.label_Zero17.Text = "Zero Value";
            // 
            // group_zero16
            // 
            this.group_zero16.BackColor = System.Drawing.Color.Transparent;
            this.group_zero16.Controls.Add(this.label_Zero16);
            this.group_zero16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero16.Location = new System.Drawing.Point(335, 186);
            this.group_zero16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero16.Name = "group_zero16";
            this.group_zero16.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero16.Size = new System.Drawing.Size(160, 88);
            this.group_zero16.TabIndex = 227;
            this.group_zero16.TabStop = false;
            this.group_zero16.Text = "ID_16";
            // 
            // label_Zero16
            // 
            this.label_Zero16.AutoSize = true;
            this.label_Zero16.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero16.Location = new System.Drawing.Point(10, 38);
            this.label_Zero16.Name = "label_Zero16";
            this.label_Zero16.Size = new System.Drawing.Size(110, 22);
            this.label_Zero16.TabIndex = 41;
            this.label_Zero16.Text = "Zero Value";
            // 
            // group_zero15
            // 
            this.group_zero15.BackColor = System.Drawing.Color.Transparent;
            this.group_zero15.Controls.Add(this.label_Zero15);
            this.group_zero15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero15.Location = new System.Drawing.Point(169, 186);
            this.group_zero15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero15.Name = "group_zero15";
            this.group_zero15.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero15.Size = new System.Drawing.Size(160, 88);
            this.group_zero15.TabIndex = 231;
            this.group_zero15.TabStop = false;
            this.group_zero15.Text = "ID_15";
            // 
            // label_Zero15
            // 
            this.label_Zero15.AutoSize = true;
            this.label_Zero15.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero15.Location = new System.Drawing.Point(10, 38);
            this.label_Zero15.Name = "label_Zero15";
            this.label_Zero15.Size = new System.Drawing.Size(110, 22);
            this.label_Zero15.TabIndex = 41;
            this.label_Zero15.Text = "Zero Value";
            // 
            // group_zero14
            // 
            this.group_zero14.BackColor = System.Drawing.Color.Transparent;
            this.group_zero14.Controls.Add(this.label_Zero14);
            this.group_zero14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero14.Location = new System.Drawing.Point(3, 186);
            this.group_zero14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero14.Name = "group_zero14";
            this.group_zero14.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero14.Size = new System.Drawing.Size(160, 88);
            this.group_zero14.TabIndex = 234;
            this.group_zero14.TabStop = false;
            this.group_zero14.Text = "ID_14";
            // 
            // label_Zero14
            // 
            this.label_Zero14.AutoSize = true;
            this.label_Zero14.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero14.Location = new System.Drawing.Point(10, 38);
            this.label_Zero14.Name = "label_Zero14";
            this.label_Zero14.Size = new System.Drawing.Size(110, 22);
            this.label_Zero14.TabIndex = 41;
            this.label_Zero14.Text = "Zero Value";
            // 
            // group_zero13
            // 
            this.group_zero13.BackColor = System.Drawing.Color.Transparent;
            this.group_zero13.Controls.Add(this.label_Zero13);
            this.group_zero13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero13.Location = new System.Drawing.Point(999, 94);
            this.group_zero13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero13.Name = "group_zero13";
            this.group_zero13.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero13.Size = new System.Drawing.Size(162, 88);
            this.group_zero13.TabIndex = 214;
            this.group_zero13.TabStop = false;
            this.group_zero13.Text = "ID_13";
            // 
            // label_Zero13
            // 
            this.label_Zero13.AutoSize = true;
            this.label_Zero13.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero13.Location = new System.Drawing.Point(10, 38);
            this.label_Zero13.Name = "label_Zero13";
            this.label_Zero13.Size = new System.Drawing.Size(110, 22);
            this.label_Zero13.TabIndex = 41;
            this.label_Zero13.Text = "Zero Value";
            // 
            // group_zero12
            // 
            this.group_zero12.BackColor = System.Drawing.Color.Transparent;
            this.group_zero12.Controls.Add(this.label_Zero12);
            this.group_zero12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero12.Location = new System.Drawing.Point(833, 94);
            this.group_zero12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero12.Name = "group_zero12";
            this.group_zero12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero12.Size = new System.Drawing.Size(160, 88);
            this.group_zero12.TabIndex = 217;
            this.group_zero12.TabStop = false;
            this.group_zero12.Text = "ID_12";
            // 
            // label_Zero12
            // 
            this.label_Zero12.AutoSize = true;
            this.label_Zero12.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero12.Location = new System.Drawing.Point(10, 38);
            this.label_Zero12.Name = "label_Zero12";
            this.label_Zero12.Size = new System.Drawing.Size(110, 22);
            this.label_Zero12.TabIndex = 41;
            this.label_Zero12.Text = "Zero Value";
            // 
            // group_zero11
            // 
            this.group_zero11.BackColor = System.Drawing.Color.Transparent;
            this.group_zero11.Controls.Add(this.label_Zero11);
            this.group_zero11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero11.Location = new System.Drawing.Point(667, 94);
            this.group_zero11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero11.Name = "group_zero11";
            this.group_zero11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero11.Size = new System.Drawing.Size(160, 88);
            this.group_zero11.TabIndex = 220;
            this.group_zero11.TabStop = false;
            this.group_zero11.Text = "ID_11";
            // 
            // label_Zero11
            // 
            this.label_Zero11.AutoSize = true;
            this.label_Zero11.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero11.Location = new System.Drawing.Point(10, 38);
            this.label_Zero11.Name = "label_Zero11";
            this.label_Zero11.Size = new System.Drawing.Size(110, 22);
            this.label_Zero11.TabIndex = 41;
            this.label_Zero11.Text = "Zero Value";
            // 
            // group_zero10
            // 
            this.group_zero10.BackColor = System.Drawing.Color.Transparent;
            this.group_zero10.Controls.Add(this.label_Zero10);
            this.group_zero10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero10.Location = new System.Drawing.Point(501, 94);
            this.group_zero10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero10.Name = "group_zero10";
            this.group_zero10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero10.Size = new System.Drawing.Size(160, 88);
            this.group_zero10.TabIndex = 223;
            this.group_zero10.TabStop = false;
            this.group_zero10.Text = "ID_10";
            // 
            // label_Zero10
            // 
            this.label_Zero10.AutoSize = true;
            this.label_Zero10.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero10.Location = new System.Drawing.Point(10, 38);
            this.label_Zero10.Name = "label_Zero10";
            this.label_Zero10.Size = new System.Drawing.Size(110, 22);
            this.label_Zero10.TabIndex = 41;
            this.label_Zero10.Text = "Zero Value";
            // 
            // group_zero9
            // 
            this.group_zero9.BackColor = System.Drawing.Color.Transparent;
            this.group_zero9.Controls.Add(this.label_Zero9);
            this.group_zero9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero9.Location = new System.Drawing.Point(335, 94);
            this.group_zero9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero9.Name = "group_zero9";
            this.group_zero9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero9.Size = new System.Drawing.Size(160, 88);
            this.group_zero9.TabIndex = 226;
            this.group_zero9.TabStop = false;
            this.group_zero9.Text = "ID_9";
            // 
            // label_Zero9
            // 
            this.label_Zero9.AutoSize = true;
            this.label_Zero9.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero9.Location = new System.Drawing.Point(10, 38);
            this.label_Zero9.Name = "label_Zero9";
            this.label_Zero9.Size = new System.Drawing.Size(110, 22);
            this.label_Zero9.TabIndex = 41;
            this.label_Zero9.Text = "Zero Value";
            // 
            // group_zero8
            // 
            this.group_zero8.BackColor = System.Drawing.Color.Transparent;
            this.group_zero8.Controls.Add(this.label_Zero8);
            this.group_zero8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero8.Location = new System.Drawing.Point(169, 94);
            this.group_zero8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero8.Name = "group_zero8";
            this.group_zero8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero8.Size = new System.Drawing.Size(160, 88);
            this.group_zero8.TabIndex = 230;
            this.group_zero8.TabStop = false;
            this.group_zero8.Text = "ID_8";
            // 
            // label_Zero8
            // 
            this.label_Zero8.AutoSize = true;
            this.label_Zero8.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero8.Location = new System.Drawing.Point(10, 38);
            this.label_Zero8.Name = "label_Zero8";
            this.label_Zero8.Size = new System.Drawing.Size(110, 22);
            this.label_Zero8.TabIndex = 41;
            this.label_Zero8.Text = "Zero Value";
            // 
            // group_zero7
            // 
            this.group_zero7.BackColor = System.Drawing.Color.Transparent;
            this.group_zero7.Controls.Add(this.label_Zero7);
            this.group_zero7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero7.Location = new System.Drawing.Point(3, 94);
            this.group_zero7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero7.Name = "group_zero7";
            this.group_zero7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero7.Size = new System.Drawing.Size(160, 88);
            this.group_zero7.TabIndex = 233;
            this.group_zero7.TabStop = false;
            this.group_zero7.Text = "ID_7";
            // 
            // label_Zero7
            // 
            this.label_Zero7.AutoSize = true;
            this.label_Zero7.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero7.Location = new System.Drawing.Point(10, 38);
            this.label_Zero7.Name = "label_Zero7";
            this.label_Zero7.Size = new System.Drawing.Size(110, 22);
            this.label_Zero7.TabIndex = 41;
            this.label_Zero7.Text = "Zero Value";
            // 
            // group_zero6
            // 
            this.group_zero6.BackColor = System.Drawing.Color.Transparent;
            this.group_zero6.Controls.Add(this.label_Zero6);
            this.group_zero6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero6.Location = new System.Drawing.Point(999, 2);
            this.group_zero6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero6.Name = "group_zero6";
            this.group_zero6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero6.Size = new System.Drawing.Size(162, 88);
            this.group_zero6.TabIndex = 213;
            this.group_zero6.TabStop = false;
            this.group_zero6.Text = "ID_6";
            // 
            // label_Zero6
            // 
            this.label_Zero6.AutoSize = true;
            this.label_Zero6.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero6.Location = new System.Drawing.Point(10, 38);
            this.label_Zero6.Name = "label_Zero6";
            this.label_Zero6.Size = new System.Drawing.Size(110, 22);
            this.label_Zero6.TabIndex = 41;
            this.label_Zero6.Text = "Zero Value";
            // 
            // group_zero5
            // 
            this.group_zero5.BackColor = System.Drawing.Color.Transparent;
            this.group_zero5.Controls.Add(this.label_Zero5);
            this.group_zero5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero5.Location = new System.Drawing.Point(833, 2);
            this.group_zero5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero5.Name = "group_zero5";
            this.group_zero5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero5.Size = new System.Drawing.Size(160, 88);
            this.group_zero5.TabIndex = 216;
            this.group_zero5.TabStop = false;
            this.group_zero5.Text = "ID_5";
            // 
            // label_Zero5
            // 
            this.label_Zero5.AutoSize = true;
            this.label_Zero5.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero5.Location = new System.Drawing.Point(10, 38);
            this.label_Zero5.Name = "label_Zero5";
            this.label_Zero5.Size = new System.Drawing.Size(110, 22);
            this.label_Zero5.TabIndex = 41;
            this.label_Zero5.Text = "Zero Value";
            // 
            // group_zero4
            // 
            this.group_zero4.BackColor = System.Drawing.Color.Transparent;
            this.group_zero4.Controls.Add(this.label_Zero4);
            this.group_zero4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero4.Location = new System.Drawing.Point(667, 2);
            this.group_zero4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero4.Name = "group_zero4";
            this.group_zero4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero4.Size = new System.Drawing.Size(160, 88);
            this.group_zero4.TabIndex = 219;
            this.group_zero4.TabStop = false;
            this.group_zero4.Text = "ID_4";
            // 
            // label_Zero4
            // 
            this.label_Zero4.AutoSize = true;
            this.label_Zero4.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero4.Location = new System.Drawing.Point(10, 38);
            this.label_Zero4.Name = "label_Zero4";
            this.label_Zero4.Size = new System.Drawing.Size(110, 22);
            this.label_Zero4.TabIndex = 41;
            this.label_Zero4.Text = "Zero Value";
            // 
            // group_zero3
            // 
            this.group_zero3.BackColor = System.Drawing.Color.Transparent;
            this.group_zero3.Controls.Add(this.label_Zero3);
            this.group_zero3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero3.Location = new System.Drawing.Point(501, 2);
            this.group_zero3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero3.Name = "group_zero3";
            this.group_zero3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero3.Size = new System.Drawing.Size(160, 88);
            this.group_zero3.TabIndex = 222;
            this.group_zero3.TabStop = false;
            this.group_zero3.Text = "ID_3";
            // 
            // label_Zero3
            // 
            this.label_Zero3.AutoSize = true;
            this.label_Zero3.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero3.Location = new System.Drawing.Point(10, 38);
            this.label_Zero3.Name = "label_Zero3";
            this.label_Zero3.Size = new System.Drawing.Size(110, 22);
            this.label_Zero3.TabIndex = 41;
            this.label_Zero3.Text = "Zero Value";
            // 
            // group_zero2
            // 
            this.group_zero2.BackColor = System.Drawing.Color.Transparent;
            this.group_zero2.Controls.Add(this.label_Zero2);
            this.group_zero2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero2.Location = new System.Drawing.Point(335, 2);
            this.group_zero2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero2.Name = "group_zero2";
            this.group_zero2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero2.Size = new System.Drawing.Size(160, 88);
            this.group_zero2.TabIndex = 225;
            this.group_zero2.TabStop = false;
            this.group_zero2.Text = "ID_2";
            // 
            // label_Zero2
            // 
            this.label_Zero2.AutoSize = true;
            this.label_Zero2.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero2.Location = new System.Drawing.Point(10, 38);
            this.label_Zero2.Name = "label_Zero2";
            this.label_Zero2.Size = new System.Drawing.Size(110, 22);
            this.label_Zero2.TabIndex = 41;
            this.label_Zero2.Text = "Zero Value";
            // 
            // group_zero1
            // 
            this.group_zero1.BackColor = System.Drawing.Color.Transparent;
            this.group_zero1.Controls.Add(this.label_Zero1);
            this.group_zero1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero1.Location = new System.Drawing.Point(169, 2);
            this.group_zero1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero1.Name = "group_zero1";
            this.group_zero1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero1.Size = new System.Drawing.Size(160, 88);
            this.group_zero1.TabIndex = 229;
            this.group_zero1.TabStop = false;
            this.group_zero1.Text = "ID_1";
            // 
            // label_Zero1
            // 
            this.label_Zero1.AutoSize = true;
            this.label_Zero1.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero1.Location = new System.Drawing.Point(10, 38);
            this.label_Zero1.Name = "label_Zero1";
            this.label_Zero1.Size = new System.Drawing.Size(110, 22);
            this.label_Zero1.TabIndex = 41;
            this.label_Zero1.Text = "Zero Value";
            // 
            // group_zero0
            // 
            this.group_zero0.BackColor = System.Drawing.Color.Transparent;
            this.group_zero0.Controls.Add(this.label_Zero0);
            this.group_zero0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_zero0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_zero0.Location = new System.Drawing.Point(3, 2);
            this.group_zero0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero0.Name = "group_zero0";
            this.group_zero0.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_zero0.Size = new System.Drawing.Size(160, 88);
            this.group_zero0.TabIndex = 212;
            this.group_zero0.TabStop = false;
            this.group_zero0.Text = "ID_0";
            // 
            // label_Zero0
            // 
            this.label_Zero0.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Zero0.AutoSize = true;
            this.label_Zero0.BackColor = System.Drawing.Color.PapayaWhip;
            this.label_Zero0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Zero0.Location = new System.Drawing.Point(10, 38);
            this.label_Zero0.Name = "label_Zero0";
            this.label_Zero0.Size = new System.Drawing.Size(110, 22);
            this.label_Zero0.TabIndex = 41;
            this.label_Zero0.Text = "Zero Value";
            // 
            // tabPage_Span
            // 
            this.tabPage_Span.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage_Span.Controls.Add(this.tableLayoutPanel4);
            this.tabPage_Span.Location = new System.Drawing.Point(4, 29);
            this.tabPage_Span.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage_Span.Name = "tabPage_Span";
            this.tabPage_Span.Size = new System.Drawing.Size(1164, 369);
            this.tabPage_Span.TabIndex = 2;
            this.tabPage_Span.Text = "【Span】";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel4.ColumnCount = 7;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel4.Controls.Add(this.group_Span23, 2, 3);
            this.tableLayoutPanel4.Controls.Add(this.group_Span22, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.group_Span0, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.group_Span14, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.group_Span15, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.group_Span20, 6, 2);
            this.tableLayoutPanel4.Controls.Add(this.group_Span19, 5, 2);
            this.tableLayoutPanel4.Controls.Add(this.group_Span18, 4, 2);
            this.tableLayoutPanel4.Controls.Add(this.group_Span17, 3, 2);
            this.tableLayoutPanel4.Controls.Add(this.group_Span16, 2, 2);
            this.tableLayoutPanel4.Controls.Add(this.group_Span1, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.group_Span7, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.group_Span2, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.group_Span8, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.group_Span3, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.group_Span9, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.group_Span10, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.group_Span11, 4, 1);
            this.tableLayoutPanel4.Controls.Add(this.group_Span12, 5, 1);
            this.tableLayoutPanel4.Controls.Add(this.group_Span13, 6, 1);
            this.tableLayoutPanel4.Controls.Add(this.group_Span4, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.group_Span5, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.group_Span6, 6, 0);
            this.tableLayoutPanel4.Controls.Add(this.group_Span21, 0, 3);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 4;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1164, 369);
            this.tableLayoutPanel4.TabIndex = 217;
            // 
            // group_Span23
            // 
            this.group_Span23.BackColor = System.Drawing.Color.Transparent;
            this.group_Span23.Controls.Add(this.label_Span23);
            this.group_Span23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span23.Location = new System.Drawing.Point(335, 278);
            this.group_Span23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span23.Name = "group_Span23";
            this.group_Span23.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span23.Size = new System.Drawing.Size(160, 89);
            this.group_Span23.TabIndex = 240;
            this.group_Span23.TabStop = false;
            this.group_Span23.Text = "ID_23";
            // 
            // label_Span23
            // 
            this.label_Span23.AutoSize = true;
            this.label_Span23.BackColor = System.Drawing.Color.Gold;
            this.label_Span23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span23.Location = new System.Drawing.Point(10, 38);
            this.label_Span23.Name = "label_Span23";
            this.label_Span23.Size = new System.Drawing.Size(110, 22);
            this.label_Span23.TabIndex = 41;
            this.label_Span23.Text = "Span Value";
            // 
            // group_Span22
            // 
            this.group_Span22.BackColor = System.Drawing.Color.Transparent;
            this.group_Span22.Controls.Add(this.label_Span22);
            this.group_Span22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span22.Location = new System.Drawing.Point(169, 278);
            this.group_Span22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span22.Name = "group_Span22";
            this.group_Span22.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span22.Size = new System.Drawing.Size(160, 89);
            this.group_Span22.TabIndex = 245;
            this.group_Span22.TabStop = false;
            this.group_Span22.Text = "ID_22";
            // 
            // label_Span22
            // 
            this.label_Span22.AutoSize = true;
            this.label_Span22.BackColor = System.Drawing.Color.Gold;
            this.label_Span22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span22.Location = new System.Drawing.Point(10, 38);
            this.label_Span22.Name = "label_Span22";
            this.label_Span22.Size = new System.Drawing.Size(110, 22);
            this.label_Span22.TabIndex = 41;
            this.label_Span22.Text = "Span Value";
            // 
            // group_Span0
            // 
            this.group_Span0.BackColor = System.Drawing.Color.Transparent;
            this.group_Span0.Controls.Add(this.label_Span0);
            this.group_Span0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span0.Location = new System.Drawing.Point(3, 2);
            this.group_Span0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span0.Name = "group_Span0";
            this.group_Span0.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span0.Size = new System.Drawing.Size(160, 88);
            this.group_Span0.TabIndex = 176;
            this.group_Span0.TabStop = false;
            this.group_Span0.Text = "ID_0";
            // 
            // label_Span0
            // 
            this.label_Span0.AutoSize = true;
            this.label_Span0.BackColor = System.Drawing.Color.Gold;
            this.label_Span0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span0.Location = new System.Drawing.Point(10, 38);
            this.label_Span0.Name = "label_Span0";
            this.label_Span0.Size = new System.Drawing.Size(110, 22);
            this.label_Span0.TabIndex = 41;
            this.label_Span0.Text = "Span Value";
            // 
            // group_Span14
            // 
            this.group_Span14.BackColor = System.Drawing.Color.Transparent;
            this.group_Span14.Controls.Add(this.label_Span14);
            this.group_Span14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span14.Location = new System.Drawing.Point(3, 186);
            this.group_Span14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span14.Name = "group_Span14";
            this.group_Span14.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span14.Size = new System.Drawing.Size(160, 88);
            this.group_Span14.TabIndex = 248;
            this.group_Span14.TabStop = false;
            this.group_Span14.Text = "ID_14";
            // 
            // label_Span14
            // 
            this.label_Span14.AutoSize = true;
            this.label_Span14.BackColor = System.Drawing.Color.Gold;
            this.label_Span14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span14.Location = new System.Drawing.Point(10, 38);
            this.label_Span14.Name = "label_Span14";
            this.label_Span14.Size = new System.Drawing.Size(110, 22);
            this.label_Span14.TabIndex = 41;
            this.label_Span14.Text = "Span Value";
            // 
            // group_Span15
            // 
            this.group_Span15.BackColor = System.Drawing.Color.Transparent;
            this.group_Span15.Controls.Add(this.label_Span15);
            this.group_Span15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span15.Location = new System.Drawing.Point(169, 186);
            this.group_Span15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span15.Name = "group_Span15";
            this.group_Span15.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span15.Size = new System.Drawing.Size(160, 88);
            this.group_Span15.TabIndex = 244;
            this.group_Span15.TabStop = false;
            this.group_Span15.Text = "ID_15";
            // 
            // label_Span15
            // 
            this.label_Span15.AutoSize = true;
            this.label_Span15.BackColor = System.Drawing.Color.Gold;
            this.label_Span15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span15.Location = new System.Drawing.Point(10, 38);
            this.label_Span15.Name = "label_Span15";
            this.label_Span15.Size = new System.Drawing.Size(110, 22);
            this.label_Span15.TabIndex = 41;
            this.label_Span15.Text = "Span Value";
            // 
            // group_Span20
            // 
            this.group_Span20.BackColor = System.Drawing.Color.Transparent;
            this.group_Span20.Controls.Add(this.label_Span20);
            this.group_Span20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span20.Location = new System.Drawing.Point(999, 186);
            this.group_Span20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span20.Name = "group_Span20";
            this.group_Span20.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span20.Size = new System.Drawing.Size(162, 88);
            this.group_Span20.TabIndex = 219;
            this.group_Span20.TabStop = false;
            this.group_Span20.Text = "ID_20";
            // 
            // label_Span20
            // 
            this.label_Span20.AutoSize = true;
            this.label_Span20.BackColor = System.Drawing.Color.Gold;
            this.label_Span20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span20.Location = new System.Drawing.Point(10, 38);
            this.label_Span20.Name = "label_Span20";
            this.label_Span20.Size = new System.Drawing.Size(110, 22);
            this.label_Span20.TabIndex = 41;
            this.label_Span20.Text = "Span Value";
            // 
            // group_Span19
            // 
            this.group_Span19.BackColor = System.Drawing.Color.Transparent;
            this.group_Span19.Controls.Add(this.label_Span19);
            this.group_Span19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span19.Location = new System.Drawing.Point(833, 186);
            this.group_Span19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span19.Name = "group_Span19";
            this.group_Span19.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span19.Size = new System.Drawing.Size(160, 88);
            this.group_Span19.TabIndex = 224;
            this.group_Span19.TabStop = false;
            this.group_Span19.Text = "ID_19";
            // 
            // label_Span19
            // 
            this.label_Span19.AutoSize = true;
            this.label_Span19.BackColor = System.Drawing.Color.Gold;
            this.label_Span19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span19.Location = new System.Drawing.Point(10, 38);
            this.label_Span19.Name = "label_Span19";
            this.label_Span19.Size = new System.Drawing.Size(110, 22);
            this.label_Span19.TabIndex = 41;
            this.label_Span19.Text = "Span Value";
            // 
            // group_Span18
            // 
            this.group_Span18.BackColor = System.Drawing.Color.Transparent;
            this.group_Span18.Controls.Add(this.label_Span18);
            this.group_Span18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span18.Location = new System.Drawing.Point(667, 186);
            this.group_Span18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span18.Name = "group_Span18";
            this.group_Span18.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span18.Size = new System.Drawing.Size(160, 88);
            this.group_Span18.TabIndex = 229;
            this.group_Span18.TabStop = false;
            this.group_Span18.Text = "ID_18";
            // 
            // label_Span18
            // 
            this.label_Span18.AutoSize = true;
            this.label_Span18.BackColor = System.Drawing.Color.Gold;
            this.label_Span18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span18.Location = new System.Drawing.Point(10, 38);
            this.label_Span18.Name = "label_Span18";
            this.label_Span18.Size = new System.Drawing.Size(110, 22);
            this.label_Span18.TabIndex = 41;
            this.label_Span18.Text = "Span Value";
            // 
            // group_Span17
            // 
            this.group_Span17.BackColor = System.Drawing.Color.Transparent;
            this.group_Span17.Controls.Add(this.label_Span17);
            this.group_Span17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span17.Location = new System.Drawing.Point(501, 186);
            this.group_Span17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span17.Name = "group_Span17";
            this.group_Span17.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span17.Size = new System.Drawing.Size(160, 88);
            this.group_Span17.TabIndex = 234;
            this.group_Span17.TabStop = false;
            this.group_Span17.Text = "ID_17";
            // 
            // label_Span17
            // 
            this.label_Span17.AutoSize = true;
            this.label_Span17.BackColor = System.Drawing.Color.Gold;
            this.label_Span17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span17.Location = new System.Drawing.Point(10, 38);
            this.label_Span17.Name = "label_Span17";
            this.label_Span17.Size = new System.Drawing.Size(110, 22);
            this.label_Span17.TabIndex = 41;
            this.label_Span17.Text = "Span Value";
            // 
            // group_Span16
            // 
            this.group_Span16.BackColor = System.Drawing.Color.Transparent;
            this.group_Span16.Controls.Add(this.label_Span16);
            this.group_Span16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span16.Location = new System.Drawing.Point(335, 186);
            this.group_Span16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span16.Name = "group_Span16";
            this.group_Span16.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span16.Size = new System.Drawing.Size(160, 88);
            this.group_Span16.TabIndex = 239;
            this.group_Span16.TabStop = false;
            this.group_Span16.Text = "ID_16";
            // 
            // label_Span16
            // 
            this.label_Span16.AutoSize = true;
            this.label_Span16.BackColor = System.Drawing.Color.Gold;
            this.label_Span16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span16.Location = new System.Drawing.Point(10, 38);
            this.label_Span16.Name = "label_Span16";
            this.label_Span16.Size = new System.Drawing.Size(110, 22);
            this.label_Span16.TabIndex = 41;
            this.label_Span16.Text = "Span Value";
            // 
            // group_Span1
            // 
            this.group_Span1.BackColor = System.Drawing.Color.Transparent;
            this.group_Span1.Controls.Add(this.label_Span1);
            this.group_Span1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span1.Location = new System.Drawing.Point(169, 2);
            this.group_Span1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span1.Name = "group_Span1";
            this.group_Span1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span1.Size = new System.Drawing.Size(160, 88);
            this.group_Span1.TabIndex = 242;
            this.group_Span1.TabStop = false;
            this.group_Span1.Text = "ID_1";
            // 
            // label_Span1
            // 
            this.label_Span1.AutoSize = true;
            this.label_Span1.BackColor = System.Drawing.Color.Gold;
            this.label_Span1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span1.Location = new System.Drawing.Point(10, 38);
            this.label_Span1.Name = "label_Span1";
            this.label_Span1.Size = new System.Drawing.Size(110, 22);
            this.label_Span1.TabIndex = 41;
            this.label_Span1.Text = "Span Value";
            // 
            // group_Span7
            // 
            this.group_Span7.BackColor = System.Drawing.Color.Transparent;
            this.group_Span7.Controls.Add(this.label_Span7);
            this.group_Span7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span7.Location = new System.Drawing.Point(3, 94);
            this.group_Span7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span7.Name = "group_Span7";
            this.group_Span7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span7.Size = new System.Drawing.Size(160, 88);
            this.group_Span7.TabIndex = 247;
            this.group_Span7.TabStop = false;
            this.group_Span7.Text = "ID_7";
            // 
            // label_Span7
            // 
            this.label_Span7.AutoSize = true;
            this.label_Span7.BackColor = System.Drawing.Color.Gold;
            this.label_Span7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span7.Location = new System.Drawing.Point(10, 38);
            this.label_Span7.Name = "label_Span7";
            this.label_Span7.Size = new System.Drawing.Size(110, 22);
            this.label_Span7.TabIndex = 41;
            this.label_Span7.Text = "Span Value";
            // 
            // group_Span2
            // 
            this.group_Span2.BackColor = System.Drawing.Color.Transparent;
            this.group_Span2.Controls.Add(this.label_Span2);
            this.group_Span2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span2.Location = new System.Drawing.Point(335, 2);
            this.group_Span2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span2.Name = "group_Span2";
            this.group_Span2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span2.Size = new System.Drawing.Size(160, 88);
            this.group_Span2.TabIndex = 237;
            this.group_Span2.TabStop = false;
            this.group_Span2.Text = "ID_2";
            // 
            // label_Span2
            // 
            this.label_Span2.AutoSize = true;
            this.label_Span2.BackColor = System.Drawing.Color.Gold;
            this.label_Span2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span2.Location = new System.Drawing.Point(10, 38);
            this.label_Span2.Name = "label_Span2";
            this.label_Span2.Size = new System.Drawing.Size(110, 22);
            this.label_Span2.TabIndex = 41;
            this.label_Span2.Text = "Span Value";
            // 
            // group_Span8
            // 
            this.group_Span8.BackColor = System.Drawing.Color.Transparent;
            this.group_Span8.Controls.Add(this.label_Span8);
            this.group_Span8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span8.Location = new System.Drawing.Point(169, 94);
            this.group_Span8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span8.Name = "group_Span8";
            this.group_Span8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span8.Size = new System.Drawing.Size(160, 88);
            this.group_Span8.TabIndex = 243;
            this.group_Span8.TabStop = false;
            this.group_Span8.Text = "ID_8";
            // 
            // label_Span8
            // 
            this.label_Span8.AutoSize = true;
            this.label_Span8.BackColor = System.Drawing.Color.Gold;
            this.label_Span8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span8.Location = new System.Drawing.Point(10, 38);
            this.label_Span8.Name = "label_Span8";
            this.label_Span8.Size = new System.Drawing.Size(110, 22);
            this.label_Span8.TabIndex = 41;
            this.label_Span8.Text = "Span Value";
            // 
            // group_Span3
            // 
            this.group_Span3.BackColor = System.Drawing.Color.Transparent;
            this.group_Span3.Controls.Add(this.label_Span3);
            this.group_Span3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span3.Location = new System.Drawing.Point(501, 2);
            this.group_Span3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span3.Name = "group_Span3";
            this.group_Span3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span3.Size = new System.Drawing.Size(160, 88);
            this.group_Span3.TabIndex = 232;
            this.group_Span3.TabStop = false;
            this.group_Span3.Text = "ID_3";
            // 
            // label_Span3
            // 
            this.label_Span3.AutoSize = true;
            this.label_Span3.BackColor = System.Drawing.Color.Gold;
            this.label_Span3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span3.Location = new System.Drawing.Point(10, 38);
            this.label_Span3.Name = "label_Span3";
            this.label_Span3.Size = new System.Drawing.Size(110, 22);
            this.label_Span3.TabIndex = 41;
            this.label_Span3.Text = "Span Value";
            // 
            // group_Span9
            // 
            this.group_Span9.BackColor = System.Drawing.Color.Transparent;
            this.group_Span9.Controls.Add(this.label_Span9);
            this.group_Span9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span9.Location = new System.Drawing.Point(335, 94);
            this.group_Span9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span9.Name = "group_Span9";
            this.group_Span9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span9.Size = new System.Drawing.Size(160, 88);
            this.group_Span9.TabIndex = 238;
            this.group_Span9.TabStop = false;
            this.group_Span9.Text = "ID_9";
            // 
            // label_Span9
            // 
            this.label_Span9.AutoSize = true;
            this.label_Span9.BackColor = System.Drawing.Color.Gold;
            this.label_Span9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span9.Location = new System.Drawing.Point(10, 38);
            this.label_Span9.Name = "label_Span9";
            this.label_Span9.Size = new System.Drawing.Size(110, 22);
            this.label_Span9.TabIndex = 41;
            this.label_Span9.Text = "Span Value";
            // 
            // group_Span10
            // 
            this.group_Span10.BackColor = System.Drawing.Color.Transparent;
            this.group_Span10.Controls.Add(this.label_Span10);
            this.group_Span10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span10.Location = new System.Drawing.Point(501, 94);
            this.group_Span10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span10.Name = "group_Span10";
            this.group_Span10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span10.Size = new System.Drawing.Size(160, 88);
            this.group_Span10.TabIndex = 233;
            this.group_Span10.TabStop = false;
            this.group_Span10.Text = "ID_10";
            // 
            // label_Span10
            // 
            this.label_Span10.AutoSize = true;
            this.label_Span10.BackColor = System.Drawing.Color.Gold;
            this.label_Span10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span10.Location = new System.Drawing.Point(10, 38);
            this.label_Span10.Name = "label_Span10";
            this.label_Span10.Size = new System.Drawing.Size(110, 22);
            this.label_Span10.TabIndex = 41;
            this.label_Span10.Text = "Span Value";
            // 
            // group_Span11
            // 
            this.group_Span11.BackColor = System.Drawing.Color.Transparent;
            this.group_Span11.Controls.Add(this.label_Span11);
            this.group_Span11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span11.Location = new System.Drawing.Point(667, 94);
            this.group_Span11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span11.Name = "group_Span11";
            this.group_Span11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span11.Size = new System.Drawing.Size(160, 88);
            this.group_Span11.TabIndex = 228;
            this.group_Span11.TabStop = false;
            this.group_Span11.Text = "ID_11";
            // 
            // label_Span11
            // 
            this.label_Span11.AutoSize = true;
            this.label_Span11.BackColor = System.Drawing.Color.Gold;
            this.label_Span11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span11.Location = new System.Drawing.Point(10, 38);
            this.label_Span11.Name = "label_Span11";
            this.label_Span11.Size = new System.Drawing.Size(110, 22);
            this.label_Span11.TabIndex = 41;
            this.label_Span11.Text = "Span Value";
            // 
            // group_Span12
            // 
            this.group_Span12.BackColor = System.Drawing.Color.Transparent;
            this.group_Span12.Controls.Add(this.label_Span12);
            this.group_Span12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span12.Location = new System.Drawing.Point(833, 94);
            this.group_Span12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span12.Name = "group_Span12";
            this.group_Span12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span12.Size = new System.Drawing.Size(160, 88);
            this.group_Span12.TabIndex = 223;
            this.group_Span12.TabStop = false;
            this.group_Span12.Text = "ID_12";
            // 
            // label_Span12
            // 
            this.label_Span12.AutoSize = true;
            this.label_Span12.BackColor = System.Drawing.Color.Gold;
            this.label_Span12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span12.Location = new System.Drawing.Point(10, 38);
            this.label_Span12.Name = "label_Span12";
            this.label_Span12.Size = new System.Drawing.Size(110, 22);
            this.label_Span12.TabIndex = 41;
            this.label_Span12.Text = "Span Value";
            // 
            // group_Span13
            // 
            this.group_Span13.BackColor = System.Drawing.Color.Transparent;
            this.group_Span13.Controls.Add(this.label_Span13);
            this.group_Span13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span13.Location = new System.Drawing.Point(999, 94);
            this.group_Span13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span13.Name = "group_Span13";
            this.group_Span13.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span13.Size = new System.Drawing.Size(162, 88);
            this.group_Span13.TabIndex = 218;
            this.group_Span13.TabStop = false;
            this.group_Span13.Text = "ID_13";
            // 
            // label_Span13
            // 
            this.label_Span13.AutoSize = true;
            this.label_Span13.BackColor = System.Drawing.Color.Gold;
            this.label_Span13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span13.Location = new System.Drawing.Point(10, 38);
            this.label_Span13.Name = "label_Span13";
            this.label_Span13.Size = new System.Drawing.Size(110, 22);
            this.label_Span13.TabIndex = 41;
            this.label_Span13.Text = "Span Value";
            // 
            // group_Span4
            // 
            this.group_Span4.BackColor = System.Drawing.Color.Transparent;
            this.group_Span4.Controls.Add(this.label_Span4);
            this.group_Span4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span4.Location = new System.Drawing.Point(667, 2);
            this.group_Span4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span4.Name = "group_Span4";
            this.group_Span4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span4.Size = new System.Drawing.Size(160, 88);
            this.group_Span4.TabIndex = 227;
            this.group_Span4.TabStop = false;
            this.group_Span4.Text = "ID_4";
            // 
            // label_Span4
            // 
            this.label_Span4.AutoSize = true;
            this.label_Span4.BackColor = System.Drawing.Color.Gold;
            this.label_Span4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span4.Location = new System.Drawing.Point(10, 38);
            this.label_Span4.Name = "label_Span4";
            this.label_Span4.Size = new System.Drawing.Size(110, 22);
            this.label_Span4.TabIndex = 41;
            this.label_Span4.Text = "Span Value";
            // 
            // group_Span5
            // 
            this.group_Span5.BackColor = System.Drawing.Color.Transparent;
            this.group_Span5.Controls.Add(this.label_Span5);
            this.group_Span5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span5.Location = new System.Drawing.Point(833, 2);
            this.group_Span5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span5.Name = "group_Span5";
            this.group_Span5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span5.Size = new System.Drawing.Size(160, 88);
            this.group_Span5.TabIndex = 222;
            this.group_Span5.TabStop = false;
            this.group_Span5.Text = "ID_5";
            // 
            // label_Span5
            // 
            this.label_Span5.AutoSize = true;
            this.label_Span5.BackColor = System.Drawing.Color.Gold;
            this.label_Span5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span5.Location = new System.Drawing.Point(10, 38);
            this.label_Span5.Name = "label_Span5";
            this.label_Span5.Size = new System.Drawing.Size(110, 22);
            this.label_Span5.TabIndex = 41;
            this.label_Span5.Text = "Span Value";
            // 
            // group_Span6
            // 
            this.group_Span6.BackColor = System.Drawing.Color.Transparent;
            this.group_Span6.Controls.Add(this.label_Span6);
            this.group_Span6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span6.Location = new System.Drawing.Point(999, 2);
            this.group_Span6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span6.Name = "group_Span6";
            this.group_Span6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span6.Size = new System.Drawing.Size(162, 88);
            this.group_Span6.TabIndex = 217;
            this.group_Span6.TabStop = false;
            this.group_Span6.Text = "ID_6";
            // 
            // label_Span6
            // 
            this.label_Span6.AutoSize = true;
            this.label_Span6.BackColor = System.Drawing.Color.Gold;
            this.label_Span6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span6.Location = new System.Drawing.Point(10, 38);
            this.label_Span6.Name = "label_Span6";
            this.label_Span6.Size = new System.Drawing.Size(110, 22);
            this.label_Span6.TabIndex = 41;
            this.label_Span6.Text = "Span Value";
            // 
            // group_Span21
            // 
            this.group_Span21.BackColor = System.Drawing.Color.Transparent;
            this.group_Span21.Controls.Add(this.label_Span21);
            this.group_Span21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_Span21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_Span21.Location = new System.Drawing.Point(3, 278);
            this.group_Span21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span21.Name = "group_Span21";
            this.group_Span21.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_Span21.Size = new System.Drawing.Size(160, 89);
            this.group_Span21.TabIndex = 249;
            this.group_Span21.TabStop = false;
            this.group_Span21.Text = "ID_21";
            // 
            // label_Span21
            // 
            this.label_Span21.AutoSize = true;
            this.label_Span21.BackColor = System.Drawing.Color.Gold;
            this.label_Span21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Span21.Location = new System.Drawing.Point(10, 38);
            this.label_Span21.Name = "label_Span21";
            this.label_Span21.Size = new System.Drawing.Size(110, 22);
            this.label_Span21.TabIndex = 41;
            this.label_Span21.Text = "Span Value";
            // 
            // a
            // 
            this.a.BackColor = System.Drawing.SystemColors.Control;
            this.a.Controls.Add(this.tableLayoutPanel17);
            this.a.Location = new System.Drawing.Point(4, 29);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(1164, 369);
            this.a.TabIndex = 14;
            this.a.Text = "【a(Slope)】";
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel17.ColumnCount = 7;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel17.Controls.Add(this.group_A23, 2, 3);
            this.tableLayoutPanel17.Controls.Add(this.group_A22, 1, 3);
            this.tableLayoutPanel17.Controls.Add(this.group_A0, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.group_A14, 0, 2);
            this.tableLayoutPanel17.Controls.Add(this.group_A15, 1, 2);
            this.tableLayoutPanel17.Controls.Add(this.group_A20, 6, 2);
            this.tableLayoutPanel17.Controls.Add(this.group_A19, 5, 2);
            this.tableLayoutPanel17.Controls.Add(this.group_A18, 4, 2);
            this.tableLayoutPanel17.Controls.Add(this.group_A17, 3, 2);
            this.tableLayoutPanel17.Controls.Add(this.group_A16, 2, 2);
            this.tableLayoutPanel17.Controls.Add(this.group_A1, 1, 0);
            this.tableLayoutPanel17.Controls.Add(this.group_A7, 0, 1);
            this.tableLayoutPanel17.Controls.Add(this.group_A2, 2, 0);
            this.tableLayoutPanel17.Controls.Add(this.group_A8, 1, 1);
            this.tableLayoutPanel17.Controls.Add(this.group_A3, 3, 0);
            this.tableLayoutPanel17.Controls.Add(this.group_A9, 2, 1);
            this.tableLayoutPanel17.Controls.Add(this.group_A10, 3, 1);
            this.tableLayoutPanel17.Controls.Add(this.group_A11, 4, 1);
            this.tableLayoutPanel17.Controls.Add(this.group_A12, 5, 1);
            this.tableLayoutPanel17.Controls.Add(this.group_A13, 6, 1);
            this.tableLayoutPanel17.Controls.Add(this.group_A4, 4, 0);
            this.tableLayoutPanel17.Controls.Add(this.group_A5, 5, 0);
            this.tableLayoutPanel17.Controls.Add(this.group_A6, 6, 0);
            this.tableLayoutPanel17.Controls.Add(this.group_A21, 0, 3);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel17.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 4;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(1164, 369);
            this.tableLayoutPanel17.TabIndex = 218;
            // 
            // group_A23
            // 
            this.group_A23.BackColor = System.Drawing.Color.Transparent;
            this.group_A23.Controls.Add(this.label_A23);
            this.group_A23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A23.Location = new System.Drawing.Point(335, 278);
            this.group_A23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A23.Name = "group_A23";
            this.group_A23.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A23.Size = new System.Drawing.Size(160, 89);
            this.group_A23.TabIndex = 240;
            this.group_A23.TabStop = false;
            this.group_A23.Text = "ID_23";
            // 
            // label_A23
            // 
            this.label_A23.AutoSize = true;
            this.label_A23.BackColor = System.Drawing.Color.Gold;
            this.label_A23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A23.Location = new System.Drawing.Point(10, 38);
            this.label_A23.Name = "label_A23";
            this.label_A23.Size = new System.Drawing.Size(80, 22);
            this.label_A23.TabIndex = 41;
            this.label_A23.Text = "A Value";
            // 
            // group_A22
            // 
            this.group_A22.BackColor = System.Drawing.Color.Transparent;
            this.group_A22.Controls.Add(this.label_A22);
            this.group_A22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A22.Location = new System.Drawing.Point(169, 278);
            this.group_A22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A22.Name = "group_A22";
            this.group_A22.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A22.Size = new System.Drawing.Size(160, 89);
            this.group_A22.TabIndex = 245;
            this.group_A22.TabStop = false;
            this.group_A22.Text = "ID_22";
            // 
            // label_A22
            // 
            this.label_A22.AutoSize = true;
            this.label_A22.BackColor = System.Drawing.Color.Gold;
            this.label_A22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A22.Location = new System.Drawing.Point(10, 38);
            this.label_A22.Name = "label_A22";
            this.label_A22.Size = new System.Drawing.Size(80, 22);
            this.label_A22.TabIndex = 41;
            this.label_A22.Text = "A Value";
            // 
            // group_A0
            // 
            this.group_A0.BackColor = System.Drawing.Color.Transparent;
            this.group_A0.Controls.Add(this.label_A0);
            this.group_A0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A0.Location = new System.Drawing.Point(3, 2);
            this.group_A0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A0.Name = "group_A0";
            this.group_A0.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A0.Size = new System.Drawing.Size(160, 88);
            this.group_A0.TabIndex = 176;
            this.group_A0.TabStop = false;
            this.group_A0.Text = "ID_0";
            // 
            // label_A0
            // 
            this.label_A0.AutoSize = true;
            this.label_A0.BackColor = System.Drawing.Color.Gold;
            this.label_A0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A0.Location = new System.Drawing.Point(10, 38);
            this.label_A0.Name = "label_A0";
            this.label_A0.Size = new System.Drawing.Size(80, 22);
            this.label_A0.TabIndex = 41;
            this.label_A0.Text = "A Value";
            // 
            // group_A14
            // 
            this.group_A14.BackColor = System.Drawing.Color.Transparent;
            this.group_A14.Controls.Add(this.label_A14);
            this.group_A14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A14.Location = new System.Drawing.Point(3, 186);
            this.group_A14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A14.Name = "group_A14";
            this.group_A14.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A14.Size = new System.Drawing.Size(160, 88);
            this.group_A14.TabIndex = 248;
            this.group_A14.TabStop = false;
            this.group_A14.Text = "ID_14";
            // 
            // label_A14
            // 
            this.label_A14.AutoSize = true;
            this.label_A14.BackColor = System.Drawing.Color.Gold;
            this.label_A14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A14.Location = new System.Drawing.Point(10, 38);
            this.label_A14.Name = "label_A14";
            this.label_A14.Size = new System.Drawing.Size(80, 22);
            this.label_A14.TabIndex = 41;
            this.label_A14.Text = "A Value";
            // 
            // group_A15
            // 
            this.group_A15.BackColor = System.Drawing.Color.Transparent;
            this.group_A15.Controls.Add(this.label_A15);
            this.group_A15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A15.Location = new System.Drawing.Point(169, 186);
            this.group_A15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A15.Name = "group_A15";
            this.group_A15.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A15.Size = new System.Drawing.Size(160, 88);
            this.group_A15.TabIndex = 244;
            this.group_A15.TabStop = false;
            this.group_A15.Text = "ID_15";
            // 
            // label_A15
            // 
            this.label_A15.AutoSize = true;
            this.label_A15.BackColor = System.Drawing.Color.Gold;
            this.label_A15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A15.Location = new System.Drawing.Point(10, 38);
            this.label_A15.Name = "label_A15";
            this.label_A15.Size = new System.Drawing.Size(80, 22);
            this.label_A15.TabIndex = 41;
            this.label_A15.Text = "A Value";
            // 
            // group_A20
            // 
            this.group_A20.BackColor = System.Drawing.Color.Transparent;
            this.group_A20.Controls.Add(this.label_A20);
            this.group_A20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A20.Location = new System.Drawing.Point(999, 186);
            this.group_A20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A20.Name = "group_A20";
            this.group_A20.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A20.Size = new System.Drawing.Size(162, 88);
            this.group_A20.TabIndex = 219;
            this.group_A20.TabStop = false;
            this.group_A20.Text = "ID_20";
            // 
            // label_A20
            // 
            this.label_A20.AutoSize = true;
            this.label_A20.BackColor = System.Drawing.Color.Gold;
            this.label_A20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A20.Location = new System.Drawing.Point(10, 38);
            this.label_A20.Name = "label_A20";
            this.label_A20.Size = new System.Drawing.Size(80, 22);
            this.label_A20.TabIndex = 41;
            this.label_A20.Text = "A Value";
            // 
            // group_A19
            // 
            this.group_A19.BackColor = System.Drawing.Color.Transparent;
            this.group_A19.Controls.Add(this.label_A19);
            this.group_A19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A19.Location = new System.Drawing.Point(833, 186);
            this.group_A19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A19.Name = "group_A19";
            this.group_A19.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A19.Size = new System.Drawing.Size(160, 88);
            this.group_A19.TabIndex = 224;
            this.group_A19.TabStop = false;
            this.group_A19.Text = "ID_19";
            // 
            // label_A19
            // 
            this.label_A19.AutoSize = true;
            this.label_A19.BackColor = System.Drawing.Color.Gold;
            this.label_A19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A19.Location = new System.Drawing.Point(10, 38);
            this.label_A19.Name = "label_A19";
            this.label_A19.Size = new System.Drawing.Size(80, 22);
            this.label_A19.TabIndex = 41;
            this.label_A19.Text = "A Value";
            // 
            // group_A18
            // 
            this.group_A18.BackColor = System.Drawing.Color.Transparent;
            this.group_A18.Controls.Add(this.label_A18);
            this.group_A18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A18.Location = new System.Drawing.Point(667, 186);
            this.group_A18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A18.Name = "group_A18";
            this.group_A18.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A18.Size = new System.Drawing.Size(160, 88);
            this.group_A18.TabIndex = 229;
            this.group_A18.TabStop = false;
            this.group_A18.Text = "ID_18";
            // 
            // label_A18
            // 
            this.label_A18.AutoSize = true;
            this.label_A18.BackColor = System.Drawing.Color.Gold;
            this.label_A18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A18.Location = new System.Drawing.Point(10, 38);
            this.label_A18.Name = "label_A18";
            this.label_A18.Size = new System.Drawing.Size(80, 22);
            this.label_A18.TabIndex = 41;
            this.label_A18.Text = "A Value";
            // 
            // group_A17
            // 
            this.group_A17.BackColor = System.Drawing.Color.Transparent;
            this.group_A17.Controls.Add(this.label_A17);
            this.group_A17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A17.Location = new System.Drawing.Point(501, 186);
            this.group_A17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A17.Name = "group_A17";
            this.group_A17.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A17.Size = new System.Drawing.Size(160, 88);
            this.group_A17.TabIndex = 234;
            this.group_A17.TabStop = false;
            this.group_A17.Text = "ID_17";
            // 
            // label_A17
            // 
            this.label_A17.AutoSize = true;
            this.label_A17.BackColor = System.Drawing.Color.Gold;
            this.label_A17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A17.Location = new System.Drawing.Point(10, 38);
            this.label_A17.Name = "label_A17";
            this.label_A17.Size = new System.Drawing.Size(80, 22);
            this.label_A17.TabIndex = 41;
            this.label_A17.Text = "A Value";
            // 
            // group_A16
            // 
            this.group_A16.BackColor = System.Drawing.Color.Transparent;
            this.group_A16.Controls.Add(this.label_A16);
            this.group_A16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A16.Location = new System.Drawing.Point(335, 186);
            this.group_A16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A16.Name = "group_A16";
            this.group_A16.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A16.Size = new System.Drawing.Size(160, 88);
            this.group_A16.TabIndex = 239;
            this.group_A16.TabStop = false;
            this.group_A16.Text = "ID_16";
            // 
            // label_A16
            // 
            this.label_A16.AutoSize = true;
            this.label_A16.BackColor = System.Drawing.Color.Gold;
            this.label_A16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A16.Location = new System.Drawing.Point(10, 38);
            this.label_A16.Name = "label_A16";
            this.label_A16.Size = new System.Drawing.Size(80, 22);
            this.label_A16.TabIndex = 41;
            this.label_A16.Text = "A Value";
            // 
            // group_A1
            // 
            this.group_A1.BackColor = System.Drawing.Color.Transparent;
            this.group_A1.Controls.Add(this.label_A1);
            this.group_A1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A1.Location = new System.Drawing.Point(169, 2);
            this.group_A1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A1.Name = "group_A1";
            this.group_A1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A1.Size = new System.Drawing.Size(160, 88);
            this.group_A1.TabIndex = 242;
            this.group_A1.TabStop = false;
            this.group_A1.Text = "ID_1";
            // 
            // label_A1
            // 
            this.label_A1.AutoSize = true;
            this.label_A1.BackColor = System.Drawing.Color.Gold;
            this.label_A1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A1.Location = new System.Drawing.Point(10, 38);
            this.label_A1.Name = "label_A1";
            this.label_A1.Size = new System.Drawing.Size(80, 22);
            this.label_A1.TabIndex = 41;
            this.label_A1.Text = "A Value";
            // 
            // group_A7
            // 
            this.group_A7.BackColor = System.Drawing.Color.Transparent;
            this.group_A7.Controls.Add(this.label_A7);
            this.group_A7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A7.Location = new System.Drawing.Point(3, 94);
            this.group_A7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A7.Name = "group_A7";
            this.group_A7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A7.Size = new System.Drawing.Size(160, 88);
            this.group_A7.TabIndex = 247;
            this.group_A7.TabStop = false;
            this.group_A7.Text = "ID_7";
            // 
            // label_A7
            // 
            this.label_A7.AutoSize = true;
            this.label_A7.BackColor = System.Drawing.Color.Gold;
            this.label_A7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A7.Location = new System.Drawing.Point(10, 38);
            this.label_A7.Name = "label_A7";
            this.label_A7.Size = new System.Drawing.Size(80, 22);
            this.label_A7.TabIndex = 41;
            this.label_A7.Text = "A Value";
            // 
            // group_A2
            // 
            this.group_A2.BackColor = System.Drawing.Color.Transparent;
            this.group_A2.Controls.Add(this.label_A2);
            this.group_A2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A2.Location = new System.Drawing.Point(335, 2);
            this.group_A2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A2.Name = "group_A2";
            this.group_A2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A2.Size = new System.Drawing.Size(160, 88);
            this.group_A2.TabIndex = 237;
            this.group_A2.TabStop = false;
            this.group_A2.Text = "ID_2";
            // 
            // label_A2
            // 
            this.label_A2.AutoSize = true;
            this.label_A2.BackColor = System.Drawing.Color.Gold;
            this.label_A2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A2.Location = new System.Drawing.Point(10, 38);
            this.label_A2.Name = "label_A2";
            this.label_A2.Size = new System.Drawing.Size(80, 22);
            this.label_A2.TabIndex = 41;
            this.label_A2.Text = "A Value";
            // 
            // group_A8
            // 
            this.group_A8.BackColor = System.Drawing.Color.Transparent;
            this.group_A8.Controls.Add(this.label_A8);
            this.group_A8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A8.Location = new System.Drawing.Point(169, 94);
            this.group_A8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A8.Name = "group_A8";
            this.group_A8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A8.Size = new System.Drawing.Size(160, 88);
            this.group_A8.TabIndex = 243;
            this.group_A8.TabStop = false;
            this.group_A8.Text = "ID_8";
            // 
            // label_A8
            // 
            this.label_A8.AutoSize = true;
            this.label_A8.BackColor = System.Drawing.Color.Gold;
            this.label_A8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A8.Location = new System.Drawing.Point(10, 38);
            this.label_A8.Name = "label_A8";
            this.label_A8.Size = new System.Drawing.Size(80, 22);
            this.label_A8.TabIndex = 41;
            this.label_A8.Text = "A Value";
            // 
            // group_A3
            // 
            this.group_A3.BackColor = System.Drawing.Color.Transparent;
            this.group_A3.Controls.Add(this.label_A3);
            this.group_A3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A3.Location = new System.Drawing.Point(501, 2);
            this.group_A3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A3.Name = "group_A3";
            this.group_A3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A3.Size = new System.Drawing.Size(160, 88);
            this.group_A3.TabIndex = 232;
            this.group_A3.TabStop = false;
            this.group_A3.Text = "ID_3";
            // 
            // label_A3
            // 
            this.label_A3.AutoSize = true;
            this.label_A3.BackColor = System.Drawing.Color.Gold;
            this.label_A3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A3.Location = new System.Drawing.Point(10, 38);
            this.label_A3.Name = "label_A3";
            this.label_A3.Size = new System.Drawing.Size(80, 22);
            this.label_A3.TabIndex = 41;
            this.label_A3.Text = "A Value";
            // 
            // group_A9
            // 
            this.group_A9.BackColor = System.Drawing.Color.Transparent;
            this.group_A9.Controls.Add(this.label_A9);
            this.group_A9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A9.Location = new System.Drawing.Point(335, 94);
            this.group_A9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A9.Name = "group_A9";
            this.group_A9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A9.Size = new System.Drawing.Size(160, 88);
            this.group_A9.TabIndex = 238;
            this.group_A9.TabStop = false;
            this.group_A9.Text = "ID_9";
            // 
            // label_A9
            // 
            this.label_A9.AutoSize = true;
            this.label_A9.BackColor = System.Drawing.Color.Gold;
            this.label_A9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A9.Location = new System.Drawing.Point(10, 38);
            this.label_A9.Name = "label_A9";
            this.label_A9.Size = new System.Drawing.Size(80, 22);
            this.label_A9.TabIndex = 41;
            this.label_A9.Text = "A Value";
            // 
            // group_A10
            // 
            this.group_A10.BackColor = System.Drawing.Color.Transparent;
            this.group_A10.Controls.Add(this.label_A10);
            this.group_A10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A10.Location = new System.Drawing.Point(501, 94);
            this.group_A10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A10.Name = "group_A10";
            this.group_A10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A10.Size = new System.Drawing.Size(160, 88);
            this.group_A10.TabIndex = 233;
            this.group_A10.TabStop = false;
            this.group_A10.Text = "ID_10";
            // 
            // label_A10
            // 
            this.label_A10.AutoSize = true;
            this.label_A10.BackColor = System.Drawing.Color.Gold;
            this.label_A10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A10.Location = new System.Drawing.Point(10, 38);
            this.label_A10.Name = "label_A10";
            this.label_A10.Size = new System.Drawing.Size(80, 22);
            this.label_A10.TabIndex = 41;
            this.label_A10.Text = "A Value";
            // 
            // group_A11
            // 
            this.group_A11.BackColor = System.Drawing.Color.Transparent;
            this.group_A11.Controls.Add(this.label_A11);
            this.group_A11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A11.Location = new System.Drawing.Point(667, 94);
            this.group_A11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A11.Name = "group_A11";
            this.group_A11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A11.Size = new System.Drawing.Size(160, 88);
            this.group_A11.TabIndex = 228;
            this.group_A11.TabStop = false;
            this.group_A11.Text = "ID_11";
            // 
            // label_A11
            // 
            this.label_A11.AutoSize = true;
            this.label_A11.BackColor = System.Drawing.Color.Gold;
            this.label_A11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A11.Location = new System.Drawing.Point(10, 38);
            this.label_A11.Name = "label_A11";
            this.label_A11.Size = new System.Drawing.Size(80, 22);
            this.label_A11.TabIndex = 41;
            this.label_A11.Text = "A Value";
            // 
            // group_A12
            // 
            this.group_A12.BackColor = System.Drawing.Color.Transparent;
            this.group_A12.Controls.Add(this.label_A12);
            this.group_A12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A12.Location = new System.Drawing.Point(833, 94);
            this.group_A12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A12.Name = "group_A12";
            this.group_A12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A12.Size = new System.Drawing.Size(160, 88);
            this.group_A12.TabIndex = 223;
            this.group_A12.TabStop = false;
            this.group_A12.Text = "ID_12";
            // 
            // label_A12
            // 
            this.label_A12.AutoSize = true;
            this.label_A12.BackColor = System.Drawing.Color.Gold;
            this.label_A12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A12.Location = new System.Drawing.Point(10, 38);
            this.label_A12.Name = "label_A12";
            this.label_A12.Size = new System.Drawing.Size(80, 22);
            this.label_A12.TabIndex = 41;
            this.label_A12.Text = "A Value";
            // 
            // group_A13
            // 
            this.group_A13.BackColor = System.Drawing.Color.Transparent;
            this.group_A13.Controls.Add(this.label_A13);
            this.group_A13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A13.Location = new System.Drawing.Point(999, 94);
            this.group_A13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A13.Name = "group_A13";
            this.group_A13.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A13.Size = new System.Drawing.Size(162, 88);
            this.group_A13.TabIndex = 218;
            this.group_A13.TabStop = false;
            this.group_A13.Text = "ID_13";
            // 
            // label_A13
            // 
            this.label_A13.AutoSize = true;
            this.label_A13.BackColor = System.Drawing.Color.Gold;
            this.label_A13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A13.Location = new System.Drawing.Point(10, 38);
            this.label_A13.Name = "label_A13";
            this.label_A13.Size = new System.Drawing.Size(80, 22);
            this.label_A13.TabIndex = 41;
            this.label_A13.Text = "A Value";
            // 
            // group_A4
            // 
            this.group_A4.BackColor = System.Drawing.Color.Transparent;
            this.group_A4.Controls.Add(this.label_A4);
            this.group_A4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A4.Location = new System.Drawing.Point(667, 2);
            this.group_A4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A4.Name = "group_A4";
            this.group_A4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A4.Size = new System.Drawing.Size(160, 88);
            this.group_A4.TabIndex = 227;
            this.group_A4.TabStop = false;
            this.group_A4.Text = "ID_4";
            // 
            // label_A4
            // 
            this.label_A4.AutoSize = true;
            this.label_A4.BackColor = System.Drawing.Color.Gold;
            this.label_A4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A4.Location = new System.Drawing.Point(10, 38);
            this.label_A4.Name = "label_A4";
            this.label_A4.Size = new System.Drawing.Size(80, 22);
            this.label_A4.TabIndex = 41;
            this.label_A4.Text = "A Value";
            // 
            // group_A5
            // 
            this.group_A5.BackColor = System.Drawing.Color.Transparent;
            this.group_A5.Controls.Add(this.label_A5);
            this.group_A5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A5.Location = new System.Drawing.Point(833, 2);
            this.group_A5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A5.Name = "group_A5";
            this.group_A5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A5.Size = new System.Drawing.Size(160, 88);
            this.group_A5.TabIndex = 222;
            this.group_A5.TabStop = false;
            this.group_A5.Text = "ID_5";
            // 
            // label_A5
            // 
            this.label_A5.AutoSize = true;
            this.label_A5.BackColor = System.Drawing.Color.Gold;
            this.label_A5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A5.Location = new System.Drawing.Point(10, 38);
            this.label_A5.Name = "label_A5";
            this.label_A5.Size = new System.Drawing.Size(80, 22);
            this.label_A5.TabIndex = 41;
            this.label_A5.Text = "A Value";
            // 
            // group_A6
            // 
            this.group_A6.BackColor = System.Drawing.Color.Transparent;
            this.group_A6.Controls.Add(this.label_A6);
            this.group_A6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A6.Location = new System.Drawing.Point(999, 2);
            this.group_A6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A6.Name = "group_A6";
            this.group_A6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A6.Size = new System.Drawing.Size(162, 88);
            this.group_A6.TabIndex = 217;
            this.group_A6.TabStop = false;
            this.group_A6.Text = "ID_6";
            // 
            // label_A6
            // 
            this.label_A6.AutoSize = true;
            this.label_A6.BackColor = System.Drawing.Color.Gold;
            this.label_A6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A6.Location = new System.Drawing.Point(10, 38);
            this.label_A6.Name = "label_A6";
            this.label_A6.Size = new System.Drawing.Size(80, 22);
            this.label_A6.TabIndex = 41;
            this.label_A6.Text = "A Value";
            // 
            // group_A21
            // 
            this.group_A21.BackColor = System.Drawing.Color.Transparent;
            this.group_A21.Controls.Add(this.label_A21);
            this.group_A21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_A21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_A21.Location = new System.Drawing.Point(3, 278);
            this.group_A21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A21.Name = "group_A21";
            this.group_A21.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_A21.Size = new System.Drawing.Size(160, 89);
            this.group_A21.TabIndex = 249;
            this.group_A21.TabStop = false;
            this.group_A21.Text = "ID_21";
            // 
            // label_A21
            // 
            this.label_A21.AutoSize = true;
            this.label_A21.BackColor = System.Drawing.Color.Gold;
            this.label_A21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_A21.Location = new System.Drawing.Point(10, 38);
            this.label_A21.Name = "label_A21";
            this.label_A21.Size = new System.Drawing.Size(80, 22);
            this.label_A21.TabIndex = 41;
            this.label_A21.Text = "A Value";
            // 
            // b
            // 
            this.b.BackColor = System.Drawing.SystemColors.Control;
            this.b.Controls.Add(this.tableLayoutPanel18);
            this.b.Location = new System.Drawing.Point(4, 29);
            this.b.Name = "b";
            this.b.Size = new System.Drawing.Size(1164, 369);
            this.b.TabIndex = 15;
            this.b.Text = "【b(intercept)】";
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel18.ColumnCount = 7;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel18.Controls.Add(this.group_B23, 2, 3);
            this.tableLayoutPanel18.Controls.Add(this.group_B22, 1, 3);
            this.tableLayoutPanel18.Controls.Add(this.group_B0, 0, 0);
            this.tableLayoutPanel18.Controls.Add(this.group_B14, 0, 2);
            this.tableLayoutPanel18.Controls.Add(this.group_B15, 1, 2);
            this.tableLayoutPanel18.Controls.Add(this.group_B20, 6, 2);
            this.tableLayoutPanel18.Controls.Add(this.group_B19, 5, 2);
            this.tableLayoutPanel18.Controls.Add(this.group_B18, 4, 2);
            this.tableLayoutPanel18.Controls.Add(this.group_B17, 3, 2);
            this.tableLayoutPanel18.Controls.Add(this.group_B16, 2, 2);
            this.tableLayoutPanel18.Controls.Add(this.group_B1, 1, 0);
            this.tableLayoutPanel18.Controls.Add(this.group_B7, 0, 1);
            this.tableLayoutPanel18.Controls.Add(this.group_B2, 2, 0);
            this.tableLayoutPanel18.Controls.Add(this.group_B8, 1, 1);
            this.tableLayoutPanel18.Controls.Add(this.group_B3, 3, 0);
            this.tableLayoutPanel18.Controls.Add(this.group_B9, 2, 1);
            this.tableLayoutPanel18.Controls.Add(this.group_B10, 3, 1);
            this.tableLayoutPanel18.Controls.Add(this.group_B11, 4, 1);
            this.tableLayoutPanel18.Controls.Add(this.group_B12, 5, 1);
            this.tableLayoutPanel18.Controls.Add(this.group_B13, 6, 1);
            this.tableLayoutPanel18.Controls.Add(this.group_B4, 4, 0);
            this.tableLayoutPanel18.Controls.Add(this.group_B5, 5, 0);
            this.tableLayoutPanel18.Controls.Add(this.group_B6, 6, 0);
            this.tableLayoutPanel18.Controls.Add(this.group_B21, 0, 3);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel18.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 4;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(1164, 369);
            this.tableLayoutPanel18.TabIndex = 218;
            // 
            // group_B23
            // 
            this.group_B23.BackColor = System.Drawing.Color.Transparent;
            this.group_B23.Controls.Add(this.label_B23);
            this.group_B23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B23.Location = new System.Drawing.Point(335, 278);
            this.group_B23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B23.Name = "group_B23";
            this.group_B23.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B23.Size = new System.Drawing.Size(160, 89);
            this.group_B23.TabIndex = 240;
            this.group_B23.TabStop = false;
            this.group_B23.Text = "ID_23";
            // 
            // label_B23
            // 
            this.label_B23.AutoSize = true;
            this.label_B23.BackColor = System.Drawing.Color.Gold;
            this.label_B23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B23.Location = new System.Drawing.Point(10, 38);
            this.label_B23.Name = "label_B23";
            this.label_B23.Size = new System.Drawing.Size(80, 22);
            this.label_B23.TabIndex = 41;
            this.label_B23.Text = "B Value";
            // 
            // group_B22
            // 
            this.group_B22.BackColor = System.Drawing.Color.Transparent;
            this.group_B22.Controls.Add(this.label_B22);
            this.group_B22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B22.Location = new System.Drawing.Point(169, 278);
            this.group_B22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B22.Name = "group_B22";
            this.group_B22.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B22.Size = new System.Drawing.Size(160, 89);
            this.group_B22.TabIndex = 245;
            this.group_B22.TabStop = false;
            this.group_B22.Text = "ID_22";
            // 
            // label_B22
            // 
            this.label_B22.AutoSize = true;
            this.label_B22.BackColor = System.Drawing.Color.Gold;
            this.label_B22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B22.Location = new System.Drawing.Point(10, 38);
            this.label_B22.Name = "label_B22";
            this.label_B22.Size = new System.Drawing.Size(80, 22);
            this.label_B22.TabIndex = 41;
            this.label_B22.Text = "B Value";
            // 
            // group_B0
            // 
            this.group_B0.BackColor = System.Drawing.Color.Transparent;
            this.group_B0.Controls.Add(this.label_B0);
            this.group_B0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B0.Location = new System.Drawing.Point(3, 2);
            this.group_B0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B0.Name = "group_B0";
            this.group_B0.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B0.Size = new System.Drawing.Size(160, 88);
            this.group_B0.TabIndex = 176;
            this.group_B0.TabStop = false;
            this.group_B0.Text = "ID_0";
            // 
            // label_B0
            // 
            this.label_B0.AutoSize = true;
            this.label_B0.BackColor = System.Drawing.Color.Gold;
            this.label_B0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B0.Location = new System.Drawing.Point(10, 38);
            this.label_B0.Name = "label_B0";
            this.label_B0.Size = new System.Drawing.Size(80, 22);
            this.label_B0.TabIndex = 41;
            this.label_B0.Text = "B Value";
            // 
            // group_B14
            // 
            this.group_B14.BackColor = System.Drawing.Color.Transparent;
            this.group_B14.Controls.Add(this.label_B14);
            this.group_B14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B14.Location = new System.Drawing.Point(3, 186);
            this.group_B14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B14.Name = "group_B14";
            this.group_B14.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B14.Size = new System.Drawing.Size(160, 88);
            this.group_B14.TabIndex = 248;
            this.group_B14.TabStop = false;
            this.group_B14.Text = "ID_14";
            // 
            // label_B14
            // 
            this.label_B14.AutoSize = true;
            this.label_B14.BackColor = System.Drawing.Color.Gold;
            this.label_B14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B14.Location = new System.Drawing.Point(10, 38);
            this.label_B14.Name = "label_B14";
            this.label_B14.Size = new System.Drawing.Size(80, 22);
            this.label_B14.TabIndex = 41;
            this.label_B14.Text = "B Value";
            // 
            // group_B15
            // 
            this.group_B15.BackColor = System.Drawing.Color.Transparent;
            this.group_B15.Controls.Add(this.label_B15);
            this.group_B15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B15.Location = new System.Drawing.Point(169, 186);
            this.group_B15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B15.Name = "group_B15";
            this.group_B15.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B15.Size = new System.Drawing.Size(160, 88);
            this.group_B15.TabIndex = 244;
            this.group_B15.TabStop = false;
            this.group_B15.Text = "ID_15";
            // 
            // label_B15
            // 
            this.label_B15.AutoSize = true;
            this.label_B15.BackColor = System.Drawing.Color.Gold;
            this.label_B15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B15.Location = new System.Drawing.Point(10, 38);
            this.label_B15.Name = "label_B15";
            this.label_B15.Size = new System.Drawing.Size(80, 22);
            this.label_B15.TabIndex = 41;
            this.label_B15.Text = "B Value";
            // 
            // group_B20
            // 
            this.group_B20.BackColor = System.Drawing.Color.Transparent;
            this.group_B20.Controls.Add(this.label_B20);
            this.group_B20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B20.Location = new System.Drawing.Point(999, 186);
            this.group_B20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B20.Name = "group_B20";
            this.group_B20.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B20.Size = new System.Drawing.Size(162, 88);
            this.group_B20.TabIndex = 219;
            this.group_B20.TabStop = false;
            this.group_B20.Text = "ID_20";
            // 
            // label_B20
            // 
            this.label_B20.AutoSize = true;
            this.label_B20.BackColor = System.Drawing.Color.Gold;
            this.label_B20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B20.Location = new System.Drawing.Point(10, 38);
            this.label_B20.Name = "label_B20";
            this.label_B20.Size = new System.Drawing.Size(80, 22);
            this.label_B20.TabIndex = 41;
            this.label_B20.Text = "B Value";
            // 
            // group_B19
            // 
            this.group_B19.BackColor = System.Drawing.Color.Transparent;
            this.group_B19.Controls.Add(this.label_B19);
            this.group_B19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B19.Location = new System.Drawing.Point(833, 186);
            this.group_B19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B19.Name = "group_B19";
            this.group_B19.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B19.Size = new System.Drawing.Size(160, 88);
            this.group_B19.TabIndex = 224;
            this.group_B19.TabStop = false;
            this.group_B19.Text = "ID_19";
            // 
            // label_B19
            // 
            this.label_B19.AutoSize = true;
            this.label_B19.BackColor = System.Drawing.Color.Gold;
            this.label_B19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B19.Location = new System.Drawing.Point(10, 38);
            this.label_B19.Name = "label_B19";
            this.label_B19.Size = new System.Drawing.Size(80, 22);
            this.label_B19.TabIndex = 41;
            this.label_B19.Text = "B Value";
            // 
            // group_B18
            // 
            this.group_B18.BackColor = System.Drawing.Color.Transparent;
            this.group_B18.Controls.Add(this.label_B18);
            this.group_B18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B18.Location = new System.Drawing.Point(667, 186);
            this.group_B18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B18.Name = "group_B18";
            this.group_B18.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B18.Size = new System.Drawing.Size(160, 88);
            this.group_B18.TabIndex = 229;
            this.group_B18.TabStop = false;
            this.group_B18.Text = "ID_18";
            // 
            // label_B18
            // 
            this.label_B18.AutoSize = true;
            this.label_B18.BackColor = System.Drawing.Color.Gold;
            this.label_B18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B18.Location = new System.Drawing.Point(10, 38);
            this.label_B18.Name = "label_B18";
            this.label_B18.Size = new System.Drawing.Size(80, 22);
            this.label_B18.TabIndex = 41;
            this.label_B18.Text = "B Value";
            // 
            // group_B17
            // 
            this.group_B17.BackColor = System.Drawing.Color.Transparent;
            this.group_B17.Controls.Add(this.label_B17);
            this.group_B17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B17.Location = new System.Drawing.Point(501, 186);
            this.group_B17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B17.Name = "group_B17";
            this.group_B17.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B17.Size = new System.Drawing.Size(160, 88);
            this.group_B17.TabIndex = 234;
            this.group_B17.TabStop = false;
            this.group_B17.Text = "ID_17";
            // 
            // label_B17
            // 
            this.label_B17.AutoSize = true;
            this.label_B17.BackColor = System.Drawing.Color.Gold;
            this.label_B17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B17.Location = new System.Drawing.Point(10, 38);
            this.label_B17.Name = "label_B17";
            this.label_B17.Size = new System.Drawing.Size(80, 22);
            this.label_B17.TabIndex = 41;
            this.label_B17.Text = "B Value";
            // 
            // group_B16
            // 
            this.group_B16.BackColor = System.Drawing.Color.Transparent;
            this.group_B16.Controls.Add(this.label_B16);
            this.group_B16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B16.Location = new System.Drawing.Point(335, 186);
            this.group_B16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B16.Name = "group_B16";
            this.group_B16.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B16.Size = new System.Drawing.Size(160, 88);
            this.group_B16.TabIndex = 239;
            this.group_B16.TabStop = false;
            this.group_B16.Text = "ID_16";
            // 
            // label_B16
            // 
            this.label_B16.AutoSize = true;
            this.label_B16.BackColor = System.Drawing.Color.Gold;
            this.label_B16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B16.Location = new System.Drawing.Point(10, 38);
            this.label_B16.Name = "label_B16";
            this.label_B16.Size = new System.Drawing.Size(80, 22);
            this.label_B16.TabIndex = 41;
            this.label_B16.Text = "B Value";
            // 
            // group_B1
            // 
            this.group_B1.BackColor = System.Drawing.Color.Transparent;
            this.group_B1.Controls.Add(this.label_B1);
            this.group_B1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B1.Location = new System.Drawing.Point(169, 2);
            this.group_B1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B1.Name = "group_B1";
            this.group_B1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B1.Size = new System.Drawing.Size(160, 88);
            this.group_B1.TabIndex = 242;
            this.group_B1.TabStop = false;
            this.group_B1.Text = "ID_1";
            // 
            // label_B1
            // 
            this.label_B1.AutoSize = true;
            this.label_B1.BackColor = System.Drawing.Color.Gold;
            this.label_B1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B1.Location = new System.Drawing.Point(10, 38);
            this.label_B1.Name = "label_B1";
            this.label_B1.Size = new System.Drawing.Size(80, 22);
            this.label_B1.TabIndex = 41;
            this.label_B1.Text = "B Value";
            // 
            // group_B7
            // 
            this.group_B7.BackColor = System.Drawing.Color.Transparent;
            this.group_B7.Controls.Add(this.label_B7);
            this.group_B7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B7.Location = new System.Drawing.Point(3, 94);
            this.group_B7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B7.Name = "group_B7";
            this.group_B7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B7.Size = new System.Drawing.Size(160, 88);
            this.group_B7.TabIndex = 247;
            this.group_B7.TabStop = false;
            this.group_B7.Text = "ID_7";
            // 
            // label_B7
            // 
            this.label_B7.AutoSize = true;
            this.label_B7.BackColor = System.Drawing.Color.Gold;
            this.label_B7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B7.Location = new System.Drawing.Point(10, 38);
            this.label_B7.Name = "label_B7";
            this.label_B7.Size = new System.Drawing.Size(80, 22);
            this.label_B7.TabIndex = 41;
            this.label_B7.Text = "B Value";
            // 
            // group_B2
            // 
            this.group_B2.BackColor = System.Drawing.Color.Transparent;
            this.group_B2.Controls.Add(this.label_B2);
            this.group_B2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B2.Location = new System.Drawing.Point(335, 2);
            this.group_B2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B2.Name = "group_B2";
            this.group_B2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B2.Size = new System.Drawing.Size(160, 88);
            this.group_B2.TabIndex = 237;
            this.group_B2.TabStop = false;
            this.group_B2.Text = "ID_2";
            // 
            // label_B2
            // 
            this.label_B2.AutoSize = true;
            this.label_B2.BackColor = System.Drawing.Color.Gold;
            this.label_B2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B2.Location = new System.Drawing.Point(10, 38);
            this.label_B2.Name = "label_B2";
            this.label_B2.Size = new System.Drawing.Size(80, 22);
            this.label_B2.TabIndex = 41;
            this.label_B2.Text = "B Value";
            // 
            // group_B8
            // 
            this.group_B8.BackColor = System.Drawing.Color.Transparent;
            this.group_B8.Controls.Add(this.label_B8);
            this.group_B8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B8.Location = new System.Drawing.Point(169, 94);
            this.group_B8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B8.Name = "group_B8";
            this.group_B8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B8.Size = new System.Drawing.Size(160, 88);
            this.group_B8.TabIndex = 243;
            this.group_B8.TabStop = false;
            this.group_B8.Text = "ID_8";
            // 
            // label_B8
            // 
            this.label_B8.AutoSize = true;
            this.label_B8.BackColor = System.Drawing.Color.Gold;
            this.label_B8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B8.Location = new System.Drawing.Point(10, 38);
            this.label_B8.Name = "label_B8";
            this.label_B8.Size = new System.Drawing.Size(80, 22);
            this.label_B8.TabIndex = 41;
            this.label_B8.Text = "B Value";
            // 
            // group_B3
            // 
            this.group_B3.BackColor = System.Drawing.Color.Transparent;
            this.group_B3.Controls.Add(this.label_B3);
            this.group_B3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B3.Location = new System.Drawing.Point(501, 2);
            this.group_B3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B3.Name = "group_B3";
            this.group_B3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B3.Size = new System.Drawing.Size(160, 88);
            this.group_B3.TabIndex = 232;
            this.group_B3.TabStop = false;
            this.group_B3.Text = "ID_3";
            // 
            // label_B3
            // 
            this.label_B3.AutoSize = true;
            this.label_B3.BackColor = System.Drawing.Color.Gold;
            this.label_B3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B3.Location = new System.Drawing.Point(10, 38);
            this.label_B3.Name = "label_B3";
            this.label_B3.Size = new System.Drawing.Size(80, 22);
            this.label_B3.TabIndex = 41;
            this.label_B3.Text = "B Value";
            // 
            // group_B9
            // 
            this.group_B9.BackColor = System.Drawing.Color.Transparent;
            this.group_B9.Controls.Add(this.label_B9);
            this.group_B9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B9.Location = new System.Drawing.Point(335, 94);
            this.group_B9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B9.Name = "group_B9";
            this.group_B9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B9.Size = new System.Drawing.Size(160, 88);
            this.group_B9.TabIndex = 238;
            this.group_B9.TabStop = false;
            this.group_B9.Text = "ID_9";
            // 
            // label_B9
            // 
            this.label_B9.AutoSize = true;
            this.label_B9.BackColor = System.Drawing.Color.Gold;
            this.label_B9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B9.Location = new System.Drawing.Point(10, 38);
            this.label_B9.Name = "label_B9";
            this.label_B9.Size = new System.Drawing.Size(80, 22);
            this.label_B9.TabIndex = 41;
            this.label_B9.Text = "B Value";
            // 
            // group_B10
            // 
            this.group_B10.BackColor = System.Drawing.Color.Transparent;
            this.group_B10.Controls.Add(this.label_B10);
            this.group_B10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B10.Location = new System.Drawing.Point(501, 94);
            this.group_B10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B10.Name = "group_B10";
            this.group_B10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B10.Size = new System.Drawing.Size(160, 88);
            this.group_B10.TabIndex = 233;
            this.group_B10.TabStop = false;
            this.group_B10.Text = "ID_10";
            // 
            // label_B10
            // 
            this.label_B10.AutoSize = true;
            this.label_B10.BackColor = System.Drawing.Color.Gold;
            this.label_B10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B10.Location = new System.Drawing.Point(10, 38);
            this.label_B10.Name = "label_B10";
            this.label_B10.Size = new System.Drawing.Size(80, 22);
            this.label_B10.TabIndex = 41;
            this.label_B10.Text = "B Value";
            // 
            // group_B11
            // 
            this.group_B11.BackColor = System.Drawing.Color.Transparent;
            this.group_B11.Controls.Add(this.label_B11);
            this.group_B11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B11.Location = new System.Drawing.Point(667, 94);
            this.group_B11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B11.Name = "group_B11";
            this.group_B11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B11.Size = new System.Drawing.Size(160, 88);
            this.group_B11.TabIndex = 228;
            this.group_B11.TabStop = false;
            this.group_B11.Text = "ID_11";
            // 
            // label_B11
            // 
            this.label_B11.AutoSize = true;
            this.label_B11.BackColor = System.Drawing.Color.Gold;
            this.label_B11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B11.Location = new System.Drawing.Point(10, 38);
            this.label_B11.Name = "label_B11";
            this.label_B11.Size = new System.Drawing.Size(80, 22);
            this.label_B11.TabIndex = 41;
            this.label_B11.Text = "B Value";
            // 
            // group_B12
            // 
            this.group_B12.BackColor = System.Drawing.Color.Transparent;
            this.group_B12.Controls.Add(this.label_B12);
            this.group_B12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B12.Location = new System.Drawing.Point(833, 94);
            this.group_B12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B12.Name = "group_B12";
            this.group_B12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B12.Size = new System.Drawing.Size(160, 88);
            this.group_B12.TabIndex = 223;
            this.group_B12.TabStop = false;
            this.group_B12.Text = "ID_12";
            // 
            // label_B12
            // 
            this.label_B12.AutoSize = true;
            this.label_B12.BackColor = System.Drawing.Color.Gold;
            this.label_B12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B12.Location = new System.Drawing.Point(10, 38);
            this.label_B12.Name = "label_B12";
            this.label_B12.Size = new System.Drawing.Size(80, 22);
            this.label_B12.TabIndex = 41;
            this.label_B12.Text = "B Value";
            // 
            // group_B13
            // 
            this.group_B13.BackColor = System.Drawing.Color.Transparent;
            this.group_B13.Controls.Add(this.label_B13);
            this.group_B13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B13.Location = new System.Drawing.Point(999, 94);
            this.group_B13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B13.Name = "group_B13";
            this.group_B13.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B13.Size = new System.Drawing.Size(162, 88);
            this.group_B13.TabIndex = 218;
            this.group_B13.TabStop = false;
            this.group_B13.Text = "ID_13";
            // 
            // label_B13
            // 
            this.label_B13.AutoSize = true;
            this.label_B13.BackColor = System.Drawing.Color.Gold;
            this.label_B13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B13.Location = new System.Drawing.Point(10, 38);
            this.label_B13.Name = "label_B13";
            this.label_B13.Size = new System.Drawing.Size(80, 22);
            this.label_B13.TabIndex = 41;
            this.label_B13.Text = "B Value";
            // 
            // group_B4
            // 
            this.group_B4.BackColor = System.Drawing.Color.Transparent;
            this.group_B4.Controls.Add(this.label_B4);
            this.group_B4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B4.Location = new System.Drawing.Point(667, 2);
            this.group_B4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B4.Name = "group_B4";
            this.group_B4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B4.Size = new System.Drawing.Size(160, 88);
            this.group_B4.TabIndex = 227;
            this.group_B4.TabStop = false;
            this.group_B4.Text = "ID_4";
            // 
            // label_B4
            // 
            this.label_B4.AutoSize = true;
            this.label_B4.BackColor = System.Drawing.Color.Gold;
            this.label_B4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B4.Location = new System.Drawing.Point(10, 38);
            this.label_B4.Name = "label_B4";
            this.label_B4.Size = new System.Drawing.Size(80, 22);
            this.label_B4.TabIndex = 41;
            this.label_B4.Text = "B Value";
            // 
            // group_B5
            // 
            this.group_B5.BackColor = System.Drawing.Color.Transparent;
            this.group_B5.Controls.Add(this.label_B5);
            this.group_B5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B5.Location = new System.Drawing.Point(833, 2);
            this.group_B5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B5.Name = "group_B5";
            this.group_B5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B5.Size = new System.Drawing.Size(160, 88);
            this.group_B5.TabIndex = 222;
            this.group_B5.TabStop = false;
            this.group_B5.Text = "ID_5";
            // 
            // label_B5
            // 
            this.label_B5.AutoSize = true;
            this.label_B5.BackColor = System.Drawing.Color.Gold;
            this.label_B5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B5.Location = new System.Drawing.Point(10, 38);
            this.label_B5.Name = "label_B5";
            this.label_B5.Size = new System.Drawing.Size(80, 22);
            this.label_B5.TabIndex = 41;
            this.label_B5.Text = "B Value";
            // 
            // group_B6
            // 
            this.group_B6.BackColor = System.Drawing.Color.Transparent;
            this.group_B6.Controls.Add(this.label_B6);
            this.group_B6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B6.Location = new System.Drawing.Point(999, 2);
            this.group_B6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B6.Name = "group_B6";
            this.group_B6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B6.Size = new System.Drawing.Size(162, 88);
            this.group_B6.TabIndex = 217;
            this.group_B6.TabStop = false;
            this.group_B6.Text = "ID_6";
            // 
            // label_B6
            // 
            this.label_B6.AutoSize = true;
            this.label_B6.BackColor = System.Drawing.Color.Gold;
            this.label_B6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B6.Location = new System.Drawing.Point(10, 38);
            this.label_B6.Name = "label_B6";
            this.label_B6.Size = new System.Drawing.Size(80, 22);
            this.label_B6.TabIndex = 41;
            this.label_B6.Text = "B Value";
            // 
            // group_B21
            // 
            this.group_B21.BackColor = System.Drawing.Color.Transparent;
            this.group_B21.Controls.Add(this.label_B21);
            this.group_B21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_B21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_B21.Location = new System.Drawing.Point(3, 278);
            this.group_B21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B21.Name = "group_B21";
            this.group_B21.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_B21.Size = new System.Drawing.Size(160, 89);
            this.group_B21.TabIndex = 249;
            this.group_B21.TabStop = false;
            this.group_B21.Text = "ID_21";
            // 
            // label_B21
            // 
            this.label_B21.AutoSize = true;
            this.label_B21.BackColor = System.Drawing.Color.Gold;
            this.label_B21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_B21.Location = new System.Drawing.Point(10, 38);
            this.label_B21.Name = "label_B21";
            this.label_B21.Size = new System.Drawing.Size(80, 22);
            this.label_B21.TabIndex = 41;
            this.label_B21.Text = "B Value";
            // 
            // tabPage_GasName
            // 
            this.tabPage_GasName.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage_GasName.Controls.Add(this.tableLayoutPanel6);
            this.tabPage_GasName.Location = new System.Drawing.Point(4, 29);
            this.tabPage_GasName.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage_GasName.Name = "tabPage_GasName";
            this.tabPage_GasName.Size = new System.Drawing.Size(1164, 369);
            this.tabPage_GasName.TabIndex = 11;
            this.tabPage_GasName.Text = "【Gas Name】";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 7;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name0, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name23, 2, 3);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name22, 1, 3);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name21, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name1, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name14, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name15, 1, 2);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name20, 6, 2);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name19, 5, 2);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name18, 4, 2);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name17, 3, 2);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name16, 2, 2);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name2, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name7, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name3, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name8, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name4, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name9, 2, 1);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name10, 3, 1);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name11, 4, 1);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name12, 5, 1);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name13, 6, 1);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name5, 5, 0);
            this.tableLayoutPanel6.Controls.Add(this.groupBox_Sensor_Name6, 6, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 4;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(1164, 369);
            this.tableLayoutPanel6.TabIndex = 242;
            // 
            // groupBox_Sensor_Name0
            // 
            this.groupBox_Sensor_Name0.Controls.Add(this.label_Sensor_Name0);
            this.groupBox_Sensor_Name0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name0.Location = new System.Drawing.Point(2, 2);
            this.groupBox_Sensor_Name0.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name0.Name = "groupBox_Sensor_Name0";
            this.groupBox_Sensor_Name0.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name0.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name0.TabIndex = 208;
            this.groupBox_Sensor_Name0.TabStop = false;
            this.groupBox_Sensor_Name0.Text = "ID_0";
            // 
            // label_Sensor_Name0
            // 
            this.label_Sensor_Name0.AutoSize = true;
            this.label_Sensor_Name0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name0.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name0.Name = "label_Sensor_Name0";
            this.label_Sensor_Name0.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name0.TabIndex = 9;
            this.label_Sensor_Name0.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name23
            // 
            this.groupBox_Sensor_Name23.Controls.Add(this.label_Sensor_Name23);
            this.groupBox_Sensor_Name23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name23.Location = new System.Drawing.Point(334, 278);
            this.groupBox_Sensor_Name23.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name23.Name = "groupBox_Sensor_Name23";
            this.groupBox_Sensor_Name23.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name23.Size = new System.Drawing.Size(162, 89);
            this.groupBox_Sensor_Name23.TabIndex = 232;
            this.groupBox_Sensor_Name23.TabStop = false;
            this.groupBox_Sensor_Name23.Text = "ID_23";
            // 
            // label_Sensor_Name23
            // 
            this.label_Sensor_Name23.AutoSize = true;
            this.label_Sensor_Name23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name23.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name23.Name = "label_Sensor_Name23";
            this.label_Sensor_Name23.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name23.TabIndex = 9;
            this.label_Sensor_Name23.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name22
            // 
            this.groupBox_Sensor_Name22.Controls.Add(this.label_Sensor_Name22);
            this.groupBox_Sensor_Name22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name22.Location = new System.Drawing.Point(168, 278);
            this.groupBox_Sensor_Name22.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name22.Name = "groupBox_Sensor_Name22";
            this.groupBox_Sensor_Name22.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name22.Size = new System.Drawing.Size(162, 89);
            this.groupBox_Sensor_Name22.TabIndex = 237;
            this.groupBox_Sensor_Name22.TabStop = false;
            this.groupBox_Sensor_Name22.Text = "ID_22";
            // 
            // label_Sensor_Name22
            // 
            this.label_Sensor_Name22.AutoSize = true;
            this.label_Sensor_Name22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name22.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name22.Name = "label_Sensor_Name22";
            this.label_Sensor_Name22.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name22.TabIndex = 9;
            this.label_Sensor_Name22.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name21
            // 
            this.groupBox_Sensor_Name21.Controls.Add(this.label_Sensor_Name21);
            this.groupBox_Sensor_Name21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name21.Location = new System.Drawing.Point(2, 278);
            this.groupBox_Sensor_Name21.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name21.Name = "groupBox_Sensor_Name21";
            this.groupBox_Sensor_Name21.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name21.Size = new System.Drawing.Size(162, 89);
            this.groupBox_Sensor_Name21.TabIndex = 241;
            this.groupBox_Sensor_Name21.TabStop = false;
            this.groupBox_Sensor_Name21.Text = "ID_21";
            // 
            // label_Sensor_Name21
            // 
            this.label_Sensor_Name21.AutoSize = true;
            this.label_Sensor_Name21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name21.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name21.Name = "label_Sensor_Name21";
            this.label_Sensor_Name21.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name21.TabIndex = 9;
            this.label_Sensor_Name21.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name1
            // 
            this.groupBox_Sensor_Name1.Controls.Add(this.label_Sensor_Name1);
            this.groupBox_Sensor_Name1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name1.Location = new System.Drawing.Point(168, 2);
            this.groupBox_Sensor_Name1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name1.Name = "groupBox_Sensor_Name1";
            this.groupBox_Sensor_Name1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name1.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name1.TabIndex = 234;
            this.groupBox_Sensor_Name1.TabStop = false;
            this.groupBox_Sensor_Name1.Text = "ID_1";
            // 
            // label_Sensor_Name1
            // 
            this.label_Sensor_Name1.AutoSize = true;
            this.label_Sensor_Name1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name1.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name1.Name = "label_Sensor_Name1";
            this.label_Sensor_Name1.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name1.TabIndex = 9;
            this.label_Sensor_Name1.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name14
            // 
            this.groupBox_Sensor_Name14.Controls.Add(this.label_Sensor_Name14);
            this.groupBox_Sensor_Name14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name14.Location = new System.Drawing.Point(2, 186);
            this.groupBox_Sensor_Name14.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name14.Name = "groupBox_Sensor_Name14";
            this.groupBox_Sensor_Name14.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name14.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name14.TabIndex = 240;
            this.groupBox_Sensor_Name14.TabStop = false;
            this.groupBox_Sensor_Name14.Text = "ID_14";
            // 
            // label_Sensor_Name14
            // 
            this.label_Sensor_Name14.AutoSize = true;
            this.label_Sensor_Name14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name14.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name14.Name = "label_Sensor_Name14";
            this.label_Sensor_Name14.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name14.TabIndex = 9;
            this.label_Sensor_Name14.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name15
            // 
            this.groupBox_Sensor_Name15.Controls.Add(this.label_Sensor_Name15);
            this.groupBox_Sensor_Name15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name15.Location = new System.Drawing.Point(168, 186);
            this.groupBox_Sensor_Name15.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name15.Name = "groupBox_Sensor_Name15";
            this.groupBox_Sensor_Name15.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name15.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name15.TabIndex = 236;
            this.groupBox_Sensor_Name15.TabStop = false;
            this.groupBox_Sensor_Name15.Text = "ID_15";
            // 
            // label_Sensor_Name15
            // 
            this.label_Sensor_Name15.AutoSize = true;
            this.label_Sensor_Name15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name15.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name15.Name = "label_Sensor_Name15";
            this.label_Sensor_Name15.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name15.TabIndex = 9;
            this.label_Sensor_Name15.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name20
            // 
            this.groupBox_Sensor_Name20.Controls.Add(this.label_Sensor_Name20);
            this.groupBox_Sensor_Name20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name20.Location = new System.Drawing.Point(998, 186);
            this.groupBox_Sensor_Name20.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name20.Name = "groupBox_Sensor_Name20";
            this.groupBox_Sensor_Name20.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name20.Size = new System.Drawing.Size(164, 88);
            this.groupBox_Sensor_Name20.TabIndex = 211;
            this.groupBox_Sensor_Name20.TabStop = false;
            this.groupBox_Sensor_Name20.Text = "ID_20";
            // 
            // label_Sensor_Name20
            // 
            this.label_Sensor_Name20.AutoSize = true;
            this.label_Sensor_Name20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name20.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name20.Name = "label_Sensor_Name20";
            this.label_Sensor_Name20.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name20.TabIndex = 9;
            this.label_Sensor_Name20.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name19
            // 
            this.groupBox_Sensor_Name19.Controls.Add(this.label_Sensor_Name19);
            this.groupBox_Sensor_Name19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name19.Location = new System.Drawing.Point(832, 186);
            this.groupBox_Sensor_Name19.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name19.Name = "groupBox_Sensor_Name19";
            this.groupBox_Sensor_Name19.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name19.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name19.TabIndex = 216;
            this.groupBox_Sensor_Name19.TabStop = false;
            this.groupBox_Sensor_Name19.Text = "ID_19";
            // 
            // label_Sensor_Name19
            // 
            this.label_Sensor_Name19.AutoSize = true;
            this.label_Sensor_Name19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name19.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name19.Name = "label_Sensor_Name19";
            this.label_Sensor_Name19.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name19.TabIndex = 9;
            this.label_Sensor_Name19.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name18
            // 
            this.groupBox_Sensor_Name18.Controls.Add(this.label_Sensor_Name18);
            this.groupBox_Sensor_Name18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name18.Location = new System.Drawing.Point(666, 186);
            this.groupBox_Sensor_Name18.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name18.Name = "groupBox_Sensor_Name18";
            this.groupBox_Sensor_Name18.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name18.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name18.TabIndex = 221;
            this.groupBox_Sensor_Name18.TabStop = false;
            this.groupBox_Sensor_Name18.Text = "ID_18";
            // 
            // label_Sensor_Name18
            // 
            this.label_Sensor_Name18.AutoSize = true;
            this.label_Sensor_Name18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name18.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name18.Name = "label_Sensor_Name18";
            this.label_Sensor_Name18.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name18.TabIndex = 9;
            this.label_Sensor_Name18.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name17
            // 
            this.groupBox_Sensor_Name17.Controls.Add(this.label_Sensor_Name17);
            this.groupBox_Sensor_Name17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name17.Location = new System.Drawing.Point(500, 186);
            this.groupBox_Sensor_Name17.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name17.Name = "groupBox_Sensor_Name17";
            this.groupBox_Sensor_Name17.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name17.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name17.TabIndex = 226;
            this.groupBox_Sensor_Name17.TabStop = false;
            this.groupBox_Sensor_Name17.Text = "ID_17";
            // 
            // label_Sensor_Name17
            // 
            this.label_Sensor_Name17.AutoSize = true;
            this.label_Sensor_Name17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name17.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name17.Name = "label_Sensor_Name17";
            this.label_Sensor_Name17.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name17.TabIndex = 9;
            this.label_Sensor_Name17.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name16
            // 
            this.groupBox_Sensor_Name16.Controls.Add(this.label_Sensor_Name16);
            this.groupBox_Sensor_Name16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name16.Location = new System.Drawing.Point(334, 186);
            this.groupBox_Sensor_Name16.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name16.Name = "groupBox_Sensor_Name16";
            this.groupBox_Sensor_Name16.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name16.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name16.TabIndex = 231;
            this.groupBox_Sensor_Name16.TabStop = false;
            this.groupBox_Sensor_Name16.Text = "ID_16";
            // 
            // label_Sensor_Name16
            // 
            this.label_Sensor_Name16.AutoSize = true;
            this.label_Sensor_Name16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name16.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name16.Name = "label_Sensor_Name16";
            this.label_Sensor_Name16.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name16.TabIndex = 9;
            this.label_Sensor_Name16.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name2
            // 
            this.groupBox_Sensor_Name2.Controls.Add(this.label_Sensor_Name2);
            this.groupBox_Sensor_Name2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name2.Location = new System.Drawing.Point(334, 2);
            this.groupBox_Sensor_Name2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name2.Name = "groupBox_Sensor_Name2";
            this.groupBox_Sensor_Name2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name2.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name2.TabIndex = 229;
            this.groupBox_Sensor_Name2.TabStop = false;
            this.groupBox_Sensor_Name2.Text = "ID_2";
            // 
            // label_Sensor_Name2
            // 
            this.label_Sensor_Name2.AutoSize = true;
            this.label_Sensor_Name2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name2.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name2.Name = "label_Sensor_Name2";
            this.label_Sensor_Name2.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name2.TabIndex = 9;
            this.label_Sensor_Name2.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name7
            // 
            this.groupBox_Sensor_Name7.Controls.Add(this.label_Sensor_Name7);
            this.groupBox_Sensor_Name7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name7.Location = new System.Drawing.Point(2, 94);
            this.groupBox_Sensor_Name7.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name7.Name = "groupBox_Sensor_Name7";
            this.groupBox_Sensor_Name7.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name7.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name7.TabIndex = 239;
            this.groupBox_Sensor_Name7.TabStop = false;
            this.groupBox_Sensor_Name7.Text = "ID_7";
            // 
            // label_Sensor_Name7
            // 
            this.label_Sensor_Name7.AutoSize = true;
            this.label_Sensor_Name7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name7.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name7.Name = "label_Sensor_Name7";
            this.label_Sensor_Name7.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name7.TabIndex = 9;
            this.label_Sensor_Name7.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name3
            // 
            this.groupBox_Sensor_Name3.Controls.Add(this.label_Sensor_Name3);
            this.groupBox_Sensor_Name3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name3.Location = new System.Drawing.Point(500, 2);
            this.groupBox_Sensor_Name3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name3.Name = "groupBox_Sensor_Name3";
            this.groupBox_Sensor_Name3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name3.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name3.TabIndex = 224;
            this.groupBox_Sensor_Name3.TabStop = false;
            this.groupBox_Sensor_Name3.Text = "ID_3";
            // 
            // label_Sensor_Name3
            // 
            this.label_Sensor_Name3.AutoSize = true;
            this.label_Sensor_Name3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name3.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name3.Name = "label_Sensor_Name3";
            this.label_Sensor_Name3.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name3.TabIndex = 9;
            this.label_Sensor_Name3.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name8
            // 
            this.groupBox_Sensor_Name8.Controls.Add(this.label_Sensor_Name8);
            this.groupBox_Sensor_Name8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name8.Location = new System.Drawing.Point(168, 94);
            this.groupBox_Sensor_Name8.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name8.Name = "groupBox_Sensor_Name8";
            this.groupBox_Sensor_Name8.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name8.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name8.TabIndex = 235;
            this.groupBox_Sensor_Name8.TabStop = false;
            this.groupBox_Sensor_Name8.Text = "ID_8";
            // 
            // label_Sensor_Name8
            // 
            this.label_Sensor_Name8.AutoSize = true;
            this.label_Sensor_Name8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name8.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name8.Name = "label_Sensor_Name8";
            this.label_Sensor_Name8.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name8.TabIndex = 9;
            this.label_Sensor_Name8.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name4
            // 
            this.groupBox_Sensor_Name4.Controls.Add(this.label_Sensor_Name4);
            this.groupBox_Sensor_Name4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name4.Location = new System.Drawing.Point(666, 2);
            this.groupBox_Sensor_Name4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name4.Name = "groupBox_Sensor_Name4";
            this.groupBox_Sensor_Name4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name4.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name4.TabIndex = 219;
            this.groupBox_Sensor_Name4.TabStop = false;
            this.groupBox_Sensor_Name4.Text = "ID_4";
            // 
            // label_Sensor_Name4
            // 
            this.label_Sensor_Name4.AutoSize = true;
            this.label_Sensor_Name4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name4.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name4.Name = "label_Sensor_Name4";
            this.label_Sensor_Name4.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name4.TabIndex = 9;
            this.label_Sensor_Name4.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name9
            // 
            this.groupBox_Sensor_Name9.Controls.Add(this.label_Sensor_Name9);
            this.groupBox_Sensor_Name9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name9.Location = new System.Drawing.Point(334, 94);
            this.groupBox_Sensor_Name9.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name9.Name = "groupBox_Sensor_Name9";
            this.groupBox_Sensor_Name9.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name9.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name9.TabIndex = 230;
            this.groupBox_Sensor_Name9.TabStop = false;
            this.groupBox_Sensor_Name9.Text = "ID_9";
            // 
            // label_Sensor_Name9
            // 
            this.label_Sensor_Name9.AutoSize = true;
            this.label_Sensor_Name9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name9.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name9.Name = "label_Sensor_Name9";
            this.label_Sensor_Name9.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name9.TabIndex = 9;
            this.label_Sensor_Name9.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name10
            // 
            this.groupBox_Sensor_Name10.Controls.Add(this.label_Sensor_Name10);
            this.groupBox_Sensor_Name10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name10.Location = new System.Drawing.Point(500, 94);
            this.groupBox_Sensor_Name10.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name10.Name = "groupBox_Sensor_Name10";
            this.groupBox_Sensor_Name10.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name10.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name10.TabIndex = 225;
            this.groupBox_Sensor_Name10.TabStop = false;
            this.groupBox_Sensor_Name10.Text = "ID_10";
            // 
            // label_Sensor_Name10
            // 
            this.label_Sensor_Name10.AutoSize = true;
            this.label_Sensor_Name10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name10.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name10.Name = "label_Sensor_Name10";
            this.label_Sensor_Name10.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name10.TabIndex = 9;
            this.label_Sensor_Name10.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name11
            // 
            this.groupBox_Sensor_Name11.Controls.Add(this.label_Sensor_Name11);
            this.groupBox_Sensor_Name11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name11.Location = new System.Drawing.Point(666, 94);
            this.groupBox_Sensor_Name11.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name11.Name = "groupBox_Sensor_Name11";
            this.groupBox_Sensor_Name11.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name11.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name11.TabIndex = 220;
            this.groupBox_Sensor_Name11.TabStop = false;
            this.groupBox_Sensor_Name11.Text = "ID_11";
            // 
            // label_Sensor_Name11
            // 
            this.label_Sensor_Name11.AutoSize = true;
            this.label_Sensor_Name11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name11.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name11.Name = "label_Sensor_Name11";
            this.label_Sensor_Name11.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name11.TabIndex = 9;
            this.label_Sensor_Name11.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name12
            // 
            this.groupBox_Sensor_Name12.Controls.Add(this.label_Sensor_Name12);
            this.groupBox_Sensor_Name12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name12.Location = new System.Drawing.Point(832, 94);
            this.groupBox_Sensor_Name12.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name12.Name = "groupBox_Sensor_Name12";
            this.groupBox_Sensor_Name12.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name12.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name12.TabIndex = 215;
            this.groupBox_Sensor_Name12.TabStop = false;
            this.groupBox_Sensor_Name12.Text = "ID_12";
            // 
            // label_Sensor_Name12
            // 
            this.label_Sensor_Name12.AutoSize = true;
            this.label_Sensor_Name12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name12.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name12.Name = "label_Sensor_Name12";
            this.label_Sensor_Name12.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name12.TabIndex = 9;
            this.label_Sensor_Name12.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name13
            // 
            this.groupBox_Sensor_Name13.Controls.Add(this.label_Sensor_Name13);
            this.groupBox_Sensor_Name13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name13.Location = new System.Drawing.Point(998, 94);
            this.groupBox_Sensor_Name13.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name13.Name = "groupBox_Sensor_Name13";
            this.groupBox_Sensor_Name13.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name13.Size = new System.Drawing.Size(164, 88);
            this.groupBox_Sensor_Name13.TabIndex = 210;
            this.groupBox_Sensor_Name13.TabStop = false;
            this.groupBox_Sensor_Name13.Text = "ID_13";
            // 
            // label_Sensor_Name13
            // 
            this.label_Sensor_Name13.AutoSize = true;
            this.label_Sensor_Name13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name13.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name13.Name = "label_Sensor_Name13";
            this.label_Sensor_Name13.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name13.TabIndex = 9;
            this.label_Sensor_Name13.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name5
            // 
            this.groupBox_Sensor_Name5.Controls.Add(this.label_Sensor_Name5);
            this.groupBox_Sensor_Name5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name5.Location = new System.Drawing.Point(832, 2);
            this.groupBox_Sensor_Name5.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name5.Name = "groupBox_Sensor_Name5";
            this.groupBox_Sensor_Name5.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name5.Size = new System.Drawing.Size(162, 88);
            this.groupBox_Sensor_Name5.TabIndex = 214;
            this.groupBox_Sensor_Name5.TabStop = false;
            this.groupBox_Sensor_Name5.Text = "ID_5";
            // 
            // label_Sensor_Name5
            // 
            this.label_Sensor_Name5.AutoSize = true;
            this.label_Sensor_Name5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name5.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name5.Name = "label_Sensor_Name5";
            this.label_Sensor_Name5.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name5.TabIndex = 9;
            this.label_Sensor_Name5.Text = "Gas Name";
            // 
            // groupBox_Sensor_Name6
            // 
            this.groupBox_Sensor_Name6.Controls.Add(this.label_Sensor_Name6);
            this.groupBox_Sensor_Name6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox_Sensor_Name6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.groupBox_Sensor_Name6.Location = new System.Drawing.Point(998, 2);
            this.groupBox_Sensor_Name6.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name6.Name = "groupBox_Sensor_Name6";
            this.groupBox_Sensor_Name6.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Sensor_Name6.Size = new System.Drawing.Size(164, 88);
            this.groupBox_Sensor_Name6.TabIndex = 209;
            this.groupBox_Sensor_Name6.TabStop = false;
            this.groupBox_Sensor_Name6.Text = "ID_6";
            // 
            // label_Sensor_Name6
            // 
            this.label_Sensor_Name6.AutoSize = true;
            this.label_Sensor_Name6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label_Sensor_Name6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_Sensor_Name6.Location = new System.Drawing.Point(10, 38);
            this.label_Sensor_Name6.Name = "label_Sensor_Name6";
            this.label_Sensor_Name6.Size = new System.Drawing.Size(90, 22);
            this.label_Sensor_Name6.TabIndex = 9;
            this.label_Sensor_Name6.Text = "Gas Name";
            // 
            // tabPage_BSN
            // 
            this.tabPage_BSN.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage_BSN.Controls.Add(this.tableLayoutPanel5);
            this.tabPage_BSN.Location = new System.Drawing.Point(4, 29);
            this.tabPage_BSN.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage_BSN.Name = "tabPage_BSN";
            this.tabPage_BSN.Size = new System.Drawing.Size(1164, 369);
            this.tabPage_BSN.TabIndex = 10;
            this.tabPage_BSN.Text = "【BSN】";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 6;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel5.Controls.Add(this.group_BSN0, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN23, 5, 3);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN1, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN22, 4, 3);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN17, 5, 2);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN21, 3, 3);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN2, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN20, 2, 3);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN11, 5, 1);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN19, 1, 3);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN16, 4, 2);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN18, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN3, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN5, 5, 0);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN15, 3, 2);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN4, 4, 0);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN10, 4, 1);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN14, 2, 2);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN6, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN7, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN8, 2, 1);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN13, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN9, 3, 1);
            this.tableLayoutPanel5.Controls.Add(this.group_BSN12, 0, 2);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 4;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1164, 369);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // group_BSN0
            // 
            this.group_BSN0.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN0.Controls.Add(this.label_BSN0);
            this.group_BSN0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN0.Location = new System.Drawing.Point(3, 2);
            this.group_BSN0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN0.Name = "group_BSN0";
            this.group_BSN0.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN0.Size = new System.Drawing.Size(187, 88);
            this.group_BSN0.TabIndex = 273;
            this.group_BSN0.TabStop = false;
            this.group_BSN0.Text = "ID_0";
            // 
            // label_BSN0
            // 
            this.label_BSN0.AutoSize = true;
            this.label_BSN0.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN0.Location = new System.Drawing.Point(10, 38);
            this.label_BSN0.Name = "label_BSN0";
            this.label_BSN0.Size = new System.Drawing.Size(100, 22);
            this.label_BSN0.TabIndex = 41;
            this.label_BSN0.Text = "SerialNum";
            // 
            // group_BSN23
            // 
            this.group_BSN23.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN23.Controls.Add(this.label_BSN23);
            this.group_BSN23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN23.Location = new System.Drawing.Point(968, 278);
            this.group_BSN23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN23.Name = "group_BSN23";
            this.group_BSN23.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN23.Size = new System.Drawing.Size(193, 89);
            this.group_BSN23.TabIndex = 326;
            this.group_BSN23.TabStop = false;
            this.group_BSN23.Text = "ID_23";
            // 
            // label_BSN23
            // 
            this.label_BSN23.AutoSize = true;
            this.label_BSN23.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN23.Location = new System.Drawing.Point(10, 38);
            this.label_BSN23.Name = "label_BSN23";
            this.label_BSN23.Size = new System.Drawing.Size(100, 22);
            this.label_BSN23.TabIndex = 41;
            this.label_BSN23.Text = "SerialNum";
            // 
            // group_BSN1
            // 
            this.group_BSN1.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN1.Controls.Add(this.label_BSN1);
            this.group_BSN1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN1.Location = new System.Drawing.Point(196, 2);
            this.group_BSN1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN1.Name = "group_BSN1";
            this.group_BSN1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN1.Size = new System.Drawing.Size(187, 88);
            this.group_BSN1.TabIndex = 308;
            this.group_BSN1.TabStop = false;
            this.group_BSN1.Text = "ID_1";
            // 
            // label_BSN1
            // 
            this.label_BSN1.AutoSize = true;
            this.label_BSN1.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN1.Location = new System.Drawing.Point(10, 38);
            this.label_BSN1.Name = "label_BSN1";
            this.label_BSN1.Size = new System.Drawing.Size(100, 22);
            this.label_BSN1.TabIndex = 41;
            this.label_BSN1.Text = "SerialNum";
            // 
            // group_BSN22
            // 
            this.group_BSN22.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN22.Controls.Add(this.label_BSN22);
            this.group_BSN22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN22.Location = new System.Drawing.Point(775, 278);
            this.group_BSN22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN22.Name = "group_BSN22";
            this.group_BSN22.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN22.Size = new System.Drawing.Size(187, 89);
            this.group_BSN22.TabIndex = 321;
            this.group_BSN22.TabStop = false;
            this.group_BSN22.Text = "ID_22";
            // 
            // label_BSN22
            // 
            this.label_BSN22.AutoSize = true;
            this.label_BSN22.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN22.Location = new System.Drawing.Point(10, 38);
            this.label_BSN22.Name = "label_BSN22";
            this.label_BSN22.Size = new System.Drawing.Size(100, 22);
            this.label_BSN22.TabIndex = 41;
            this.label_BSN22.Text = "SerialNum";
            // 
            // group_BSN17
            // 
            this.group_BSN17.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN17.Controls.Add(this.label_BSN17);
            this.group_BSN17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN17.Location = new System.Drawing.Point(968, 186);
            this.group_BSN17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN17.Name = "group_BSN17";
            this.group_BSN17.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN17.Size = new System.Drawing.Size(193, 88);
            this.group_BSN17.TabIndex = 325;
            this.group_BSN17.TabStop = false;
            this.group_BSN17.Text = "ID_17";
            // 
            // label_BSN17
            // 
            this.label_BSN17.AutoSize = true;
            this.label_BSN17.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN17.Location = new System.Drawing.Point(10, 38);
            this.label_BSN17.Name = "label_BSN17";
            this.label_BSN17.Size = new System.Drawing.Size(100, 22);
            this.label_BSN17.TabIndex = 41;
            this.label_BSN17.Text = "SerialNum";
            // 
            // group_BSN21
            // 
            this.group_BSN21.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN21.Controls.Add(this.label_BSN21);
            this.group_BSN21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN21.Location = new System.Drawing.Point(582, 278);
            this.group_BSN21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN21.Name = "group_BSN21";
            this.group_BSN21.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN21.Size = new System.Drawing.Size(187, 89);
            this.group_BSN21.TabIndex = 316;
            this.group_BSN21.TabStop = false;
            this.group_BSN21.Text = "ID_21";
            // 
            // label_BSN21
            // 
            this.label_BSN21.AutoSize = true;
            this.label_BSN21.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN21.Location = new System.Drawing.Point(10, 38);
            this.label_BSN21.Name = "label_BSN21";
            this.label_BSN21.Size = new System.Drawing.Size(100, 22);
            this.label_BSN21.TabIndex = 41;
            this.label_BSN21.Text = "SerialNum";
            // 
            // group_BSN2
            // 
            this.group_BSN2.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN2.Controls.Add(this.label_BSN2);
            this.group_BSN2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN2.Location = new System.Drawing.Point(389, 2);
            this.group_BSN2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN2.Name = "group_BSN2";
            this.group_BSN2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN2.Size = new System.Drawing.Size(187, 88);
            this.group_BSN2.TabIndex = 308;
            this.group_BSN2.TabStop = false;
            this.group_BSN2.Text = "ID_2";
            // 
            // label_BSN2
            // 
            this.label_BSN2.AutoSize = true;
            this.label_BSN2.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN2.Location = new System.Drawing.Point(10, 38);
            this.label_BSN2.Name = "label_BSN2";
            this.label_BSN2.Size = new System.Drawing.Size(100, 22);
            this.label_BSN2.TabIndex = 41;
            this.label_BSN2.Text = "SerialNum";
            // 
            // group_BSN20
            // 
            this.group_BSN20.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN20.Controls.Add(this.label_BSN20);
            this.group_BSN20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN20.Location = new System.Drawing.Point(389, 278);
            this.group_BSN20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN20.Name = "group_BSN20";
            this.group_BSN20.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN20.Size = new System.Drawing.Size(187, 89);
            this.group_BSN20.TabIndex = 311;
            this.group_BSN20.TabStop = false;
            this.group_BSN20.Text = "ID_20";
            // 
            // label_BSN20
            // 
            this.label_BSN20.AutoSize = true;
            this.label_BSN20.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN20.Location = new System.Drawing.Point(10, 38);
            this.label_BSN20.Name = "label_BSN20";
            this.label_BSN20.Size = new System.Drawing.Size(100, 22);
            this.label_BSN20.TabIndex = 41;
            this.label_BSN20.Text = "SerialNum";
            // 
            // group_BSN11
            // 
            this.group_BSN11.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN11.Controls.Add(this.label_BSN11);
            this.group_BSN11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN11.Location = new System.Drawing.Point(968, 94);
            this.group_BSN11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN11.Name = "group_BSN11";
            this.group_BSN11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN11.Size = new System.Drawing.Size(193, 88);
            this.group_BSN11.TabIndex = 324;
            this.group_BSN11.TabStop = false;
            this.group_BSN11.Text = "ID_11";
            // 
            // label_BSN11
            // 
            this.label_BSN11.AutoSize = true;
            this.label_BSN11.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN11.Location = new System.Drawing.Point(10, 38);
            this.label_BSN11.Name = "label_BSN11";
            this.label_BSN11.Size = new System.Drawing.Size(100, 22);
            this.label_BSN11.TabIndex = 41;
            this.label_BSN11.Text = "SerialNum";
            // 
            // group_BSN19
            // 
            this.group_BSN19.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN19.Controls.Add(this.label_BSN19);
            this.group_BSN19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN19.Location = new System.Drawing.Point(196, 278);
            this.group_BSN19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN19.Name = "group_BSN19";
            this.group_BSN19.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN19.Size = new System.Drawing.Size(187, 89);
            this.group_BSN19.TabIndex = 311;
            this.group_BSN19.TabStop = false;
            this.group_BSN19.Text = "ID_19";
            // 
            // label_BSN19
            // 
            this.label_BSN19.AutoSize = true;
            this.label_BSN19.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN19.Location = new System.Drawing.Point(10, 38);
            this.label_BSN19.Name = "label_BSN19";
            this.label_BSN19.Size = new System.Drawing.Size(100, 22);
            this.label_BSN19.TabIndex = 41;
            this.label_BSN19.Text = "SerialNum";
            // 
            // group_BSN16
            // 
            this.group_BSN16.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN16.Controls.Add(this.label_BSN16);
            this.group_BSN16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN16.Location = new System.Drawing.Point(775, 186);
            this.group_BSN16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN16.Name = "group_BSN16";
            this.group_BSN16.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN16.Size = new System.Drawing.Size(187, 88);
            this.group_BSN16.TabIndex = 320;
            this.group_BSN16.TabStop = false;
            this.group_BSN16.Text = "ID_16";
            // 
            // label_BSN16
            // 
            this.label_BSN16.AutoSize = true;
            this.label_BSN16.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN16.Location = new System.Drawing.Point(10, 38);
            this.label_BSN16.Name = "label_BSN16";
            this.label_BSN16.Size = new System.Drawing.Size(100, 22);
            this.label_BSN16.TabIndex = 41;
            this.label_BSN16.Text = "SerialNum";
            // 
            // group_BSN18
            // 
            this.group_BSN18.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN18.Controls.Add(this.label_BSN18);
            this.group_BSN18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN18.Location = new System.Drawing.Point(3, 278);
            this.group_BSN18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN18.Name = "group_BSN18";
            this.group_BSN18.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN18.Size = new System.Drawing.Size(187, 89);
            this.group_BSN18.TabIndex = 306;
            this.group_BSN18.TabStop = false;
            this.group_BSN18.Text = "ID_18";
            // 
            // label_BSN18
            // 
            this.label_BSN18.AutoSize = true;
            this.label_BSN18.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN18.Location = new System.Drawing.Point(10, 38);
            this.label_BSN18.Name = "label_BSN18";
            this.label_BSN18.Size = new System.Drawing.Size(100, 22);
            this.label_BSN18.TabIndex = 41;
            this.label_BSN18.Text = "SerialNum";
            // 
            // group_BSN3
            // 
            this.group_BSN3.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN3.Controls.Add(this.label_BSN3);
            this.group_BSN3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN3.Location = new System.Drawing.Point(582, 2);
            this.group_BSN3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN3.Name = "group_BSN3";
            this.group_BSN3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN3.Size = new System.Drawing.Size(187, 88);
            this.group_BSN3.TabIndex = 313;
            this.group_BSN3.TabStop = false;
            this.group_BSN3.Text = "ID_3";
            // 
            // label_BSN3
            // 
            this.label_BSN3.AutoSize = true;
            this.label_BSN3.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN3.Location = new System.Drawing.Point(10, 38);
            this.label_BSN3.Name = "label_BSN3";
            this.label_BSN3.Size = new System.Drawing.Size(100, 22);
            this.label_BSN3.TabIndex = 41;
            this.label_BSN3.Text = "SerialNum";
            // 
            // group_BSN5
            // 
            this.group_BSN5.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN5.Controls.Add(this.label_BSN5);
            this.group_BSN5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN5.Location = new System.Drawing.Point(968, 2);
            this.group_BSN5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN5.Name = "group_BSN5";
            this.group_BSN5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN5.Size = new System.Drawing.Size(193, 88);
            this.group_BSN5.TabIndex = 323;
            this.group_BSN5.TabStop = false;
            this.group_BSN5.Text = "ID_5";
            // 
            // label_BSN5
            // 
            this.label_BSN5.AutoSize = true;
            this.label_BSN5.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN5.Location = new System.Drawing.Point(10, 38);
            this.label_BSN5.Name = "label_BSN5";
            this.label_BSN5.Size = new System.Drawing.Size(100, 22);
            this.label_BSN5.TabIndex = 41;
            this.label_BSN5.Text = "SerialNum";
            // 
            // group_BSN15
            // 
            this.group_BSN15.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN15.Controls.Add(this.label_BSN15);
            this.group_BSN15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN15.Location = new System.Drawing.Point(582, 186);
            this.group_BSN15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN15.Name = "group_BSN15";
            this.group_BSN15.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN15.Size = new System.Drawing.Size(187, 88);
            this.group_BSN15.TabIndex = 315;
            this.group_BSN15.TabStop = false;
            this.group_BSN15.Text = "ID_15";
            // 
            // label_BSN15
            // 
            this.label_BSN15.AutoSize = true;
            this.label_BSN15.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN15.Location = new System.Drawing.Point(10, 38);
            this.label_BSN15.Name = "label_BSN15";
            this.label_BSN15.Size = new System.Drawing.Size(100, 22);
            this.label_BSN15.TabIndex = 41;
            this.label_BSN15.Text = "SerialNum";
            // 
            // group_BSN4
            // 
            this.group_BSN4.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN4.Controls.Add(this.label_BSN4);
            this.group_BSN4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN4.Location = new System.Drawing.Point(775, 2);
            this.group_BSN4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN4.Name = "group_BSN4";
            this.group_BSN4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN4.Size = new System.Drawing.Size(187, 88);
            this.group_BSN4.TabIndex = 318;
            this.group_BSN4.TabStop = false;
            this.group_BSN4.Text = "ID_4";
            // 
            // label_BSN4
            // 
            this.label_BSN4.AutoSize = true;
            this.label_BSN4.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN4.Location = new System.Drawing.Point(10, 38);
            this.label_BSN4.Name = "label_BSN4";
            this.label_BSN4.Size = new System.Drawing.Size(100, 22);
            this.label_BSN4.TabIndex = 41;
            this.label_BSN4.Text = "SerialNum";
            // 
            // group_BSN10
            // 
            this.group_BSN10.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN10.Controls.Add(this.label_BSN10);
            this.group_BSN10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN10.Location = new System.Drawing.Point(775, 94);
            this.group_BSN10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN10.Name = "group_BSN10";
            this.group_BSN10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN10.Size = new System.Drawing.Size(187, 88);
            this.group_BSN10.TabIndex = 319;
            this.group_BSN10.TabStop = false;
            this.group_BSN10.Text = "ID_10";
            // 
            // label_BSN10
            // 
            this.label_BSN10.AutoSize = true;
            this.label_BSN10.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN10.Location = new System.Drawing.Point(10, 38);
            this.label_BSN10.Name = "label_BSN10";
            this.label_BSN10.Size = new System.Drawing.Size(100, 22);
            this.label_BSN10.TabIndex = 41;
            this.label_BSN10.Text = "SerialNum";
            // 
            // group_BSN14
            // 
            this.group_BSN14.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN14.Controls.Add(this.label_BSN14);
            this.group_BSN14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN14.Location = new System.Drawing.Point(389, 186);
            this.group_BSN14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN14.Name = "group_BSN14";
            this.group_BSN14.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN14.Size = new System.Drawing.Size(187, 88);
            this.group_BSN14.TabIndex = 310;
            this.group_BSN14.TabStop = false;
            this.group_BSN14.Text = "ID_14";
            // 
            // label_BSN14
            // 
            this.label_BSN14.AutoSize = true;
            this.label_BSN14.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN14.Location = new System.Drawing.Point(10, 38);
            this.label_BSN14.Name = "label_BSN14";
            this.label_BSN14.Size = new System.Drawing.Size(100, 22);
            this.label_BSN14.TabIndex = 41;
            this.label_BSN14.Text = "SerialNum";
            // 
            // group_BSN6
            // 
            this.group_BSN6.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN6.Controls.Add(this.label_BSN6);
            this.group_BSN6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN6.Location = new System.Drawing.Point(3, 94);
            this.group_BSN6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN6.Name = "group_BSN6";
            this.group_BSN6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN6.Size = new System.Drawing.Size(187, 88);
            this.group_BSN6.TabIndex = 304;
            this.group_BSN6.TabStop = false;
            this.group_BSN6.Text = "ID_6";
            // 
            // label_BSN6
            // 
            this.label_BSN6.AutoSize = true;
            this.label_BSN6.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN6.Location = new System.Drawing.Point(10, 38);
            this.label_BSN6.Name = "label_BSN6";
            this.label_BSN6.Size = new System.Drawing.Size(100, 22);
            this.label_BSN6.TabIndex = 41;
            this.label_BSN6.Text = "SerialNum";
            // 
            // group_BSN7
            // 
            this.group_BSN7.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN7.Controls.Add(this.label_BSN7);
            this.group_BSN7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN7.Location = new System.Drawing.Point(196, 94);
            this.group_BSN7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN7.Name = "group_BSN7";
            this.group_BSN7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN7.Size = new System.Drawing.Size(187, 88);
            this.group_BSN7.TabIndex = 309;
            this.group_BSN7.TabStop = false;
            this.group_BSN7.Text = "ID_7";
            // 
            // label_BSN7
            // 
            this.label_BSN7.AutoSize = true;
            this.label_BSN7.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN7.Location = new System.Drawing.Point(10, 38);
            this.label_BSN7.Name = "label_BSN7";
            this.label_BSN7.Size = new System.Drawing.Size(100, 22);
            this.label_BSN7.TabIndex = 41;
            this.label_BSN7.Text = "SerialNum";
            // 
            // group_BSN8
            // 
            this.group_BSN8.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN8.Controls.Add(this.label_BSN8);
            this.group_BSN8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN8.Location = new System.Drawing.Point(389, 94);
            this.group_BSN8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN8.Name = "group_BSN8";
            this.group_BSN8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN8.Size = new System.Drawing.Size(187, 88);
            this.group_BSN8.TabIndex = 309;
            this.group_BSN8.TabStop = false;
            this.group_BSN8.Text = "ID_8";
            // 
            // label_BSN8
            // 
            this.label_BSN8.AutoSize = true;
            this.label_BSN8.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN8.Location = new System.Drawing.Point(10, 38);
            this.label_BSN8.Name = "label_BSN8";
            this.label_BSN8.Size = new System.Drawing.Size(100, 22);
            this.label_BSN8.TabIndex = 41;
            this.label_BSN8.Text = "SerialNum";
            // 
            // group_BSN13
            // 
            this.group_BSN13.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN13.Controls.Add(this.label82);
            this.group_BSN13.Controls.Add(this.label_BSN13);
            this.group_BSN13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN13.Location = new System.Drawing.Point(196, 186);
            this.group_BSN13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN13.Name = "group_BSN13";
            this.group_BSN13.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN13.Size = new System.Drawing.Size(187, 88);
            this.group_BSN13.TabIndex = 310;
            this.group_BSN13.TabStop = false;
            this.group_BSN13.Text = "ID_13";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.BackColor = System.Drawing.Color.DarkGray;
            this.label82.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label82.Location = new System.Drawing.Point(32, -101);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(117, 24);
            this.label82.TabIndex = 41;
            this.label82.Text = "SerialNum";
            // 
            // label_BSN13
            // 
            this.label_BSN13.AutoSize = true;
            this.label_BSN13.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN13.Location = new System.Drawing.Point(10, 38);
            this.label_BSN13.Name = "label_BSN13";
            this.label_BSN13.Size = new System.Drawing.Size(100, 22);
            this.label_BSN13.TabIndex = 41;
            this.label_BSN13.Text = "SerialNum";
            // 
            // group_BSN9
            // 
            this.group_BSN9.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN9.Controls.Add(this.label_BSN9);
            this.group_BSN9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN9.Location = new System.Drawing.Point(582, 94);
            this.group_BSN9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN9.Name = "group_BSN9";
            this.group_BSN9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN9.Size = new System.Drawing.Size(187, 88);
            this.group_BSN9.TabIndex = 314;
            this.group_BSN9.TabStop = false;
            this.group_BSN9.Text = "ID_9";
            // 
            // label_BSN9
            // 
            this.label_BSN9.AutoSize = true;
            this.label_BSN9.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN9.Location = new System.Drawing.Point(10, 38);
            this.label_BSN9.Name = "label_BSN9";
            this.label_BSN9.Size = new System.Drawing.Size(100, 22);
            this.label_BSN9.TabIndex = 41;
            this.label_BSN9.Text = "SerialNum";
            // 
            // group_BSN12
            // 
            this.group_BSN12.BackColor = System.Drawing.Color.Transparent;
            this.group_BSN12.Controls.Add(this.label_BSN12);
            this.group_BSN12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_BSN12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_BSN12.Location = new System.Drawing.Point(3, 186);
            this.group_BSN12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN12.Name = "group_BSN12";
            this.group_BSN12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_BSN12.Size = new System.Drawing.Size(187, 88);
            this.group_BSN12.TabIndex = 305;
            this.group_BSN12.TabStop = false;
            this.group_BSN12.Text = "ID_12";
            // 
            // label_BSN12
            // 
            this.label_BSN12.AutoSize = true;
            this.label_BSN12.BackColor = System.Drawing.Color.LightGray;
            this.label_BSN12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_BSN12.Location = new System.Drawing.Point(10, 38);
            this.label_BSN12.Name = "label_BSN12";
            this.label_BSN12.Size = new System.Drawing.Size(100, 22);
            this.label_BSN12.TabIndex = 41;
            this.label_BSN12.Text = "SerialNum";
            // 
            // tabPage_FWV
            // 
            this.tabPage_FWV.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage_FWV.Controls.Add(this.tableLayoutPanel7);
            this.tabPage_FWV.Location = new System.Drawing.Point(4, 29);
            this.tabPage_FWV.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage_FWV.Name = "tabPage_FWV";
            this.tabPage_FWV.Size = new System.Drawing.Size(1164, 369);
            this.tabPage_FWV.TabIndex = 6;
            this.tabPage_FWV.Text = "【FW_Ver】";
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 7;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Controls.Add(this.group_FW0, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.group_FW23, 2, 3);
            this.tableLayoutPanel7.Controls.Add(this.group_FW22, 1, 3);
            this.tableLayoutPanel7.Controls.Add(this.group_FW21, 0, 3);
            this.tableLayoutPanel7.Controls.Add(this.group_FW1, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.group_FW14, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.group_FW15, 1, 2);
            this.tableLayoutPanel7.Controls.Add(this.group_FW20, 6, 2);
            this.tableLayoutPanel7.Controls.Add(this.group_FW19, 5, 2);
            this.tableLayoutPanel7.Controls.Add(this.group_FW18, 4, 2);
            this.tableLayoutPanel7.Controls.Add(this.group_FW17, 3, 2);
            this.tableLayoutPanel7.Controls.Add(this.group_FW16, 2, 2);
            this.tableLayoutPanel7.Controls.Add(this.group_FW2, 2, 0);
            this.tableLayoutPanel7.Controls.Add(this.group_FW7, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.group_FW3, 3, 0);
            this.tableLayoutPanel7.Controls.Add(this.group_FW8, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.group_FW4, 4, 0);
            this.tableLayoutPanel7.Controls.Add(this.group_FW9, 2, 1);
            this.tableLayoutPanel7.Controls.Add(this.group_FW10, 3, 1);
            this.tableLayoutPanel7.Controls.Add(this.group_FW11, 4, 1);
            this.tableLayoutPanel7.Controls.Add(this.group_FW12, 5, 1);
            this.tableLayoutPanel7.Controls.Add(this.group_FW13, 6, 1);
            this.tableLayoutPanel7.Controls.Add(this.group_FW5, 5, 0);
            this.tableLayoutPanel7.Controls.Add(this.group_FW6, 6, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 4;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(1164, 369);
            this.tableLayoutPanel7.TabIndex = 207;
            // 
            // group_FW0
            // 
            this.group_FW0.Controls.Add(this.label_FW_0);
            this.group_FW0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW0.Location = new System.Drawing.Point(2, 2);
            this.group_FW0.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW0.Name = "group_FW0";
            this.group_FW0.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW0.Size = new System.Drawing.Size(162, 88);
            this.group_FW0.TabIndex = 0;
            this.group_FW0.TabStop = false;
            this.group_FW0.Text = "ID_0";
            // 
            // label_FW_0
            // 
            this.label_FW_0.AutoSize = true;
            this.label_FW_0.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_0.Location = new System.Drawing.Point(10, 38);
            this.label_FW_0.Name = "label_FW_0";
            this.label_FW_0.Size = new System.Drawing.Size(70, 22);
            this.label_FW_0.TabIndex = 9;
            this.label_FW_0.Text = "FW Ver";
            // 
            // group_FW23
            // 
            this.group_FW23.Controls.Add(this.label_FW_23);
            this.group_FW23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW23.Location = new System.Drawing.Point(334, 278);
            this.group_FW23.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW23.Name = "group_FW23";
            this.group_FW23.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW23.Size = new System.Drawing.Size(162, 89);
            this.group_FW23.TabIndex = 197;
            this.group_FW23.TabStop = false;
            this.group_FW23.Text = "ID_23";
            // 
            // label_FW_23
            // 
            this.label_FW_23.AutoSize = true;
            this.label_FW_23.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_23.Location = new System.Drawing.Point(10, 38);
            this.label_FW_23.Name = "label_FW_23";
            this.label_FW_23.Size = new System.Drawing.Size(70, 22);
            this.label_FW_23.TabIndex = 9;
            this.label_FW_23.Text = "FW Ver";
            // 
            // group_FW22
            // 
            this.group_FW22.Controls.Add(this.label_FW_22);
            this.group_FW22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW22.Location = new System.Drawing.Point(168, 278);
            this.group_FW22.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW22.Name = "group_FW22";
            this.group_FW22.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW22.Size = new System.Drawing.Size(162, 89);
            this.group_FW22.TabIndex = 202;
            this.group_FW22.TabStop = false;
            this.group_FW22.Text = "ID_22";
            // 
            // label_FW_22
            // 
            this.label_FW_22.AutoSize = true;
            this.label_FW_22.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_22.Location = new System.Drawing.Point(10, 38);
            this.label_FW_22.Name = "label_FW_22";
            this.label_FW_22.Size = new System.Drawing.Size(70, 22);
            this.label_FW_22.TabIndex = 9;
            this.label_FW_22.Text = "FW Ver";
            // 
            // group_FW21
            // 
            this.group_FW21.Controls.Add(this.label_FW_21);
            this.group_FW21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW21.Location = new System.Drawing.Point(2, 278);
            this.group_FW21.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW21.Name = "group_FW21";
            this.group_FW21.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW21.Size = new System.Drawing.Size(162, 89);
            this.group_FW21.TabIndex = 206;
            this.group_FW21.TabStop = false;
            this.group_FW21.Text = "ID_21";
            // 
            // label_FW_21
            // 
            this.label_FW_21.AutoSize = true;
            this.label_FW_21.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_21.Location = new System.Drawing.Point(10, 38);
            this.label_FW_21.Name = "label_FW_21";
            this.label_FW_21.Size = new System.Drawing.Size(70, 22);
            this.label_FW_21.TabIndex = 9;
            this.label_FW_21.Text = "FW Ver";
            // 
            // group_FW1
            // 
            this.group_FW1.Controls.Add(this.label_FW_1);
            this.group_FW1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW1.Location = new System.Drawing.Point(168, 2);
            this.group_FW1.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW1.Name = "group_FW1";
            this.group_FW1.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW1.Size = new System.Drawing.Size(162, 88);
            this.group_FW1.TabIndex = 199;
            this.group_FW1.TabStop = false;
            this.group_FW1.Text = "ID_1";
            // 
            // label_FW_1
            // 
            this.label_FW_1.AutoSize = true;
            this.label_FW_1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_1.Location = new System.Drawing.Point(10, 38);
            this.label_FW_1.Name = "label_FW_1";
            this.label_FW_1.Size = new System.Drawing.Size(70, 22);
            this.label_FW_1.TabIndex = 9;
            this.label_FW_1.Text = "FW Ver";
            // 
            // group_FW14
            // 
            this.group_FW14.Controls.Add(this.label_FW_14);
            this.group_FW14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW14.Location = new System.Drawing.Point(2, 186);
            this.group_FW14.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW14.Name = "group_FW14";
            this.group_FW14.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW14.Size = new System.Drawing.Size(162, 88);
            this.group_FW14.TabIndex = 205;
            this.group_FW14.TabStop = false;
            this.group_FW14.Text = "ID_14";
            // 
            // label_FW_14
            // 
            this.label_FW_14.AutoSize = true;
            this.label_FW_14.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_14.Location = new System.Drawing.Point(10, 38);
            this.label_FW_14.Name = "label_FW_14";
            this.label_FW_14.Size = new System.Drawing.Size(70, 22);
            this.label_FW_14.TabIndex = 9;
            this.label_FW_14.Text = "FW Ver";
            // 
            // group_FW15
            // 
            this.group_FW15.Controls.Add(this.label_FW_15);
            this.group_FW15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW15.Location = new System.Drawing.Point(168, 186);
            this.group_FW15.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW15.Name = "group_FW15";
            this.group_FW15.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW15.Size = new System.Drawing.Size(162, 88);
            this.group_FW15.TabIndex = 201;
            this.group_FW15.TabStop = false;
            this.group_FW15.Text = "ID_15";
            // 
            // label_FW_15
            // 
            this.label_FW_15.AutoSize = true;
            this.label_FW_15.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_15.Location = new System.Drawing.Point(10, 38);
            this.label_FW_15.Name = "label_FW_15";
            this.label_FW_15.Size = new System.Drawing.Size(70, 22);
            this.label_FW_15.TabIndex = 9;
            this.label_FW_15.Text = "FW Ver";
            // 
            // group_FW20
            // 
            this.group_FW20.Controls.Add(this.label_FW_20);
            this.group_FW20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW20.Location = new System.Drawing.Point(998, 186);
            this.group_FW20.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW20.Name = "group_FW20";
            this.group_FW20.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW20.Size = new System.Drawing.Size(164, 88);
            this.group_FW20.TabIndex = 176;
            this.group_FW20.TabStop = false;
            this.group_FW20.Text = "ID_20";
            // 
            // label_FW_20
            // 
            this.label_FW_20.AutoSize = true;
            this.label_FW_20.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_20.Location = new System.Drawing.Point(10, 38);
            this.label_FW_20.Name = "label_FW_20";
            this.label_FW_20.Size = new System.Drawing.Size(70, 22);
            this.label_FW_20.TabIndex = 9;
            this.label_FW_20.Text = "FW Ver";
            // 
            // group_FW19
            // 
            this.group_FW19.Controls.Add(this.label_FW_19);
            this.group_FW19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW19.Location = new System.Drawing.Point(832, 186);
            this.group_FW19.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW19.Name = "group_FW19";
            this.group_FW19.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW19.Size = new System.Drawing.Size(162, 88);
            this.group_FW19.TabIndex = 181;
            this.group_FW19.TabStop = false;
            this.group_FW19.Text = "ID_19";
            // 
            // label_FW_19
            // 
            this.label_FW_19.AutoSize = true;
            this.label_FW_19.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_19.Location = new System.Drawing.Point(10, 38);
            this.label_FW_19.Name = "label_FW_19";
            this.label_FW_19.Size = new System.Drawing.Size(70, 22);
            this.label_FW_19.TabIndex = 9;
            this.label_FW_19.Text = "FW Ver";
            // 
            // group_FW18
            // 
            this.group_FW18.Controls.Add(this.label_FW_18);
            this.group_FW18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW18.Location = new System.Drawing.Point(666, 186);
            this.group_FW18.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW18.Name = "group_FW18";
            this.group_FW18.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW18.Size = new System.Drawing.Size(162, 88);
            this.group_FW18.TabIndex = 186;
            this.group_FW18.TabStop = false;
            this.group_FW18.Text = "ID_18";
            // 
            // label_FW_18
            // 
            this.label_FW_18.AutoSize = true;
            this.label_FW_18.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_18.Location = new System.Drawing.Point(10, 38);
            this.label_FW_18.Name = "label_FW_18";
            this.label_FW_18.Size = new System.Drawing.Size(70, 22);
            this.label_FW_18.TabIndex = 9;
            this.label_FW_18.Text = "FW Ver";
            // 
            // group_FW17
            // 
            this.group_FW17.Controls.Add(this.label_FW_17);
            this.group_FW17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW17.Location = new System.Drawing.Point(500, 186);
            this.group_FW17.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW17.Name = "group_FW17";
            this.group_FW17.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW17.Size = new System.Drawing.Size(162, 88);
            this.group_FW17.TabIndex = 191;
            this.group_FW17.TabStop = false;
            this.group_FW17.Text = "ID_17";
            // 
            // label_FW_17
            // 
            this.label_FW_17.AutoSize = true;
            this.label_FW_17.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_17.Location = new System.Drawing.Point(10, 38);
            this.label_FW_17.Name = "label_FW_17";
            this.label_FW_17.Size = new System.Drawing.Size(70, 22);
            this.label_FW_17.TabIndex = 9;
            this.label_FW_17.Text = "FW Ver";
            // 
            // group_FW16
            // 
            this.group_FW16.Controls.Add(this.label_FW_16);
            this.group_FW16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW16.Location = new System.Drawing.Point(334, 186);
            this.group_FW16.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW16.Name = "group_FW16";
            this.group_FW16.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW16.Size = new System.Drawing.Size(162, 88);
            this.group_FW16.TabIndex = 196;
            this.group_FW16.TabStop = false;
            this.group_FW16.Text = "ID_16";
            // 
            // label_FW_16
            // 
            this.label_FW_16.AutoSize = true;
            this.label_FW_16.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_16.Location = new System.Drawing.Point(10, 38);
            this.label_FW_16.Name = "label_FW_16";
            this.label_FW_16.Size = new System.Drawing.Size(70, 22);
            this.label_FW_16.TabIndex = 9;
            this.label_FW_16.Text = "FW Ver";
            // 
            // group_FW2
            // 
            this.group_FW2.Controls.Add(this.label_FW_2);
            this.group_FW2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW2.Location = new System.Drawing.Point(334, 2);
            this.group_FW2.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW2.Name = "group_FW2";
            this.group_FW2.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW2.Size = new System.Drawing.Size(162, 88);
            this.group_FW2.TabIndex = 194;
            this.group_FW2.TabStop = false;
            this.group_FW2.Text = "ID_2";
            // 
            // label_FW_2
            // 
            this.label_FW_2.AutoSize = true;
            this.label_FW_2.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_2.Location = new System.Drawing.Point(10, 38);
            this.label_FW_2.Name = "label_FW_2";
            this.label_FW_2.Size = new System.Drawing.Size(70, 22);
            this.label_FW_2.TabIndex = 9;
            this.label_FW_2.Text = "FW Ver";
            // 
            // group_FW7
            // 
            this.group_FW7.Controls.Add(this.label_FW_7);
            this.group_FW7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW7.Location = new System.Drawing.Point(2, 94);
            this.group_FW7.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW7.Name = "group_FW7";
            this.group_FW7.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW7.Size = new System.Drawing.Size(162, 88);
            this.group_FW7.TabIndex = 204;
            this.group_FW7.TabStop = false;
            this.group_FW7.Text = "ID_7";
            // 
            // label_FW_7
            // 
            this.label_FW_7.AutoSize = true;
            this.label_FW_7.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_7.Location = new System.Drawing.Point(10, 38);
            this.label_FW_7.Name = "label_FW_7";
            this.label_FW_7.Size = new System.Drawing.Size(70, 22);
            this.label_FW_7.TabIndex = 9;
            this.label_FW_7.Text = "FW Ver";
            // 
            // group_FW3
            // 
            this.group_FW3.Controls.Add(this.label_FW_3);
            this.group_FW3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW3.Location = new System.Drawing.Point(500, 2);
            this.group_FW3.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW3.Name = "group_FW3";
            this.group_FW3.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW3.Size = new System.Drawing.Size(162, 88);
            this.group_FW3.TabIndex = 189;
            this.group_FW3.TabStop = false;
            this.group_FW3.Text = "ID_3";
            // 
            // label_FW_3
            // 
            this.label_FW_3.AutoSize = true;
            this.label_FW_3.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_3.Location = new System.Drawing.Point(10, 38);
            this.label_FW_3.Name = "label_FW_3";
            this.label_FW_3.Size = new System.Drawing.Size(70, 22);
            this.label_FW_3.TabIndex = 9;
            this.label_FW_3.Text = "FW Ver";
            // 
            // group_FW8
            // 
            this.group_FW8.Controls.Add(this.label_FW_8);
            this.group_FW8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW8.Location = new System.Drawing.Point(168, 94);
            this.group_FW8.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW8.Name = "group_FW8";
            this.group_FW8.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW8.Size = new System.Drawing.Size(162, 88);
            this.group_FW8.TabIndex = 200;
            this.group_FW8.TabStop = false;
            this.group_FW8.Text = "ID_8";
            // 
            // label_FW_8
            // 
            this.label_FW_8.AutoSize = true;
            this.label_FW_8.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_8.Location = new System.Drawing.Point(10, 38);
            this.label_FW_8.Name = "label_FW_8";
            this.label_FW_8.Size = new System.Drawing.Size(70, 22);
            this.label_FW_8.TabIndex = 9;
            this.label_FW_8.Text = "FW Ver";
            // 
            // group_FW4
            // 
            this.group_FW4.Controls.Add(this.label_FW_4);
            this.group_FW4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW4.Location = new System.Drawing.Point(666, 2);
            this.group_FW4.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW4.Name = "group_FW4";
            this.group_FW4.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW4.Size = new System.Drawing.Size(162, 88);
            this.group_FW4.TabIndex = 184;
            this.group_FW4.TabStop = false;
            this.group_FW4.Text = "ID_4";
            // 
            // label_FW_4
            // 
            this.label_FW_4.AutoSize = true;
            this.label_FW_4.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_4.Location = new System.Drawing.Point(10, 38);
            this.label_FW_4.Name = "label_FW_4";
            this.label_FW_4.Size = new System.Drawing.Size(70, 22);
            this.label_FW_4.TabIndex = 9;
            this.label_FW_4.Text = "FW Ver";
            // 
            // group_FW9
            // 
            this.group_FW9.Controls.Add(this.label_FW_9);
            this.group_FW9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW9.Location = new System.Drawing.Point(334, 94);
            this.group_FW9.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW9.Name = "group_FW9";
            this.group_FW9.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW9.Size = new System.Drawing.Size(162, 88);
            this.group_FW9.TabIndex = 195;
            this.group_FW9.TabStop = false;
            this.group_FW9.Text = "ID_9";
            // 
            // label_FW_9
            // 
            this.label_FW_9.AutoSize = true;
            this.label_FW_9.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_9.Location = new System.Drawing.Point(10, 38);
            this.label_FW_9.Name = "label_FW_9";
            this.label_FW_9.Size = new System.Drawing.Size(70, 22);
            this.label_FW_9.TabIndex = 9;
            this.label_FW_9.Text = "FW Ver";
            // 
            // group_FW10
            // 
            this.group_FW10.Controls.Add(this.label_FW_10);
            this.group_FW10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW10.Location = new System.Drawing.Point(500, 94);
            this.group_FW10.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW10.Name = "group_FW10";
            this.group_FW10.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW10.Size = new System.Drawing.Size(162, 88);
            this.group_FW10.TabIndex = 190;
            this.group_FW10.TabStop = false;
            this.group_FW10.Text = "ID_10";
            // 
            // label_FW_10
            // 
            this.label_FW_10.AutoSize = true;
            this.label_FW_10.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_10.Location = new System.Drawing.Point(10, 38);
            this.label_FW_10.Name = "label_FW_10";
            this.label_FW_10.Size = new System.Drawing.Size(70, 22);
            this.label_FW_10.TabIndex = 9;
            this.label_FW_10.Text = "FW Ver";
            // 
            // group_FW11
            // 
            this.group_FW11.Controls.Add(this.label_FW_11);
            this.group_FW11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW11.Location = new System.Drawing.Point(666, 94);
            this.group_FW11.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW11.Name = "group_FW11";
            this.group_FW11.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW11.Size = new System.Drawing.Size(162, 88);
            this.group_FW11.TabIndex = 185;
            this.group_FW11.TabStop = false;
            this.group_FW11.Text = "ID_11";
            // 
            // label_FW_11
            // 
            this.label_FW_11.AutoSize = true;
            this.label_FW_11.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_11.Location = new System.Drawing.Point(10, 38);
            this.label_FW_11.Name = "label_FW_11";
            this.label_FW_11.Size = new System.Drawing.Size(70, 22);
            this.label_FW_11.TabIndex = 9;
            this.label_FW_11.Text = "FW Ver";
            // 
            // group_FW12
            // 
            this.group_FW12.Controls.Add(this.label_FW_12);
            this.group_FW12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW12.Location = new System.Drawing.Point(832, 94);
            this.group_FW12.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW12.Name = "group_FW12";
            this.group_FW12.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW12.Size = new System.Drawing.Size(162, 88);
            this.group_FW12.TabIndex = 180;
            this.group_FW12.TabStop = false;
            this.group_FW12.Text = "ID_12";
            // 
            // label_FW_12
            // 
            this.label_FW_12.AutoSize = true;
            this.label_FW_12.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_12.Location = new System.Drawing.Point(10, 38);
            this.label_FW_12.Name = "label_FW_12";
            this.label_FW_12.Size = new System.Drawing.Size(70, 22);
            this.label_FW_12.TabIndex = 9;
            this.label_FW_12.Text = "FW Ver";
            // 
            // group_FW13
            // 
            this.group_FW13.Controls.Add(this.label_FW_13);
            this.group_FW13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW13.Location = new System.Drawing.Point(998, 94);
            this.group_FW13.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW13.Name = "group_FW13";
            this.group_FW13.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW13.Size = new System.Drawing.Size(164, 88);
            this.group_FW13.TabIndex = 175;
            this.group_FW13.TabStop = false;
            this.group_FW13.Text = "ID_13";
            // 
            // label_FW_13
            // 
            this.label_FW_13.AutoSize = true;
            this.label_FW_13.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_13.Location = new System.Drawing.Point(10, 38);
            this.label_FW_13.Name = "label_FW_13";
            this.label_FW_13.Size = new System.Drawing.Size(70, 22);
            this.label_FW_13.TabIndex = 9;
            this.label_FW_13.Text = "FW Ver";
            // 
            // group_FW5
            // 
            this.group_FW5.Controls.Add(this.label_FW_5);
            this.group_FW5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW5.Location = new System.Drawing.Point(832, 2);
            this.group_FW5.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW5.Name = "group_FW5";
            this.group_FW5.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW5.Size = new System.Drawing.Size(162, 88);
            this.group_FW5.TabIndex = 179;
            this.group_FW5.TabStop = false;
            this.group_FW5.Text = "ID_5";
            // 
            // label_FW_5
            // 
            this.label_FW_5.AutoSize = true;
            this.label_FW_5.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_5.Location = new System.Drawing.Point(10, 38);
            this.label_FW_5.Name = "label_FW_5";
            this.label_FW_5.Size = new System.Drawing.Size(70, 22);
            this.label_FW_5.TabIndex = 9;
            this.label_FW_5.Text = "FW Ver";
            // 
            // group_FW6
            // 
            this.group_FW6.Controls.Add(this.label_FW_6);
            this.group_FW6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_FW6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_FW6.Location = new System.Drawing.Point(998, 2);
            this.group_FW6.Margin = new System.Windows.Forms.Padding(2);
            this.group_FW6.Name = "group_FW6";
            this.group_FW6.Padding = new System.Windows.Forms.Padding(2);
            this.group_FW6.Size = new System.Drawing.Size(164, 88);
            this.group_FW6.TabIndex = 174;
            this.group_FW6.TabStop = false;
            this.group_FW6.Text = "ID_6";
            // 
            // label_FW_6
            // 
            this.label_FW_6.AutoSize = true;
            this.label_FW_6.BackColor = System.Drawing.Color.DarkTurquoise;
            this.label_FW_6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_FW_6.Location = new System.Drawing.Point(10, 38);
            this.label_FW_6.Name = "label_FW_6";
            this.label_FW_6.Size = new System.Drawing.Size(70, 22);
            this.label_FW_6.TabIndex = 9;
            this.label_FW_6.Text = "FW Ver";
            // 
            // Cal_Date
            // 
            this.Cal_Date.BackColor = System.Drawing.SystemColors.Control;
            this.Cal_Date.Controls.Add(this.tableLayoutPanel15);
            this.Cal_Date.Location = new System.Drawing.Point(4, 29);
            this.Cal_Date.Name = "Cal_Date";
            this.Cal_Date.Size = new System.Drawing.Size(1164, 369);
            this.Cal_Date.TabIndex = 13;
            this.Cal_Date.Text = "【Cal_Date】";
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.tableLayoutPanel15.ColumnCount = 7;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate23, 2, 3);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate22, 1, 3);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate14, 0, 2);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate15, 1, 2);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate20, 6, 2);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate19, 5, 2);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate18, 4, 2);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate17, 3, 2);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate16, 2, 2);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate1, 1, 0);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate7, 0, 1);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate2, 2, 0);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate8, 1, 1);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate3, 3, 0);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate9, 2, 1);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate10, 3, 1);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate11, 4, 1);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate12, 5, 1);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate13, 6, 1);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate4, 4, 0);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate5, 5, 0);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate6, 6, 0);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate21, 0, 3);
            this.tableLayoutPanel15.Controls.Add(this.group_CalDate0, 0, 0);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel15.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 4;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(1164, 369);
            this.tableLayoutPanel15.TabIndex = 218;
            // 
            // group_CalDate23
            // 
            this.group_CalDate23.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate23.Controls.Add(this.label_CalDate23);
            this.group_CalDate23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate23.Location = new System.Drawing.Point(335, 278);
            this.group_CalDate23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate23.Name = "group_CalDate23";
            this.group_CalDate23.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate23.Size = new System.Drawing.Size(160, 89);
            this.group_CalDate23.TabIndex = 240;
            this.group_CalDate23.TabStop = false;
            this.group_CalDate23.Text = "ID_23";
            // 
            // label_CalDate23
            // 
            this.label_CalDate23.AutoSize = true;
            this.label_CalDate23.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate23.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate23.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate23.Name = "label_CalDate23";
            this.label_CalDate23.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate23.TabIndex = 41;
            this.label_CalDate23.Text = "Cal Date";
            // 
            // group_CalDate22
            // 
            this.group_CalDate22.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate22.Controls.Add(this.label_CalDate22);
            this.group_CalDate22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate22.Location = new System.Drawing.Point(169, 278);
            this.group_CalDate22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate22.Name = "group_CalDate22";
            this.group_CalDate22.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate22.Size = new System.Drawing.Size(160, 89);
            this.group_CalDate22.TabIndex = 245;
            this.group_CalDate22.TabStop = false;
            this.group_CalDate22.Text = "ID_22";
            // 
            // label_CalDate22
            // 
            this.label_CalDate22.AutoSize = true;
            this.label_CalDate22.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate22.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate22.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate22.Name = "label_CalDate22";
            this.label_CalDate22.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate22.TabIndex = 41;
            this.label_CalDate22.Text = "Cal Date";
            // 
            // group_CalDate14
            // 
            this.group_CalDate14.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate14.Controls.Add(this.label_CalDate14);
            this.group_CalDate14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate14.Location = new System.Drawing.Point(3, 186);
            this.group_CalDate14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate14.Name = "group_CalDate14";
            this.group_CalDate14.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate14.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate14.TabIndex = 248;
            this.group_CalDate14.TabStop = false;
            this.group_CalDate14.Text = "ID_14";
            // 
            // label_CalDate14
            // 
            this.label_CalDate14.AutoSize = true;
            this.label_CalDate14.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate14.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate14.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate14.Name = "label_CalDate14";
            this.label_CalDate14.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate14.TabIndex = 41;
            this.label_CalDate14.Text = "Cal Date";
            // 
            // group_CalDate15
            // 
            this.group_CalDate15.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate15.Controls.Add(this.label_CalDate15);
            this.group_CalDate15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate15.Location = new System.Drawing.Point(169, 186);
            this.group_CalDate15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate15.Name = "group_CalDate15";
            this.group_CalDate15.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate15.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate15.TabIndex = 244;
            this.group_CalDate15.TabStop = false;
            this.group_CalDate15.Text = "ID_15";
            // 
            // label_CalDate15
            // 
            this.label_CalDate15.AutoSize = true;
            this.label_CalDate15.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate15.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate15.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate15.Name = "label_CalDate15";
            this.label_CalDate15.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate15.TabIndex = 41;
            this.label_CalDate15.Text = "Cal Date";
            // 
            // group_CalDate20
            // 
            this.group_CalDate20.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate20.Controls.Add(this.label_CalDate20);
            this.group_CalDate20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate20.Location = new System.Drawing.Point(999, 186);
            this.group_CalDate20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate20.Name = "group_CalDate20";
            this.group_CalDate20.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate20.Size = new System.Drawing.Size(162, 88);
            this.group_CalDate20.TabIndex = 219;
            this.group_CalDate20.TabStop = false;
            this.group_CalDate20.Text = "ID_20";
            // 
            // label_CalDate20
            // 
            this.label_CalDate20.AutoSize = true;
            this.label_CalDate20.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate20.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate20.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate20.Name = "label_CalDate20";
            this.label_CalDate20.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate20.TabIndex = 41;
            this.label_CalDate20.Text = "Cal Date";
            // 
            // group_CalDate19
            // 
            this.group_CalDate19.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate19.Controls.Add(this.label_CalDate19);
            this.group_CalDate19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate19.Location = new System.Drawing.Point(833, 186);
            this.group_CalDate19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate19.Name = "group_CalDate19";
            this.group_CalDate19.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate19.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate19.TabIndex = 224;
            this.group_CalDate19.TabStop = false;
            this.group_CalDate19.Text = "ID_19";
            // 
            // label_CalDate19
            // 
            this.label_CalDate19.AutoSize = true;
            this.label_CalDate19.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate19.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate19.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate19.Name = "label_CalDate19";
            this.label_CalDate19.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate19.TabIndex = 41;
            this.label_CalDate19.Text = "Cal Date";
            // 
            // group_CalDate18
            // 
            this.group_CalDate18.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate18.Controls.Add(this.label_CalDate18);
            this.group_CalDate18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate18.Location = new System.Drawing.Point(667, 186);
            this.group_CalDate18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate18.Name = "group_CalDate18";
            this.group_CalDate18.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate18.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate18.TabIndex = 229;
            this.group_CalDate18.TabStop = false;
            this.group_CalDate18.Text = "ID_18";
            // 
            // label_CalDate18
            // 
            this.label_CalDate18.AutoSize = true;
            this.label_CalDate18.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate18.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate18.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate18.Name = "label_CalDate18";
            this.label_CalDate18.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate18.TabIndex = 41;
            this.label_CalDate18.Text = "Cal Date";
            // 
            // group_CalDate17
            // 
            this.group_CalDate17.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate17.Controls.Add(this.label_CalDate17);
            this.group_CalDate17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate17.Location = new System.Drawing.Point(501, 186);
            this.group_CalDate17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate17.Name = "group_CalDate17";
            this.group_CalDate17.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate17.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate17.TabIndex = 234;
            this.group_CalDate17.TabStop = false;
            this.group_CalDate17.Text = "ID_17";
            // 
            // label_CalDate17
            // 
            this.label_CalDate17.AutoSize = true;
            this.label_CalDate17.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate17.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate17.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate17.Name = "label_CalDate17";
            this.label_CalDate17.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate17.TabIndex = 41;
            this.label_CalDate17.Text = "Cal Date";
            // 
            // group_CalDate16
            // 
            this.group_CalDate16.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate16.Controls.Add(this.label_CalDate16);
            this.group_CalDate16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate16.Location = new System.Drawing.Point(335, 186);
            this.group_CalDate16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate16.Name = "group_CalDate16";
            this.group_CalDate16.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate16.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate16.TabIndex = 239;
            this.group_CalDate16.TabStop = false;
            this.group_CalDate16.Text = "ID_16";
            // 
            // label_CalDate16
            // 
            this.label_CalDate16.AutoSize = true;
            this.label_CalDate16.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate16.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate16.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate16.Name = "label_CalDate16";
            this.label_CalDate16.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate16.TabIndex = 41;
            this.label_CalDate16.Text = "Cal Date";
            // 
            // group_CalDate1
            // 
            this.group_CalDate1.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate1.Controls.Add(this.label_CalDate1);
            this.group_CalDate1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate1.Location = new System.Drawing.Point(169, 2);
            this.group_CalDate1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate1.Name = "group_CalDate1";
            this.group_CalDate1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate1.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate1.TabIndex = 242;
            this.group_CalDate1.TabStop = false;
            this.group_CalDate1.Text = "ID_1";
            // 
            // label_CalDate1
            // 
            this.label_CalDate1.AutoSize = true;
            this.label_CalDate1.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate1.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate1.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate1.Name = "label_CalDate1";
            this.label_CalDate1.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate1.TabIndex = 41;
            this.label_CalDate1.Text = "Cal Date";
            // 
            // group_CalDate7
            // 
            this.group_CalDate7.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate7.Controls.Add(this.label_CalDate7);
            this.group_CalDate7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate7.Location = new System.Drawing.Point(3, 94);
            this.group_CalDate7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate7.Name = "group_CalDate7";
            this.group_CalDate7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate7.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate7.TabIndex = 247;
            this.group_CalDate7.TabStop = false;
            this.group_CalDate7.Text = "ID_7";
            // 
            // label_CalDate7
            // 
            this.label_CalDate7.AutoSize = true;
            this.label_CalDate7.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate7.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate7.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate7.Name = "label_CalDate7";
            this.label_CalDate7.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate7.TabIndex = 41;
            this.label_CalDate7.Text = "Cal Date";
            // 
            // group_CalDate2
            // 
            this.group_CalDate2.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate2.Controls.Add(this.label_CalDate2);
            this.group_CalDate2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate2.Location = new System.Drawing.Point(335, 2);
            this.group_CalDate2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate2.Name = "group_CalDate2";
            this.group_CalDate2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate2.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate2.TabIndex = 237;
            this.group_CalDate2.TabStop = false;
            this.group_CalDate2.Text = "ID_2";
            // 
            // label_CalDate2
            // 
            this.label_CalDate2.AutoSize = true;
            this.label_CalDate2.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate2.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate2.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate2.Name = "label_CalDate2";
            this.label_CalDate2.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate2.TabIndex = 41;
            this.label_CalDate2.Text = "Cal Date";
            // 
            // group_CalDate8
            // 
            this.group_CalDate8.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate8.Controls.Add(this.label_CalDate8);
            this.group_CalDate8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate8.Location = new System.Drawing.Point(169, 94);
            this.group_CalDate8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate8.Name = "group_CalDate8";
            this.group_CalDate8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate8.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate8.TabIndex = 243;
            this.group_CalDate8.TabStop = false;
            this.group_CalDate8.Text = "ID_8";
            // 
            // label_CalDate8
            // 
            this.label_CalDate8.AutoSize = true;
            this.label_CalDate8.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate8.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate8.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate8.Name = "label_CalDate8";
            this.label_CalDate8.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate8.TabIndex = 41;
            this.label_CalDate8.Text = "Cal Date";
            // 
            // group_CalDate3
            // 
            this.group_CalDate3.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate3.Controls.Add(this.label_CalDate3);
            this.group_CalDate3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate3.Location = new System.Drawing.Point(501, 2);
            this.group_CalDate3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate3.Name = "group_CalDate3";
            this.group_CalDate3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate3.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate3.TabIndex = 232;
            this.group_CalDate3.TabStop = false;
            this.group_CalDate3.Text = "ID_3";
            // 
            // label_CalDate3
            // 
            this.label_CalDate3.AutoSize = true;
            this.label_CalDate3.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate3.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate3.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate3.Name = "label_CalDate3";
            this.label_CalDate3.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate3.TabIndex = 41;
            this.label_CalDate3.Text = "Cal Date";
            // 
            // group_CalDate9
            // 
            this.group_CalDate9.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate9.Controls.Add(this.label_CalDate9);
            this.group_CalDate9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate9.Location = new System.Drawing.Point(335, 94);
            this.group_CalDate9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate9.Name = "group_CalDate9";
            this.group_CalDate9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate9.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate9.TabIndex = 238;
            this.group_CalDate9.TabStop = false;
            this.group_CalDate9.Text = "ID_9";
            // 
            // label_CalDate9
            // 
            this.label_CalDate9.AutoSize = true;
            this.label_CalDate9.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate9.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate9.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate9.Name = "label_CalDate9";
            this.label_CalDate9.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate9.TabIndex = 41;
            this.label_CalDate9.Text = "Cal Date";
            // 
            // group_CalDate10
            // 
            this.group_CalDate10.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate10.Controls.Add(this.label_CalDate10);
            this.group_CalDate10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate10.Location = new System.Drawing.Point(501, 94);
            this.group_CalDate10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate10.Name = "group_CalDate10";
            this.group_CalDate10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate10.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate10.TabIndex = 233;
            this.group_CalDate10.TabStop = false;
            this.group_CalDate10.Text = "ID_10";
            // 
            // label_CalDate10
            // 
            this.label_CalDate10.AutoSize = true;
            this.label_CalDate10.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate10.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate10.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate10.Name = "label_CalDate10";
            this.label_CalDate10.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate10.TabIndex = 41;
            this.label_CalDate10.Text = "Cal Date";
            // 
            // group_CalDate11
            // 
            this.group_CalDate11.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate11.Controls.Add(this.label_CalDate11);
            this.group_CalDate11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate11.Location = new System.Drawing.Point(667, 94);
            this.group_CalDate11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate11.Name = "group_CalDate11";
            this.group_CalDate11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate11.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate11.TabIndex = 228;
            this.group_CalDate11.TabStop = false;
            this.group_CalDate11.Text = "ID_11";
            // 
            // label_CalDate11
            // 
            this.label_CalDate11.AutoSize = true;
            this.label_CalDate11.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate11.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate11.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate11.Name = "label_CalDate11";
            this.label_CalDate11.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate11.TabIndex = 41;
            this.label_CalDate11.Text = "Cal Date";
            // 
            // group_CalDate12
            // 
            this.group_CalDate12.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate12.Controls.Add(this.label_CalDate12);
            this.group_CalDate12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate12.Location = new System.Drawing.Point(833, 94);
            this.group_CalDate12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate12.Name = "group_CalDate12";
            this.group_CalDate12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate12.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate12.TabIndex = 223;
            this.group_CalDate12.TabStop = false;
            this.group_CalDate12.Text = "ID_12";
            // 
            // label_CalDate12
            // 
            this.label_CalDate12.AutoSize = true;
            this.label_CalDate12.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate12.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate12.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate12.Name = "label_CalDate12";
            this.label_CalDate12.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate12.TabIndex = 41;
            this.label_CalDate12.Text = "Cal Date";
            // 
            // group_CalDate13
            // 
            this.group_CalDate13.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate13.Controls.Add(this.label_CalDate13);
            this.group_CalDate13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate13.Location = new System.Drawing.Point(999, 94);
            this.group_CalDate13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate13.Name = "group_CalDate13";
            this.group_CalDate13.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate13.Size = new System.Drawing.Size(162, 88);
            this.group_CalDate13.TabIndex = 218;
            this.group_CalDate13.TabStop = false;
            this.group_CalDate13.Text = "ID_13";
            // 
            // label_CalDate13
            // 
            this.label_CalDate13.AutoSize = true;
            this.label_CalDate13.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate13.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate13.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate13.Name = "label_CalDate13";
            this.label_CalDate13.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate13.TabIndex = 41;
            this.label_CalDate13.Text = "Cal Date";
            // 
            // group_CalDate4
            // 
            this.group_CalDate4.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate4.Controls.Add(this.label_CalDate4);
            this.group_CalDate4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate4.Location = new System.Drawing.Point(667, 2);
            this.group_CalDate4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate4.Name = "group_CalDate4";
            this.group_CalDate4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate4.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate4.TabIndex = 227;
            this.group_CalDate4.TabStop = false;
            this.group_CalDate4.Text = "ID_4";
            // 
            // label_CalDate4
            // 
            this.label_CalDate4.AutoSize = true;
            this.label_CalDate4.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate4.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate4.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate4.Name = "label_CalDate4";
            this.label_CalDate4.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate4.TabIndex = 41;
            this.label_CalDate4.Text = "Cal Date";
            // 
            // group_CalDate5
            // 
            this.group_CalDate5.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate5.Controls.Add(this.label_CalDate5);
            this.group_CalDate5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate5.Location = new System.Drawing.Point(833, 2);
            this.group_CalDate5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate5.Name = "group_CalDate5";
            this.group_CalDate5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate5.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate5.TabIndex = 222;
            this.group_CalDate5.TabStop = false;
            this.group_CalDate5.Text = "ID_5";
            // 
            // label_CalDate5
            // 
            this.label_CalDate5.AutoSize = true;
            this.label_CalDate5.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate5.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate5.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate5.Name = "label_CalDate5";
            this.label_CalDate5.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate5.TabIndex = 41;
            this.label_CalDate5.Text = "Cal Date";
            // 
            // group_CalDate6
            // 
            this.group_CalDate6.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate6.Controls.Add(this.label_CalDate6);
            this.group_CalDate6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate6.Location = new System.Drawing.Point(999, 2);
            this.group_CalDate6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate6.Name = "group_CalDate6";
            this.group_CalDate6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate6.Size = new System.Drawing.Size(162, 88);
            this.group_CalDate6.TabIndex = 217;
            this.group_CalDate6.TabStop = false;
            this.group_CalDate6.Text = "ID_6";
            // 
            // label_CalDate6
            // 
            this.label_CalDate6.AutoSize = true;
            this.label_CalDate6.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate6.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate6.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate6.Name = "label_CalDate6";
            this.label_CalDate6.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate6.TabIndex = 41;
            this.label_CalDate6.Text = "Cal Date";
            // 
            // group_CalDate21
            // 
            this.group_CalDate21.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate21.Controls.Add(this.label_CalDate21);
            this.group_CalDate21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate21.Location = new System.Drawing.Point(3, 278);
            this.group_CalDate21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate21.Name = "group_CalDate21";
            this.group_CalDate21.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate21.Size = new System.Drawing.Size(160, 89);
            this.group_CalDate21.TabIndex = 249;
            this.group_CalDate21.TabStop = false;
            this.group_CalDate21.Text = "ID_21";
            // 
            // label_CalDate21
            // 
            this.label_CalDate21.AutoSize = true;
            this.label_CalDate21.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate21.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate21.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate21.Name = "label_CalDate21";
            this.label_CalDate21.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate21.TabIndex = 41;
            this.label_CalDate21.Text = "Cal Date";
            // 
            // group_CalDate0
            // 
            this.group_CalDate0.BackColor = System.Drawing.Color.Transparent;
            this.group_CalDate0.Controls.Add(this.label_CalDate0);
            this.group_CalDate0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.group_CalDate0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.group_CalDate0.Location = new System.Drawing.Point(3, 2);
            this.group_CalDate0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate0.Name = "group_CalDate0";
            this.group_CalDate0.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.group_CalDate0.Size = new System.Drawing.Size(160, 88);
            this.group_CalDate0.TabIndex = 176;
            this.group_CalDate0.TabStop = false;
            this.group_CalDate0.Text = "ID_0";
            // 
            // label_CalDate0
            // 
            this.label_CalDate0.AutoSize = true;
            this.label_CalDate0.BackColor = System.Drawing.Color.Gold;
            this.label_CalDate0.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Bold);
            this.label_CalDate0.Location = new System.Drawing.Point(10, 38);
            this.label_CalDate0.Name = "label_CalDate0";
            this.label_CalDate0.Size = new System.Drawing.Size(90, 22);
            this.label_CalDate0.TabIndex = 41;
            this.label_CalDate0.Text = "Cal Date";
            // 
            // timer_command
            // 
            this.timer_command.Interval = 5000;
            this.timer_command.Tick += new System.EventHandler(this.timer_command_Tick);
            // 
            // timer_getStatus
            // 
            this.timer_getStatus.Interval = 1000;
            this.timer_getStatus.Tick += new System.EventHandler(this.timer_getStatus_Tick);
            // 
            // timer_getValue
            // 
            this.timer_getValue.Interval = 1000;
            this.timer_getValue.Tick += new System.EventHandler(this.timer_getValue_Tick);
            // 
            // label_Serial0
            // 
            this.label_Serial0.AutoSize = true;
            this.label_Serial0.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial0.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial0.Location = new System.Drawing.Point(16, 66);
            this.label_Serial0.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial0.Name = "label_Serial0";
            this.label_Serial0.Size = new System.Drawing.Size(169, 36);
            this.label_Serial0.TabIndex = 41;
            // 
            // label_Serial_Value0
            // 
            this.label_Serial_Value0.AutoSize = true;
            this.label_Serial_Value0.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value0.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value0.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value0.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value0.Name = "label_Serial_Value0";
            this.label_Serial_Value0.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value0.TabIndex = 7;
            // 
            // label_SN_Temp4
            // 
            this.label_SN_Temp4.AutoSize = true;
            this.label_SN_Temp4.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_SN_Temp4.Location = new System.Drawing.Point(16, 32);
            this.label_SN_Temp4.Name = "label_SN_Temp4";
            this.label_SN_Temp4.Size = new System.Drawing.Size(94, 36);
            this.label_SN_Temp4.TabIndex = 6;
            // 
            // label_SN_Humidity4
            // 
            this.label_SN_Humidity4.AutoSize = true;
            this.label_SN_Humidity4.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_SN_Humidity4.Location = new System.Drawing.Point(16, 68);
            this.label_SN_Humidity4.Name = "label_SN_Humidity4";
            this.label_SN_Humidity4.Size = new System.Drawing.Size(143, 36);
            this.label_SN_Humidity4.TabIndex = 5;
            // 
            // label_Serial6
            // 
            this.label_Serial6.AutoSize = true;
            this.label_Serial6.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial6.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial6.Location = new System.Drawing.Point(16, 66);
            this.label_Serial6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial6.Name = "label_Serial6";
            this.label_Serial6.Size = new System.Drawing.Size(169, 36);
            this.label_Serial6.TabIndex = 41;
            // 
            // label_Serial_Value6
            // 
            this.label_Serial_Value6.AutoSize = true;
            this.label_Serial_Value6.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value6.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value6.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value6.Name = "label_Serial_Value6";
            this.label_Serial_Value6.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value6.TabIndex = 7;
            // 
            // label_Serial13
            // 
            this.label_Serial13.AutoSize = true;
            this.label_Serial13.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial13.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial13.Location = new System.Drawing.Point(16, 66);
            this.label_Serial13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial13.Name = "label_Serial13";
            this.label_Serial13.Size = new System.Drawing.Size(169, 36);
            this.label_Serial13.TabIndex = 41;
            // 
            // label_Serial_Value13
            // 
            this.label_Serial_Value13.AutoSize = true;
            this.label_Serial_Value13.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value13.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value13.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value13.Name = "label_Serial_Value13";
            this.label_Serial_Value13.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value13.TabIndex = 7;
            // 
            // label_Serial20
            // 
            this.label_Serial20.AutoSize = true;
            this.label_Serial20.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial20.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial20.Location = new System.Drawing.Point(16, 66);
            this.label_Serial20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial20.Name = "label_Serial20";
            this.label_Serial20.Size = new System.Drawing.Size(169, 36);
            this.label_Serial20.TabIndex = 41;
            // 
            // label_Serial_Value20
            // 
            this.label_Serial_Value20.AutoSize = true;
            this.label_Serial_Value20.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value20.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value20.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value20.Name = "label_Serial_Value20";
            this.label_Serial_Value20.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value20.TabIndex = 7;
            // 
            // label_Serial27
            // 
            this.label_Serial27.AutoSize = true;
            this.label_Serial27.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial27.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial27.Location = new System.Drawing.Point(16, 66);
            this.label_Serial27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial27.Name = "label_Serial27";
            this.label_Serial27.Size = new System.Drawing.Size(169, 36);
            this.label_Serial27.TabIndex = 41;
            // 
            // label_Serial_Value27
            // 
            this.label_Serial_Value27.AutoSize = true;
            this.label_Serial_Value27.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value27.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value27.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value27.Name = "label_Serial_Value27";
            this.label_Serial_Value27.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value27.TabIndex = 7;
            // 
            // label_Serial34
            // 
            this.label_Serial34.AutoSize = true;
            this.label_Serial34.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial34.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial34.Location = new System.Drawing.Point(16, 66);
            this.label_Serial34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial34.Name = "label_Serial34";
            this.label_Serial34.Size = new System.Drawing.Size(169, 36);
            this.label_Serial34.TabIndex = 41;
            // 
            // label_Serial_Value34
            // 
            this.label_Serial_Value34.AutoSize = true;
            this.label_Serial_Value34.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value34.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value34.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value34.Name = "label_Serial_Value34";
            this.label_Serial_Value34.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value34.TabIndex = 7;
            // 
            // label_Serial5
            // 
            this.label_Serial5.AutoSize = true;
            this.label_Serial5.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial5.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial5.Location = new System.Drawing.Point(16, 66);
            this.label_Serial5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial5.Name = "label_Serial5";
            this.label_Serial5.Size = new System.Drawing.Size(169, 36);
            this.label_Serial5.TabIndex = 41;
            // 
            // label_Serial_Value5
            // 
            this.label_Serial_Value5.AutoSize = true;
            this.label_Serial_Value5.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value5.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value5.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value5.Name = "label_Serial_Value5";
            this.label_Serial_Value5.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value5.TabIndex = 7;
            // 
            // label_Serial12
            // 
            this.label_Serial12.AutoSize = true;
            this.label_Serial12.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial12.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial12.Location = new System.Drawing.Point(16, 66);
            this.label_Serial12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial12.Name = "label_Serial12";
            this.label_Serial12.Size = new System.Drawing.Size(169, 36);
            this.label_Serial12.TabIndex = 41;
            // 
            // label_Serial_Value12
            // 
            this.label_Serial_Value12.AutoSize = true;
            this.label_Serial_Value12.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value12.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value12.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value12.Name = "label_Serial_Value12";
            this.label_Serial_Value12.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value12.TabIndex = 7;
            // 
            // label_Serial19
            // 
            this.label_Serial19.AutoSize = true;
            this.label_Serial19.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial19.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial19.Location = new System.Drawing.Point(16, 66);
            this.label_Serial19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial19.Name = "label_Serial19";
            this.label_Serial19.Size = new System.Drawing.Size(169, 36);
            this.label_Serial19.TabIndex = 41;
            // 
            // label_Serial_Value19
            // 
            this.label_Serial_Value19.AutoSize = true;
            this.label_Serial_Value19.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value19.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value19.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value19.Name = "label_Serial_Value19";
            this.label_Serial_Value19.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value19.TabIndex = 7;
            // 
            // label_Serial26
            // 
            this.label_Serial26.AutoSize = true;
            this.label_Serial26.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial26.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial26.Location = new System.Drawing.Point(16, 66);
            this.label_Serial26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial26.Name = "label_Serial26";
            this.label_Serial26.Size = new System.Drawing.Size(169, 36);
            this.label_Serial26.TabIndex = 41;
            // 
            // label_Serial_Value26
            // 
            this.label_Serial_Value26.AutoSize = true;
            this.label_Serial_Value26.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value26.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value26.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value26.Name = "label_Serial_Value26";
            this.label_Serial_Value26.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value26.TabIndex = 7;
            // 
            // label_Serial33
            // 
            this.label_Serial33.AutoSize = true;
            this.label_Serial33.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial33.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial33.Location = new System.Drawing.Point(16, 66);
            this.label_Serial33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial33.Name = "label_Serial33";
            this.label_Serial33.Size = new System.Drawing.Size(169, 36);
            this.label_Serial33.TabIndex = 41;
            // 
            // label_Serial_Value33
            // 
            this.label_Serial_Value33.AutoSize = true;
            this.label_Serial_Value33.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value33.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value33.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value33.Name = "label_Serial_Value33";
            this.label_Serial_Value33.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value33.TabIndex = 7;
            // 
            // label_Serial4
            // 
            this.label_Serial4.AutoSize = true;
            this.label_Serial4.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial4.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial4.Location = new System.Drawing.Point(16, 66);
            this.label_Serial4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial4.Name = "label_Serial4";
            this.label_Serial4.Size = new System.Drawing.Size(169, 36);
            this.label_Serial4.TabIndex = 41;
            // 
            // label_Serial_Value4
            // 
            this.label_Serial_Value4.AutoSize = true;
            this.label_Serial_Value4.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value4.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value4.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value4.Name = "label_Serial_Value4";
            this.label_Serial_Value4.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value4.TabIndex = 7;
            // 
            // label_Serial11
            // 
            this.label_Serial11.AutoSize = true;
            this.label_Serial11.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial11.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial11.Location = new System.Drawing.Point(16, 66);
            this.label_Serial11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial11.Name = "label_Serial11";
            this.label_Serial11.Size = new System.Drawing.Size(169, 36);
            this.label_Serial11.TabIndex = 41;
            // 
            // label_Serial_Value11
            // 
            this.label_Serial_Value11.AutoSize = true;
            this.label_Serial_Value11.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value11.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value11.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value11.Name = "label_Serial_Value11";
            this.label_Serial_Value11.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value11.TabIndex = 7;
            // 
            // label_Serial18
            // 
            this.label_Serial18.AutoSize = true;
            this.label_Serial18.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial18.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial18.Location = new System.Drawing.Point(16, 66);
            this.label_Serial18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial18.Name = "label_Serial18";
            this.label_Serial18.Size = new System.Drawing.Size(169, 36);
            this.label_Serial18.TabIndex = 41;
            // 
            // label_Serial_Value18
            // 
            this.label_Serial_Value18.AutoSize = true;
            this.label_Serial_Value18.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value18.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value18.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value18.Name = "label_Serial_Value18";
            this.label_Serial_Value18.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value18.TabIndex = 7;
            // 
            // label_Serial25
            // 
            this.label_Serial25.AutoSize = true;
            this.label_Serial25.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial25.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial25.Location = new System.Drawing.Point(16, 66);
            this.label_Serial25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial25.Name = "label_Serial25";
            this.label_Serial25.Size = new System.Drawing.Size(169, 36);
            this.label_Serial25.TabIndex = 41;
            // 
            // label_Serial_Value25
            // 
            this.label_Serial_Value25.AutoSize = true;
            this.label_Serial_Value25.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value25.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value25.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value25.Name = "label_Serial_Value25";
            this.label_Serial_Value25.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value25.TabIndex = 7;
            // 
            // label_Serial32
            // 
            this.label_Serial32.AutoSize = true;
            this.label_Serial32.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial32.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial32.Location = new System.Drawing.Point(16, 66);
            this.label_Serial32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial32.Name = "label_Serial32";
            this.label_Serial32.Size = new System.Drawing.Size(169, 36);
            this.label_Serial32.TabIndex = 41;
            // 
            // label_Serial_Value32
            // 
            this.label_Serial_Value32.AutoSize = true;
            this.label_Serial_Value32.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value32.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value32.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value32.Name = "label_Serial_Value32";
            this.label_Serial_Value32.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value32.TabIndex = 7;
            // 
            // label_Serial3
            // 
            this.label_Serial3.AutoSize = true;
            this.label_Serial3.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial3.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial3.Location = new System.Drawing.Point(16, 66);
            this.label_Serial3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial3.Name = "label_Serial3";
            this.label_Serial3.Size = new System.Drawing.Size(169, 36);
            this.label_Serial3.TabIndex = 41;
            // 
            // label_Serial_Value3
            // 
            this.label_Serial_Value3.AutoSize = true;
            this.label_Serial_Value3.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value3.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value3.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value3.Name = "label_Serial_Value3";
            this.label_Serial_Value3.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value3.TabIndex = 7;
            // 
            // label_Serial10
            // 
            this.label_Serial10.AutoSize = true;
            this.label_Serial10.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial10.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial10.Location = new System.Drawing.Point(16, 66);
            this.label_Serial10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial10.Name = "label_Serial10";
            this.label_Serial10.Size = new System.Drawing.Size(169, 36);
            this.label_Serial10.TabIndex = 41;
            // 
            // label_Serial_Value10
            // 
            this.label_Serial_Value10.AutoSize = true;
            this.label_Serial_Value10.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value10.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value10.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value10.Name = "label_Serial_Value10";
            this.label_Serial_Value10.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value10.TabIndex = 7;
            // 
            // label_Serial17
            // 
            this.label_Serial17.AutoSize = true;
            this.label_Serial17.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial17.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial17.Location = new System.Drawing.Point(16, 66);
            this.label_Serial17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial17.Name = "label_Serial17";
            this.label_Serial17.Size = new System.Drawing.Size(169, 36);
            this.label_Serial17.TabIndex = 41;
            // 
            // label_Serial_Value17
            // 
            this.label_Serial_Value17.AutoSize = true;
            this.label_Serial_Value17.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value17.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value17.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value17.Name = "label_Serial_Value17";
            this.label_Serial_Value17.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value17.TabIndex = 7;
            // 
            // label_Serial24
            // 
            this.label_Serial24.AutoSize = true;
            this.label_Serial24.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial24.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial24.Location = new System.Drawing.Point(16, 66);
            this.label_Serial24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial24.Name = "label_Serial24";
            this.label_Serial24.Size = new System.Drawing.Size(169, 36);
            this.label_Serial24.TabIndex = 41;
            // 
            // label_Serial_Value24
            // 
            this.label_Serial_Value24.AutoSize = true;
            this.label_Serial_Value24.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value24.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value24.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value24.Name = "label_Serial_Value24";
            this.label_Serial_Value24.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value24.TabIndex = 7;
            // 
            // label_Serial31
            // 
            this.label_Serial31.AutoSize = true;
            this.label_Serial31.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial31.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial31.Location = new System.Drawing.Point(16, 66);
            this.label_Serial31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial31.Name = "label_Serial31";
            this.label_Serial31.Size = new System.Drawing.Size(169, 36);
            this.label_Serial31.TabIndex = 41;
            // 
            // label_Serial_Value31
            // 
            this.label_Serial_Value31.AutoSize = true;
            this.label_Serial_Value31.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value31.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value31.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value31.Name = "label_Serial_Value31";
            this.label_Serial_Value31.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value31.TabIndex = 7;
            // 
            // label_Serial2
            // 
            this.label_Serial2.AutoSize = true;
            this.label_Serial2.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial2.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial2.Location = new System.Drawing.Point(16, 66);
            this.label_Serial2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial2.Name = "label_Serial2";
            this.label_Serial2.Size = new System.Drawing.Size(169, 36);
            this.label_Serial2.TabIndex = 41;
            // 
            // label_Serial_Value2
            // 
            this.label_Serial_Value2.AutoSize = true;
            this.label_Serial_Value2.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value2.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value2.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value2.Name = "label_Serial_Value2";
            this.label_Serial_Value2.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value2.TabIndex = 7;
            // 
            // label_Serial9
            // 
            this.label_Serial9.AutoSize = true;
            this.label_Serial9.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial9.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial9.Location = new System.Drawing.Point(16, 66);
            this.label_Serial9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial9.Name = "label_Serial9";
            this.label_Serial9.Size = new System.Drawing.Size(169, 36);
            this.label_Serial9.TabIndex = 41;
            // 
            // label_Serial_Value9
            // 
            this.label_Serial_Value9.AutoSize = true;
            this.label_Serial_Value9.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value9.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value9.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value9.Name = "label_Serial_Value9";
            this.label_Serial_Value9.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value9.TabIndex = 7;
            // 
            // label_Serial16
            // 
            this.label_Serial16.AutoSize = true;
            this.label_Serial16.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial16.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial16.Location = new System.Drawing.Point(16, 66);
            this.label_Serial16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial16.Name = "label_Serial16";
            this.label_Serial16.Size = new System.Drawing.Size(169, 36);
            this.label_Serial16.TabIndex = 41;
            // 
            // label_Serial_Value16
            // 
            this.label_Serial_Value16.AutoSize = true;
            this.label_Serial_Value16.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value16.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value16.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value16.Name = "label_Serial_Value16";
            this.label_Serial_Value16.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value16.TabIndex = 7;
            // 
            // label_Serial23
            // 
            this.label_Serial23.AutoSize = true;
            this.label_Serial23.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial23.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial23.Location = new System.Drawing.Point(16, 66);
            this.label_Serial23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial23.Name = "label_Serial23";
            this.label_Serial23.Size = new System.Drawing.Size(169, 36);
            this.label_Serial23.TabIndex = 41;
            // 
            // label_Serial_Value23
            // 
            this.label_Serial_Value23.AutoSize = true;
            this.label_Serial_Value23.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value23.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value23.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value23.Name = "label_Serial_Value23";
            this.label_Serial_Value23.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value23.TabIndex = 7;
            // 
            // label_Serial30
            // 
            this.label_Serial30.AutoSize = true;
            this.label_Serial30.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial30.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial30.Location = new System.Drawing.Point(16, 66);
            this.label_Serial30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial30.Name = "label_Serial30";
            this.label_Serial30.Size = new System.Drawing.Size(169, 36);
            this.label_Serial30.TabIndex = 41;
            // 
            // label_Serial_Value30
            // 
            this.label_Serial_Value30.AutoSize = true;
            this.label_Serial_Value30.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value30.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value30.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value30.Name = "label_Serial_Value30";
            this.label_Serial_Value30.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value30.TabIndex = 7;
            // 
            // label_Serial1
            // 
            this.label_Serial1.AutoSize = true;
            this.label_Serial1.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial1.Location = new System.Drawing.Point(16, 66);
            this.label_Serial1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial1.Name = "label_Serial1";
            this.label_Serial1.Size = new System.Drawing.Size(169, 36);
            this.label_Serial1.TabIndex = 41;
            // 
            // label_Serial_Value1
            // 
            this.label_Serial_Value1.AutoSize = true;
            this.label_Serial_Value1.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value1.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value1.Name = "label_Serial_Value1";
            this.label_Serial_Value1.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value1.TabIndex = 7;
            // 
            // label_Serial8
            // 
            this.label_Serial8.AutoSize = true;
            this.label_Serial8.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial8.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial8.Location = new System.Drawing.Point(16, 66);
            this.label_Serial8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial8.Name = "label_Serial8";
            this.label_Serial8.Size = new System.Drawing.Size(169, 36);
            this.label_Serial8.TabIndex = 41;
            // 
            // label_Serial_Value8
            // 
            this.label_Serial_Value8.AutoSize = true;
            this.label_Serial_Value8.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value8.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value8.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value8.Name = "label_Serial_Value8";
            this.label_Serial_Value8.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value8.TabIndex = 7;
            // 
            // label_Serial15
            // 
            this.label_Serial15.AutoSize = true;
            this.label_Serial15.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial15.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial15.Location = new System.Drawing.Point(16, 66);
            this.label_Serial15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial15.Name = "label_Serial15";
            this.label_Serial15.Size = new System.Drawing.Size(169, 36);
            this.label_Serial15.TabIndex = 41;
            // 
            // label_Serial_Value15
            // 
            this.label_Serial_Value15.AutoSize = true;
            this.label_Serial_Value15.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value15.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value15.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value15.Name = "label_Serial_Value15";
            this.label_Serial_Value15.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value15.TabIndex = 7;
            // 
            // label_Serial22
            // 
            this.label_Serial22.AutoSize = true;
            this.label_Serial22.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial22.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial22.Location = new System.Drawing.Point(16, 66);
            this.label_Serial22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial22.Name = "label_Serial22";
            this.label_Serial22.Size = new System.Drawing.Size(169, 36);
            this.label_Serial22.TabIndex = 41;
            // 
            // label_Serial_Value22
            // 
            this.label_Serial_Value22.AutoSize = true;
            this.label_Serial_Value22.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value22.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value22.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value22.Name = "label_Serial_Value22";
            this.label_Serial_Value22.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value22.TabIndex = 7;
            // 
            // label_Serial29
            // 
            this.label_Serial29.AutoSize = true;
            this.label_Serial29.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial29.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial29.Location = new System.Drawing.Point(16, 66);
            this.label_Serial29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial29.Name = "label_Serial29";
            this.label_Serial29.Size = new System.Drawing.Size(169, 36);
            this.label_Serial29.TabIndex = 41;
            // 
            // label_Serial_Value29
            // 
            this.label_Serial_Value29.AutoSize = true;
            this.label_Serial_Value29.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value29.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value29.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value29.Name = "label_Serial_Value29";
            this.label_Serial_Value29.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value29.TabIndex = 7;
            // 
            // label_Serial7
            // 
            this.label_Serial7.AutoSize = true;
            this.label_Serial7.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial7.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial7.Location = new System.Drawing.Point(16, 66);
            this.label_Serial7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial7.Name = "label_Serial7";
            this.label_Serial7.Size = new System.Drawing.Size(169, 36);
            this.label_Serial7.TabIndex = 41;
            // 
            // label_Serial_Value7
            // 
            this.label_Serial_Value7.AutoSize = true;
            this.label_Serial_Value7.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value7.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value7.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value7.Name = "label_Serial_Value7";
            this.label_Serial_Value7.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value7.TabIndex = 7;
            // 
            // label_Serial14
            // 
            this.label_Serial14.AutoSize = true;
            this.label_Serial14.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial14.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial14.Location = new System.Drawing.Point(16, 66);
            this.label_Serial14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial14.Name = "label_Serial14";
            this.label_Serial14.Size = new System.Drawing.Size(169, 36);
            this.label_Serial14.TabIndex = 41;
            // 
            // label_Serial_Value14
            // 
            this.label_Serial_Value14.AutoSize = true;
            this.label_Serial_Value14.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value14.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value14.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value14.Name = "label_Serial_Value14";
            this.label_Serial_Value14.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value14.TabIndex = 7;
            // 
            // label_Serial21
            // 
            this.label_Serial21.AutoSize = true;
            this.label_Serial21.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial21.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial21.Location = new System.Drawing.Point(16, 66);
            this.label_Serial21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial21.Name = "label_Serial21";
            this.label_Serial21.Size = new System.Drawing.Size(169, 36);
            this.label_Serial21.TabIndex = 41;
            // 
            // label_Serial_Value21
            // 
            this.label_Serial_Value21.AutoSize = true;
            this.label_Serial_Value21.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value21.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value21.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value21.Name = "label_Serial_Value21";
            this.label_Serial_Value21.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value21.TabIndex = 7;
            // 
            // label_Serial28
            // 
            this.label_Serial28.AutoSize = true;
            this.label_Serial28.BackColor = System.Drawing.Color.DarkGray;
            this.label_Serial28.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial28.Location = new System.Drawing.Point(16, 66);
            this.label_Serial28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial28.Name = "label_Serial28";
            this.label_Serial28.Size = new System.Drawing.Size(169, 36);
            this.label_Serial28.TabIndex = 41;
            // 
            // label_Serial_Value28
            // 
            this.label_Serial_Value28.AutoSize = true;
            this.label_Serial_Value28.BackColor = System.Drawing.Color.Lime;
            this.label_Serial_Value28.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_Serial_Value28.Location = new System.Drawing.Point(18, 30);
            this.label_Serial_Value28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_Serial_Value28.Name = "label_Serial_Value28";
            this.label_Serial_Value28.Size = new System.Drawing.Size(164, 36);
            this.label_Serial_Value28.TabIndex = 7;
            // 
            // label_SN_Temp3
            // 
            this.label_SN_Temp3.AutoSize = true;
            this.label_SN_Temp3.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_SN_Temp3.Location = new System.Drawing.Point(18, 32);
            this.label_SN_Temp3.Name = "label_SN_Temp3";
            this.label_SN_Temp3.Size = new System.Drawing.Size(94, 36);
            this.label_SN_Temp3.TabIndex = 0;
            // 
            // label_SN_Humidity3
            // 
            this.label_SN_Humidity3.AutoSize = true;
            this.label_SN_Humidity3.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_SN_Humidity3.Location = new System.Drawing.Point(16, 68);
            this.label_SN_Humidity3.Name = "label_SN_Humidity3";
            this.label_SN_Humidity3.Size = new System.Drawing.Size(143, 36);
            this.label_SN_Humidity3.TabIndex = 0;
            // 
            // label_SN_Temp2
            // 
            this.label_SN_Temp2.AutoSize = true;
            this.label_SN_Temp2.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_SN_Temp2.Location = new System.Drawing.Point(18, 32);
            this.label_SN_Temp2.Name = "label_SN_Temp2";
            this.label_SN_Temp2.Size = new System.Drawing.Size(94, 36);
            this.label_SN_Temp2.TabIndex = 0;
            // 
            // label_SN_Humidity2
            // 
            this.label_SN_Humidity2.AutoSize = true;
            this.label_SN_Humidity2.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_SN_Humidity2.Location = new System.Drawing.Point(16, 68);
            this.label_SN_Humidity2.Name = "label_SN_Humidity2";
            this.label_SN_Humidity2.Size = new System.Drawing.Size(143, 36);
            this.label_SN_Humidity2.TabIndex = 0;
            // 
            // label_SN_Temp1
            // 
            this.label_SN_Temp1.AutoSize = true;
            this.label_SN_Temp1.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_SN_Temp1.Location = new System.Drawing.Point(18, 32);
            this.label_SN_Temp1.Name = "label_SN_Temp1";
            this.label_SN_Temp1.Size = new System.Drawing.Size(94, 36);
            this.label_SN_Temp1.TabIndex = 0;
            // 
            // label_SN_Humidity1
            // 
            this.label_SN_Humidity1.AutoSize = true;
            this.label_SN_Humidity1.Font = new System.Drawing.Font("新細明體", 18F);
            this.label_SN_Humidity1.Location = new System.Drawing.Point(16, 68);
            this.label_SN_Humidity1.Name = "label_SN_Humidity1";
            this.label_SN_Humidity1.Size = new System.Drawing.Size(143, 36);
            this.label_SN_Humidity1.TabIndex = 0;
            // 
            // serialPort2
            // 
            this.serialPort2.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort2_DataReceived);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // flowLayoutPanel18
            // 
            this.flowLayoutPanel18.Controls.Add(this.groupBox_I2C);
            this.flowLayoutPanel18.Controls.Add(this.groupBox_USBLink);
            this.flowLayoutPanel18.Controls.Add(this.flowLayoutPanel20);
            this.flowLayoutPanel18.Location = new System.Drawing.Point(13, 13);
            this.flowLayoutPanel18.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.flowLayoutPanel18.Name = "flowLayoutPanel18";
            this.flowLayoutPanel18.Size = new System.Drawing.Size(1422, 1440);
            this.flowLayoutPanel18.TabIndex = 2;
            // 
            // flowLayoutPanel20
            // 
            this.flowLayoutPanel20.Controls.Add(this.label32);
            this.flowLayoutPanel20.Controls.Add(this.Sabio_Info_Box);
            this.flowLayoutPanel20.Controls.Add(this.brn_InfoCln);
            this.flowLayoutPanel20.Location = new System.Drawing.Point(3, 1276);
            this.flowLayoutPanel20.Name = "flowLayoutPanel20";
            this.flowLayoutPanel20.Size = new System.Drawing.Size(306, 195);
            this.flowLayoutPanel20.TabIndex = 24;
            // 
            // timer_alcap
            // 
            this.timer_alcap.Interval = 1000;
            this.timer_alcap.Tick += new System.EventHandler(this.timer_alcap_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1482, 676);
            this.Controls.Add(this.flowLayoutPanel18);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox_USBLink.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel9.ResumeLayout(false);
            this.flowLayoutPanel9.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.flowLayoutPanel13.ResumeLayout(false);
            this.flowLayoutPanel13.PerformLayout();
            this.flowLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel16.PerformLayout();
            this.flowLayoutPanel12.ResumeLayout(false);
            this.flowLayoutPanel12.PerformLayout();
            this.flowLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.flowLayoutPanel16.ResumeLayout(false);
            this.flowLayoutPanel16.PerformLayout();
            this.flowLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.flowLayoutPanel11.ResumeLayout(false);
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel10.ResumeLayout(false);
            this.flowLayoutPanel6.ResumeLayout(false);
            this.flowLayoutPanel6.PerformLayout();
            this.flowLayoutPanel8.ResumeLayout(false);
            this.flowLayoutPanel8.PerformLayout();
            this.flowLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.groupBox_I2C.ResumeLayout(false);
            this.groupBox_I2C.PerformLayout();
            this.groupBox_IDBOX.ResumeLayout(false);
            this.groupBox_IDBOX.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SpanValue_box)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ID_box)).EndInit();
            this.group_SHT0.ResumeLayout(false);
            this.group_SHT0.PerformLayout();
            this.group_SHT1.ResumeLayout(false);
            this.group_SHT1.PerformLayout();
            this.group_Response.ResumeLayout(false);
            this.group_Response.PerformLayout();
            this.group_SHT2.ResumeLayout(false);
            this.group_SHT2.PerformLayout();
            this.group_SHT3.ResumeLayout(false);
            this.group_SHT3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabSelect.ResumeLayout(false);
            this.tabPage_PCBA_WEAE.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.group_PCBA23.ResumeLayout(false);
            this.group_PCBA23.PerformLayout();
            this.group_PCBA22.ResumeLayout(false);
            this.group_PCBA22.PerformLayout();
            this.group_PCBA21.ResumeLayout(false);
            this.group_PCBA21.PerformLayout();
            this.group_PCBA20.ResumeLayout(false);
            this.group_PCBA20.PerformLayout();
            this.group_PCBA19.ResumeLayout(false);
            this.group_PCBA19.PerformLayout();
            this.group_PCBA18.ResumeLayout(false);
            this.group_PCBA18.PerformLayout();
            this.group_PCBA17.ResumeLayout(false);
            this.group_PCBA17.PerformLayout();
            this.group_PCBA16.ResumeLayout(false);
            this.group_PCBA16.PerformLayout();
            this.group_PCBA15.ResumeLayout(false);
            this.group_PCBA15.PerformLayout();
            this.group_PCBA14.ResumeLayout(false);
            this.group_PCBA14.PerformLayout();
            this.group_PCBA13.ResumeLayout(false);
            this.group_PCBA13.PerformLayout();
            this.group_PCBA12.ResumeLayout(false);
            this.group_PCBA12.PerformLayout();
            this.group_PCBA11.ResumeLayout(false);
            this.group_PCBA11.PerformLayout();
            this.group_PCBA10.ResumeLayout(false);
            this.group_PCBA10.PerformLayout();
            this.group_PCBA9.ResumeLayout(false);
            this.group_PCBA9.PerformLayout();
            this.group_PCBA8.ResumeLayout(false);
            this.group_PCBA8.PerformLayout();
            this.group_PCBA7.ResumeLayout(false);
            this.group_PCBA7.PerformLayout();
            this.group_PCBA6.ResumeLayout(false);
            this.group_PCBA6.PerformLayout();
            this.group_PCBA5.ResumeLayout(false);
            this.group_PCBA5.PerformLayout();
            this.group_PCBA4.ResumeLayout(false);
            this.group_PCBA4.PerformLayout();
            this.group_PCBA3.ResumeLayout(false);
            this.group_PCBA3.PerformLayout();
            this.group_PCBA2.ResumeLayout(false);
            this.group_PCBA2.PerformLayout();
            this.group_PCBA1.ResumeLayout(false);
            this.group_PCBA1.PerformLayout();
            this.group_PCBA0.ResumeLayout(false);
            this.group_PCBA0.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage_ADC.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.group_ADC23.ResumeLayout(false);
            this.group_ADC23.PerformLayout();
            this.group_ADC22.ResumeLayout(false);
            this.group_ADC22.PerformLayout();
            this.group_ADC21.ResumeLayout(false);
            this.group_ADC21.PerformLayout();
            this.group_ADC20.ResumeLayout(false);
            this.group_ADC20.PerformLayout();
            this.group_ADC19.ResumeLayout(false);
            this.group_ADC19.PerformLayout();
            this.group_ADC18.ResumeLayout(false);
            this.group_ADC18.PerformLayout();
            this.group_ADC17.ResumeLayout(false);
            this.group_ADC17.PerformLayout();
            this.group_ADC16.ResumeLayout(false);
            this.group_ADC16.PerformLayout();
            this.group_ADC15.ResumeLayout(false);
            this.group_ADC15.PerformLayout();
            this.group_ADC14.ResumeLayout(false);
            this.group_ADC14.PerformLayout();
            this.group_ADC13.ResumeLayout(false);
            this.group_ADC13.PerformLayout();
            this.group_ADC12.ResumeLayout(false);
            this.group_ADC12.PerformLayout();
            this.group_ADC11.ResumeLayout(false);
            this.group_ADC11.PerformLayout();
            this.group_ADC10.ResumeLayout(false);
            this.group_ADC10.PerformLayout();
            this.group_ADC9.ResumeLayout(false);
            this.group_ADC9.PerformLayout();
            this.group_ADC8.ResumeLayout(false);
            this.group_ADC8.PerformLayout();
            this.group_ADC7.ResumeLayout(false);
            this.group_ADC7.PerformLayout();
            this.group_ADC6.ResumeLayout(false);
            this.group_ADC6.PerformLayout();
            this.group_ADC5.ResumeLayout(false);
            this.group_ADC5.PerformLayout();
            this.group_ADC4.ResumeLayout(false);
            this.group_ADC4.PerformLayout();
            this.group_ADC3.ResumeLayout(false);
            this.group_ADC3.PerformLayout();
            this.group_ADC2.ResumeLayout(false);
            this.group_ADC2.PerformLayout();
            this.group_ADC1.ResumeLayout(false);
            this.group_ADC1.PerformLayout();
            this.group_ADC0.ResumeLayout(false);
            this.group_ADC0.PerformLayout();
            this.tabPage_Zero.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.group_zero18.ResumeLayout(false);
            this.group_zero18.PerformLayout();
            this.group_zero23.ResumeLayout(false);
            this.group_zero23.PerformLayout();
            this.group_zero22.ResumeLayout(false);
            this.group_zero22.PerformLayout();
            this.group_zero21.ResumeLayout(false);
            this.group_zero21.PerformLayout();
            this.group_zero20.ResumeLayout(false);
            this.group_zero20.PerformLayout();
            this.group_zero19.ResumeLayout(false);
            this.group_zero19.PerformLayout();
            this.group_zero17.ResumeLayout(false);
            this.group_zero17.PerformLayout();
            this.group_zero16.ResumeLayout(false);
            this.group_zero16.PerformLayout();
            this.group_zero15.ResumeLayout(false);
            this.group_zero15.PerformLayout();
            this.group_zero14.ResumeLayout(false);
            this.group_zero14.PerformLayout();
            this.group_zero13.ResumeLayout(false);
            this.group_zero13.PerformLayout();
            this.group_zero12.ResumeLayout(false);
            this.group_zero12.PerformLayout();
            this.group_zero11.ResumeLayout(false);
            this.group_zero11.PerformLayout();
            this.group_zero10.ResumeLayout(false);
            this.group_zero10.PerformLayout();
            this.group_zero9.ResumeLayout(false);
            this.group_zero9.PerformLayout();
            this.group_zero8.ResumeLayout(false);
            this.group_zero8.PerformLayout();
            this.group_zero7.ResumeLayout(false);
            this.group_zero7.PerformLayout();
            this.group_zero6.ResumeLayout(false);
            this.group_zero6.PerformLayout();
            this.group_zero5.ResumeLayout(false);
            this.group_zero5.PerformLayout();
            this.group_zero4.ResumeLayout(false);
            this.group_zero4.PerformLayout();
            this.group_zero3.ResumeLayout(false);
            this.group_zero3.PerformLayout();
            this.group_zero2.ResumeLayout(false);
            this.group_zero2.PerformLayout();
            this.group_zero1.ResumeLayout(false);
            this.group_zero1.PerformLayout();
            this.group_zero0.ResumeLayout(false);
            this.group_zero0.PerformLayout();
            this.tabPage_Span.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.group_Span23.ResumeLayout(false);
            this.group_Span23.PerformLayout();
            this.group_Span22.ResumeLayout(false);
            this.group_Span22.PerformLayout();
            this.group_Span0.ResumeLayout(false);
            this.group_Span0.PerformLayout();
            this.group_Span14.ResumeLayout(false);
            this.group_Span14.PerformLayout();
            this.group_Span15.ResumeLayout(false);
            this.group_Span15.PerformLayout();
            this.group_Span20.ResumeLayout(false);
            this.group_Span20.PerformLayout();
            this.group_Span19.ResumeLayout(false);
            this.group_Span19.PerformLayout();
            this.group_Span18.ResumeLayout(false);
            this.group_Span18.PerformLayout();
            this.group_Span17.ResumeLayout(false);
            this.group_Span17.PerformLayout();
            this.group_Span16.ResumeLayout(false);
            this.group_Span16.PerformLayout();
            this.group_Span1.ResumeLayout(false);
            this.group_Span1.PerformLayout();
            this.group_Span7.ResumeLayout(false);
            this.group_Span7.PerformLayout();
            this.group_Span2.ResumeLayout(false);
            this.group_Span2.PerformLayout();
            this.group_Span8.ResumeLayout(false);
            this.group_Span8.PerformLayout();
            this.group_Span3.ResumeLayout(false);
            this.group_Span3.PerformLayout();
            this.group_Span9.ResumeLayout(false);
            this.group_Span9.PerformLayout();
            this.group_Span10.ResumeLayout(false);
            this.group_Span10.PerformLayout();
            this.group_Span11.ResumeLayout(false);
            this.group_Span11.PerformLayout();
            this.group_Span12.ResumeLayout(false);
            this.group_Span12.PerformLayout();
            this.group_Span13.ResumeLayout(false);
            this.group_Span13.PerformLayout();
            this.group_Span4.ResumeLayout(false);
            this.group_Span4.PerformLayout();
            this.group_Span5.ResumeLayout(false);
            this.group_Span5.PerformLayout();
            this.group_Span6.ResumeLayout(false);
            this.group_Span6.PerformLayout();
            this.group_Span21.ResumeLayout(false);
            this.group_Span21.PerformLayout();
            this.a.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.group_A23.ResumeLayout(false);
            this.group_A23.PerformLayout();
            this.group_A22.ResumeLayout(false);
            this.group_A22.PerformLayout();
            this.group_A0.ResumeLayout(false);
            this.group_A0.PerformLayout();
            this.group_A14.ResumeLayout(false);
            this.group_A14.PerformLayout();
            this.group_A15.ResumeLayout(false);
            this.group_A15.PerformLayout();
            this.group_A20.ResumeLayout(false);
            this.group_A20.PerformLayout();
            this.group_A19.ResumeLayout(false);
            this.group_A19.PerformLayout();
            this.group_A18.ResumeLayout(false);
            this.group_A18.PerformLayout();
            this.group_A17.ResumeLayout(false);
            this.group_A17.PerformLayout();
            this.group_A16.ResumeLayout(false);
            this.group_A16.PerformLayout();
            this.group_A1.ResumeLayout(false);
            this.group_A1.PerformLayout();
            this.group_A7.ResumeLayout(false);
            this.group_A7.PerformLayout();
            this.group_A2.ResumeLayout(false);
            this.group_A2.PerformLayout();
            this.group_A8.ResumeLayout(false);
            this.group_A8.PerformLayout();
            this.group_A3.ResumeLayout(false);
            this.group_A3.PerformLayout();
            this.group_A9.ResumeLayout(false);
            this.group_A9.PerformLayout();
            this.group_A10.ResumeLayout(false);
            this.group_A10.PerformLayout();
            this.group_A11.ResumeLayout(false);
            this.group_A11.PerformLayout();
            this.group_A12.ResumeLayout(false);
            this.group_A12.PerformLayout();
            this.group_A13.ResumeLayout(false);
            this.group_A13.PerformLayout();
            this.group_A4.ResumeLayout(false);
            this.group_A4.PerformLayout();
            this.group_A5.ResumeLayout(false);
            this.group_A5.PerformLayout();
            this.group_A6.ResumeLayout(false);
            this.group_A6.PerformLayout();
            this.group_A21.ResumeLayout(false);
            this.group_A21.PerformLayout();
            this.b.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.group_B23.ResumeLayout(false);
            this.group_B23.PerformLayout();
            this.group_B22.ResumeLayout(false);
            this.group_B22.PerformLayout();
            this.group_B0.ResumeLayout(false);
            this.group_B0.PerformLayout();
            this.group_B14.ResumeLayout(false);
            this.group_B14.PerformLayout();
            this.group_B15.ResumeLayout(false);
            this.group_B15.PerformLayout();
            this.group_B20.ResumeLayout(false);
            this.group_B20.PerformLayout();
            this.group_B19.ResumeLayout(false);
            this.group_B19.PerformLayout();
            this.group_B18.ResumeLayout(false);
            this.group_B18.PerformLayout();
            this.group_B17.ResumeLayout(false);
            this.group_B17.PerformLayout();
            this.group_B16.ResumeLayout(false);
            this.group_B16.PerformLayout();
            this.group_B1.ResumeLayout(false);
            this.group_B1.PerformLayout();
            this.group_B7.ResumeLayout(false);
            this.group_B7.PerformLayout();
            this.group_B2.ResumeLayout(false);
            this.group_B2.PerformLayout();
            this.group_B8.ResumeLayout(false);
            this.group_B8.PerformLayout();
            this.group_B3.ResumeLayout(false);
            this.group_B3.PerformLayout();
            this.group_B9.ResumeLayout(false);
            this.group_B9.PerformLayout();
            this.group_B10.ResumeLayout(false);
            this.group_B10.PerformLayout();
            this.group_B11.ResumeLayout(false);
            this.group_B11.PerformLayout();
            this.group_B12.ResumeLayout(false);
            this.group_B12.PerformLayout();
            this.group_B13.ResumeLayout(false);
            this.group_B13.PerformLayout();
            this.group_B4.ResumeLayout(false);
            this.group_B4.PerformLayout();
            this.group_B5.ResumeLayout(false);
            this.group_B5.PerformLayout();
            this.group_B6.ResumeLayout(false);
            this.group_B6.PerformLayout();
            this.group_B21.ResumeLayout(false);
            this.group_B21.PerformLayout();
            this.tabPage_GasName.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.groupBox_Sensor_Name0.ResumeLayout(false);
            this.groupBox_Sensor_Name0.PerformLayout();
            this.groupBox_Sensor_Name23.ResumeLayout(false);
            this.groupBox_Sensor_Name23.PerformLayout();
            this.groupBox_Sensor_Name22.ResumeLayout(false);
            this.groupBox_Sensor_Name22.PerformLayout();
            this.groupBox_Sensor_Name21.ResumeLayout(false);
            this.groupBox_Sensor_Name21.PerformLayout();
            this.groupBox_Sensor_Name1.ResumeLayout(false);
            this.groupBox_Sensor_Name1.PerformLayout();
            this.groupBox_Sensor_Name14.ResumeLayout(false);
            this.groupBox_Sensor_Name14.PerformLayout();
            this.groupBox_Sensor_Name15.ResumeLayout(false);
            this.groupBox_Sensor_Name15.PerformLayout();
            this.groupBox_Sensor_Name20.ResumeLayout(false);
            this.groupBox_Sensor_Name20.PerformLayout();
            this.groupBox_Sensor_Name19.ResumeLayout(false);
            this.groupBox_Sensor_Name19.PerformLayout();
            this.groupBox_Sensor_Name18.ResumeLayout(false);
            this.groupBox_Sensor_Name18.PerformLayout();
            this.groupBox_Sensor_Name17.ResumeLayout(false);
            this.groupBox_Sensor_Name17.PerformLayout();
            this.groupBox_Sensor_Name16.ResumeLayout(false);
            this.groupBox_Sensor_Name16.PerformLayout();
            this.groupBox_Sensor_Name2.ResumeLayout(false);
            this.groupBox_Sensor_Name2.PerformLayout();
            this.groupBox_Sensor_Name7.ResumeLayout(false);
            this.groupBox_Sensor_Name7.PerformLayout();
            this.groupBox_Sensor_Name3.ResumeLayout(false);
            this.groupBox_Sensor_Name3.PerformLayout();
            this.groupBox_Sensor_Name8.ResumeLayout(false);
            this.groupBox_Sensor_Name8.PerformLayout();
            this.groupBox_Sensor_Name4.ResumeLayout(false);
            this.groupBox_Sensor_Name4.PerformLayout();
            this.groupBox_Sensor_Name9.ResumeLayout(false);
            this.groupBox_Sensor_Name9.PerformLayout();
            this.groupBox_Sensor_Name10.ResumeLayout(false);
            this.groupBox_Sensor_Name10.PerformLayout();
            this.groupBox_Sensor_Name11.ResumeLayout(false);
            this.groupBox_Sensor_Name11.PerformLayout();
            this.groupBox_Sensor_Name12.ResumeLayout(false);
            this.groupBox_Sensor_Name12.PerformLayout();
            this.groupBox_Sensor_Name13.ResumeLayout(false);
            this.groupBox_Sensor_Name13.PerformLayout();
            this.groupBox_Sensor_Name5.ResumeLayout(false);
            this.groupBox_Sensor_Name5.PerformLayout();
            this.groupBox_Sensor_Name6.ResumeLayout(false);
            this.groupBox_Sensor_Name6.PerformLayout();
            this.tabPage_BSN.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.group_BSN0.ResumeLayout(false);
            this.group_BSN0.PerformLayout();
            this.group_BSN23.ResumeLayout(false);
            this.group_BSN23.PerformLayout();
            this.group_BSN1.ResumeLayout(false);
            this.group_BSN1.PerformLayout();
            this.group_BSN22.ResumeLayout(false);
            this.group_BSN22.PerformLayout();
            this.group_BSN17.ResumeLayout(false);
            this.group_BSN17.PerformLayout();
            this.group_BSN21.ResumeLayout(false);
            this.group_BSN21.PerformLayout();
            this.group_BSN2.ResumeLayout(false);
            this.group_BSN2.PerformLayout();
            this.group_BSN20.ResumeLayout(false);
            this.group_BSN20.PerformLayout();
            this.group_BSN11.ResumeLayout(false);
            this.group_BSN11.PerformLayout();
            this.group_BSN19.ResumeLayout(false);
            this.group_BSN19.PerformLayout();
            this.group_BSN16.ResumeLayout(false);
            this.group_BSN16.PerformLayout();
            this.group_BSN18.ResumeLayout(false);
            this.group_BSN18.PerformLayout();
            this.group_BSN3.ResumeLayout(false);
            this.group_BSN3.PerformLayout();
            this.group_BSN5.ResumeLayout(false);
            this.group_BSN5.PerformLayout();
            this.group_BSN15.ResumeLayout(false);
            this.group_BSN15.PerformLayout();
            this.group_BSN4.ResumeLayout(false);
            this.group_BSN4.PerformLayout();
            this.group_BSN10.ResumeLayout(false);
            this.group_BSN10.PerformLayout();
            this.group_BSN14.ResumeLayout(false);
            this.group_BSN14.PerformLayout();
            this.group_BSN6.ResumeLayout(false);
            this.group_BSN6.PerformLayout();
            this.group_BSN7.ResumeLayout(false);
            this.group_BSN7.PerformLayout();
            this.group_BSN8.ResumeLayout(false);
            this.group_BSN8.PerformLayout();
            this.group_BSN13.ResumeLayout(false);
            this.group_BSN13.PerformLayout();
            this.group_BSN9.ResumeLayout(false);
            this.group_BSN9.PerformLayout();
            this.group_BSN12.ResumeLayout(false);
            this.group_BSN12.PerformLayout();
            this.tabPage_FWV.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.group_FW0.ResumeLayout(false);
            this.group_FW0.PerformLayout();
            this.group_FW23.ResumeLayout(false);
            this.group_FW23.PerformLayout();
            this.group_FW22.ResumeLayout(false);
            this.group_FW22.PerformLayout();
            this.group_FW21.ResumeLayout(false);
            this.group_FW21.PerformLayout();
            this.group_FW1.ResumeLayout(false);
            this.group_FW1.PerformLayout();
            this.group_FW14.ResumeLayout(false);
            this.group_FW14.PerformLayout();
            this.group_FW15.ResumeLayout(false);
            this.group_FW15.PerformLayout();
            this.group_FW20.ResumeLayout(false);
            this.group_FW20.PerformLayout();
            this.group_FW19.ResumeLayout(false);
            this.group_FW19.PerformLayout();
            this.group_FW18.ResumeLayout(false);
            this.group_FW18.PerformLayout();
            this.group_FW17.ResumeLayout(false);
            this.group_FW17.PerformLayout();
            this.group_FW16.ResumeLayout(false);
            this.group_FW16.PerformLayout();
            this.group_FW2.ResumeLayout(false);
            this.group_FW2.PerformLayout();
            this.group_FW7.ResumeLayout(false);
            this.group_FW7.PerformLayout();
            this.group_FW3.ResumeLayout(false);
            this.group_FW3.PerformLayout();
            this.group_FW8.ResumeLayout(false);
            this.group_FW8.PerformLayout();
            this.group_FW4.ResumeLayout(false);
            this.group_FW4.PerformLayout();
            this.group_FW9.ResumeLayout(false);
            this.group_FW9.PerformLayout();
            this.group_FW10.ResumeLayout(false);
            this.group_FW10.PerformLayout();
            this.group_FW11.ResumeLayout(false);
            this.group_FW11.PerformLayout();
            this.group_FW12.ResumeLayout(false);
            this.group_FW12.PerformLayout();
            this.group_FW13.ResumeLayout(false);
            this.group_FW13.PerformLayout();
            this.group_FW5.ResumeLayout(false);
            this.group_FW5.PerformLayout();
            this.group_FW6.ResumeLayout(false);
            this.group_FW6.PerformLayout();
            this.Cal_Date.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.group_CalDate23.ResumeLayout(false);
            this.group_CalDate23.PerformLayout();
            this.group_CalDate22.ResumeLayout(false);
            this.group_CalDate22.PerformLayout();
            this.group_CalDate14.ResumeLayout(false);
            this.group_CalDate14.PerformLayout();
            this.group_CalDate15.ResumeLayout(false);
            this.group_CalDate15.PerformLayout();
            this.group_CalDate20.ResumeLayout(false);
            this.group_CalDate20.PerformLayout();
            this.group_CalDate19.ResumeLayout(false);
            this.group_CalDate19.PerformLayout();
            this.group_CalDate18.ResumeLayout(false);
            this.group_CalDate18.PerformLayout();
            this.group_CalDate17.ResumeLayout(false);
            this.group_CalDate17.PerformLayout();
            this.group_CalDate16.ResumeLayout(false);
            this.group_CalDate16.PerformLayout();
            this.group_CalDate1.ResumeLayout(false);
            this.group_CalDate1.PerformLayout();
            this.group_CalDate7.ResumeLayout(false);
            this.group_CalDate7.PerformLayout();
            this.group_CalDate2.ResumeLayout(false);
            this.group_CalDate2.PerformLayout();
            this.group_CalDate8.ResumeLayout(false);
            this.group_CalDate8.PerformLayout();
            this.group_CalDate3.ResumeLayout(false);
            this.group_CalDate3.PerformLayout();
            this.group_CalDate9.ResumeLayout(false);
            this.group_CalDate9.PerformLayout();
            this.group_CalDate10.ResumeLayout(false);
            this.group_CalDate10.PerformLayout();
            this.group_CalDate11.ResumeLayout(false);
            this.group_CalDate11.PerformLayout();
            this.group_CalDate12.ResumeLayout(false);
            this.group_CalDate12.PerformLayout();
            this.group_CalDate13.ResumeLayout(false);
            this.group_CalDate13.PerformLayout();
            this.group_CalDate4.ResumeLayout(false);
            this.group_CalDate4.PerformLayout();
            this.group_CalDate5.ResumeLayout(false);
            this.group_CalDate5.PerformLayout();
            this.group_CalDate6.ResumeLayout(false);
            this.group_CalDate6.PerformLayout();
            this.group_CalDate21.ResumeLayout(false);
            this.group_CalDate21.PerformLayout();
            this.group_CalDate0.ResumeLayout(false);
            this.group_CalDate0.PerformLayout();
            this.flowLayoutPanel18.ResumeLayout(false);
            this.flowLayoutPanel20.ResumeLayout(false);
            this.flowLayoutPanel20.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_USBLink;
        private System.Windows.Forms.GroupBox groupBox_I2C;
        private System.Windows.Forms.Timer timer_command;
        private System.Windows.Forms.GroupBox groupBox_IDBOX;
        private System.Windows.Forms.Button btn_AlphFix_cap;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_AlphFix_Log;
        private System.Windows.Forms.Timer timer_getStatus;
        private System.Windows.Forms.Button btn_AutoSpan;
        private System.Windows.Forms.Button btn_CalZero;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer_getValue;
        private System.Windows.Forms.TabControl tabSelect;
        private System.Windows.Forms.TabPage tabPage_PCBA_WEAE;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label_PCBA_WEAE_Humidity1;
        private System.Windows.Forms.Label label_PCBA_WEAE_Temp1;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label_PCBA_WEAE_Humidity2;
        private System.Windows.Forms.Label label_PCBA_WEAE_Temp2;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label_PCBA_WEAE_Humidity3;
        private System.Windows.Forms.Label label_PCBA_WEAE_Temp3;
        private System.Windows.Forms.GroupBox group_PCBA21;
        private System.Windows.Forms.Label label_WE21;
        private System.Windows.Forms.Label label_AE21;
        private System.Windows.Forms.GroupBox group_PCBA14;
        private System.Windows.Forms.Label label_WE14;
        private System.Windows.Forms.Label label_AE14;
        private System.Windows.Forms.GroupBox group_PCBA7;
        private System.Windows.Forms.Label label_WE7;
        private System.Windows.Forms.Label label_AE7;
        private System.Windows.Forms.GroupBox group_PCBA22;
        private System.Windows.Forms.Label label_WE22;
        private System.Windows.Forms.Label label_AE22;
        private System.Windows.Forms.GroupBox group_PCBA15;
        private System.Windows.Forms.Label label_WE15;
        private System.Windows.Forms.Label label_AE15;
        private System.Windows.Forms.GroupBox group_PCBA8;
        private System.Windows.Forms.Label label_WE8;
        private System.Windows.Forms.Label label_AE8;
        private System.Windows.Forms.GroupBox group_PCBA1;
        private System.Windows.Forms.Label label_WE1;
        private System.Windows.Forms.Label label_AE1;
        private System.Windows.Forms.GroupBox group_PCBA23;
        private System.Windows.Forms.Label label_WE23;
        private System.Windows.Forms.Label label_AE23;
        private System.Windows.Forms.GroupBox group_PCBA16;
        private System.Windows.Forms.Label label_WE16;
        private System.Windows.Forms.Label label_AE16;
        private System.Windows.Forms.GroupBox group_PCBA9;
        private System.Windows.Forms.Label label_WE9;
        private System.Windows.Forms.Label label_AE9;
        private System.Windows.Forms.GroupBox group_PCBA2;
        private System.Windows.Forms.Label label_WE2;
        private System.Windows.Forms.Label label_AE2;
        private System.Windows.Forms.GroupBox group_PCBA17;
        private System.Windows.Forms.Label label_WE17;
        private System.Windows.Forms.Label label_AE17;
        private System.Windows.Forms.GroupBox group_PCBA10;
        private System.Windows.Forms.Label label_WE10;
        private System.Windows.Forms.Label label_AE10;
        private System.Windows.Forms.GroupBox group_PCBA3;
        private System.Windows.Forms.Label label_WE3;
        private System.Windows.Forms.Label label_AE3;
        private System.Windows.Forms.GroupBox group_PCBA18;
        private System.Windows.Forms.Label label_WE18;
        private System.Windows.Forms.Label label_AE18;
        private System.Windows.Forms.GroupBox group_PCBA11;
        private System.Windows.Forms.Label label_WE11;
        private System.Windows.Forms.Label label_AE11;
        private System.Windows.Forms.GroupBox group_PCBA4;
        private System.Windows.Forms.Label label_WE4;
        private System.Windows.Forms.Label label_AE4;
        private System.Windows.Forms.GroupBox group_PCBA19;
        private System.Windows.Forms.Label label_WE19;
        private System.Windows.Forms.Label label_AE19;
        private System.Windows.Forms.GroupBox group_PCBA12;
        private System.Windows.Forms.Label label_WE12;
        private System.Windows.Forms.Label label_AE12;
        private System.Windows.Forms.GroupBox group_PCBA5;
        private System.Windows.Forms.Label label_WE5;
        private System.Windows.Forms.Label label_AE5;
        private System.Windows.Forms.GroupBox group_PCBA20;
        private System.Windows.Forms.Label label_WE20;
        private System.Windows.Forms.Label label_AE20;
        private System.Windows.Forms.GroupBox group_PCBA13;
        private System.Windows.Forms.Label label_WE13;
        private System.Windows.Forms.Label label_AE13;
        private System.Windows.Forms.GroupBox group_PCBA6;
        private System.Windows.Forms.Label label_WE6;
        private System.Windows.Forms.Label label_AE6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label_PCBA_WEAE_Humidity4;
        private System.Windows.Forms.Label label_PCBA_WEAE_Temp4;
        private System.Windows.Forms.GroupBox group_PCBA0;
        private System.Windows.Forms.Label label_WE0;
        private System.Windows.Forms.Label label_AE0;
        private System.Windows.Forms.TabPage tabPage_Span;
        private System.Windows.Forms.TabPage tabPage_ADC;
        private System.Windows.Forms.GroupBox group_ADC21;
        private System.Windows.Forms.Label label_ADC_Value21;
        private System.Windows.Forms.Label label_ADC21;
        private System.Windows.Forms.GroupBox group_ADC14;
        private System.Windows.Forms.Label label_ADC_Value14;
        private System.Windows.Forms.Label label_ADC14;
        private System.Windows.Forms.GroupBox group_ADC7;
        private System.Windows.Forms.Label label_ADC_Value7;
        private System.Windows.Forms.Label label_ADC7;
        private System.Windows.Forms.GroupBox group_ADC22;
        private System.Windows.Forms.Label label_ADC_Value22;
        private System.Windows.Forms.Label label_ADC22;
        private System.Windows.Forms.GroupBox group_ADC15;
        private System.Windows.Forms.Label label_ADC_Value15;
        private System.Windows.Forms.Label label_ADC15;
        private System.Windows.Forms.GroupBox group_ADC8;
        private System.Windows.Forms.Label label_ADC_Value8;
        private System.Windows.Forms.Label label_ADC8;
        private System.Windows.Forms.GroupBox group_ADC1;
        private System.Windows.Forms.Label label_ADC_Value1;
        private System.Windows.Forms.Label label_ADC1;
        private System.Windows.Forms.GroupBox group_ADC23;
        private System.Windows.Forms.Label label_ADC_Value23;
        private System.Windows.Forms.Label label_ADC23;
        private System.Windows.Forms.GroupBox group_ADC16;
        private System.Windows.Forms.Label label_ADC_Value16;
        private System.Windows.Forms.Label label_ADC16;
        private System.Windows.Forms.GroupBox group_ADC9;
        private System.Windows.Forms.Label label_ADC_Value9;
        private System.Windows.Forms.Label label_ADC9;
        private System.Windows.Forms.GroupBox group_ADC2;
        private System.Windows.Forms.Label label_ADC_Value2;
        private System.Windows.Forms.Label label_ADC2;
        private System.Windows.Forms.GroupBox group_ADC17;
        private System.Windows.Forms.Label label_ADC_Value17;
        private System.Windows.Forms.Label label_ADC17;
        private System.Windows.Forms.GroupBox group_ADC10;
        private System.Windows.Forms.Label label_ADC_Value10;
        private System.Windows.Forms.Label label_ADC10;
        private System.Windows.Forms.GroupBox group_ADC3;
        private System.Windows.Forms.Label label_ADC_Value3;
        private System.Windows.Forms.Label label_ADC3;
        private System.Windows.Forms.GroupBox group_ADC18;
        private System.Windows.Forms.Label label_ADC_Value18;
        private System.Windows.Forms.Label label_ADC18;
        private System.Windows.Forms.GroupBox group_ADC11;
        private System.Windows.Forms.Label label_ADC_Value11;
        private System.Windows.Forms.Label label_ADC11;
        private System.Windows.Forms.GroupBox group_ADC4;
        private System.Windows.Forms.Label label_ADC_Value4;
        private System.Windows.Forms.Label label_ADC4;
        private System.Windows.Forms.GroupBox group_ADC19;
        private System.Windows.Forms.Label label_ADC_Value19;
        private System.Windows.Forms.Label label_ADC19;
        private System.Windows.Forms.GroupBox group_ADC12;
        private System.Windows.Forms.Label label_ADC_Value12;
        private System.Windows.Forms.Label label_ADC12;
        private System.Windows.Forms.GroupBox group_ADC5;
        private System.Windows.Forms.Label label_ADC_Value5;
        private System.Windows.Forms.Label label_ADC5;
        private System.Windows.Forms.GroupBox group_ADC20;
        private System.Windows.Forms.Label label_ADC_Value20;
        private System.Windows.Forms.Label label_ADC20;
        private System.Windows.Forms.GroupBox group_ADC13;
        private System.Windows.Forms.Label label_ADC_Value13;
        private System.Windows.Forms.Label label_ADC13;
        private System.Windows.Forms.GroupBox group_ADC6;
        private System.Windows.Forms.Label label_ADC_Value6;
        private System.Windows.Forms.Label label_ADC6;
        private System.Windows.Forms.GroupBox group_ADC0;
        private System.Windows.Forms.Label label_ADC_Value0;
        private System.Windows.Forms.Label label_ADC0;
        private System.Windows.Forms.TabPage tabPage_FWV;
        private System.Windows.Forms.GroupBox group_FW21;
        private System.Windows.Forms.Label label_FW_21;
        private System.Windows.Forms.GroupBox group_FW14;
        private System.Windows.Forms.Label label_FW_14;
        private System.Windows.Forms.GroupBox group_FW7;
        private System.Windows.Forms.Label label_FW_7;
        private System.Windows.Forms.GroupBox group_FW22;
        private System.Windows.Forms.Label label_FW_22;
        private System.Windows.Forms.GroupBox group_FW15;
        private System.Windows.Forms.Label label_FW_15;
        private System.Windows.Forms.GroupBox group_FW8;
        private System.Windows.Forms.Label label_FW_8;
        private System.Windows.Forms.GroupBox group_FW1;
        private System.Windows.Forms.Label label_FW_1;
        private System.Windows.Forms.GroupBox group_FW23;
        private System.Windows.Forms.Label label_FW_23;
        private System.Windows.Forms.GroupBox group_FW16;
        private System.Windows.Forms.Label label_FW_16;
        private System.Windows.Forms.GroupBox group_FW9;
        private System.Windows.Forms.Label label_FW_9;
        private System.Windows.Forms.GroupBox group_FW2;
        private System.Windows.Forms.Label label_FW_2;
        private System.Windows.Forms.GroupBox group_FW17;
        private System.Windows.Forms.Label label_FW_17;
        private System.Windows.Forms.GroupBox group_FW10;
        private System.Windows.Forms.Label label_FW_10;
        private System.Windows.Forms.GroupBox group_FW3;
        private System.Windows.Forms.Label label_FW_3;
        private System.Windows.Forms.GroupBox group_FW18;
        private System.Windows.Forms.Label label_FW_18;
        private System.Windows.Forms.GroupBox group_FW11;
        private System.Windows.Forms.Label label_FW_11;
        private System.Windows.Forms.GroupBox group_FW4;
        private System.Windows.Forms.Label label_FW_4;
        private System.Windows.Forms.GroupBox group_FW19;
        private System.Windows.Forms.Label label_FW_19;
        private System.Windows.Forms.GroupBox group_FW12;
        private System.Windows.Forms.Label label_FW_12;
        private System.Windows.Forms.GroupBox group_FW5;
        private System.Windows.Forms.Label label_FW_5;
        private System.Windows.Forms.GroupBox group_FW20;
        private System.Windows.Forms.Label label_FW_20;
        private System.Windows.Forms.GroupBox group_FW13;
        private System.Windows.Forms.Label label_FW_13;
        private System.Windows.Forms.GroupBox group_FW6;
        private System.Windows.Forms.Label label_FW_6;
        private System.Windows.Forms.GroupBox group_FW0;
        private System.Windows.Forms.Label label_FW_0;
        private System.Windows.Forms.Label label_Serial0;
        private System.Windows.Forms.Label label_Serial_Value0;
        private System.Windows.Forms.Label label_SN_Temp4;
        private System.Windows.Forms.Label label_SN_Humidity4;
        private System.Windows.Forms.Label label_Serial6;
        private System.Windows.Forms.Label label_Serial_Value6;
        private System.Windows.Forms.Label label_Serial13;
        private System.Windows.Forms.Label label_Serial_Value13;
        private System.Windows.Forms.Label label_Serial20;
        private System.Windows.Forms.Label label_Serial_Value20;
        private System.Windows.Forms.Label label_Serial27;
        private System.Windows.Forms.Label label_Serial_Value27;
        private System.Windows.Forms.Label label_Serial34;
        private System.Windows.Forms.Label label_Serial_Value34;
        private System.Windows.Forms.Label label_Serial5;
        private System.Windows.Forms.Label label_Serial_Value5;
        private System.Windows.Forms.Label label_Serial12;
        private System.Windows.Forms.Label label_Serial_Value12;
        private System.Windows.Forms.Label label_Serial19;
        private System.Windows.Forms.Label label_Serial_Value19;
        private System.Windows.Forms.Label label_Serial26;
        private System.Windows.Forms.Label label_Serial_Value26;
        private System.Windows.Forms.Label label_Serial33;
        private System.Windows.Forms.Label label_Serial_Value33;
        private System.Windows.Forms.Label label_Serial4;
        private System.Windows.Forms.Label label_Serial_Value4;
        private System.Windows.Forms.Label label_Serial11;
        private System.Windows.Forms.Label label_Serial_Value11;
        private System.Windows.Forms.Label label_Serial18;
        private System.Windows.Forms.Label label_Serial_Value18;
        private System.Windows.Forms.Label label_Serial25;
        private System.Windows.Forms.Label label_Serial_Value25;
        private System.Windows.Forms.Label label_Serial32;
        private System.Windows.Forms.Label label_Serial_Value32;
        private System.Windows.Forms.Label label_Serial3;
        private System.Windows.Forms.Label label_Serial_Value3;
        private System.Windows.Forms.Label label_Serial10;
        private System.Windows.Forms.Label label_Serial_Value10;
        private System.Windows.Forms.Label label_Serial17;
        private System.Windows.Forms.Label label_Serial_Value17;
        private System.Windows.Forms.Label label_Serial24;
        private System.Windows.Forms.Label label_Serial_Value24;
        private System.Windows.Forms.Label label_Serial31;
        private System.Windows.Forms.Label label_Serial_Value31;
        private System.Windows.Forms.Label label_Serial2;
        private System.Windows.Forms.Label label_Serial_Value2;
        private System.Windows.Forms.Label label_Serial9;
        private System.Windows.Forms.Label label_Serial_Value9;
        private System.Windows.Forms.Label label_Serial16;
        private System.Windows.Forms.Label label_Serial_Value16;
        private System.Windows.Forms.Label label_Serial23;
        private System.Windows.Forms.Label label_Serial_Value23;
        private System.Windows.Forms.Label label_Serial30;
        private System.Windows.Forms.Label label_Serial_Value30;
        private System.Windows.Forms.Label label_Serial1;
        private System.Windows.Forms.Label label_Serial_Value1;
        private System.Windows.Forms.Label label_Serial8;
        private System.Windows.Forms.Label label_Serial_Value8;
        private System.Windows.Forms.Label label_Serial15;
        private System.Windows.Forms.Label label_Serial_Value15;
        private System.Windows.Forms.Label label_Serial22;
        private System.Windows.Forms.Label label_Serial_Value22;
        private System.Windows.Forms.Label label_Serial29;
        private System.Windows.Forms.Label label_Serial_Value29;
        private System.Windows.Forms.Label label_Serial7;
        private System.Windows.Forms.Label label_Serial_Value7;
        private System.Windows.Forms.Label label_Serial14;
        private System.Windows.Forms.Label label_Serial_Value14;
        private System.Windows.Forms.Label label_Serial21;
        private System.Windows.Forms.Label label_Serial_Value21;
        private System.Windows.Forms.Label label_Serial28;
        private System.Windows.Forms.Label label_Serial_Value28;
        private System.Windows.Forms.Label label_SN_Temp3;
        private System.Windows.Forms.Label label_SN_Humidity3;
        private System.Windows.Forms.Label label_SN_Temp2;
        private System.Windows.Forms.Label label_SN_Humidity2;
        private System.Windows.Forms.Label label_SN_Temp1;
        private System.Windows.Forms.Label label_SN_Humidity1;
        private System.Windows.Forms.TabPage tabPage_BSN;
        private System.Windows.Forms.GroupBox group_BSN18;
        private System.Windows.Forms.Label label_BSN18;
        private System.Windows.Forms.GroupBox group_BSN12;
        private System.Windows.Forms.Label label_BSN12;
        private System.Windows.Forms.GroupBox group_BSN6;
        private System.Windows.Forms.Label label_BSN6;
        private System.Windows.Forms.GroupBox group_BSN0;
        private System.Windows.Forms.Label label_BSN0;
        private System.Windows.Forms.GroupBox group_BSN23;
        private System.Windows.Forms.Label label_BSN23;
        private System.Windows.Forms.GroupBox group_BSN17;
        private System.Windows.Forms.Label label_BSN17;
        private System.Windows.Forms.GroupBox group_BSN11;
        private System.Windows.Forms.Label label_BSN11;
        private System.Windows.Forms.GroupBox group_BSN5;
        private System.Windows.Forms.Label label_BSN5;
        private System.Windows.Forms.GroupBox group_BSN22;
        private System.Windows.Forms.Label label_BSN22;
        private System.Windows.Forms.GroupBox group_BSN16;
        private System.Windows.Forms.Label label_BSN16;
        private System.Windows.Forms.GroupBox group_BSN10;
        private System.Windows.Forms.Label label_BSN10;
        private System.Windows.Forms.GroupBox group_BSN4;
        private System.Windows.Forms.Label label_BSN4;
        private System.Windows.Forms.GroupBox group_BSN21;
        private System.Windows.Forms.Label label_BSN21;
        private System.Windows.Forms.GroupBox group_BSN15;
        private System.Windows.Forms.Label label_BSN15;
        private System.Windows.Forms.GroupBox group_BSN9;
        private System.Windows.Forms.Label label_BSN9;
        private System.Windows.Forms.GroupBox group_BSN3;
        private System.Windows.Forms.Label label_BSN3;
        private System.Windows.Forms.GroupBox group_BSN20;
        private System.Windows.Forms.Label label_BSN20;
        private System.Windows.Forms.GroupBox group_BSN14;
        private System.Windows.Forms.Label label_BSN14;
        private System.Windows.Forms.GroupBox group_BSN19;
        private System.Windows.Forms.Label label_BSN19;
        private System.Windows.Forms.GroupBox group_BSN8;
        private System.Windows.Forms.Label label_BSN8;
        private System.Windows.Forms.GroupBox group_BSN2;
        private System.Windows.Forms.Label label_BSN2;
        private System.Windows.Forms.GroupBox group_BSN13;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label_BSN13;
        private System.Windows.Forms.GroupBox group_BSN7;
        private System.Windows.Forms.Label label_BSN7;
        private System.Windows.Forms.GroupBox group_BSN1;
        private System.Windows.Forms.Label label_BSN1;
        private System.Windows.Forms.GroupBox group_Response;
        private System.Windows.Forms.Label label_Response;
        private System.Windows.Forms.NumericUpDown SpanValue_box;
        private System.Windows.Forms.TabPage tabPage_GasName;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name21;
        private System.Windows.Forms.Label label_Sensor_Name21;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name14;
        private System.Windows.Forms.Label label_Sensor_Name14;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name7;
        private System.Windows.Forms.Label label_Sensor_Name7;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name22;
        private System.Windows.Forms.Label label_Sensor_Name22;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name15;
        private System.Windows.Forms.Label label_Sensor_Name15;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name8;
        private System.Windows.Forms.Label label_Sensor_Name8;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name1;
        private System.Windows.Forms.Label label_Sensor_Name1;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name23;
        private System.Windows.Forms.Label label_Sensor_Name23;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name16;
        private System.Windows.Forms.Label label_Sensor_Name16;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name9;
        private System.Windows.Forms.Label label_Sensor_Name9;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name2;
        private System.Windows.Forms.Label label_Sensor_Name2;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name17;
        private System.Windows.Forms.Label label_Sensor_Name17;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name10;
        private System.Windows.Forms.Label label_Sensor_Name10;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name3;
        private System.Windows.Forms.Label label_Sensor_Name3;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name18;
        private System.Windows.Forms.Label label_Sensor_Name18;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name11;
        private System.Windows.Forms.Label label_Sensor_Name11;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name4;
        private System.Windows.Forms.Label label_Sensor_Name4;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name19;
        private System.Windows.Forms.Label label_Sensor_Name19;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name12;
        private System.Windows.Forms.Label label_Sensor_Name12;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name5;
        private System.Windows.Forms.Label label_Sensor_Name5;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name20;
        private System.Windows.Forms.Label label_Sensor_Name20;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name13;
        private System.Windows.Forms.Label label_Sensor_Name13;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name6;
        private System.Windows.Forms.Label label_Sensor_Name6;
        private System.Windows.Forms.GroupBox groupBox_Sensor_Name0;
        private System.Windows.Forms.Label label_Sensor_Name0;
        private System.IO.Ports.SerialPort serialPort2;
        private System.Windows.Forms.Label label_AlphFix_time;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox AlphFix_FileName_box;
        private System.Windows.Forms.GroupBox group_SHT0;
        private System.Windows.Forms.Label label_AH0;
        private System.Windows.Forms.Label label_RH0;
        private System.Windows.Forms.Label label_Temp0;
        private System.Windows.Forms.GroupBox group_SHT1;
        private System.Windows.Forms.Label label_AH1;
        private System.Windows.Forms.Label label_RH1;
        private System.Windows.Forms.Label label_Temp1;
        private System.Windows.Forms.GroupBox group_SHT2;
        private System.Windows.Forms.Label label_AH2;
        private System.Windows.Forms.Label label_RH2;
        private System.Windows.Forms.Label label_Temp2;
        private System.Windows.Forms.GroupBox group_SHT3;
        private System.Windows.Forms.Label label_AH3;
        private System.Windows.Forms.Label label_RH3;
        private System.Windows.Forms.Label label_Temp3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox Item_box;
        private System.Windows.Forms.NumericUpDown ID_box;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Value_box;
        private System.Windows.Forms.Button btn_AlphFix_write;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage_Zero;
        private System.Windows.Forms.GroupBox group_zero21;
        private System.Windows.Forms.Label label_Zero21;
        private System.Windows.Forms.GroupBox group_zero14;
        private System.Windows.Forms.Label label_Zero14;
        private System.Windows.Forms.GroupBox group_zero7;
        private System.Windows.Forms.Label label_Zero7;
        private System.Windows.Forms.GroupBox group_zero22;
        private System.Windows.Forms.Label label_Zero22;
        private System.Windows.Forms.GroupBox group_zero15;
        private System.Windows.Forms.Label label_Zero15;
        private System.Windows.Forms.GroupBox group_zero8;
        private System.Windows.Forms.Label label_Zero8;
        private System.Windows.Forms.GroupBox group_zero1;
        private System.Windows.Forms.Label label_Zero1;
        private System.Windows.Forms.GroupBox group_zero23;
        private System.Windows.Forms.Label label_Zero23;
        private System.Windows.Forms.GroupBox group_zero16;
        private System.Windows.Forms.Label label_Zero16;
        private System.Windows.Forms.GroupBox group_zero9;
        private System.Windows.Forms.Label label_Zero9;
        private System.Windows.Forms.GroupBox group_zero2;
        private System.Windows.Forms.Label label_Zero2;
        private System.Windows.Forms.GroupBox group_zero17;
        private System.Windows.Forms.Label label_Zero17;
        private System.Windows.Forms.GroupBox group_zero10;
        private System.Windows.Forms.Label label_Zero10;
        private System.Windows.Forms.GroupBox group_zero3;
        private System.Windows.Forms.Label label_Zero3;
        private System.Windows.Forms.GroupBox group_zero18;
        private System.Windows.Forms.Label label_Zero18;
        private System.Windows.Forms.GroupBox group_zero11;
        private System.Windows.Forms.Label label_Zero11;
        private System.Windows.Forms.GroupBox group_zero4;
        private System.Windows.Forms.Label label_Zero4;
        private System.Windows.Forms.GroupBox group_zero19;
        private System.Windows.Forms.Label label_Zero19;
        private System.Windows.Forms.GroupBox group_zero12;
        private System.Windows.Forms.Label label_Zero12;
        private System.Windows.Forms.GroupBox group_zero5;
        private System.Windows.Forms.Label label_Zero5;
        private System.Windows.Forms.GroupBox group_zero20;
        private System.Windows.Forms.Label label_Zero20;
        private System.Windows.Forms.GroupBox group_zero13;
        private System.Windows.Forms.Label label_Zero13;
        private System.Windows.Forms.GroupBox group_zero6;
        private System.Windows.Forms.Label label_Zero6;
        private System.Windows.Forms.GroupBox group_zero0;
        private System.Windows.Forms.Label label_Zero0;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.ComboBox AlphFix_Port_box;
        private System.Windows.Forms.Button btn_AlphFix_stopORstart;
        private System.Windows.Forms.Label label_AlphFix_State;
        private System.Windows.Forms.Button btn_AlphFix_Connect;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btn_Sabio_Connect;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel11;
        private System.Windows.Forms.ComboBox Sabio_UpdateRate_Box;
        private System.Windows.Forms.Button btn_CheckNow;
        private System.Windows.Forms.Button btn_PurgeLock;
        private System.Windows.Forms.Button btn_Purge;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel10;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox Addr_Box;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox Sequence_Box;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox Point_Box;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox Sabio_Time_Box;
        private System.Windows.Forms.Button btn_MS;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel8;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox FileName_Box;
        private System.Windows.Forms.Button btn_Sabio_cap;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.RichTextBox Sabio_Info_Box;
        private System.Windows.Forms.Button brn_InfoCln;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button btn_CmdStart;
        private System.Windows.Forms.Button btn_CmdStop;
        private System.Windows.Forms.Button btn_ClnList;
        private System.Windows.Forms.Label label_Sabio_State;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label6;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel18;
        private System.Windows.Forms.RichTextBox AlphFix_Info_box;
        private System.Windows.Forms.ComboBox AlphFix_UpdateRate_Box;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_test;
        private System.Windows.Forms.TextBox test_box;
        private System.Windows.Forms.TabPage Cal_Date;
        private System.Windows.Forms.TabPage a;
        private System.Windows.Forms.TabPage b;
        private System.Windows.Forms.Button btn_AlphFix_read;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label Update_LED;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel13;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Label label_Status8;
        private System.Windows.Forms.Label label_Status6;
        private System.Windows.Forms.Label label_Status4;
        private System.Windows.Forms.Label label_Status7;
        private System.Windows.Forms.Label label_Status5;
        private System.Windows.Forms.Label label_Status3;
        private System.Windows.Forms.Label label_Status1;
        private System.Windows.Forms.Label label_Status2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel12;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Label label_Measure4;
        private System.Windows.Forms.Label label_Measure2;
        private System.Windows.Forms.Label label_Measure3;
        private System.Windows.Forms.Label label_Measure1;
        private System.Windows.Forms.Label label_Measure5;
        private System.Windows.Forms.Label label_Measure6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.GroupBox group_Span23;
        private System.Windows.Forms.Label label_Span23;
        private System.Windows.Forms.GroupBox group_Span22;
        private System.Windows.Forms.Label label_Span22;
        private System.Windows.Forms.GroupBox group_Span0;
        private System.Windows.Forms.Label label_Span0;
        private System.Windows.Forms.GroupBox group_Span14;
        private System.Windows.Forms.Label label_Span14;
        private System.Windows.Forms.GroupBox group_Span15;
        private System.Windows.Forms.Label label_Span15;
        private System.Windows.Forms.GroupBox group_Span20;
        private System.Windows.Forms.Label label_Span20;
        private System.Windows.Forms.GroupBox group_Span19;
        private System.Windows.Forms.Label label_Span19;
        private System.Windows.Forms.GroupBox group_Span18;
        private System.Windows.Forms.Label label_Span18;
        private System.Windows.Forms.GroupBox group_Span17;
        private System.Windows.Forms.Label label_Span17;
        private System.Windows.Forms.GroupBox group_Span16;
        private System.Windows.Forms.Label label_Span16;
        private System.Windows.Forms.GroupBox group_Span1;
        private System.Windows.Forms.Label label_Span1;
        private System.Windows.Forms.GroupBox group_Span7;
        private System.Windows.Forms.Label label_Span7;
        private System.Windows.Forms.GroupBox group_Span2;
        private System.Windows.Forms.Label label_Span2;
        private System.Windows.Forms.GroupBox group_Span8;
        private System.Windows.Forms.Label label_Span8;
        private System.Windows.Forms.GroupBox group_Span3;
        private System.Windows.Forms.Label label_Span3;
        private System.Windows.Forms.GroupBox group_Span9;
        private System.Windows.Forms.Label label_Span9;
        private System.Windows.Forms.GroupBox group_Span10;
        private System.Windows.Forms.Label label_Span10;
        private System.Windows.Forms.GroupBox group_Span11;
        private System.Windows.Forms.Label label_Span11;
        private System.Windows.Forms.GroupBox group_Span12;
        private System.Windows.Forms.Label label_Span12;
        private System.Windows.Forms.GroupBox group_Span13;
        private System.Windows.Forms.Label label_Span13;
        private System.Windows.Forms.GroupBox group_Span4;
        private System.Windows.Forms.Label label_Span4;
        private System.Windows.Forms.GroupBox group_Span5;
        private System.Windows.Forms.Label label_Span5;
        private System.Windows.Forms.GroupBox group_Span6;
        private System.Windows.Forms.Label label_Span6;
        private System.Windows.Forms.GroupBox group_Span21;
        private System.Windows.Forms.Label label_Span21;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.GroupBox group_CalDate23;
        private System.Windows.Forms.Label label_CalDate23;
        private System.Windows.Forms.GroupBox group_CalDate22;
        private System.Windows.Forms.Label label_CalDate22;
        private System.Windows.Forms.GroupBox group_CalDate0;
        private System.Windows.Forms.Label label_CalDate0;
        private System.Windows.Forms.GroupBox group_CalDate14;
        private System.Windows.Forms.Label label_CalDate14;
        private System.Windows.Forms.GroupBox group_CalDate15;
        private System.Windows.Forms.Label label_CalDate15;
        private System.Windows.Forms.GroupBox group_CalDate20;
        private System.Windows.Forms.Label label_CalDate20;
        private System.Windows.Forms.GroupBox group_CalDate19;
        private System.Windows.Forms.Label label_CalDate19;
        private System.Windows.Forms.GroupBox group_CalDate18;
        private System.Windows.Forms.Label label_CalDate18;
        private System.Windows.Forms.GroupBox group_CalDate17;
        private System.Windows.Forms.Label label_CalDate17;
        private System.Windows.Forms.GroupBox group_CalDate16;
        private System.Windows.Forms.Label label_CalDate16;
        private System.Windows.Forms.GroupBox group_CalDate1;
        private System.Windows.Forms.Label label_CalDate1;
        private System.Windows.Forms.GroupBox group_CalDate7;
        private System.Windows.Forms.Label label_CalDate7;
        private System.Windows.Forms.GroupBox group_CalDate2;
        private System.Windows.Forms.Label label_CalDate2;
        private System.Windows.Forms.GroupBox group_CalDate8;
        private System.Windows.Forms.Label label_CalDate8;
        private System.Windows.Forms.GroupBox group_CalDate3;
        private System.Windows.Forms.Label label_CalDate3;
        private System.Windows.Forms.GroupBox group_CalDate9;
        private System.Windows.Forms.Label label_CalDate9;
        private System.Windows.Forms.GroupBox group_CalDate10;
        private System.Windows.Forms.Label label_CalDate10;
        private System.Windows.Forms.GroupBox group_CalDate11;
        private System.Windows.Forms.Label label_CalDate11;
        private System.Windows.Forms.GroupBox group_CalDate12;
        private System.Windows.Forms.Label label_CalDate12;
        private System.Windows.Forms.GroupBox group_CalDate13;
        private System.Windows.Forms.Label label_CalDate13;
        private System.Windows.Forms.GroupBox group_CalDate4;
        private System.Windows.Forms.Label label_CalDate4;
        private System.Windows.Forms.GroupBox group_CalDate5;
        private System.Windows.Forms.Label label_CalDate5;
        private System.Windows.Forms.GroupBox group_CalDate6;
        private System.Windows.Forms.Label label_CalDate6;
        private System.Windows.Forms.GroupBox group_CalDate21;
        private System.Windows.Forms.Label label_CalDate21;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.GroupBox group_A23;
        private System.Windows.Forms.Label label_A23;
        private System.Windows.Forms.GroupBox group_A22;
        private System.Windows.Forms.Label label_A22;
        private System.Windows.Forms.GroupBox group_A0;
        private System.Windows.Forms.Label label_A0;
        private System.Windows.Forms.GroupBox group_A14;
        private System.Windows.Forms.Label label_A14;
        private System.Windows.Forms.GroupBox group_A15;
        private System.Windows.Forms.Label label_A15;
        private System.Windows.Forms.GroupBox group_A20;
        private System.Windows.Forms.Label label_A20;
        private System.Windows.Forms.GroupBox group_A19;
        private System.Windows.Forms.Label label_A19;
        private System.Windows.Forms.GroupBox group_A18;
        private System.Windows.Forms.Label label_A18;
        private System.Windows.Forms.GroupBox group_A17;
        private System.Windows.Forms.Label label_A17;
        private System.Windows.Forms.GroupBox group_A16;
        private System.Windows.Forms.Label label_A16;
        private System.Windows.Forms.GroupBox group_A1;
        private System.Windows.Forms.Label label_A1;
        private System.Windows.Forms.GroupBox group_A7;
        private System.Windows.Forms.Label label_A7;
        private System.Windows.Forms.GroupBox group_A2;
        private System.Windows.Forms.Label label_A2;
        private System.Windows.Forms.GroupBox group_A8;
        private System.Windows.Forms.Label label_A8;
        private System.Windows.Forms.GroupBox group_A3;
        private System.Windows.Forms.Label label_A3;
        private System.Windows.Forms.GroupBox group_A9;
        private System.Windows.Forms.Label label_A9;
        private System.Windows.Forms.GroupBox group_A10;
        private System.Windows.Forms.Label label_A10;
        private System.Windows.Forms.GroupBox group_A11;
        private System.Windows.Forms.Label label_A11;
        private System.Windows.Forms.GroupBox group_A12;
        private System.Windows.Forms.Label label_A12;
        private System.Windows.Forms.GroupBox group_A13;
        private System.Windows.Forms.Label label_A13;
        private System.Windows.Forms.GroupBox group_A4;
        private System.Windows.Forms.Label label_A4;
        private System.Windows.Forms.GroupBox group_A5;
        private System.Windows.Forms.Label label_A5;
        private System.Windows.Forms.GroupBox group_A6;
        private System.Windows.Forms.Label label_A6;
        private System.Windows.Forms.GroupBox group_A21;
        private System.Windows.Forms.Label label_A21;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.GroupBox group_B23;
        private System.Windows.Forms.Label label_B23;
        private System.Windows.Forms.GroupBox group_B22;
        private System.Windows.Forms.Label label_B22;
        private System.Windows.Forms.GroupBox group_B0;
        private System.Windows.Forms.Label label_B0;
        private System.Windows.Forms.GroupBox group_B14;
        private System.Windows.Forms.Label label_B14;
        private System.Windows.Forms.GroupBox group_B15;
        private System.Windows.Forms.Label label_B15;
        private System.Windows.Forms.GroupBox group_B20;
        private System.Windows.Forms.Label label_B20;
        private System.Windows.Forms.GroupBox group_B19;
        private System.Windows.Forms.Label label_B19;
        private System.Windows.Forms.GroupBox group_B18;
        private System.Windows.Forms.Label label_B18;
        private System.Windows.Forms.GroupBox group_B17;
        private System.Windows.Forms.Label label_B17;
        private System.Windows.Forms.GroupBox group_B16;
        private System.Windows.Forms.Label label_B16;
        private System.Windows.Forms.GroupBox group_B1;
        private System.Windows.Forms.Label label_B1;
        private System.Windows.Forms.GroupBox group_B7;
        private System.Windows.Forms.Label label_B7;
        private System.Windows.Forms.GroupBox group_B2;
        private System.Windows.Forms.Label label_B2;
        private System.Windows.Forms.GroupBox group_B8;
        private System.Windows.Forms.Label label_B8;
        private System.Windows.Forms.GroupBox group_B3;
        private System.Windows.Forms.Label label_B3;
        private System.Windows.Forms.GroupBox group_B9;
        private System.Windows.Forms.Label label_B9;
        private System.Windows.Forms.GroupBox group_B10;
        private System.Windows.Forms.Label label_B10;
        private System.Windows.Forms.GroupBox group_B11;
        private System.Windows.Forms.Label label_B11;
        private System.Windows.Forms.GroupBox group_B12;
        private System.Windows.Forms.Label label_B12;
        private System.Windows.Forms.GroupBox group_B13;
        private System.Windows.Forms.Label label_B13;
        private System.Windows.Forms.GroupBox group_B4;
        private System.Windows.Forms.Label label_B4;
        private System.Windows.Forms.GroupBox group_B5;
        private System.Windows.Forms.Label label_B5;
        private System.Windows.Forms.GroupBox group_B6;
        private System.Windows.Forms.Label label_B6;
        private System.Windows.Forms.GroupBox group_B21;
        private System.Windows.Forms.Label label_B21;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox Sabio_Port_box;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox Sabio_Baud_box;
        private System.Windows.Forms.Label label_Sabio_time;
        private System.Windows.Forms.Button btn_Zero_MS;
        private System.Windows.Forms.Button btn_Span_MS;
        private System.Windows.Forms.Button btn_InitALL;
        private System.Windows.Forms.Timer timer_alcap;
    }
}

